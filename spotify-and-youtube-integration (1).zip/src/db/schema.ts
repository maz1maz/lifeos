import {
  index,
  integer,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { pgTable } from "drizzle-orm/pg-core";

/** OAuth credentials for a connected provider (spotify | youtube). */
export const connections = pgTable("connections", {
  id: serial("id").primaryKey(),
  provider: text("provider").notNull().unique(),
  accessToken: text("access_token"),
  refreshToken: text("refresh_token"),
  expiresAt: timestamp("expires_at"),
  scopes: text("scopes"),
  accountLabel: text("account_label"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

/** Every play / watch event, logged into the LifeOS history. */
export const plays = pgTable(
  "plays",
  {
    id: serial("id").primaryKey(),
    provider: text("provider").notNull(),
    kind: text("kind").notNull(),
    externalId: text("external_id").notNull(),
    title: text("title").notNull(),
    subtitle: text("subtitle"),
    artwork: text("artwork"),
    durationMs: integer("duration_ms"),
    msPlayed: integer("ms_played"),
    views: integer("views"),
    context: text("context"),
    origin: text("origin").notNull().default("demo"),
    playedAt: timestamp("played_at").defaultNow().notNull(),
  },
  (t) => [index("plays_played_at_idx").on(t.playedAt)],
);

/** Items pinned to the LifeOS shelf ("ثبت در LifeOS"). */
export const saved = pgTable(
  "saved",
  {
    id: serial("id").primaryKey(),
    provider: text("provider").notNull(),
    kind: text("kind").notNull(),
    externalId: text("external_id").notNull(),
    title: text("title").notNull(),
    subtitle: text("subtitle"),
    artwork: text("artwork"),
    note: text("note"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => [uniqueIndex("saved_item_uidx").on(t.provider, t.externalId)],
);

/** Small system log that drives the status strip. */
export const syncLog = pgTable("sync_log", {
  id: serial("id").primaryKey(),
  level: text("level").notNull().default("info"),
  message: text("message").notNull(),
  provider: text("provider"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
