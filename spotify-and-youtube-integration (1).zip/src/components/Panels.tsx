"use client";

import type { ReactNode } from "react";
import Plate from "@/components/Plate";
import { clock, fa, group, relativeTime } from "@/lib/format";
import type { MediaItem } from "@/lib/catalog";

export function Panel({
  code,
  title,
  hint,
  children,
  className,
  tone = "default",
}: {
  code: string;
  title: string;
  hint?: string;
  children: ReactNode;
  className?: string;
  tone?: "default" | "amber";
}) {
  return (
    <section className={`panel ${className ?? ""}`}>
      <span className="screw screw-tl" aria-hidden="true" />
      <span className="screw screw-tr" aria-hidden="true" />
      <header className="flex flex-wrap items-baseline justify-between gap-2 border-b border-etch/70 px-5 py-3">
        <div className="flex items-baseline gap-3">
          <span className={`label ${tone === "amber" ? "text-amber" : "text-signal"}`}>{code}</span>
          <h2 className="text-[20px] font-extrabold tracking-tight text-cream">{title}</h2>
        </div>
        {hint ? <p className="font-mono text-[11px] text-mute">{hint}</p> : null}
      </header>
      <div className="px-2 py-2 sm:px-3">{children}</div>
    </section>
  );
}

export function ItemRow({
  item,
  index,
  onPlay,
  onSave,
  saved,
  reason,
  active,
}: {
  item: MediaItem;
  index?: number;
  onPlay: (item: MediaItem) => void;
  onSave: (item: MediaItem) => void;
  saved: boolean;
  reason?: string;
  active?: boolean;
}) {
  return (
    <li
      className={`row ${active ? "row-active" : ""}`}
    >
      <div className="flex min-w-0 flex-1 items-center gap-3 px-3 py-3">
        <Plate title={item.title} subtitle={item.subtitle} artwork={item.artwork} size={52} />
        <div className="min-w-0 flex-1">
          {reason ? (
            <p className="mb-1 font-mono text-[10.5px] uppercase tracking-[0.14em] text-amber">{reason}</p>
          ) : null}
          <h3 className="truncate text-[16px] font-bold leading-tight text-cream">{item.title}</h3>
          <p className="truncate font-mono text-[11.5px] text-mute">
            {[item.subtitle, item.detail].filter(Boolean).join("  ·  ")}
          </p>
          <p className="tnum mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 font-mono text-[10.5px] text-mute/80">
            {item.views ? <span className="text-amber">{group(item.views)} بازدید</span> : null}
            {item.durationMs ? <span>{clock(item.durationMs)}</span> : null}
            {item.playedAt ? <span>{relativeTime(item.playedAt)}</span> : null}
            {item.context ? <span className="opacity-80">{item.context}</span> : null}
          </p>
        </div>
      </div>
      <div className="flex shrink-0 flex-col justify-center gap-1.5 border-r border-etch/50 px-3 py-2 sm:flex-row sm:items-center">
        <button type="button" onClick={() => onPlay(item)} className="btn-plate btn-plate-lg">
          پخش
        </button>
        <button
          type="button"
          onClick={() => onSave(item)}
          className={`btn-plate ${saved ? "btn-plate-on" : ""}`}
          aria-pressed={saved}
        >
          {saved ? "ثبت شد" : "ثبت در LifeOS"}
        </button>
        {index !== undefined ? (
          <span className="tnum label hidden opacity-50 sm:block">{fa(String(index).padStart(2, "0"))}</span>
        ) : null}
      </div>
    </li>
  );
}

export function Empty({ title, hint, image }: { title: string; hint: string; image?: string }) {
  return (
    <div className="relative overflow-hidden rounded-[3px] border border-dashed border-etch/70 m-2">
      {image ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={image}
          alt=""
          aria-hidden="true"
          className="absolute inset-0 h-full w-full object-cover opacity-25 [mask-image:linear-gradient(to_left,black,transparent)]"
        />
      ) : null}
      <div className="relative px-6 py-10 text-center">
        <p className="text-[18px] font-extrabold text-cream">{title}</p>
        <p className="mt-1 font-mono text-[11.5px] text-mute">{hint}</p>
      </div>
    </div>
  );
}

export function StatBlock({
  value,
  label,
  sub,
  tone = "cream",
}: {
  value: string;
  label: string;
  sub?: string;
  tone?: "cream" | "amber" | "signal";
}) {
  const color =
    tone === "amber" ? "text-amber" : tone === "signal" ? "text-signal" : "text-cream";
  return (
    <div className="border-l border-etch/60 px-5 py-4 last:border-l-0">
      <p className="label mb-1">{label}</p>
      <p className={`tnum text-[34px] font-extrabold leading-none tracking-tight ${color}`}>{value}</p>
      {sub ? <p className="mt-1.5 font-mono text-[11px] text-mute">{sub}</p> : null}
    </div>
  );
}

export function HourHistogram({ data }: { data: number[] }) {
  const max = Math.max(...data, 1);
  return (
    <div className="flex h-24 items-end gap-[3px] px-5 pb-4">
      {data.map((v, i) => (
        <div key={i} className="group relative flex-1">
          <div
            className="w-full rounded-[1px] bg-gradient-to-t from-etch/50 to-signal/70 transition-all duration-500 group-hover:to-amber"
            style={{ height: `${Math.max(3, (v / max) * 88)}px` }}
          />
          {i % 6 === 0 ? (
            <span className="tnum absolute -bottom-4 right-0 font-mono text-[9px] text-mute">{fa(i)}</span>
          ) : null}
        </div>
      ))}
    </div>
  );
}
