"use client";

import { useEffect, useRef, useState } from "react";
import Plate from "@/components/Plate";
import { clock, fa, group } from "@/lib/format";
import type { MediaItem } from "@/lib/catalog";

type Props = {
  item: MediaItem | null;
  live: boolean;
  onLog: (item: MediaItem, msPlayed: number) => void;
  onSave: (item: MediaItem) => void;
  saved: boolean;
  onNotify: (level: "ok" | "info" | "error", message: string) => void;
};

function Reel({ size = 54, spin, reverse }: { size?: number; spin: boolean; reverse?: boolean }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 60 60"
      aria-hidden="true"
      className={spin ? (reverse ? "reel reel-spin-rev" : "reel reel-spin") : "reel"}
    >
      <circle cx="30" cy="30" r="28" fill="#0A1A25" stroke="#37596D" strokeWidth="1.2" />
      <circle cx="30" cy="30" r="23" fill="none" stroke="#2A4A5C" strokeWidth="1" />
      <g fill="#173243" stroke="#4B728A" strokeWidth="0.8">
        <path d="M30 10c3.4 0 6.5 1.6 8.4 4.2L30 26l-8.4-11.8A10.5 10.5 0 0 1 30 10Z" />
        <path d="M47.3 40a10.5 10.5 0 0 1-11.6 4.9L38 31.6l11-2.9A10.5 10.5 0 0 1 47.3 40Z" />
        <path d="M12.7 40a10.5 10.5 0 0 0 1.7 12.1A10.5 10.5 0 0 0 26 44.9l-2.3-13.3-11 2.9Z" />
      </g>
      <circle cx="30" cy="30" r="7" fill="#0A1A25" stroke="#E8A33D" strokeWidth="1" />
      <circle cx="30" cy="30" r="2.4" fill="#E8A33D" opacity="0.85" />
    </svg>
  );
}

function VuMeter({ active }: { active: boolean }) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = 132;
    const h = 52;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    ctx.scale(dpr, dpr);

    let raf = 0;
    let level = 0;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    const draw = (t: number) => {
      const target = active
        ? 0.42 +
          0.3 * Math.abs(Math.sin(t / 420)) +
          0.22 * Math.abs(Math.sin(t / 137)) +
          0.08 * Math.random()
        : 0.03;
      level += (Math.min(target, 1) - level) * (active ? 0.18 : 0.06);

      ctx.clearRect(0, 0, w, h);
      // صفحه‌ی متر
      ctx.fillStyle = "#0A1A25";
      ctx.fillRect(0, 0, w, h);
      ctx.strokeStyle = "rgba(232,163,61,0.18)";
      ctx.lineWidth = 1;
      ctx.strokeRect(0.5, 0.5, w - 1, h - 1);

      // کمانِ مقیاس
      const cx = w / 2;
      const cy = h + 8;
      const r = 44;
      ctx.beginPath();
      ctx.arc(cx, cy, r, Math.PI * 1.15, Math.PI * 1.85);
      ctx.strokeStyle = "rgba(237,228,210,0.35)";
      ctx.lineWidth = 1;
      ctx.stroke();

      // ناحیه‌ی قرمز (بالای ۸۰٪)
      ctx.beginPath();
      ctx.arc(cx, cy, r, Math.PI * 1.72, Math.PI * 1.85);
      ctx.strokeStyle = "rgba(232,90,61,0.85)";
      ctx.lineWidth = 2;
      ctx.stroke();

      // خط‌کش
      for (let i = 0; i <= 8; i++) {
        const a = Math.PI * (1.15 + (0.7 * i) / 8);
        const x1 = cx + Math.cos(a) * (r - 5);
        const y1 = cy + Math.sin(a) * (r - 5);
        const x2 = cx + Math.cos(a) * r;
        const y2 = cy + Math.sin(a) * r;
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.strokeStyle = i > 6 ? "rgba(232,90,61,0.7)" : "rgba(143,168,182,0.55)";
        ctx.lineWidth = 1;
        ctx.stroke();
      }

      // عقربه
      const ang = Math.PI * (1.15 + 0.7 * level);
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + Math.cos(ang) * (r - 3), cy + Math.sin(ang) * (r - 3));
      ctx.strokeStyle = "#E8A33D";
      ctx.lineWidth = 1.6;
      ctx.stroke();

      ctx.font = "600 8px var(--font-plex), ui-monospace, monospace";
      ctx.fillStyle = "rgba(237,228,210,0.5)";
      ctx.fillText("VU", w / 2 - 6, h - 6);

      if (!reduce) raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [active]);

  return (
    <canvas
      ref={ref}
      aria-hidden="true"
      style={{ width: 132, height: 52 }}
      className="rounded-[2px] ring-1 ring-etch/70"
    />
  );
}

function loadYouTubeApi(): Promise<any> {
  const w = window as any;
  if (w.YT?.Player) return Promise.resolve(w.YT);
  if (w.__loYtPromise) return w.__loYtPromise;
  w.__loYtPromise = new Promise((resolve, reject) => {
    const timer = window.setTimeout(() => reject(new Error("yt timeout")), 6000);
    const prev = w.onYouTubeIframeAPIReady;
    w.onYouTubeIframeAPIReady = () => {
      window.clearTimeout(timer);
      if (typeof prev === "function") prev();
      resolve(w.YT);
    };
    const s = document.createElement("script");
    s.src = "https://www.youtube.com/iframe_api";
    s.async = true;
    s.onerror = () => {
      window.clearTimeout(timer);
      reject(new Error("yt load failed"));
    };
    document.head.appendChild(s);
  });
  return w.__loYtPromise;
}

export default function Transport({
  item,
  live,
  onLog,
  onSave,
  saved,
  onNotify,
}: Props) {
  const [playing, setPlaying] = useState(false);
  const [position, setPosition] = useState(0);
  const [fallback, setFallback] = useState(false);
  const [liveDuration, setLiveDuration] = useState(0);
  const playerRef = useRef<any>(null);
  const hostRef = useRef<HTMLDivElement | null>(null);
  const lastLen = useRef(0);
  const duration = liveDuration || item?.durationMs || 210_000;

  const isRealVideo =
    Boolean(item) &&
    live &&
    item!.provider === "youtube" &&
    item!.kind === "video" &&
    !item!.externalId.startsWith("demo");

  const isRealSpotify =
    Boolean(item) &&
    live &&
    item!.provider === "spotify" &&
    !item!.externalId.startsWith("demo");

  /* ثبتِ پخش در تاریخچه‌ی LifeOS + روشن‌شدنِ دستگاه */
  useEffect(() => {
    if (!item) return;
    setPosition(0);
    setPlaying(true);
    onLog(item, 0);
    onNotify("ok", `در تاریخچه‌ی LifeOS ثبت شد: ${item.title}`);
    return () => {
      setPlaying(false);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [item?.id]);

  /* پخشِ واقعیِ YouTube */
  useEffect(() => {
    if (!isRealVideo || fallback) return;
    let cancelled = false;
    setFallback(false);
    loadYouTubeApi()
      .then((YT: any) => {
        if (cancelled || !hostRef.current) return;
        playerRef.current = new YT.Player(hostRef.current, {
          videoId: item!.externalId,
          width: "260",
          height: "146",
          playerVars: { rel: 0, modestbranding: 1, playsinline: 1 },
          events: {
            onReady: (e: any) => {
              e.target.playVideo();
              const d = e.target.getDuration?.();
              if (d) setPosition(0);
            },
            onStateChange: (e: any) => setPlaying(e.data === 1),
          },
        });
      })
      .catch(() => {
        if (!cancelled) setFallback(true);
      });
    return () => {
      cancelled = true;
      try {
        playerRef.current?.destroy?.();
      } catch {
        /* ignore */
      }
      playerRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [item?.id, isRealVideo]);

  /* ساعتِ شبیه‌سازی برای حالت نمایشی و Spotify */
  useEffect(() => {
    if (!item || !playing || isRealVideo) return;
    const id = window.setInterval(() => {
      setPosition((p) => {
        if (p + 250 >= duration) {
          window.clearInterval(id);
          setPlaying(false);
          return duration;
        }
        return p + 250;
      });
    }, 250);
    return () => window.clearInterval(id);
  }, [item, playing, duration, isRealVideo]);

  /* شمارنده‌ی واقعی برای YouTube */
  useEffect(() => {
    if (!isRealVideo || !playing) return;
    const id = window.setInterval(() => {
      const p = playerRef.current;
      if (!p?.getCurrentTime) return;
      setPosition(p.getCurrentTime() * 1000);
      const d = (p.getDuration?.() ?? 0) * 1000;
      if (d && d !== lastLen.current) {
        lastLen.current = d;
        setLiveDuration(d);
      }
    }, 500);
    return () => window.clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isRealVideo, playing]);

  const toggle = () => {
    if (!item) return;
    if (isRealVideo && playerRef.current?.playVideo) {
      if (playing) playerRef.current.pauseVideo();
      else playerRef.current.playVideo();
      return;
    }
    setPlaying((p) => !p);
  };

  const seek = (value: number) => {
    if (isRealVideo && playerRef.current?.seekTo) {
      playerRef.current.seekTo(value / 1000, true);
    }
    setPosition(value);
  };

  const total = duration;
  const pct = total ? Math.min(100, (position / total) * 100) : 0;

  return (
    <div className="transport">
      <div className="transport-grain" aria-hidden="true" />
      <div className="mx-auto flex w-full max-w-[1440px] flex-wrap items-center gap-4 px-4 py-3 sm:gap-6 lg:px-8">
        {/* خلیجِ پخش: قرقره‌ها یا صفحه‌ی ویدیو */}
        <div className="flex items-center gap-3">
          {isRealVideo ? (
            <div
              ref={hostRef}
              className="hidden overflow-hidden rounded-[3px] ring-1 ring-etch sm:block"
              style={{ width: 260, height: 146 }}
            />
          ) : (
            <div className="relative hidden items-center gap-2 sm:flex">
              <Reel spin={playing} />
              <div className="h-[3px] w-8 rounded-full bg-[#2A4A5C]" />
              <Reel spin={playing} reverse />
            </div>
          )}
          {isRealSpotify && item ? (
            <iframe
              key={item.externalId}
              title="Spotify player"
              src={`https://open.spotify.com/embed/track/${item.externalId}?utm_source=generator&theme=0`}
              width="220"
              height="152"
              className="hidden rounded-[3px] ring-1 ring-etch xl:block"
              allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
              loading="lazy"
            />
          ) : null}
        </div>

        {/* عنوان و نوارِ پیشرفت */}
        <div className="min-w-[220px] flex-1">
          <div className="flex items-baseline gap-2">
            <span className="label">{item ? (item.provider === "spotify" ? "SPOTIFY" : "YOUTUBE") : "STANDBY"}</span>
            <span className="label opacity-60">{item ? (item.kind === "video" ? "VIDEO" : "TRACK") : "NO SIGNAL"}</span>
          </div>
          <h3 className="truncate text-[17px] font-extrabold tracking-tight text-cream">
            {item ? item.title : "دستگاه آماده‌به‌کار است"}
          </h3>
          <p className="truncate font-mono text-[11px] text-mute">
            {item ? [item.subtitle, item.detail].filter(Boolean).join("  ·  ") : "یک قطعه را برای پخش انتخاب کنید"}
          </p>

          <div className="mt-2 flex items-center gap-3">
            <span className="tnum font-mono text-[12px] text-signal">{clock(position)}</span>
            <input
              type="range"
              min={0}
              max={Math.max(total, 1000)}
              value={Math.min(position, total)}
              onChange={(e) => seek(Number(e.target.value))}
              aria-label="محلِ پخش"
              className="scrub h-[3px] flex-1 cursor-pointer appearance-none rounded-full"
              style={{ background: `linear-gradient(to left, #34D3EE ${pct}%, #24485C ${pct}%)` }}
            />
            <span className="tnum font-mono text-[12px] text-mute">{clock(total)}</span>
          </div>
        </div>

        {/* کنترل‌ها و متر */}
        <div className="flex items-center gap-3">
          <VuMeter active={playing} />
          <button
            type="button"
            onClick={toggle}
            disabled={!item}
            className="grid h-14 w-14 place-items-center rounded-full border border-signal/70 bg-signal/10 text-signal transition hover:bg-signal/20 focus:outline-none focus-visible:ring-2 focus-visible:ring-signal disabled:opacity-40"
            aria-label={playing ? "توقف" : "پخش"}
          >
            {playing ? (
              <svg width="18" height="18" viewBox="0 0 18 18" aria-hidden="true">
                <rect x="3" y="2" width="4" height="14" fill="currentColor" />
                <rect x="11" y="2" width="4" height="14" fill="currentColor" />
              </svg>
            ) : (
              <svg width="18" height="18" viewBox="0 0 18 18" aria-hidden="true">
                <path d="M4 2 16 9 4 16V2Z" fill="currentColor" />
              </svg>
            )}
          </button>
          <div className="flex flex-col gap-1">
            <button
              type="button"
              onClick={() => item && onSave(item)}
              disabled={!item}
              className={`btn-plate ${saved ? "btn-plate-on" : ""}`}
            >
              {saved ? "در LifeOS ثبت شد" : "ثبت در LifeOS"}
            </button>
            <span className="tnum label text-center opacity-70">
              {item?.views ? `${group(item.views)} بازدید` : fa(Math.round(pct)) + "٪"}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
