type Props = {
  size?: number;
  className?: string;
  title?: string;
};

/**
 * نشانِ میزِ رسانه: قرقره‌ی نوار که مرکزش مثلثِ پخش است.
 * برداری و تک‌رنگ — در ۱۶px هم خوانا می‌ماند.
 */
export default function Mark({ size = 40, className, title = "میزِ رسانه" }: Props) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      role="img"
      aria-label={title}
      className={className}
    >
      <defs>
        <clipPath id="markHub">
          <circle cx="24" cy="24" r="9.5" />
        </clipPath>
      </defs>
      {/* بدنه‌ی بیرونی قرقره */}
      <circle cx="24" cy="24" r="21" fill="none" stroke="currentColor" strokeWidth="2.2" />
      <circle cx="24" cy="24" r="16.4" fill="none" stroke="currentColor" strokeWidth="1" opacity="0.45" />
      {/* سه پره‌ی قرقره */}
      <path
        d="M24 8.6c2.1 0 4 .9 5.3 2.4l-5.3 8.2-5.3-8.2A7.3 7.3 0 0 1 24 8.6Z"
        fill="currentColor"
        opacity="0.9"
      />
      <path
        d="M37.3 32.2a7.3 7.3 0 0 1-8.1 3.4l2.3-9.3 8.2-2.1a7.3 7.3 0 0 1-2.4 8Z"
        fill="currentColor"
        opacity="0.9"
      />
      <path
        d="M10.7 32.2a7.3 7.3 0 0 0 2.4 8 7.3 7.3 0 0 0 8.1-3.4l-2.3-9.3-8.2 2.1Z"
        fill="currentColor"
        opacity="0.9"
      />
      {/* مرکز: مثلثِ پخش */}
      <g clipPath="url(#markHub)">
        <path d="M20.4 18.6 31 24l-10.6 5.4V18.6Z" fill="currentColor" />
      </g>
    </svg>
  );
}
