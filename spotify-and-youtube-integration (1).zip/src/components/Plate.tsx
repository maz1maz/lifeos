import { initials } from "@/lib/format";

type Props = {
  title: string;
  subtitle?: string | null;
  artwork?: string | null;
  size?: number;
  className?: string;
};

function hash(input: string) {
  let h = 0;
  for (let i = 0; i < input.length; i++) h = (h * 31 + input.charCodeAt(i)) | 0;
  return Math.abs(h);
}

/**
 * پلاکِ آلبوم: وقتی کاور واقعی در دسترس نیست، یک «جِی‌کارتِ» برداری
 * با شیارهای صفحه می‌سازیم؛ نه تصویرِ جای‌خالی.
 */
export default function Plate({
  title,
  subtitle,
  artwork,
  size = 56,
  className,
}: Props) {
  if (artwork) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={artwork}
        alt={title}
        width={size}
        height={size}
        loading="lazy"
        className={`shrink-0 rounded-[3px] object-cover ring-1 ring-etch/80 ${className ?? ""}`}
        style={{ width: size, height: size }}
      />
    );
  }

  const h = hash(title + (subtitle ?? ""));
  const tilt = (h % 7) - 3;
  const gid = `pg-${h % 100000}`;
  const dark = "#0B1B27";
  const light = h % 2 === 0 ? "#1D4256" : "#233C4A";
  const accent = h % 3 === 0 ? "#E8A33D" : "#34D3EE";

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 56 56"
      aria-hidden="true"
      className={`shrink-0 rounded-[3px] ring-1 ring-etch/80 ${className ?? ""}`}
    >
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={light} />
          <stop offset="100%" stopColor={dark} />
        </linearGradient>
      </defs>
      <rect width="56" height="56" fill={`url(#${gid})`} />
      <g transform={`rotate(${tilt} 28 28)`} opacity="0.5">
        <circle cx="28" cy="28" r="20" fill="none" stroke="#EDE4D2" strokeWidth="0.4" opacity="0.35" />
        <circle cx="28" cy="28" r="15.5" fill="none" stroke="#EDE4D2" strokeWidth="0.4" opacity="0.3" />
        <circle cx="28" cy="28" r="11" fill="none" stroke="#EDE4D2" strokeWidth="0.4" opacity="0.25" />
        <circle cx="28" cy="28" r="3.2" fill={dark} stroke={accent} strokeWidth="0.8" />
      </g>
      <text
        x="6"
        y="49"
        fill="#EDE4D2"
        opacity="0.92"
        fontSize="18"
        fontFamily="var(--font-vazir), serif"
        fontWeight="800"
      >
        {initials(title)}
      </text>
    </svg>
  );
}
