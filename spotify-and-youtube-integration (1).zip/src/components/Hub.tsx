"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Transport from "@/components/Transport";
import Mark from "@/components/Mark";
import {
  Empty,
  HourHistogram,
  ItemRow,
  Panel,
  StatBlock,
} from "@/components/Panels";
import { fa, group, stamp } from "@/lib/format";
import type { MediaItem, Provider } from "@/lib/catalog";

export type ConnState = {
  provider: Provider;
  connected: boolean;
  configured: boolean;
  label: string | null;
};

export type SuggestionDto = { id: string; reason: string; item: MediaItem };
export type LogLine = {
  level: string;
  message: string;
  provider: string | null;
  createdAt: string;
};

type Stats = {
  plays30d: number;
  minutes30d: number;
  videos30d: number;
  totalViews: number;
  topArtist: string;
  topShare: number;
  streak: number;
  byHour: number[];
  live?: boolean;
};

type Notice = { level: "ok" | "info" | "error"; message: string };

const PROVIDER_META: Record<Provider, { name: string; code: string; blurb: string }> = {
  spotify: {
    name: "Spotify",
    code: "UNIT 01 · AUDIO",
    blurb: "اتصال و داده‌های امن حساب",
  },
  youtube: {
    name: "YouTube",
    code: "UNIT 02 · VIDEO",
    blurb: "اتصال و داده‌های امن حساب",
  },
};

export default function Hub({
  initial,
  notice,
}: {
  initial: {
    recent: MediaItem[];
    playlists: MediaItem[];
    saved: MediaItem[];
    savedKeys: string[];
    stats: Stats;
    suggestions: SuggestionDto[];
    log: LogLine[];
    connections: Record<Provider, ConnState>;
  };
  notice: Notice | null;
}) {
  const [provider, setProvider] = useState<Provider>("spotify");
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<MediaItem[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [recent, setRecent] = useState<MediaItem[]>(initial.recent);
  const [playlists, setPlaylists] = useState<MediaItem[]>(initial.playlists);
  const [savedKeys, setSavedKeys] = useState<string[]>(initial.savedKeys);
  const [shelf, setShelf] = useState<MediaItem[]>(initial.saved);
  const [log, setLog] = useState<LogLine[]>(initial.log);
  const [noticeState, setNoticeState] = useState<Notice | null>(notice);
  const [current, setCurrent] = useState<MediaItem | null>(null);
  const [conn, setConn] = useState(initial.connections);
  const [detail, setDetail] = useState<string | null>(null);
  const noticeId = useRef(0);

  const meta = PROVIDER_META[provider];
  const isLive = conn[provider]?.connected;

  const pushNotice = useCallback((level: Notice["level"], message: string) => {
    const id = ++noticeId.current;
    setNoticeState({ level, message });
    setLog((prev) =>
      [
        {
          level,
          message,
          provider: null,
          createdAt: new Date().toISOString(),
        },
        ...prev,
      ].slice(0, 6),
    );
    window.setTimeout(() => {
      if (noticeId.current === id) setNoticeState(null);
    }, 7000);
  }, []);

  /* بارگذاری تاریخچه و پلی‌لیست بر اساس سرویسِ انتخاب‌شده */
  const loadProvider = useCallback(
    async (p: Provider) => {
      try {
        const [hist, lib] = await Promise.all([
          fetch(`/api/history?provider=${p}`).then((r) => r.json()),
          fetch(`/api/library?provider=${p}`).then((r) => r.json()),
        ]);
        setRecent(hist.items ?? []);
        setPlaylists(lib.items ?? []);
      } catch {
        pushNotice("error", "خطا در خواندنِ کتابخانه");
      }
    },
    [pushNotice],
  );

  useEffect(() => {
    void loadProvider(provider);
    void fetch("/api/connection")
      .then((r) => r.json())
      .then((json) => {
        if (json?.spotify && json?.youtube) {
          setConn({
            spotify: {
              provider: "spotify",
              connected: json.spotify.connected,
              configured: json.spotify.configured,
              label: json.spotify.label,
            },
            youtube: {
              provider: "youtube",
              connected: json.youtube.connected,
              configured: json.youtube.configured,
              label: json.youtube.label,
            },
          });
        }
      })
      .catch(() => undefined);
  }, [provider, loadProvider]);

  const runSearch = async (q: string) => {
    setLoading(true);
    try {
      const res = await fetch(
        `/api/search?provider=${provider}&q=${encodeURIComponent(q)}`,
      );
      const json = await res.json();
      setResults(json.items ?? []);
      if (!(json.items ?? []).length) {
        pushNotice("info", "چیزی پیدا نشد — املای دیگری را امتحان کن");
      }
    } catch {
      pushNotice("error", "جستجو ناموفق بود");
    } finally {
      setLoading(false);
    }
  };

  const openPlaylist = async (pl: MediaItem) => {
    setDetail(pl.title);
    setLoading(true);
    try {
      const res = await fetch(
        `/api/library?provider=${provider}&id=${encodeURIComponent(pl.externalId)}`,
      );
      const json = await res.json();
      setResults(json.items ?? []);
      pushNotice("info", `پلی‌لیستِ «${pl.title}» باز شد`);
    } catch {
      pushNotice("error", "بازکردنِ پلی‌لیست ناموفق بود");
    } finally {
      setLoading(false);
    }
  };

  const save = async (item: MediaItem) => {
    try {
      const res = await fetch("/api/saved", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ item }),
      });
      const json = await res.json();
      if (!json.ok) {
        pushNotice("error", "در تاریخچه‌ی LifeOS ثبت نشد.");
        return;
      }
      setSavedKeys(json.keys ?? []);
      setShelf((prev) => {
        const exists = prev.some(
          (s) => s.provider === item.provider && s.externalId === item.externalId,
        );
        return exists
          ? prev.filter(
              (s) => !(s.provider === item.provider && s.externalId === item.externalId),
            )
          : [item, ...prev];
      });
      pushNotice(json.saved ? "ok" : "info", json.saved ? `در LifeOS ثبت شد: ${item.title}` : `برداشته شد: ${item.title}`);
    } catch {
      pushNotice("error", "در تاریخچه‌ی LifeOS ثبت نشد.");
    }
  };

  const logPlay = async (item: MediaItem, msPlayed: number) => {
    try {
      const res = await fetch("/api/history", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ item, msPlayed, origin: isLive ? "live" : "demo" }),
      });
      const json = await res.json();
      if (!json.ok) pushNotice("error", "در تاریخچه‌ی LifeOS ثبت نشد.");
      else void loadProvider(provider);
    } catch {
      pushNotice("error", "در تاریخچه‌ی LifeOS ثبت نشد.");
    }
  };

  const disconnect = async (p: Provider) => {
    await fetch(`/api/connection?provider=${p}`, { method: "DELETE" });
    setConn((c) => ({ ...c, [p]: { ...c[p], connected: false, label: null } }));
    pushNotice("info", `حساب ${PROVIDER_META[p].name} قطع شد`);
    void loadProvider(p);
  };

  const isSaved = useCallback(
    (item: MediaItem) =>
      savedKeys.includes(`${item.provider}:${item.externalId}`),
    [savedKeys],
  );

  const suggestions = initial.suggestions;
  const stats = initial.stats;
  const feedTitle = provider === "spotify" ? "آخرها پخش‌شده" : "آخرها دیده‌شده";

  const resultList = useMemo(() => results ?? [], [results]);

  return (
    <div className="min-h-screen pb-[220px] sm:pb-[150px]">
      {/* ─── سَرِ رَک ─── */}
      <header className="relative overflow-hidden border-b border-etch/60">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="images/deck.jpg"
          alt=""
          aria-hidden="true"
          className="absolute inset-0 h-full w-full object-cover object-center opacity-45 [mask-image:linear-gradient(to_left,black_10%,transparent_85%)]"
        />
        <div className="absolute inset-0 bg-gradient-to-l from-deck/20 via-deck/70 to-deck" aria-hidden="true" />
        <div className="relative mx-auto flex w-full max-w-[1440px] flex-wrap items-center justify-between gap-6 px-4 py-8 lg:px-8 lg:py-12">
          <div className="flex items-center gap-4">
            <span className="text-signal">
              <Mark size={54} />
            </span>
            <div>
              <p className="label">LIFEOS · MEDIA DESK</p>
              <h1 className="text-[30px] font-extrabold leading-none tracking-tight text-cream lg:text-[40px]">
                میزِ رسانه
              </h1>
              <p className="mt-1.5 max-w-[46ch] font-mono text-[11.5px] leading-relaxed text-mute">
                {meta.blurb} — پخش، تاریخچه، پلی‌لیست‌ها و آمارِ Spotify و YouTube در یک دستگاه.
              </p>
            </div>
          </div>

          {/* انتخابِ سرویس + اتصال */}
          <div className="flex flex-wrap items-stretch gap-3">
            {(Object.keys(PROVIDER_META) as Provider[]).map((p) => {
              const c = conn[p];
              const active = p === provider;
              return (
                <div
                  key={p}
                  className={`unit-select ${active ? "unit-select-on" : ""}`}
                >
                  <button
                    type="button"
                    onClick={() => setProvider(p)}
                    className="block text-start"
                    aria-pressed={active}
                  >
                    <span className="label flex items-center gap-2">
                      <i
                        className={`led ${c.connected ? "led-on" : "led-off"}`}
                        aria-hidden="true"
                      />
                      {PROVIDER_META[p].code}
                    </span>
                    <span className="block text-[22px] font-extrabold leading-tight tracking-tight text-cream">
                      {PROVIDER_META[p].name}
                    </span>
                    <span className="mt-0.5 block font-mono text-[10.5px] text-mute">
                      {c.connected
                        ? `متصل: ${c.label ?? "حسابِ کاربری"}`
                        : c.configured
                          ? "آماده‌ی اتصال"
                          : "کلیدِ API در .env لازم است"}
                    </span>
                  </button>
                  <div className="mt-2 flex items-center gap-2">
                    {c.connected ? (
                      <button
                        type="button"
                        onClick={() => disconnect(p)}
                        className="btn-plate"
                      >
                        قطعِ اتصال
                      </button>
                    ) : (
                      <a href={`/api/auth/${p}`} className="btn-signal">
                        اتصالِ {PROVIDER_META[p].name}
                      </a>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </header>

      {/* ─── نوارِ وضعیت ─── */}
      <div className="mx-auto w-full max-w-[1440px] px-4 pt-4 lg:px-8">
        {noticeState ? (
          <div
            role="status"
            className={`status-strip ${
              noticeState.level === "error"
                ? "status-error"
                : noticeState.level === "ok"
                  ? "status-ok"
                  : "status-info"
            }`}
          >
            <button
              type="button"
              onClick={() => setNoticeState(null)}
              aria-label="بستن"
              className="px-3 text-mute transition hover:text-cream"
            >
              ×
            </button>
            <p className="flex-1 py-2.5 text-[13.5px] font-medium">{noticeState.message}</p>
            <span className="label px-3 opacity-70">
              {noticeState.level === "error" ? "ERR" : noticeState.level === "ok" ? "OK" : "INFO"}
            </span>
          </div>
        ) : (
          <div className="status-strip status-info opacity-70">
            <span className="px-3 text-mute">×</span>
            <p className="flex-1 py-2.5 font-mono text-[11.5px]">
              {log[0]
                ? `${log[0].message}  —  ${stamp(log[0].createdAt)}`
                : "آماده: هر پخش و تماشا به‌طور خودکار در LifeOS ثبت می‌شود."}
            </p>
            <span className="label px-3 opacity-70">LOG</span>
          </div>
        )}
      </div>

      {/* ─── دکِ جستجو ─── */}
      <div className="mx-auto w-full max-w-[1440px] px-4 pt-4 lg:px-8">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void runSearch(query);
          }}
          className="panel flex flex-wrap items-center gap-3 px-3 py-3"
        >
          <span className="screw screw-tl" aria-hidden="true" />
          <span className="screw screw-tr" aria-hidden="true" />
          <button type="submit" className="btn-signal btn-signal-lg">
            جستجو
          </button>
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={`جستجو در ${meta.name} — نامِ قطعه، خواننده یا پلی‌لیست`}
            aria-label={`جستجو در ${meta.name}`}
            className="min-w-[200px] flex-1 rounded-[3px] border border-etch/80 bg-deep/60 px-4 py-2.5 text-[15px] text-cream outline-none transition placeholder:text-mute/70 focus:border-signal/80 focus:ring-2 focus:ring-signal/30"
          />
          <div className="flex items-center gap-2">
            <span className="label opacity-70">SOURCE</span>
            <span className={`chip ${isLive ? "chip-on" : ""}`}>
              {isLive ? "حسابِ متصل" : "حالت نمایشی"}
            </span>
            {detail ? (
              <button
                type="button"
                onClick={() => {
                  setDetail(null);
                  setResults(null);
                }}
                className="chip chip-btn"
              >
                پاک‌کردنِ {detail} ×
              </button>
            ) : null}
          </div>
        </form>
      </div>

      {/* ─── دو ستونِ نامتقارن ─── */}
      <main className="mx-auto grid w-full max-w-[1440px] gap-5 px-4 pt-5 lg:grid-cols-[1.25fr_1fr] lg:px-8">
        <Panel
          code={feedTitle === "آخرها پخش‌شده" ? "UNIT 03 / FEED" : "UNIT 03 / WATCH"}
          title={feedTitle}
          hint={`۲۴ رویدادِ آخر · ${isLive ? "همگام‌شده از حساب" : "آرشیوِ نمایشی"}`}
          className="order-1"
        >
          {recent.length ? (
            <ol>
              {recent.map((item, i) => (
                <ItemRow
                  key={`${item.id}-${i}`}
                  item={item}
                  index={i + 1}
                  active={current?.id === item.id}
                  onPlay={setCurrent}
                  onSave={save}
                  saved={isSaved(item)}
                />
              ))}
            </ol>
          ) : (
            <Empty
              title="هنوز چیزی پخش نشده"
              hint="برای شروع، اتصال را برقرار کنید یا از جستجو یک قطعه انتخاب کنید."
              image="images/room.jpg"
            />
          )}
        </Panel>

        <div className="order-2 flex flex-col gap-5">
          <Panel
            code="UNIT 04 / SEARCH"
            title="نتیجه‌ی جستجو"
            hint={loading ? "در حالِ تبادلِ داده…" : results ? `${fa(resultList.length)} نتیجه` : "جستجو کنید تا نمایش داده شود"}
          >
            {resultList.length ? (
              <ol>
                {resultList.map((item, i) => (
                  <ItemRow
                    key={`${item.id}-${i}`}
                    item={item}
                    active={current?.id === item.id}
                    onPlay={(it) =>
                      it.kind === "playlist" ? openPlaylist(it) : setCurrent(it)
                    }
                    onSave={save}
                    saved={isSaved(item)}
                  />
                ))}
              </ol>
            ) : (
              <Empty
                title="جستجو کنید تا نتایج داده شود"
                hint="نامِ قطعه، خواننده یا پلی‌لیست را بنویسید و دکمه‌ی جستجو را بزنید."
                image="images/room.jpg"
              />
            )}
          </Panel>

          <Panel
            code="UNIT 05 / SHELF"
            title="قفسه‌ی LifeOS"
            hint={`${fa(shelf.length)} موردِ ثبت‌شده`}
            tone="amber"
          >
            {shelf.length ? (
              <ol>
                {shelf.map((item, i) => (
                  <ItemRow
                    key={`${item.id}-${i}`}
                    item={item}
                    active={current?.id === item.id}
                    onPlay={setCurrent}
                    onSave={save}
                    saved={isSaved(item)}
                  />
                ))}
              </ol>
            ) : (
              <Empty
                title="قفسه خالی است"
                hint="هر ردیف را با «ثبت در LifeOS» نگه دارید تا اینجا جمع شود."
              />
            )}
          </Panel>
        </div>
      </main>

      {/* ─── پلی‌لیست‌ها ─── */}
      <section className="relative mt-8 border-y border-etch/60">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="images/shelf.jpg"
          alt=""
          aria-hidden="true"
          className="absolute inset-0 h-full w-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-l from-deck/60 via-deck/85 to-deck" aria-hidden="true" />
        <div className="relative mx-auto w-full max-w-[1440px] px-4 py-8 lg:px-8">
          <div className="mb-4 flex flex-wrap items-baseline justify-between gap-2">
            <div className="flex items-baseline gap-3">
              <span className="label text-signal">UNIT 06 / PLAYLISTS</span>
              <h2 className="text-[24px] font-extrabold tracking-tight text-cream">
                پلی‌لیست‌های {meta.name}
              </h2>
            </div>
            <p className="font-mono text-[11px] text-mute">
              {isLive ? "خوانده‌شده از حسابِ متصل" : "نمونه‌ی آرشیوِ شخصی"} — برای دیدنِ اعضا کلیک کنید
            </p>
          </div>
          <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {playlists.map((pl) => (
              <li key={pl.id}>
                <button
                  type="button"
                  onClick={() => openPlaylist(pl)}
                  className="pl-card group w-full text-start"
                >
                  <span className="label opacity-70">{pl.itemCount ? `${fa(pl.itemCount)} مورد` : "PLAYLIST"}</span>
                  <span className="mt-1 block truncate text-[17px] font-extrabold tracking-tight text-cream group-hover:text-signal">
                    {pl.title}
                  </span>
                  <span className="mt-0.5 block truncate font-mono text-[11px] text-mute">
                    {[pl.subtitle, pl.detail].filter(Boolean).join("  ·  ")}
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* ─── آمار ─── */}
      <section className="mx-auto w-full max-w-[1440px] px-4 pt-8 lg:px-8">
        <Panel
          code="UNIT 07 / METER"
          title="آمارِ سی‌روزِ اخیر"
          hint={stats.live ? "محاسبه‌شده از تاریخچه‌ی LifeOS" : "نمونه‌ی آمارِ آرشیو"}
          tone="amber"
        >
          <div className="grid grid-cols-2 md:grid-cols-4">
            <StatBlock
              value={group(stats.plays30d)}
              label="PLAYS · پخش"
              sub="در سی روزِ اخیر"
            />
            <StatBlock
              value={group(stats.minutes30d)}
              label="MINUTES · دقیقه"
              tone="amber"
              sub="زمانِ گوش‌دادن"
            />
            <StatBlock
              value={group(stats.videos30d)}
              label="WATCHED · دیده‌شده"
              sub="ویدیوی کامل‌دیده‌شده"
            />
            <StatBlock
              value={group(stats.totalViews)}
              label="VIEWS · بازدید"
              tone="signal"
              sub={`پیاپی: ${fa(stats.streak)} روز`}
            />
          </div>
          <div className="border-t border-etch/60">
            <div className="flex items-baseline justify-between px-5 pt-4">
              <p className="label">HOURS · پراکندگیِ ساعتِ گوش‌دادن</p>
              <p className="font-mono text-[11px] text-mute">
                پرتکرارترین صدا: <span className="text-amber">{stats.topArtist}</span> — {fa(stats.topShare)}٪
              </p>
            </div>
            <HourHistogram data={stats.byHour} />
          </div>
        </Panel>
      </section>

      {/* ─── پیشنهادها ─── */}
      <section className="mx-auto w-full max-w-[1440px] px-4 pt-5 lg:px-8">
        <Panel
          code="UNIT 08 / SUGGEST"
          title="پیشنهادها"
          hint="بر اساسِ تاریخچه‌ی پخش و تماشای شما"
        >
          <ol>
            {suggestions.map((s) => (
              <ItemRow
                key={s.id}
                item={s.item}
                reason={s.reason}
                active={current?.id === s.item.id}
                onPlay={setCurrent}
                onSave={save}
                saved={isSaved(s.item)}
              />
            ))}
          </ol>
        </Panel>
      </section>

      {/* ─── گزارشِ دستگاه ─── */}
      <footer className="mx-auto w-full max-w-[1440px] px-4 py-8 lg:px-8">
        <div className="flex flex-wrap items-start justify-between gap-6 border-t border-etch/60 pt-5">
          <div className="max-w-[52ch]">
            <p className="label">SYSTEM LOG</p>
            <ul className="mt-2 space-y-1">
              {log.map((l, i) => (
                <li key={`${l.createdAt}-${i}`} className="font-mono text-[11px] text-mute">
                  <span className={l.level === "error" ? "text-[#E85A3D]" : l.level === "ok" ? "text-signal" : "text-amber"}>
                    {l.level === "error" ? "ERR" : l.level === "ok" ? "OK  " : "INFO"}
                  </span>{" "}
                  {l.message} — {stamp(l.createdAt)}
                </li>
              ))}
              {!log.length ? (
                <li className="font-mono text-[11px] text-mute">رویدادی ثبت نشده است.</li>
              ) : null}
            </ul>
          </div>
          <div className="font-mono text-[11px] leading-relaxed text-mute">
            <p className="label mb-2">SCOPES</p>
            <p className="max-w-[36ch]">
              Spotify: recently-played · top-read · playlists · library-read
              <br />
              YouTube: youtube.readonly · youtube.force-ssl
            </p>
            <p className="mt-3 opacity-80">
              توکن‌ها فقط روی سرور و در PostgreSQL نگهداری می‌شوند.
            </p>
          </div>
        </div>
      </footer>

      <Transport
        item={current}
        live={Boolean(isLive)}
        onLog={logPlay}
        onSave={save}
        saved={current ? isSaved(current) : false}
        onNotify={pushNotice}
      />
    </div>
  );
}
