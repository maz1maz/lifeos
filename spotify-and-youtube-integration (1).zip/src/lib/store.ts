import { db } from "@/db";
import { plays, saved, syncLog } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import {
  DEMO_STATS,
  DEMO_TRACKS,
  DEMO_VIDEOS,
  demoRecent,
  type MediaItem,
  type Provider,
} from "@/lib/catalog";

const DAY = 86_400_000;

export type Row = Record<string, unknown>;

function toItem(r: Row): MediaItem {
  return {
    id: `db-${r.id}`,
    provider: r.provider as Provider,
    kind: r.kind as MediaItem["kind"],
    externalId: r.externalId as string,
    title: r.title as string,
    subtitle: (r.subtitle as string) ?? "",
    artwork: (r.artwork as string) ?? null,
    durationMs: (r.durationMs as number) ?? null,
    views: (r.views as number) ?? null,
    context: (r.context as string) ?? null,
    playedAt: r.playedAt ? new Date(r.playedAt as Date).toISOString() : null,
  };
}

export async function logPlay(item: MediaItem, msPlayed: number, origin: string) {
  try {
    await db.insert(plays).values({
      provider: item.provider,
      kind: item.kind,
      externalId: item.externalId,
      title: item.title,
      subtitle: item.subtitle,
      artwork: item.artwork ?? null,
      durationMs: item.durationMs ?? null,
      msPlayed,
      views: item.views ?? null,
      context: item.context ?? null,
      origin,
    });
    await db.insert(syncLog).values({
      level: "ok",
      provider: item.provider,
      message: `در تاریخچه‌ی LifeOS ثبت شد: ${item.title}`,
    });
    return true;
  } catch {
    return false;
  }
}

export async function saveItem(item: MediaItem, note?: string) {
  try {
    const existing = await db
      .select()
      .from(saved)
      .where(
        and(
          eq(saved.provider, item.provider),
          eq(saved.externalId, item.externalId),
        ),
      )
      .limit(1);
    if (existing.length) {
      await db
        .delete(saved)
        .where(eq(saved.id, existing[0].id));
      await db.insert(syncLog).values({
        level: "info",
        provider: item.provider,
        message: `از قفسه‌ی LifeOS برداشته شد: ${item.title}`,
      });
      return { ok: true, saved: false };
    }
    await db.insert(saved).values({
      provider: item.provider,
      kind: item.kind,
      externalId: item.externalId,
      title: item.title,
      subtitle: item.subtitle,
      artwork: item.artwork ?? null,
      note: note ?? null,
    });
    await db.insert(syncLog).values({
      level: "ok",
      provider: item.provider,
      message: `در LifeOS ثبت شد: ${item.title}`,
    });
    return { ok: true, saved: true };
  } catch {
    return { ok: false, saved: false };
  }
}

export async function getSaved() {
  try {
    const rows = await db.select().from(saved).orderBy(desc(saved.createdAt)).limit(60);
    return rows.map((r) => ({
      ...toItem(r as Row),
      note: (r as Row).note as string | null,
    }));
  } catch {
    return [] as (MediaItem & { note: string | null })[];
  }
}

export async function getSavedKeys() {
  try {
    const rows = await db.select().from(saved).limit(500);
    return rows.map((r) => `${r.provider}:${r.externalId}`);
  } catch {
    return [] as string[];
  }
}

export async function getHistory(limit = 24) {
  try {
    const rows = await db
      .select()
      .from(plays)
      .orderBy(desc(plays.playedAt))
      .limit(limit);
    if (rows.length) return rows.map((r) => toItem(r as Row));
  } catch {
    /* fall through to demo */
  }
  return [];
}

export async function recentFor(provider: Provider, limit = 12) {
  let items: MediaItem[] = [];
  try {
    const rows = await db
      .select()
      .from(plays)
      .where(eq(plays.provider, provider))
      .orderBy(desc(plays.playedAt))
      .limit(limit);
    items = rows.map((r) => toItem(r as Row));
  } catch {
    items = [];
  }
  // آرشیوِ نمایشی بقیه‌ی فید را پر می‌کند تا صفحه‌ی تازه هم کامل باشد.
  const seen = new Set(items.map((i) => i.externalId));
  for (const demo of demoRecent(provider)) {
    if (items.length >= limit) break;
    if (!seen.has(demo.externalId)) items.push(demo);
  }
  return items;
}

export async function getLog(limit = 4) {
  try {
    const rows = await db
      .select()
      .from(syncLog)
      .orderBy(desc(syncLog.createdAt))
      .limit(limit);
    return rows.map((r) => ({
      level: r.level,
      message: r.message,
      provider: r.provider,
      createdAt: r.createdAt.toISOString(),
    }));
  } catch {
    return [] as { level: string; message: string; provider: string | null; createdAt: string }[];
  }
}

export async function getStats() {
  let playsRows: Row[] = [];
  try {
    playsRows = (await db.select().from(plays).limit(2000)) as unknown as Row[];
  } catch {
    playsRows = [];
  }
  if (!playsRows.length) return { ...DEMO_STATS, live: false };


  const now = Date.now();
  const inWindow = playsRows.filter(
    (r) => now - new Date(r.playedAt as Date).getTime() < 30 * DAY,
  );
  // تا وقتی تاریخچه‌ی واقعی از هشت رویداد پر نشده، آمارِ آرشیو نشان داده می‌شود.
  if (inWindow.length < 8) return { ...DEMO_STATS, live: false };
  const minutes = Math.round(
    inWindow.reduce((sum, r) => sum + ((r.msPlayed as number) ?? 0), 0) / 60000,
  );
  const videos = inWindow.filter((r) => r.kind === "video").length;
  const totalViews = inWindow.reduce((sum, r) => sum + ((r.views as number) ?? 0), 0);

  const byArtist = new Map<string, number>();
  inWindow.forEach((r) => {
    const key = (r.subtitle as string) || "نامشخص";
    byArtist.set(key, (byArtist.get(key) ?? 0) + 1);
  });
  const top = [...byArtist.entries()].sort((a, b) => b[1] - a[1])[0] ?? ["—", 0];
  const share = inWindow.length
    ? Math.round((top[1] / inWindow.length) * 100)
    : 0;

  const days = new Set(
    playsRows.map((r) => new Date(r.playedAt as Date).toDateString()),
  );
  let streak = 0;
  for (let i = 0; i < 400; i++) {
    const d = new Date(now - i * DAY).toDateString();
    if (days.has(d)) streak++;
    else if (i > 0) break;
  }

  const byHour = new Array(24).fill(0) as number[];
  inWindow.forEach((r) => {
    byHour[new Date(r.playedAt as Date).getHours()] += 1;
  });

  return {
    plays30d: inWindow.length,
    minutes30d: minutes,
    videos30d: videos,
    totalViews,
    topArtist: top[0],
    topShare: share,
    streak,
    byHour,
    live: true,
  };
}

export function demoLibrary() {
  return {
    tracks: DEMO_TRACKS,
    videos: DEMO_VIDEOS,
  };
}
