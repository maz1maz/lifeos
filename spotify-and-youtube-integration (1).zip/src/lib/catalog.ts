export type Provider = "spotify" | "youtube";
export type Kind = "track" | "video" | "playlist";

export type MediaItem = {
  id: string;
  provider: Provider;
  kind: Kind;
  title: string;
  subtitle: string;
  detail?: string;
  artwork?: string | null;
  durationMs?: number | null;
  views?: number | null;
  playedAt?: string | null;
  context?: string | null;
  itemCount?: number | null;
  externalId: string;
};

export type Playlist = MediaItem & { kind: "playlist" };

/* ------------------------------------------------------------------ *
 * کاتالوگ نمایشی — همان قطعه‌های آرشیو شخصی، وقتی حسابی وصل نیست.
 * ------------------------------------------------------------------ */

const MIN = 60_000;

export const DEMO_TRACKS: MediaItem[] = [
  {
    id: "sp-demo-1",
    provider: "spotify",
    kind: "track",
    externalId: "demo-elaheh-naaz",
    title: "الاهه ناز",
    subtitle: "معین",
    detail: "آلبومِ الاهه · ۱۹۸۴",
    durationMs: 4 * MIN + 12_000,
  },
  {
    id: "sp-demo-2",
    provider: "spotify",
    kind: "track",
    externalId: "demo-ayeneh",
    title: "آینه (مسخ)",
    subtitle: "فرهاد مهراد",
    detail: "آلبومِ مردِ تنها · ۱۹۷۷",
    durationMs: 5 * MIN + 38_000,
  },
  {
    id: "sp-demo-3",
    provider: "spotify",
    kind: "track",
    externalId: "demo-gol-vajeh",
    title: "گل واژه",
    subtitle: "هایده",
    detail: "آلبومِ گل واژه · ۱۹۷۶",
    durationMs: 6 * MIN + 4_000,
  },
  {
    id: "sp-demo-4",
    provider: "spotify",
    kind: "track",
    externalId: "demo-saghi",
    title: "ساقی",
    subtitle: "الهه",
    detail: "تک‌آهنگ · ۱۹۷۳",
    durationMs: 3 * MIN + 51_000,
  },
  {
    id: "sp-demo-5",
    provider: "spotify",
    kind: "track",
    externalId: "demo-farangis",
    title: "فرنگیس",
    subtitle: "سیاوش قمیشی",
    detail: "آلبومِ فرنگیس · ۱۹۷۸",
    durationMs: 4 * MIN + 44_000,
  },
  {
    id: "sp-demo-6",
    provider: "spotify",
    kind: "track",
    externalId: "demo-divar",
    title: "دیوار",
    subtitle: "فرامرز اصلانی",
    detail: "آلبومِ اگر یک روز · ۱۹۷۵",
    durationMs: 5 * MIN + 17_000,
  },
  {
    id: "sp-demo-7",
    provider: "spotify",
    kind: "track",
    externalId: "demo-shab",
    title: "شبِ بی‌ستاره",
    subtitle: "گوگوش",
    detail: "آلبومِ سایه‌ها · ۱۹۷۹",
    durationMs: 3 * MIN + 27_000,
  },
  {
    id: "sp-demo-8",
    provider: "spotify",
    kind: "track",
    externalId: "demo-kavir",
    title: "کویر",
    subtitle: "حسین علیزاده",
    detail: "آلبومِ دستگاه‌ها · ۱۹۹۱",
    durationMs: 8 * MIN + 12_000,
  },
];

export const DEMO_VIDEOS: MediaItem[] = [
  {
    id: "yt-demo-1",
    provider: "youtube",
    kind: "video",
    externalId: "demo-yt-1",
    title: "اجرای زنده‌ی گل واژه — تالار رودکی",
    subtitle: "هایده",
    detail: "تهران · ۱۹۷۶ · ۴:۵۹",
    durationMs: 4 * MIN + 59_000,
    views: 2_412_887,
  },
  {
    id: "yt-demo-2",
    provider: "youtube",
    kind: "video",
    externalId: "demo-yt-2",
    title: "مردِ تنها — کنسرتِ دانشگاه تهران",
    subtitle: "فرهاد مهراد",
    detail: "تهران · ۱۹۷۴ · ۶:۳۱",
    durationMs: 6 * MIN + 31_000,
    views: 1_038_502,
  },
  {
    id: "yt-demo-3",
    provider: "youtube",
    kind: "video",
    externalId: "demo-yt-3",
    title: "فرنگیس — موزیک‌ویدیوی اصلی",
    subtitle: "سیاوش قمیشی",
    detail: "لندن · ۱۹۷۸ · ۴:۴۴",
    durationMs: 4 * MIN + 44_000,
    views: 884_310,
  },
  {
    id: "yt-demo-4",
    provider: "youtube",
    kind: "video",
    externalId: "demo-yt-4",
    title: "اگر یک روز — خانه‌ی اپرا",
    subtitle: "فرامرز اصلانی",
    detail: "تهران · ۱۹۷۵ · ۵:۲۲",
    durationMs: 5 * MIN + 22_000,
    views: 612_045,
  },
  {
    id: "yt-demo-5",
    provider: "youtube",
    kind: "video",
    externalId: "demo-yt-5",
    title: "مستند: ضبطِ آلبومِ مردِ تنها",
    subtitle: "آرشیوِ صدا و سیما",
    detail: "۲۹:۱۰ · مستند",
    durationMs: 29 * MIN + 10_000,
    views: 214_662,
  },
];

export const DEMO_PLAYLISTS: Record<Provider, Playlist[]> = {
  spotify: [
    {
      id: "pl-sp-1",
      provider: "spotify",
      kind: "playlist",
      externalId: "demo-pl-sp-1",
      title: "کافه‌ی شبانه",
      subtitle: "خودم · عمومی",
      detail: "۴۲ قطعه · ۲س ۴۱د",
      itemCount: 42,
    },
    {
      id: "pl-sp-2",
      provider: "spotify",
      kind: "playlist",
      externalId: "demo-pl-sp-2",
      title: "تالارِ گوش‌دادن",
      subtitle: "خودم · خصوصی",
      detail: "۱۸ قطعه · ۱س ۳۲د",
      itemCount: 18,
    },
    {
      id: "pl-sp-3",
      provider: "spotify",
      kind: "playlist",
      externalId: "demo-pl-sp-3",
      title: "معین: بهترین‌ها",
      subtitle: "مشترک با نگار",
      detail: "۲۷ قطعه · ۱س ۵۴د",
      itemCount: 27,
    },
    {
      id: "pl-sp-4",
      provider: "spotify",
      kind: "playlist",
      externalId: "demo-pl-sp-4",
      title: "بی‌کلام برای نوشتن",
      subtitle: "خودم · عمومی",
      detail: "۶۳ قطعه · ۴س ۰۸د",
      itemCount: 63,
    },
  ],
  youtube: [
    {
      id: "pl-yt-1",
      provider: "youtube",
      kind: "playlist",
      externalId: "demo-pl-yt-1",
      title: "آرشیوِ کنسرت‌ها",
      subtitle: "کانالِ من",
      detail: "۳۱ ویدیو · ۳س ۱۲د",
      itemCount: 31,
    },
    {
      id: "pl-yt-2",
      provider: "youtube",
      kind: "playlist",
      externalId: "demo-pl-yt-2",
      title: "موزیک‌ویدیوهای دهه‌ی پنجاه",
      subtitle: "کانالِ من",
      detail: "۲۴ ویدیو · ۱س ۴۷د",
      itemCount: 24,
    },
    {
      id: "pl-yt-3",
      provider: "youtube",
      kind: "playlist",
      externalId: "demo-pl-yt-3",
      title: "مستندهای موسیقی",
      subtitle: "کانالِ من",
      detail: "۱۲ ویدیو · ۴س ۳۰د",
      itemCount: 12,
    },
  ],
};

/** Recent activity is generated relative to "now" so it never goes stale. */
export function demoRecent(provider: Provider): MediaItem[] {
  const source = provider === "spotify" ? DEMO_TRACKS : DEMO_VIDEOS;
  const offsets = [2, 11, 17, 25, 43, 68, 96, 141];
  const contexts = [
    "کافه‌ی شبانه",
    "تالارِ گوش‌دادن",
    "آرشیوِ کنسرت‌ها",
    "بی‌کلام برای نوشتن",
    "جستجو",
    "کافه‌ی شبانه",
    "رادیوی شب",
    "آرشیوِ کنسرت‌ها",
  ];
  return source.slice(0, 6).map((item, i) => ({
    ...item,
    playedAt: new Date(Date.now() - offsets[i] * 60_000).toISOString(),
    context: contexts[i],
  }));
}

export const DEMO_STATS = {
  plays30d: 312,
  minutes30d: 1284,
  videos30d: 96,
  totalViews: 5_162_304,
  topArtist: "هایده",
  topShare: 23,
  streak: 17,
  byHour: [2, 1, 0, 0, 0, 1, 4, 9, 12, 8, 6, 7, 11, 9, 6, 8, 13, 18, 24, 29, 34, 31, 22, 11],
};

export const DEMO_SUGGESTIONS = [
  {
    id: "sg-1",
    reason: "چون ۲۳٪ از گوش‌دادنِ این ماه مالِ هایده بود",
    title: "مرغِ سحر",
    subtitle: "هایده",
    detail: "قطعه · ۱۹۷۴ · ۵:۰۲",
    provider: "spotify" as Provider,
    kind: "track" as Kind,
    externalId: "demo-sg-1",
  },
  {
    id: "sg-2",
    reason: "چون آینه‌ی فرهاد را سه بار پشتِ سرِ هم پخش کردی",
    title: "شهزاده‌ی رویاها",
    subtitle: "فرهاد مهراد",
    detail: "قطعه · ۱۹۷۷ · ۴:۲۹",
    provider: "spotify" as Provider,
    kind: "track" as Kind,
    externalId: "demo-sg-2",
  },
  {
    id: "sg-3",
    reason: "چون ویدیوهای زنده‌ی دهه‌ی پنجاه را تا انتها می‌بینی",
    title: "اجرای زنده‌ی فرنگیس — جزیره‌ی کیش",
    subtitle: "سیاوش قمیشی",
    detail: "ویدیو · ۱۹۷۸ · ۵:۱۱",
    provider: "youtube" as Provider,
    kind: "video" as Kind,
    externalId: "demo-sg-3",
    views: 402_118,
  },
  {
    id: "sg-4",
    reason: "چون پلی‌لیستِ «بی‌کلام برای نوشتن» را دو هفته است باز نکرده‌ای",
    title: "دستگاهِ چهارگاه",
    subtitle: "حسین علیزاده",
    detail: "قطعه · ۱۹۹۱ · ۹:۴۰",
    provider: "spotify" as Provider,
    kind: "track" as Kind,
    externalId: "demo-sg-4",
  },
];
