/** Formatting helpers shared by server and client (Persian, RTL). */

const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

export function fa(input: string | number | null | undefined): string {
  if (input === null || input === undefined || input === "") return "—";
  return String(input)
    .replace(/\d/g, (d) => FA_DIGITS[Number(d)])
    .replace(/,/g, "٬");
}

export function group(n: number | null | undefined): string {
  if (n === null || n === undefined) return "—";
  return fa(n.toLocaleString("en-US"));
}

export function clock(ms?: number | null): string {
  if (!ms && ms !== 0) return "--:--";
  const total = Math.max(0, Math.round(ms / 1000));
  const m = Math.floor(total / 60);
  const s = total % 60;
  return fa(`${m}:${String(s).padStart(2, "0")}`);
}

export function minutesLabel(ms?: number | null): string {
  if (!ms) return "—";
  return `${fa(Math.round(ms / 60000))} دقیقه`;
}

export function relativeTime(iso?: string | null): string {
  if (!iso) return "—";
  const diff = Date.now() - new Date(iso).getTime();
  const min = Math.round(diff / 60000);
  if (min < 1) return "همین حالا";
  if (min < 60) return `${fa(min)} دقیقه پیش`;
  const hrs = Math.round(min / 60);
  if (hrs < 24) return `${fa(hrs)} ساعت پیش`;
  const days = Math.round(hrs / 24);
  return `${fa(days)} روز پیش`;
}

export function stamp(iso?: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  const p = (n: number) => String(n).padStart(2, "0");
  return fa(
    `${d.getFullYear()}/${p(d.getMonth() + 1)}/${p(d.getDate())} — ${p(
      d.getHours(),
    )}:${p(d.getMinutes())}`,
  );
}

export function initials(title?: string | null): string {
  const t = (title ?? "").trim();
  return t ? t.slice(0, 1) : "•";
}
