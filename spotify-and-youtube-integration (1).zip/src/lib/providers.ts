import { db } from "@/db";
import { connections } from "@/db/schema";
import { eq } from "drizzle-orm";

/* ------------------------------------------------------------------ *
 * لایه‌ی اتصال به Spotify (Web API + PKCE) و YouTube (Data API v3).
 * همه‌ی کلیدها از متغیرهای محیطی خوانده می‌شوند؛ هیچ‌وقت در کلاینت.
 * ------------------------------------------------------------------ */

export type Provider = "spotify" | "youtube";

const SPOTIFY_AUTH = "https://accounts.spotify.com/authorize";
const SPOTIFY_TOKEN = "https://accounts.spotify.com/api/token";
const SPOTIFY_API = "https://api.spotify.com/v1";
const GOOGLE_AUTH = "https://accounts.googleapis.com/o/oauth2/v2/auth";
const GOOGLE_TOKEN = "https://oauth2.googleapis.com/token";
const YOUTUBE_API = "https://www.googleapis.com/youtube/v3";

const SPOTIFY_SCOPES = [
  "user-read-private",
  "user-read-email",
  "user-read-recently-played",
  "user-top-read",
  "playlist-read-private",
  "playlist-read-collaborative",
  "user-library-read",
].join(" ");

const YOUTUBE_SCOPES = [
  "https://www.googleapis.com/auth/youtube.readonly",
  "https://www.googleapis.com/auth/youtube.force-ssl",
  "openid",
  "email",
].join(" ");

export function redirectUri(provider: Provider) {
  const base =
    process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, "") ||
    "http://localhost:3000";
  return `${base}/api/auth/callback/${provider}`;
}

export function providerConfig(provider: Provider) {
  if (provider === "spotify") {
    const clientId = process.env.SPOTIFY_CLIENT_ID || process.env.NEXT_PUBLIC_SPOTIFY_CLIENT_ID || "";
    return {
      provider,
      clientId,
      clientSecret: process.env.SPOTIFY_CLIENT_SECRET || "",
      scopes: SPOTIFY_SCOPES,
      configured: Boolean(clientId && process.env.SPOTIFY_CLIENT_SECRET),
    };
  }
  const clientId =
    process.env.YOUTUBE_CLIENT_ID || process.env.GOOGLE_CLIENT_ID || process.env.NEXT_PUBLIC_YOUTUBE_CLIENT_ID || "";
  const clientSecret =
    process.env.YOUTUBE_CLIENT_SECRET || process.env.GOOGLE_CLIENT_SECRET || "";
  return {
    provider,
    clientId,
    clientSecret,
    scopes: YOUTUBE_SCOPES,
    configured: Boolean(clientId && clientSecret),
  };
}

function b64url(bytes: Uint8Array) {
  let s = "";
  bytes.forEach((b) => (s += String.fromCharCode(b)));
  return Buffer.from(s, "binary").toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

/** Random, url-safe string (PKCE verifier / OAuth state). */
export function randomString(bytes = 32) {
  return b64url(crypto.getRandomValues(new Uint8Array(bytes)));
}

export async function pkcePair() {
  const verifier = randomString(32);
  const challenge = await sha256Base64Url(verifier);
  return { verifier, challenge };
}

export function sha256Base64Url(input: string) {
  // Web Crypto is async; this helper is used from route handlers with await.
  return crypto.subtle
    .digest("SHA-256", new TextEncoder().encode(input))
    .then((buf) => Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""));
}

export async function buildAuthorizeUrl(provider: Provider, opts: {
  state: string;
  codeChallenge: string;
}) {
  const cfg = providerConfig(provider);
  const params = new URLSearchParams({
    client_id: cfg.clientId,
    redirect_uri: redirectUri(provider),
    state: opts.state,
    scope: cfg.scopes,
  });
  if (provider === "spotify") {
    params.set("response_type", "code");
    params.set("code_challenge_method", "S256");
    params.set("code_challenge", opts.codeChallenge);
    params.set("show_dialog", "true");
    return `${SPOTIFY_AUTH}?${params.toString()}`;
  }
  params.set("response_type", "code");
  params.set("access_type", "offline");
  params.set("prompt", "consent");
  return `${GOOGLE_AUTH}?${params.toString()}`;
}

export type TokenRow = {
  accessToken: string | null;
  refreshToken: string | null;
  expiresAt: Date | null;
};

export async function saveTokens(
  provider: Provider,
  data: {
    accessToken: string;
    refreshToken?: string | null;
    expiresIn?: number;
    scopes?: string;
    accountLabel?: string | null;
  },
) {
  const expiresAt = new Date(Date.now() + (data.expiresIn ?? 3600) * 1000);
  const existing = await db
    .select()
    .from(connections)
    .where(eq(connections.provider, provider))
    .limit(1);
  if (existing.length) {
    await db
      .update(connections)
      .set({
        accessToken: data.accessToken,
        refreshToken: data.refreshToken ?? existing[0].refreshToken,
        expiresAt,
        scopes: data.scopes ?? existing[0].scopes,
        accountLabel: data.accountLabel ?? existing[0].accountLabel,
        updatedAt: new Date(),
      })
      .where(eq(connections.provider, provider));
  } else {
    await db.insert(connections).values({
      provider,
      accessToken: data.accessToken,
      refreshToken: data.refreshToken ?? null,
      expiresAt,
      scopes: data.scopes ?? null,
      accountLabel: data.accountLabel ?? null,
    });
  }
}

export async function deleteConnection(provider: Provider) {
  await db.delete(connections).where(eq(connections.provider, provider));
}

export async function getConnection(provider: Provider): Promise<TokenRow | null> {
  const rows = await db
    .select()
    .from(connections)
    .where(eq(connections.provider, provider))
    .limit(1);
  if (!rows.length) return null;
  return {
    accessToken: rows[0].accessToken,
    refreshToken: rows[0].refreshToken,
    expiresAt: rows[0].expiresAt,
  };
}

export async function isLive(provider: Provider): Promise<boolean> {
  try {
    const row = await getConnection(provider);
    return Boolean(row?.accessToken);
  } catch {
    return false;
  }
}

async function refresh(provider: Provider, row: TokenRow) {
  const cfg = providerConfig(provider);
  if (!cfg.clientId || !row.refreshToken) return null;
  const body = new URLSearchParams({
    grant_type: "refresh_token",
    refresh_token: row.refreshToken,
    client_id: cfg.clientId,
  });
  if (provider === "spotify" && cfg.clientSecret) body.set("client_secret", cfg.clientSecret);
  if (provider === "youtube") {
    body.set("client_id", cfg.clientId);
    if (cfg.clientSecret) body.set("client_secret", cfg.clientSecret);
  }
  const res = await fetch(provider === "spotify" ? SPOTIFY_TOKEN : GOOGLE_TOKEN, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body,
    cache: "no-store",
  });
  if (!res.ok) return null;
  const json = (await res.json()) as {
    access_token: string;
    refresh_token?: string;
    expires_in?: number;
    scope?: string;
  };
  await saveTokens(provider, {
    accessToken: json.access_token,
    refreshToken: json.refresh_token ?? row.refreshToken,
    expiresIn: json.expires_in ?? 3600,
    scopes: json.scope,
  });
  return json.access_token;
}

export async function exchangeCode(
  provider: Provider,
  code: string,
  codeVerifier: string,
) {
  const cfg = providerConfig(provider);
  const body = new URLSearchParams({
    grant_type: "authorization_code",
    code,
    redirect_uri: redirectUri(provider),
    client_id: cfg.clientId,
  });
  if (provider === "spotify") {
    body.set("code_verifier", codeVerifier);
    body.set("client_secret", cfg.clientSecret);
  } else {
    body.set("client_secret", cfg.clientSecret);
  }
  const res = await fetch(provider === "spotify" ? SPOTIFY_TOKEN : GOOGLE_TOKEN, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body,
    cache: "no-store",
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`token exchange failed (${res.status}): ${text.slice(0, 200)}`);
  }
  return (await res.json()) as {
    access_token: string;
    refresh_token?: string;
    expires_in?: number;
    scope?: string;
    id_token?: string;
  };
}

async function accessToken(provider: Provider) {
  const row = await getConnection(provider);
  if (!row?.accessToken) return null;
  const expiring =
    row.expiresAt && row.expiresAt.getTime() < Date.now() + 60_000;
  if (expiring && row.refreshToken) {
    return (await refresh(provider, row)) ?? row.accessToken;
  }
  return row.accessToken;
}

export async function apiFetch(
  provider: Provider,
  path: string,
  params: Record<string, string | number | undefined> = {},
) {
  const token = await accessToken(provider);
  if (!token) return null;
  const base = provider === "spotify" ? SPOTIFY_API : YOUTUBE_API;
  const url = new URL(`${base}${path}`);
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== "") url.searchParams.set(k, String(v));
  });
  const res = await fetch(url.toString(), {
    headers: { Authorization: `Bearer ${token}` },
    cache: "no-store",
  });
  if (!res.ok) return null;
  return (await res.json()) as any;
}

export async function accountLabel(provider: Provider) {
  try {
    if (provider === "spotify") {
      const me = await apiFetch("spotify", "/me");
      return me?.display_name ? `${me.display_name}` : null;
    }
    const me = await apiFetch("youtube", "/channels", {
      part: "snippet",
      mine: "true",
    });
    const item = me?.items?.[0];
    return item?.snippet?.title ?? null;
  } catch {
    return null;
  }
}

export { accessToken };
