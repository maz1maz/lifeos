import { NextRequest, NextResponse } from "next/server";
import { getSaved, getSavedKeys, saveItem } from "@/lib/store";
import type { MediaItem } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export async function GET() {
  const [items, keys] = await Promise.all([getSaved(), getSavedKeys()]);
  return NextResponse.json({ items, keys });
}

export async function POST(req: NextRequest) {
  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "bad request" }, { status: 400 });
  }
  const item = body?.item as MediaItem | undefined;
  if (!item?.title || !item?.provider) {
    return NextResponse.json({ ok: false, error: "bad request" }, { status: 400 });
  }
  const result = await saveItem(
    {
      ...item,
      kind: item.kind ?? (item.provider === "youtube" ? "video" : "track"),
      externalId: item.externalId ?? item.id ?? "unknown",
    },
    body?.note,
  );
  const keys = await getSavedKeys();
  return NextResponse.json({ ...result, keys });
}
