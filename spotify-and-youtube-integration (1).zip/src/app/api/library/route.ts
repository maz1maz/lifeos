import { NextRequest, NextResponse } from "next/server";
import { apiFetch, isLive, type Provider } from "@/lib/providers";
import { DEMO_PLAYLISTS, DEMO_TRACKS, DEMO_VIDEOS, type MediaItem } from "@/lib/catalog";

export const dynamic = "force-dynamic";

async function spotifyPlaylists(): Promise<MediaItem[]> {
  const json = await apiFetch("spotify", "/me/playlists", { limit: "20" });
  if (!json?.items) return [];
  return json.items.map((p: any) => ({
    id: `spp-${p.id}`,
    provider: "spotify" as Provider,
    kind: "playlist" as const,
    externalId: p.id,
    title: p.name,
    subtitle: p.owner?.display_name ?? "Spotify",
    detail: `${p.tracks?.total ?? 0} قطعه`,
    artwork: p.images?.[0]?.url ?? null,
    itemCount: p.tracks?.total ?? 0,
  }));
}

async function youtubePlaylists(): Promise<MediaItem[]> {
  const json = await apiFetch("youtube", "/playlists", {
    part: "snippet,contentDetails",
    mine: "true",
    maxResults: "20",
  });
  if (!json?.items) return [];
  return json.items.map((p: any) => ({
    id: `ytp-${p.id}`,
    provider: "youtube" as Provider,
    kind: "playlist" as const,
    externalId: p.id,
    title: p.snippet?.title ?? "بدون عنوان",
    subtitle: p.snippet?.channelTitle ?? "YouTube",
    detail: `${p.contentDetails?.itemCount ?? 0} ویدیو`,
    artwork: p.snippet?.thumbnails?.medium?.url ?? null,
    itemCount: p.contentDetails?.itemCount ?? 0,
  }));
}

async function playlistItems(provider: Provider, id: string): Promise<MediaItem[]> {
  if (provider === "spotify") {
    const json = await apiFetch("spotify", `/playlists/${id}/tracks`, { limit: "30" });
    if (!json?.items) return [];
    return json.items.map((row: any) => {
      const t = row.track;
      return {
        id: `sp-${t?.id}`,
        provider: "spotify" as Provider,
        kind: "track" as const,
        externalId: t?.id ?? "",
        title: t?.name ?? "—",
        subtitle: (t?.artists ?? []).map((a: any) => a.name).join("، "),
        detail: t?.album?.name ?? "",
        artwork: t?.album?.images?.[0]?.url ?? null,
        durationMs: t?.duration_ms ?? null,
      };
    });
  }
  const json = await apiFetch("youtube", "/playlistItems", {
    part: "snippet,contentDetails",
    playlistId: id,
    maxResults: "30",
  });
  if (!json?.items) return [];
  return json.items.map((i: any) => {
    const vid = i.contentDetails?.videoId ?? i.snippet?.resourceId?.videoId;
    return {
      id: `yt-${vid}`,
      provider: "youtube" as Provider,
      kind: "video" as const,
      externalId: vid,
      title: i.snippet?.title ?? "بدون عنوان",
      subtitle: i.snippet?.videoOwnerChannelTitle ?? i.snippet?.channelTitle ?? "YouTube",
      artwork: i.snippet?.thumbnails?.medium?.url ?? null,
    };
  });
}

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const provider = (sp.get("provider") ?? "spotify") as Provider;
  const id = sp.get("id");
  const live = await isLive(provider);

  if (id) {
    let items: MediaItem[] = [];
    if (live) {
      try {
        items = await playlistItems(provider, id);
      } catch {
        items = [];
      }
    }
    if (!items.length) {
      items = (provider === "youtube" ? DEMO_VIDEOS : DEMO_TRACKS).slice(0, 8);
    }
    return NextResponse.json({ provider, id, items, live });
  }

  let items: MediaItem[] = [];
  if (live) {
    try {
      items =
        provider === "youtube" ? await youtubePlaylists() : await spotifyPlaylists();
    } catch {
      items = [];
    }
  }
  if (!items.length) items = DEMO_PLAYLISTS[provider] ?? [];
  return NextResponse.json({ provider, items, live });
}
