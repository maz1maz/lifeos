import { NextResponse } from "next/server";
import { DEMO_SUGGESTIONS, DEMO_STATS, type MediaItem } from "@/lib/catalog";
import { fa } from "@/lib/format";
import { getStats } from "@/lib/store";
import { isLive, apiFetch } from "@/lib/providers";

export const dynamic = "force-dynamic";

type Suggestion = {
  id: string;
  reason: string;
  item: MediaItem;
};

export async function GET() {
  const [stats, spLive, ytLive] = await Promise.all([
    getStats(),
    isLive("spotify"),
    isLive("youtube"),
  ]);

  const reasons = [
    `چون ${fa(stats.topShare)}٪ از گوش‌دادنِ این ماه مالِ ${stats.topArtist} بود`,
    `چون ${fa(stats.plays30d)} قطعه در سی روز گذشته پخش کرده‌ای و ریتمِ شبانه داری`,
    `چون ویدیوهای زنده را تا انتها می‌بینی`,
    `چون این پلی‌لیست را دو هفته است باز نکرده‌ای`,
  ];

  let suggestions: Suggestion[] = DEMO_SUGGESTIONS.map((s, i) => ({
    id: s.id,
    reason: reasons[i % reasons.length],
    item: {
      id: s.id,
      provider: s.provider,
      kind: s.kind,
      externalId: s.externalId,
      title: s.title,
      subtitle: s.subtitle,
      detail: s.detail,
      views: (s as { views?: number }).views ?? null,
    },
  }));

  // When a real Spotify account is attached, mix in a real recommendation
  // seeded from the top artist of the last 30 days.
  if (spLive) {
    try {
      const json = await apiFetch("spotify", "/search", {
        q: `artist:${stats.topArtist}`,
        type: "track",
        limit: "3",
      });
      const liveItems: Suggestion[] = (json?.tracks?.items ?? []).map(
        (t: any, i: number) => ({
          id: `live-sg-${t.id}`,
          reason: `پیشنهاد زنده از Spotify · چون ${stats.topArtist} پرتکرارترین صدای ماه است`,
          item: {
            id: `sp-${t.id}`,
            provider: "spotify" as const,
            kind: "track" as const,
            externalId: t.id,
            title: t.name,
            subtitle: (t.artists ?? []).map((a: any) => a.name).join("، "),
            detail: t.album?.name ?? "",
            artwork: t.album?.images?.[0]?.url ?? null,
            durationMs: t.duration_ms ?? null,
          },
        }),
      );
      if (liveItems.length) suggestions = [...liveItems, ...suggestions];
    } catch {
      /* keep demo suggestions */
    }
  }

  void ytLive;

  return NextResponse.json({
    suggestions: suggestions.slice(0, 5),
    baseline: DEMO_STATS,
  });
}
