import { NextRequest, NextResponse } from "next/server";
import {
  accountLabel,
  deleteConnection,
  getConnection,
  providerConfig,
  type Provider,
} from "@/lib/providers";
import { db } from "@/db";
import { syncLog } from "@/db/schema";

export const dynamic = "force-dynamic";

async function state(provider: Provider) {
  const cfg = providerConfig(provider);
  let row = null;
  try {
    row = await getConnection(provider);
  } catch {
    row = null;
  }
  const connected = Boolean(row?.accessToken);
  let label = null;
  if (connected) {
    try {
      const { connections } = await import("@/db/schema");
      const { eq } = await import("drizzle-orm");
      const rows = await db
        .select()
        .from(connections)
        .where(eq(connections.provider, provider))
        .limit(1);
      label = rows[0]?.accountLabel ?? null;
    } catch {
      label = null;
    }
    if (!label) label = await accountLabel(provider);
  }
  return {
    provider,
    connected,
    configured: cfg.configured,
    label,
    scopes: cfg.scopes.split(" "),
  };
}

export async function GET() {
  const [spotify, youtube] = await Promise.all([
    state("spotify"),
    state("youtube"),
  ]);
  return NextResponse.json({ spotify, youtube });
}

export async function DELETE(req: NextRequest) {
  const provider = (req.nextUrl.searchParams.get("provider") ?? "") as Provider;
  if (provider !== "spotify" && provider !== "youtube") {
    return NextResponse.json({ ok: false, error: "bad provider" }, { status: 400 });
  }
  await deleteConnection(provider);
  try {
    await db.insert(syncLog).values({
      level: "info",
      provider,
      message: `حساب ${provider === "spotify" ? "Spotify" : "YouTube"} قطع شد`,
    });
  } catch {
    /* ignore */
  }
  return NextResponse.json({ ok: true });
}
