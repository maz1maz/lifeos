import { NextRequest, NextResponse } from "next/server";
import { apiFetch, isLive, type Provider } from "@/lib/providers";
import {
  DEMO_PLAYLISTS,
  DEMO_TRACKS,
  DEMO_VIDEOS,
  type MediaItem,
} from "@/lib/catalog";

export const dynamic = "force-dynamic";

function norm(s: string) {
  return s
    .toLowerCase()
    .replace(/[يی]/g, "ی")
    .replace(/[كک]/g, "ک")
    .replace(/[\u064B-\u065F]/g, "")
    .trim();
}

function demoSearch(q: string, provider: Provider): MediaItem[] {
  const pool =
    provider === "spotify"
      ? DEMO_TRACKS
      : provider === "youtube"
        ? DEMO_VIDEOS
        : [...DEMO_TRACKS, ...DEMO_VIDEOS];
  const playlists =
    provider === "youtube"
      ? DEMO_PLAYLISTS.youtube
      : provider === "spotify"
        ? DEMO_PLAYLISTS.spotify
        : [...DEMO_PLAYLISTS.spotify, ...DEMO_PLAYLISTS.youtube];
  if (!q.trim()) return [...pool, ...playlists];
  const n = norm(q);
  return [...pool, ...playlists].filter((item) =>
    norm(`${item.title} ${item.subtitle} ${item.detail ?? ""}`).includes(n),
  );
}

async function spotifySearch(q: string): Promise<MediaItem[]> {
  const json = await apiFetch("spotify", "/search", {
    q,
    type: "track,playlist",
    limit: "12",
    market: "from_token",
  });
  if (!json) return [];
  const items: MediaItem[] = [];
  (json.tracks?.items ?? []).forEach((t: any) => {
    items.push({
      id: `sp-${t.id}`,
      provider: "spotify",
      kind: "track",
      externalId: t.id,
      title: t.name,
      subtitle: (t.artists ?? []).map((a: any) => a.name).join("، "),
      detail: `${t.album?.name ?? ""} · ${Math.round((t.duration_ms ?? 0) / 60000)} دقیقه`,
      artwork: t.album?.images?.[0]?.url ?? null,
      durationMs: t.duration_ms ?? null,
    });
  });
  (json.playlists?.items ?? []).filter(Boolean).forEach((p: any) => {
    items.push({
      id: `spp-${p.id}`,
      provider: "spotify",
      kind: "playlist",
      externalId: p.id,
      title: p.name,
      subtitle: p.owner?.display_name ?? "Spotify",
      detail: `${p.tracks?.total ?? 0} قطعه`,
      artwork: p.images?.[0]?.url ?? null,
      itemCount: p.tracks?.total ?? 0,
    });
  });
  return items;
}

async function youtubeSearch(q: string): Promise<MediaItem[]> {
  const json = await apiFetch("youtube", "/search", {
    part: "snippet",
    q,
    type: "video,playlist",
    maxResults: "12",
  });
  if (!json) return [];
  const ids = (json.items ?? [])
    .map((i: any) => i.id?.videoId)
    .filter(Boolean)
    .join(",");
  const stats = ids
    ? await apiFetch("youtube", "/videos", {
        part: "statistics,contentDetails",
        id: ids,
      })
    : null;
  const statMap = new Map<string, any>();
  (stats?.items ?? []).forEach((v: any) => statMap.set(v.id, v));
  const out: MediaItem[] = [];
  (json.items ?? []).forEach((i: any) => {
    const vid = i.id?.videoId;
    const plid = i.id?.playlistId;
    const stat = vid ? statMap.get(vid) : null;
    out.push({
      id: `yt-${vid ?? plid}`,
      provider: "youtube",
      kind: vid ? "video" : "playlist",
      externalId: vid ?? plid,
      title: i.snippet?.title ?? "بدون عنوان",
      subtitle: i.snippet?.channelTitle ?? "YouTube",
      detail: i.snippet?.publishedAt
        ? new Date(i.snippet.publishedAt).toLocaleDateString("fa-IR")
        : undefined,
      artwork: i.snippet?.thumbnails?.medium?.url ?? null,
      views: stat ? Number(stat.statistics?.viewCount ?? 0) : null,
      durationMs: null,
    });
  });
  return out;
}

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const q = sp.get("q") ?? "";
  const provider = (sp.get("provider") ?? "all") as Provider | "all";

  const wantsSpotify = provider === "all" || provider === "spotify";
  const wantsYoutube = provider === "all" || provider === "youtube";

  const [spLive, ytLive] = await Promise.all([
    wantsSpotify ? isLive("spotify") : Promise.resolve(false),
    wantsYoutube ? isLive("youtube") : Promise.resolve(false),
  ]);

  let items: MediaItem[] = [];
  const sources: string[] = [];

  if (wantsSpotify) {
    const res = spLive && q ? await spotifySearch(q) : demoSearch(q, "spotify");
    items = items.concat(res);
    sources.push(spLive && q ? "spotify-live" : "spotify-demo");
  }
  if (wantsYoutube) {
    const res = ytLive && q ? await youtubeSearch(q) : demoSearch(q, "youtube");
    items = items.concat(res);
    sources.push(ytLive && q ? "youtube-live" : "youtube-demo");
  }

  return NextResponse.json({
    query: q,
    items,
    sources,
    live: { spotify: spLive, youtube: ytLive },
  });
}
