import { NextRequest, NextResponse } from "next/server";
import {
  buildAuthorizeUrl,
  pkcePair,
  providerConfig,
  randomString,
  type Provider,
} from "@/lib/providers";

const ALLOWED: Provider[] = ["spotify", "youtube"];

export async function GET(
  req: NextRequest,
  ctx: { params: Promise<{ provider: string }> },
) {
  const { provider: raw } = await ctx.params;
  const provider = raw as Provider;
  const origin = new URL(req.url).origin;

  if (!ALLOWED.includes(provider)) {
    return NextResponse.redirect(`${origin}/?notice=badprovider`);
  }

  const cfg = providerConfig(provider);
  if (!cfg.configured) {
    return NextResponse.redirect(`${origin}/?notice=nokeys&provider=${provider}`);
  }

  const { verifier, challenge } = await pkcePair();
  const state = randomString(16);
  const url = await buildAuthorizeUrl(provider, { state, codeChallenge: challenge });

  const res = NextResponse.redirect(url);
  res.cookies.set(`lo_verifier_${provider}`, verifier, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 600,
  });
  res.cookies.set(`lo_state_${provider}`, state, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 600,
  });
  return res;
}
