import { NextRequest, NextResponse } from "next/server";
import { accountLabel, exchangeCode, saveTokens, type Provider } from "@/lib/providers";
import { db } from "@/db";
import { syncLog } from "@/db/schema";

const ALLOWED: Provider[] = ["spotify", "youtube"];

export async function GET(
  req: NextRequest,
  ctx: { params: Promise<{ provider: string }> },
) {
  const { provider: raw } = await ctx.params;
  const provider = raw as Provider;
  const url = new URL(req.url);
  const origin = url.origin;

  if (!ALLOWED.includes(provider)) {
    return NextResponse.redirect(`${origin}/?notice=badprovider`);
  }

  const error = url.searchParams.get("error");
  if (error) {
    return NextResponse.redirect(
      `${origin}/?notice=denied&provider=${provider}&detail=${encodeURIComponent(error)}`,
    );
  }

  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const expected = req.cookies.get(`lo_state_${provider}`)?.value;
  const verifier = req.cookies.get(`lo_verifier_${provider}`)?.value;

  if (!code || !state || state !== expected || !verifier) {
    return NextResponse.redirect(`${origin}/?notice=stale&provider=${provider}`);
  }

  try {
    const tokens = await exchangeCode(provider, code, verifier);
    await saveTokens(provider, {
      accessToken: tokens.access_token,
      refreshToken: tokens.refresh_token ?? null,
      expiresIn: tokens.expires_in ?? 3600,
      scopes: tokens.scope ?? undefined,
    });
    const label = await accountLabel(provider);
    if (label) {
      const { connections } = await import("@/db/schema");
      const { eq } = await import("drizzle-orm");
      await db
        .update(connections)
        .set({ accountLabel: label })
        .where(eq(connections.provider, provider));
    }
    await db.insert(syncLog).values({
      level: "ok",
      provider,
      message: `حساب ${provider === "spotify" ? "Spotify" : "YouTube"} متصل شد${
        label ? `: ${label}` : ""
      }`,
    });
    const res = NextResponse.redirect(`${origin}/?notice=connected&provider=${provider}`);
    res.cookies.delete(`lo_verifier_${provider}`);
    res.cookies.delete(`lo_state_${provider}`);
    return res;
  } catch (e) {
    const detail = e instanceof Error ? e.message.slice(0, 120) : "unknown";
    await db
      .insert(syncLog)
      .values({
        level: "error",
        provider,
        message: `خطا در اتصال: ${detail}`,
      })
      .catch(() => undefined);
    return NextResponse.redirect(
      `${origin}/?notice=failed&provider=${provider}&detail=${encodeURIComponent(detail)}`,
    );
  }
}
