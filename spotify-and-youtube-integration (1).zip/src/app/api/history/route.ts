import { NextRequest, NextResponse } from "next/server";
import { apiFetch, isLive, type Provider } from "@/lib/providers";
import { recentFor, logPlay } from "@/lib/store";
import type { MediaItem } from "@/lib/catalog";

export const dynamic = "force-dynamic";

async function spotifyRecent(): Promise<MediaItem[]> {
  const json = await apiFetch("spotify", "/me/player/recently-played", { limit: "24" });
  if (!json?.items) return [];
  return json.items.map((row: any) => {
    const t = row.track;
    return {
      id: `sp-${t.id}-${row.played_at}`,
      provider: "spotify" as Provider,
      kind: "track" as const,
      externalId: t.id,
      title: t.name,
      subtitle: (t.artists ?? []).map((a: any) => a.name).join("، "),
      detail: t.album?.name ?? "",
      artwork: t.album?.images?.[0]?.url ?? null,
      durationMs: t.duration_ms ?? null,
      playedAt: row.played_at ?? null,
      context: "Spotify",
    } as MediaItem;
  });
}

async function youtubeRecent(): Promise<MediaItem[]> {
  let json = await apiFetch("youtube", "/playlistItems", {
    part: "snippet,contentDetails",
    playlistId: "HL",
    maxResults: "24",
  });
  if (!json?.items?.length) {
    json = await apiFetch("youtube", "/activities", {
      part: "snippet,contentDetails",
      mine: "true",
      maxResults: "24",
    });
  }
  if (!json?.items) return [];
  const ids = json.items
    .map((i: any) => i.contentDetails?.upload?.videoId ?? i.contentDetails?.playlistItem?.resourceId?.videoId)
    .filter(Boolean)
    .join(",");
  const stats = ids
    ? await apiFetch("youtube", "/videos", { part: "statistics", id: ids })
    : null;
  const statMap = new Map<string, number>();
  (stats?.items ?? []).forEach((v: any) =>
    statMap.set(v.id, Number(v.statistics?.viewCount ?? 0)),
  );
  return json.items
    .map((i: any) => {
      const vid =
        i.contentDetails?.upload?.videoId ??
        i.contentDetails?.playlistItem?.resourceId?.videoId ??
        i.contentDetails?.videoId;
      if (!vid) return null;
      return {
        id: `yt-${vid}-${i.snippet?.publishedAt ?? ""}`,
        provider: "youtube" as Provider,
        kind: "video" as const,
        externalId: vid,
        title: i.snippet?.title ?? "بدون عنوان",
        subtitle: i.snippet?.videoOwnerChannelTitle ?? i.snippet?.channelTitle ?? "YouTube",
        detail: i.snippet?.publishedAt
          ? new Date(i.snippet.publishedAt).toLocaleDateString("fa-IR")
          : undefined,
        artwork: i.snippet?.thumbnails?.medium?.url ?? null,
        views: statMap.get(vid) ?? null,
        playedAt: i.snippet?.publishedAt ?? null,
        context: "YouTube",
      } as MediaItem;
    })
    .filter(Boolean) as MediaItem[];
}

export async function GET(req: NextRequest) {
  const provider = (req.nextUrl.searchParams.get("provider") ?? "spotify") as Provider;
  const live = await isLive(provider);
  let items: MediaItem[] = [];
  if (live) {
    try {
      items =
        provider === "spotify" ? await spotifyRecent() : await youtubeRecent();
    } catch {
      items = [];
    }
  }
  if (!items.length) items = await recentFor(provider, 12);
  return NextResponse.json({ provider, items, live });
}

export async function POST(req: NextRequest) {
  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "bad request" }, { status: 400 });
  }
  const item = body?.item as MediaItem | undefined;
  if (!item?.title || !item?.provider) {
    return NextResponse.json({ ok: false, error: "bad request" }, { status: 400 });
  }
  const msPlayed = Number(body?.msPlayed ?? 0);
  const ok = await logPlay(
    {
      ...item,
      kind: item.kind ?? (item.provider === "youtube" ? "video" : "track"),
      externalId: item.externalId ?? item.id ?? "unknown",
    },
    Number.isFinite(msPlayed) ? msPlayed : 0,
    String(body?.origin ?? "demo"),
  );
  return NextResponse.json({ ok, registered: ok });
}
