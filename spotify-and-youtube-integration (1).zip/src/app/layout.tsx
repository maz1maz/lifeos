import type { Metadata } from "next";
import type { ReactNode } from "react";
import { IBM_Plex_Mono, Vazirmatn } from "next/font/google";
import "./globals.css";

const vazir = Vazirmatn({
  subsets: ["arabic"],
  variable: "--font-vazir",
  weight: ["300", "400", "500", "700", "800", "900"],
  display: "swap",
});

const plex = IBM_Plex_Mono({
  subsets: ["latin"],
  variable: "--font-plex",
  weight: ["400", "500", "600"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "میزِ رسانه — Spotify و YouTube در سایت شخصی",
  description:
    "دستگاهِ شخصی برای اتصال به Spotify و YouTube: پخش، تاریخچه‌ی پخش و تماشا، پلی‌لیست‌ها، آمار و پیشنهادها — همه در یک صفحه.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html
      lang="fa"
      dir="rtl"
      className={`${vazir.variable} ${plex.variable}`}
    >
      <body className="bg-deck font-sans text-cream antialiased">{children}</body>
    </html>
  );
}
