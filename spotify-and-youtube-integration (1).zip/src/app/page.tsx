import Hub from "@/components/Hub";
import { db } from "@/db";
import { connections } from "@/db/schema";
import {
  DEMO_PLAYLISTS,
  DEMO_SUGGESTIONS,
  type MediaItem,
  type Provider,
} from "@/lib/catalog";
import { fa } from "@/lib/format";
import { getConnection, providerConfig } from "@/lib/providers";
import {
  getLog,
  getSaved,
  getSavedKeys,
  getStats,
  recentFor,
} from "@/lib/store";

export const dynamic = "force-dynamic";

const NOTICE_TEXT: Record<string, string> = {
  connected: "حساب متصل شد — داده‌ها همگام می‌شوند.",
  denied: "دسترسی لغو شد. برای ادامه دوباره اتصال را بزنید.",
  stale: "نشست منقضی شده است؛ لطفاً دوباره اتصال را برقرار کنید.",
  failed: "خطا در برقراریِ اتصال. کلیدها و نشانیِ بازگشت را در .env بررسی کنید.",
  nokeys: "کلیدِ API تنظیم نشده است؛ حالتِ نمایشی فعال می‌ماند.",
  badprovider: "سرویسِ ناشناخته.",
};

type Row0 = { provider: string; accountLabel: string | null };

function buildSuggestions(stats: {
  topArtist: string;
  topShare: number;
  plays30d: number;
}) {
  const reasons = [
    `چون ${fa(stats.topShare)}٪ از گوش‌دادنِ این ماه مالِ ${stats.topArtist} بود`,
    `چون ${fa(stats.plays30d)} قطعه در سی روزِ گذشته پخش کرده‌ای و ریتمِ شبانه داری`,
    `چون ویدیوهای زنده را تا انتها می‌بینی`,
    `چون این پلی‌لیست را دو هفته است باز نکرده‌ای`,
  ];
  return DEMO_SUGGESTIONS.map((s, i) => ({
    id: s.id,
    reason: reasons[i % reasons.length],
    item: {
      id: s.id,
      provider: s.provider,
      kind: s.kind,
      externalId: s.externalId,
      title: s.title,
      subtitle: s.subtitle,
      detail: s.detail,
      views: (s as { views?: number }).views ?? null,
    } as MediaItem,
  }));
}

async function connectionStates() {
  let rows: Row0[] = [];
  try {
    rows = (await db.select().from(connections)) as unknown as Row0[];
  } catch {
    rows = [];
  }
  const label = (p: Provider) =>
    rows.find((r) => r.provider === p)?.accountLabel ?? null;
  const build = async (p: Provider) => {
    const cfg = providerConfig(p);
    let connected = false;
    try {
      const row = await getConnection(p);
      connected = Boolean(row?.accessToken);
    } catch {
      connected = false;
    }
    return {
      provider: p,
      connected,
      configured: cfg.configured,
      label: label(p),
    };
  };
  const [spotify, youtube] = await Promise.all([build("spotify"), build("youtube")]);
  return { spotify, youtube };
}

export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ notice?: string; provider?: string; detail?: string }>;
}) {
  const params = await searchParams;
  const noticeKey = params.notice;

  const [recentSpotify, recentYoutube, saved, savedKeys, stats, log, connectionsState] =
    await Promise.all([
      recentFor("spotify", 12),
      recentFor("youtube", 12),
      getSaved(),
      getSavedKeys(),
      getStats(),
      getLog(6),
      connectionStates(),
    ]);

  // ستونِ خوراک با سرویسِ پیش‌فرض (Spotify) پر می‌شود؛ با تعویضِ تب تازه می‌شود.
  const recent: MediaItem[] = recentSpotify.length ? recentSpotify : recentYoutube;
  const playlists: MediaItem[] = DEMO_PLAYLISTS.spotify;

  const notice = noticeKey
    ? {
        level: (noticeKey === "connected" ? "ok" : noticeKey === "badprovider" || noticeKey === "failed" || noticeKey === "denied" ? "error" : "info") as
          | "ok"
          | "info"
          | "error",
        message:
          `${NOTICE_TEXT[noticeKey] ?? "آماده."}` +
          (params.provider
            ? ` (${params.provider === "spotify" ? "Spotify" : "YouTube"})`
            : "") +
          (params.detail ? ` — ${params.detail}` : ""),
      }
    : null;

  const suggestions = buildSuggestions(stats);

  return (
    <Hub
      initial={{
        recent,
        playlists,
        saved,
        savedKeys,
        stats,
        suggestions,
        log,
        connections: connectionsState,
      }}
      notice={notice}
    />
  );
}
