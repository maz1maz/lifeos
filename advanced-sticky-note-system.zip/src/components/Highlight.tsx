import type { ReactNode } from "react";

/** Wraps every case-insensitive hit of `query` in a marker stroke. */
export function Highlight({
  text,
  query,
  className = "",
}: {
  text: string;
  query: string;
  className?: string;
}): ReactNode {
  const q = query.trim();
  if (!q) return <span className={className}>{text}</span>;

  const hay = text.toLowerCase();
  const needle = q.toLowerCase();
  const out: ReactNode[] = [];
  let i = 0;
  let key = 0;

  while (i < text.length) {
    const at = hay.indexOf(needle, i);
    if (at === -1) {
      out.push(text.slice(i));
      break;
    }
    if (at > i) out.push(text.slice(i, at));
    out.push(
      <mark className="hit" key={key++}>
        {text.slice(at, at + needle.length)}
      </mark>,
    );
    i = at + needle.length;
  }

  return <span className={className}>{out}</span>;
}
