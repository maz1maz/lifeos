"use client";

import { useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ImagePlus, Loader2, Paperclip, Pin, X, Check } from "lucide-react";

import { createNote, fetchNotes, updateNote } from "@/app/actions";
import { bytes, isImage, readFiles } from "@/lib/format";
import {
  COLORS,
  MAX_FILES_PER_NOTE,
  MAX_FILE_BYTES,
  colorOf,
  type NoteDTO,
  type PendingFile,
} from "@/lib/types";

type Props = {
  editing: NoteDTO | null;
  onCloseEdit: () => void;
  onSaved: (notes: NoteDTO[]) => void;
};

export default function Composer({ editing, onCloseEdit, onSaved }: Props) {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [color, setColor] = useState("sky");
  const [tags, setTags] = useState<string[]>([]);
  const [tagDraft, setTagDraft] = useState("");
  const [pinned, setPinned] = useState(false);
  const [files, setFiles] = useState<PendingFile[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [dragging, setDragging] = useState(false);
  const titleRef = useRef<HTMLInputElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const loadedEditingId = useRef<string | null>(null);

  // hydrate the form whenever we enter edit mode
  if (editing && loadedEditingId.current !== editing.id) {
    loadedEditingId.current = editing.id;
    setTitle(editing.title);
    setBody(editing.body);
    setColor(editing.color);
    setTags(editing.tags);
    setPinned(editing.pinned);
    setFiles(editing.attachments.map(({ name, mime, size, data }) => ({ name, mime, size, data })));
    setError(null);
  }
  function clearForm() {
    setTitle("");
    setBody("");
    setColor("sky");
    setTags([]);
    setTagDraft("");
    setPinned(false);
    setFiles([]);
    setError(null);
  }

  // leaving edit mode wipes the draft so a stray save cannot duplicate a note
  if (!editing && loadedEditingId.current !== null) {
    loadedEditingId.current = null;
    clearForm();
  }

  function reset() {
    clearForm();
    loadedEditingId.current = null;
  }

  function addTag(raw: string) {
    const value = raw.trim().replace(/^#/, "");
    if (!value) return;
    setTags((prev) =>
      prev.includes(value) || prev.length >= 8 ? prev : [...prev, value],
    );
    setTagDraft("");
  }

  async function ingest(list: FileList | File[] | null) {
    if (!list) return;
    const incoming = Array.from(list);
    if (!incoming.length) return;
    const room = MAX_FILES_PER_NOTE - files.length;
    if (room <= 0) {
      setError(`حداکثر ${MAX_FILES_PER_NOTE} پیوست برای هر یادداشت.`);
      return;
    }
    const tooBig = incoming.find((f) => f.size > MAX_FILE_BYTES);
    if (tooBig) {
      setError(`حجم «${tooBig.name}» بیشتر از ۴ مگابایت است.`);
      return;
    }
    try {
      const read = await readFiles(incoming.slice(0, room));
      setError(null);
      setFiles((prev) => [...prev, ...read]);
    } catch {
      setError("خواندن فایل(ها) ناموفق بود.");
    }
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) {
      setError("عنوان یادداشت را بنویسید.");
      titleRef.current?.focus();
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const payload = { title, body, color, tags, pinned };
      const res = editing
        ? await updateNote(editing.id, payload, files)
        : await createNote(payload, files);
      if (!res.ok) {
        setError(res.error);
      } else {
        const fresh = await fetchNotes();
        onSaved(fresh);
        reset();
      }
    } catch {
      setError("ذخیره‌سازی ناموفق بود. دوباره تلاش کنید.");
    } finally {
      setBusy(false);
    }
  }

  const active = colorOf(color);

  return (
    <form
      onSubmit={submit}
      className="relative overflow-hidden rounded-2xl border border-line bg-panel/90 shadow-[0_24px_60px_-30px_rgba(0,0,0,0.9)] backdrop-blur"
    >
      <div
        className="absolute inset-x-0 top-0 h-px"
        style={{ background: `linear-gradient(90deg, transparent, ${active.hex}, transparent)` }}
      />

      <div className="flex items-center justify-between gap-3 border-b border-line px-5 py-4">
        <div>
          <div className="mono-label text-cyan/70">
            {editing ? "EDIT / ویرایش" : "NEW / یادداشت تازه"}
          </div>
          <h2 className="mt-1 text-2xl font-black tracking-tight">
            {editing ? "ویرایش" : "افزودن"}
          </h2>
        </div>
        <span
          className="h-9 w-9 rounded-lg border border-white/10"
          style={{ background: active.hex, boxShadow: `0 0 22px -6px ${active.hex}` }}
          aria-hidden
        />
      </div>

      <div className="space-y-4 px-5 py-5">
        <div>
          <label htmlFor="note-title" className="mono-label mb-2 block text-mute">
            TITLE / عنوان
          </label>
          <input
            id="note-title"
            ref={titleRef}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="عنوان…"
            maxLength={140}
            className="w-full rounded-lg border border-line bg-ink-2 px-4 py-3 text-base font-bold placeholder:font-normal placeholder:text-mute/70 focus:border-cyan focus:outline-none"
          />
        </div>

        <div>
          <label className="mono-label mb-2 block text-mute">TAGS / برچسب‌ها</label>
          <div className="flex flex-wrap items-center gap-2 rounded-lg border border-line bg-ink-2 px-3 py-2">
            <AnimatePresence initial={false}>
              {tags.map((tag) => (
                <motion.span
                  key={tag}
                  initial={{ opacity: 0, scale: 0.85 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.85 }}
                  className="inline-flex items-center gap-1 rounded-md bg-cyan/15 px-2 py-1 text-xs font-medium text-cyan ring-1 ring-cyan/30"
                >
                  #{tag}
                  <button
                    type="button"
                    aria-label={`حذف برچسب ${tag}`}
                    onClick={() => setTags((p) => p.filter((t) => t !== tag))}
                    className="text-cyan/60 transition hover:text-cyan"
                  >
                    <X size={12} />
                  </button>
                </motion.span>
              ))}
            </AnimatePresence>
            <input
              value={tagDraft}
              onChange={(e) => setTagDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === ",") {
                  e.preventDefault();
                  addTag(tagDraft);
                }
                if (e.key === "Backspace" && !tagDraft) setTags((p) => p.slice(0, -1));
              }}
              onBlur={() => addTag(tagDraft)}
              placeholder={tags.length ? "" : "کلید Enter برای برچسب"}
              className="min-w-24 flex-1 bg-transparent py-1 text-sm placeholder:text-mute/70 focus:outline-none"
            />
          </div>
        </div>

        <div>
          <span className="mono-label mb-2 block text-mute">COLOR / رنگ</span>
          <div className="flex flex-wrap gap-2">
            {COLORS.map((c) => {
              const on = c.key === color;
              return (
                <button
                  key={c.key}
                  type="button"
                  onClick={() => setColor(c.key)}
                  aria-pressed={on}
                  title={c.label}
                  className={`group flex items-center gap-2 rounded-md border px-2.5 py-1.5 text-xs transition ${
                    on
                      ? "border-white/25 bg-white/10 text-chalk"
                      : "border-line bg-ink-2 text-mute hover:border-mute/50 hover:text-chalk"
                  }`}
                >
                  <span
                    className="h-3.5 w-3.5 rounded-sm"
                    style={{ background: c.hex, boxShadow: on ? `0 0 12px -2px ${c.hex}` : undefined }}
                  />
                  {c.label}
                  {on && <Check size={12} className="text-cyan" />}
                </button>
              );
            })}
          </div>
        </div>

        <button
          type="button"
          onClick={() => setPinned((p) => !p)}
          aria-pressed={pinned}
          className={`flex w-full items-center justify-between rounded-lg border px-4 py-3 text-sm transition ${
            pinned
              ? "border-amber/40 bg-amber/10 text-amber"
              : "border-line bg-ink-2 text-mute hover:text-chalk"
          }`}
        >
          <span className="flex items-center gap-2">
            <Pin size={15} />
            سنجاق شود بالای فهرست
          </span>
          <span
            className={`relative h-5 w-9 rounded-full transition ${pinned ? "bg-amber" : "bg-line"}`}
          >
            <span
              className="absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all"
              style={{ right: pinned ? "1.125rem" : "0.125rem" }}
            />
          </span>
        </button>

        <div>
          <label htmlFor="note-body" className="mono-label mb-2 block text-mute">
            BODY / متن
          </label>
          <textarea
            id="note-body"
            value={body}
            onChange={(e) => setBody(e.target.value)}
            placeholder="متن یادداشت…"
            rows={6}
            className="w-full rounded-lg border border-line bg-ink-2 px-4 py-3 text-sm leading-7 placeholder:text-mute/70 focus:border-cyan focus:outline-none"
          />
        </div>

        {/* attachments */}
        <div>
          <span className="mono-label mb-2 block text-mute">
            FILES / پیوست ({files.length}/{MAX_FILES_PER_NOTE})
          </span>
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragging(false);
              void ingest(e.dataTransfer.files);
            }}
            className={`rounded-lg border border-dashed px-4 py-4 text-center transition ${
              dragging ? "border-cyan bg-cyan/10" : "border-line bg-ink-2"
            }`}
          >
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="mx-auto flex items-center gap-2 rounded-md border border-line bg-panel px-3 py-2 text-xs font-medium text-chalk transition hover:border-cyan hover:text-cyan"
            >
              <Paperclip size={13} />
              انتخاب فایل یا عکس
              <ImagePlus size={13} className="opacity-60" />
            </button>
            <p className="mt-2 text-[11px] text-mute">
              یا فایل را اینجا رها کنید — تا ۴ مگابایت برای هر فایل
            </p>
            <input
              ref={fileRef}
              type="file"
              multiple
              hidden
              onChange={(e) => {
                void ingest(e.target.files);
                e.target.value = "";
              }}
            />
          </div>

          <AnimatePresence initial={false}>
            {files.length > 0 && (
              <motion.ul
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-2 space-y-1.5 overflow-hidden"
              >
                {files.map((f, idx) => (
                  <li
                    key={`${f.name}-${idx}`}
                    className="flex items-center gap-3 rounded-md border border-line bg-ink-2 px-3 py-2"
                  >
                    {isImage(f.mime) ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={f.data} alt="" className="h-8 w-8 rounded object-cover" />
                    ) : (
                      <span className="grid h-8 w-8 place-items-center rounded bg-panel text-[9px] text-mute">
                        {f.name.split(".").pop()?.slice(0, 4).toUpperCase()}
                      </span>
                    )}
                    <span className="min-w-0 flex-1 truncate text-xs text-chalk">{f.name}</span>
                    <span className="tnum font-mono text-[10px] text-mute">{bytes(f.size)}</span>
                    <button
                      type="button"
                      aria-label={`حذف ${f.name}`}
                      onClick={() => setFiles((p) => p.filter((_, i) => i !== idx))}
                      className="text-mute transition hover:text-rose"
                    >
                      <X size={14} />
                    </button>
                  </li>
                ))}
              </motion.ul>
            )}
          </AnimatePresence>
        </div>

        {error && (
          <p className="rounded-md border border-rose/40 bg-rose/10 px-3 py-2 text-xs text-rose">
            {error}
          </p>
        )}

        <div className="flex gap-2 pt-1">
          <button
            type="submit"
            disabled={busy}
            className="relative flex flex-1 items-center justify-center gap-2 overflow-hidden rounded-lg bg-cyan px-4 py-3 text-base font-black text-[#04202b] transition hover:brightness-110 disabled:opacity-60"
            style={{ boxShadow: `0 14px 34px -18px ${active.hex}` }}
          >
            {busy && <Loader2 size={16} className="animate-spin" />}
            {busy ? "در حال ذخیره…" : editing ? "به‌روزرسانی" : "ذخیره"}
          </button>
          {editing && (
            <button
              type="button"
              onClick={() => {
                reset();
                onCloseEdit();
              }}
              className="rounded-lg border border-line px-4 py-3 text-sm text-mute transition hover:border-mute hover:text-chalk"
            >
              انصراف
            </button>
          )}
        </div>
      </div>
    </form>
  );
}
