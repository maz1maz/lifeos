"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { FileText, Paperclip, Pin, PinOff, Trash2 } from "lucide-react";

import { Highlight } from "@/components/Highlight";
import { bytes, isImage, shortDate } from "@/lib/format";
import { colorOf, type NoteDTO } from "@/lib/types";

type Props = {
  note: NoteDTO;
  query: string;
  selected: boolean;
  busy?: boolean;
  view: "grid" | "list";
  onSelect: (id: string) => void;
  onEdit: (note: NoteDTO) => void;
  onTogglePin: (note: NoteDTO) => void;
  onDelete: (id: string) => void;
};

export default function NoteCard({
  note,
  query,
  selected,
  busy = false,
  view,
  onSelect,
  onEdit,
  onTogglePin,
  onDelete,
}: Props) {
  const [confirm, setConfirm] = useState(false);
  const c = colorOf(note.color);
  const images = note.attachments.filter((a) => isImage(a.mime));
  const others = note.attachments.filter((a) => !isImage(a.mime));

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.97 }}
      transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
      onClick={() => onSelect(note.id)}
      onKeyDown={(e) => {
        if (e.key === "Enter") onSelect(note.id);
      }}
      tabIndex={0}
      role="button"
      aria-pressed={selected}
      aria-busy={busy}
      className={`group relative cursor-pointer overflow-hidden rounded-xl border bg-gradient-to-l from-panel to-panel-2/60 transition-all duration-200 hover:-translate-y-0.5 ${
        busy ? "pointer-events-none opacity-60" : ""
      } ${
        selected
          ? "border-cyan/60 shadow-[0_0_0_1px_rgba(34,211,238,0.35),0_24px_50px_-30px_rgba(0,0,0,0.9)]"
          : "border-line hover:border-mute/40"
      }`}
    >
      {/* colour spine */}
      <span
        aria-hidden
        className="absolute inset-y-0 right-0 w-[6px]"
        style={{ background: c.hex, boxShadow: `0 0 26px -4px ${c.hex}` }}
      />
      <span
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
        style={{ background: `radial-gradient(120% 70% at 100% 0%, ${c.wash}, transparent 60%)` }}
      />

      <div className="relative p-4 pr-5 sm:p-5 sm:pr-6">
        <header className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span
                className="h-2 w-2 shrink-0 rounded-full"
                style={{ background: c.hex }}
                aria-hidden
              />
              <span className="mono-label text-mute">
                #{note.id.slice(0, 4)} · {shortDate(note.updatedAt)}
              </span>
              {note.pinned && (
                <span className="inline-flex items-center gap-1 rounded bg-amber/15 px-1.5 py-0.5 text-[10px] font-bold text-amber">
                  <Pin size={10} />
                  سنجاق
                </span>
              )}
            </div>
            <h3 className="mt-1.5 truncate text-lg font-black leading-snug tracking-tight sm:text-xl">
              <Highlight text={note.title} query={query} />
            </h3>
          </div>

          <div
            className="flex shrink-0 items-center gap-1 opacity-0 transition-opacity focus-within:opacity-100 group-hover:opacity-100 max-md:opacity-100"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              title={note.pinned ? "برداشتن سنجاق" : "سنجاق کردن"}
              aria-label={note.pinned ? "برداشتن سنجاق" : "سنجاق کردن"}
              onClick={() => onTogglePin(note)}
              className={`grid h-8 w-8 place-items-center rounded-md border border-line bg-ink-2 transition hover:border-amber hover:text-amber ${
                note.pinned ? "text-amber" : "text-mute"
              }`}
            >
              {note.pinned ? <PinOff size={14} /> : <Pin size={14} />}
            </button>
            <button
              type="button"
              title="ویرایش"
              aria-label="ویرایش یادداشت"
              onClick={() => onEdit(note)}
              className="grid h-8 w-8 place-items-center rounded-md border border-line bg-ink-2 text-mute transition hover:border-cyan hover:text-cyan"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <path d="M12 20h9" />
                <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z" />
              </svg>
            </button>
            {confirm ? (
              <div className="flex items-center gap-1 rounded-md border border-rose/50 bg-rose/10 px-1.5 py-1">
                <button
                  type="button"
                  onClick={() => {
                    onDelete(note.id);
                    setConfirm(false);
                  }}
                  className="text-[11px] font-bold text-rose"
                >
                  حذف
                </button>
                <button
                  type="button"
                  onClick={() => setConfirm(false)}
                  className="text-[11px] text-mute"
                >
                  خیر
                </button>
              </div>
            ) : (
              <button
                type="button"
                title="حذف"
                aria-label="حذف یادداشت"
                onClick={() => setConfirm(true)}
                className="grid h-8 w-8 place-items-center rounded-md border border-line bg-ink-2 text-mute transition hover:border-rose hover:text-rose"
              >
                <Trash2 size={14} />
              </button>
            )}
          </div>
        </header>

        {note.tags.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-1.5">
            {note.tags.map((t) => (
              <span
                key={t}
                className="rounded border px-1.5 py-0.5 text-[11px]"
                style={{
                  color: c.hex,
                  borderColor: `${c.hex}44`,
                  background: c.wash,
                }}
              >
                #{t}
              </span>
            ))}
          </div>
        )}

        {note.body && (
          <p className={`mt-3 text-sm leading-7 text-chalk/70 ${view === "grid" ? "clamp-3" : "clamp-3"}`}>
            <Highlight text={note.body} query={query} />
          </p>
        )}

        {note.attachments.length > 0 && (
          <footer
            className="mt-4 flex flex-wrap items-center gap-2"
            onClick={(e) => e.stopPropagation()}
          >
            {images.slice(0, view === "grid" ? 3 : 4).map((img) => (
              <span key={img.id} className="relative block">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={img.data}
                  alt={img.name}
                  className="h-12 w-12 rounded-md border border-line object-cover transition hover:border-cyan"
                />
              </span>
            ))}
            {images.length > (view === "grid" ? 3 : 4) && (
              <span className="tnum grid h-12 w-12 place-items-center rounded-md border border-line bg-ink-2 text-[11px] text-mute">
                +{images.length - (view === "grid" ? 3 : 4)}
              </span>
            )}
            {others.slice(0, 2).map((f) => (
              <span
                key={f.id}
                className="flex max-w-40 items-center gap-1.5 rounded-md border border-line bg-ink-2 px-2 py-1.5 text-[11px] text-mute"
              >
                <FileText size={12} />
                <span className="truncate">{f.name}</span>
                <span className="tnum font-mono text-[9px] opacity-70">{bytes(f.size)}</span>
              </span>
            ))}
            <span className="mono-label ms-auto flex items-center gap-1 text-mute">
              <Paperclip size={11} />
              {note.attachments.length}
            </span>
          </footer>
        )}
      </div>
    </motion.article>
  );
}
