"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowDownUp,
  LayoutGrid,
  Plus,
  Rows3,
  Search,
  SlidersHorizontal,
  X,
} from "lucide-react";

import Composer from "@/components/Composer";
import Inspector from "@/components/Inspector";
import NoteCard from "@/components/NoteCard";
import { deleteNote, fetchNotes, togglePin } from "@/app/actions";
import { COLORS, colorOf, type NoteDTO } from "@/lib/types";
import { faNum } from "@/lib/format";

type SortKey = "updated" | "created" | "title";

export default function NoteApp({ initialNotes }: { initialNotes: NoteDTO[] }) {
  const [notes, setNotes] = useState<NoteDTO[]>(initialNotes);
  const [query, setQuery] = useState("");
  const [colorFilter, setColorFilter] = useState<string | null>(null);
  const [tagFilter, setTagFilter] = useState<string | null>(null);
  const [sort, setSort] = useState<SortKey>("updated");
  const [view, setView] = useState<"grid" | "list">("list");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [editing, setEditing] = useState<NoteDTO | null>(null);
  const [composerOpen, setComposerOpen] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const searchRef = useRef<HTMLInputElement>(null);

  const allTags = useMemo(() => {
    const set = new Map<string, number>();
    for (const n of notes) for (const t of n.tags) set.set(t, (set.get(t) ?? 0) + 1);
    return [...set.entries()].sort((a, b) => b[1] - a[1]);
  }, [notes]);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = notes.filter((n) => {
      if (colorFilter && n.color !== colorFilter) return false;
      if (tagFilter && !n.tags.includes(tagFilter)) return false;
      if (!q) return true;
      return (
        n.title.toLowerCase().includes(q) ||
        n.body.toLowerCase().includes(q) ||
        n.tags.some((t) => t.toLowerCase().includes(q))
      );
    });

    list = [...list].sort((a, b) => {
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
      if (sort === "title") return a.title.localeCompare(b.title, "fa");
      if (sort === "created") return +new Date(b.createdAt) - +new Date(a.createdAt);
      return +new Date(b.updatedAt) - +new Date(a.updatedAt);
    });
    return list;
  }, [notes, query, colorFilter, tagFilter, sort]);

  const selected = notes.find((n) => n.id === selectedId) ?? null;

  // keyboard: Ctrl/Cmd+K focuses search, Esc clears overlays
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        searchRef.current?.focus();
        searchRef.current?.select();
      }
      if (e.key === "Escape") {
        if (composerOpen) setComposerOpen(false);
        else if (editing) setEditing(null);
        else if (selectedId) setSelectedId(null);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [composerOpen, editing, selectedId]);

  async function refresh() {
    setNotes(await fetchNotes());
  }

  async function handleTogglePin(note: NoteDTO) {
    setBusyId(note.id);
    await togglePin(note.id, !note.pinned);
    await refresh();
    setBusyId(null);
  }

  async function handleDelete(id: string) {
    setBusyId(id);
    await deleteNote(id);
    if (selectedId === id) setSelectedId(null);
    if (editing?.id === id) setEditing(null);
    await refresh();
    setBusyId(null);
  }

  function handleEdit(note: NoteDTO) {
    setEditing(note);
    setComposerOpen(true);
    if (typeof window !== "undefined" && window.innerWidth < 1024) {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }

  const filtersOn = Boolean(colorFilter || tagFilter || query.trim());

  return (
    <div className="min-h-screen">
      {/* ── masthead ─────────────────────────────────────────── */}
      <header className="relative overflow-hidden border-b border-line">
        <img
          src="images/header-texture.jpg"
          alt=""
          aria-hidden
          className="absolute inset-0 h-full w-full object-cover opacity-70"
        />
        <div className="absolute inset-0 bg-gradient-to-l from-ink via-ink/90 to-ink/55" />
        <div
          className="absolute inset-x-0 bottom-0 h-px"
          style={{ background: "linear-gradient(90deg, transparent, #22d3ee, transparent)" }}
        />

        <div className="relative mx-auto flex max-w-[1480px] flex-col gap-6 px-5 py-10 sm:px-8 lg:flex-row lg:items-end lg:justify-between lg:py-14">
          <div>
            <div className="mono-label flex items-center gap-3 text-cyan/80">
              <span className="h-px w-10 bg-cyan/50" />
              LifeOS — دفترچهٔ یادداشت
            </div>
            <h1 className="mt-3 text-5xl font-black leading-[0.95] tracking-tighter sm:text-6xl lg:text-7xl">
              یادداشت‌ها
            </h1>
            <p className="mt-4 max-w-lg text-sm leading-7 text-mute">
              هر فکر رنگ خودش را دارد. یادداشت بنویس، برچسب بزن، سنجاق کن، فایل و عکس پیوست کن
              و در یک چشم‌به‌هم‌زدن پیداش کن.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-6">
            {[
              { k: "کل یادداشت‌ها", v: notes.length },
              { k: "سنجاق‌شده", v: notes.filter((n) => n.pinned).length },
              { k: "پیوست", v: notes.reduce((s, n) => s + n.attachments.length, 0) },
            ].map((s) => (
              <div key={s.k} className="border-s border-line ps-4">
                <div className="tnum text-3xl font-black text-chalk lg:text-4xl">
                  {faNum(s.v)}
                </div>
                <div className="mono-label mt-1 text-mute">{s.k}</div>
              </div>
            ))}
            <button
              onClick={() => {
                setEditing(null);
                setComposerOpen(true);
              }}
              className="inline-flex items-center gap-2 rounded-lg bg-cyan px-5 py-3 text-sm font-black text-[#04202b] transition hover:brightness-110 lg:hidden"
            >
              <Plus size={16} />
              یادداشت تازه
            </button>
          </div>
        </div>
      </header>

      {/* ── workspace ────────────────────────────────────────── */}
      <main className="mx-auto max-w-[1480px] px-5 pb-24 pt-6 sm:px-8">
        <div className="grid items-start gap-6 lg:grid-cols-[336px_minmax(0,1fr)] xl:grid-cols-[336px_minmax(0,1fr)_352px]">
          {/* composer rail (right in RTL) */}
          <div
            className={
              composerOpen
                ? "fixed inset-0 z-50 overflow-y-auto bg-ink/95 p-4 backdrop-blur lg:static lg:p-0"
                : "hidden lg:sticky lg:top-6 lg:block"
            }
          >
            <div className="lg:sticky lg:top-6">
              <div className="mb-3 flex items-center justify-between lg:hidden">
                <span className="mono-label text-mute">COMPOSER</span>
                <button
                  onClick={() => setComposerOpen(false)}
                  aria-label="بستن"
                  className="grid h-8 w-8 place-items-center rounded-md border border-line text-mute"
                >
                  <X size={15} />
                </button>
              </div>
              <Composer
                editing={editing}
                onCloseEdit={() => setEditing(null)}
                onSaved={(fresh) => {
                  setNotes(fresh);
                  setEditing(null);
                  setComposerOpen(false);
                }}
              />
            </div>
          </div>

          {/* ledger */}
          <section className="min-w-0">
            <div className="sticky top-0 z-30 -mx-5 mb-5 border-b border-line bg-ink/90 px-5 py-3 backdrop-blur-xl sm:-mx-8 sm:px-8">
              <div className="flex flex-wrap items-center gap-2">
                <div className="relative min-w-0 flex-1 sm:min-w-56">
                  <Search
                    size={16}
                    className="pointer-events-none absolute inset-y-0 end-3 my-auto text-mute"
                  />
                  <input
                    ref={searchRef}
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    aria-label="جست‌وجو در یادداشت‌ها"
                    placeholder="جست‌وجو در عنوان، متن و برچسب…  (Ctrl+K)"
                    className="w-full rounded-lg border border-line bg-panel py-2.5 pe-10 ps-9 text-sm placeholder:text-mute/70 focus:border-cyan focus:outline-none"
                  />
                  {query && (
                    <button
                      onClick={() => setQuery("")}
                      aria-label="پاک کردن جست‌وجو"
                      className="absolute inset-y-0 start-2 my-auto grid h-6 w-6 place-items-center rounded text-mute transition hover:text-rose"
                    >
                      <X size={14} />
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-1 rounded-lg border border-line bg-panel px-2 py-1.5">
                  <button
                    onClick={() => setColorFilter(null)}
                    title="همهٔ رنگ‌ها"
                    aria-pressed={colorFilter === null}
                    className={`h-5 w-5 rounded border text-[9px] leading-none transition ${
                      colorFilter === null
                        ? "border-cyan text-cyan"
                        : "border-line text-mute hover:border-mute"
                    }`}
                  >
                    ✓
                  </button>
                  {COLORS.map((c) => (
                    <button
                      key={c.key}
                      onClick={() => setColorFilter(colorFilter === c.key ? null : c.key)}
                      title={c.label}
                      aria-pressed={colorFilter === c.key}
                      className="h-5 w-5 rounded transition hover:scale-110"
                      style={{
                        background: c.hex,
                        boxShadow:
                          colorFilter === c.key
                            ? `0 0 0 2px #071522, 0 0 0 3.5px ${c.hex}`
                            : undefined,
                        opacity: colorFilter && colorFilter !== c.key ? 0.35 : 1,
                      }}
                    />
                  ))}
                </div>

                <div className="flex items-center gap-1 rounded-lg border border-line bg-panel px-1.5 py-1.5">
                  <button
                    onClick={() => setSort("updated")}
                    title="مرتب‌سازی"
                    className="flex items-center gap-1 rounded px-2 py-1 text-[11px] transition"
                    style={{
                      background: sort === "updated" ? "rgba(34,211,238,0.12)" : "transparent",
                      color: sort === "updated" ? "#22d3ee" : "#6f8ca6",
                    }}
                  >
                    <ArrowDownUp size={12} />
                    {sort === "updated"
                      ? "آخرین ویرایش"
                      : sort === "created"
                        ? "تاریخ ایجاد"
                        : "عنوان"}
                  </button>
                  <button
                    onClick={() =>
                      setSort(sort === "updated" ? "created" : sort === "created" ? "title" : "updated")
                    }
                    aria-label="تغییر مرتب‌سازی"
                    className="grid h-6 w-6 place-items-center rounded text-mute transition hover:text-cyan"
                  >
                    <SlidersHorizontal size={13} />
                  </button>
                </div>

                <div className="flex items-center rounded-lg border border-line bg-panel p-1">
                  <button
                    onClick={() => setView("list")}
                    aria-pressed={view === "list"}
                    title="نمای فهرستی"
                    className={`grid h-7 w-7 place-items-center rounded transition ${
                      view === "list" ? "bg-cyan/15 text-cyan" : "text-mute hover:text-chalk"
                    }`}
                  >
                    <Rows3 size={14} />
                  </button>
                  <button
                    onClick={() => setView("grid")}
                    aria-pressed={view === "grid"}
                    title="نمای شبکه‌ای"
                    className={`grid h-7 w-7 place-items-center rounded transition ${
                      view === "grid" ? "bg-cyan/15 text-cyan" : "text-mute hover:text-chalk"
                    }`}
                  >
                    <LayoutGrid size={14} />
                  </button>
                </div>
              </div>

              {/* active tag chips + count */}
              <div className="mt-2.5 flex flex-wrap items-center gap-2">
                <span className="mono-label text-mute">
                  {faNum(visible.length)} / {faNum(notes.length)} RESULT
                </span>
                {tagFilter && (
                  <button
                    onClick={() => setTagFilter(null)}
                    className="inline-flex items-center gap-1 rounded-md bg-cyan/15 px-2 py-1 text-[11px] text-cyan ring-1 ring-cyan/40"
                  >
                    #{tagFilter}
                    <X size={11} />
                  </button>
                )}
                {colorFilter && (
                  <button
                    onClick={() => setColorFilter(null)}
                    className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] ring-1"
                    style={{
                      color: colorOf(colorFilter).hex,
                      background: colorOf(colorFilter).wash,
                      borderColor: colorOf(colorFilter).hex,
                      boxShadow: `0 0 0 1px ${colorOf(colorFilter).hex}55`,
                    }}
                  >
                    {colorOf(colorFilter).label}
                    <X size={11} />
                  </button>
                )}
                {filtersOn && (
                  <button
                    onClick={() => {
                      setQuery("");
                      setColorFilter(null);
                      setTagFilter(null);
                    }}
                    className="text-[11px] text-mute underline underline-offset-4 transition hover:text-chalk"
                  >
                    پاک کردن همه
                  </button>
                )}
              </div>

              {allTags.length > 0 && (
                <div className="mt-2.5 flex flex-wrap gap-1.5 pb-1">
                  {allTags.slice(0, 14).map(([t, n]) => (
                    <button
                      key={t}
                      onClick={() => setTagFilter(tagFilter === t ? null : t)}
                      className={`rounded border px-2 py-0.5 text-[11px] transition ${
                        tagFilter === t
                          ? "border-cyan bg-cyan/15 text-cyan"
                          : "border-line bg-panel text-mute hover:border-mute hover:text-chalk"
                      }`}
                    >
                      #{t}
                      <span className="tnum ms-1 font-mono text-[9px] opacity-60">{n}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {visible.length === 0 ? (
              <div className="overflow-hidden rounded-2xl border border-dashed border-line bg-panel/50">
                <div className="relative h-44">
                  <img
                    src="images/empty-state.jpg"
                    alt=""
                    aria-hidden
                    className="h-full w-full object-cover opacity-70"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-panel via-panel/50 to-transparent" />
                </div>
                <div className="px-6 pb-8 pt-2 text-center">
                  <h3 className="text-xl font-black">
                    {notes.length === 0 ? "هنوز یادداشتی نداری" : "چیزی پیدا نشد"}
                  </h3>
                  <p className="mx-auto mt-2 max-w-sm text-sm leading-7 text-mute">
                    {notes.length === 0
                      ? "از ستون کناری اولین یادداشت را بنویس؛ رنگش را انتخاب کن و عکس پیوست کن."
                      : "عبارت دیگری امتحان کن، یا فیلتر رنگ و برچسب را بردار."}
                  </p>
                  {notes.length > 0 && (
                    <button
                      onClick={() => {
                        setQuery("");
                        setColorFilter(null);
                        setTagFilter(null);
                      }}
                      className="mt-4 rounded-lg border border-cyan/40 bg-cyan/10 px-4 py-2 text-sm text-cyan transition hover:bg-cyan/20"
                    >
                      نمایش همهٔ یادداشت‌ها
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div
                className={
                  view === "grid"
                    ? "grid gap-4 sm:grid-cols-2"
                    : "flex flex-col gap-3"
                }
              >
                <AnimatePresence initial={false} mode="popLayout">
                  {visible.map((note) => (
                    <NoteCard
                      key={note.id}
                      note={note}
                      query={query}
                      view={view}
                      busy={busyId === note.id}
                      selected={note.id === selectedId}
                      onSelect={(id) => setSelectedId(id === selectedId ? null : id)}
                      onEdit={handleEdit}
                      onTogglePin={handleTogglePin}
                      onDelete={handleDelete}
                    />
                  ))}
                </AnimatePresence>
              </div>
            )}
          </section>

          {/* inspector — persistent on xl, drawer below */}
          <aside className="hidden xl:sticky xl:top-6 xl:block">
            <Inspector
              note={selected}
              allNotes={notes}
              query={query}
              onClose={() => setSelectedId(null)}
              onEdit={handleEdit}
              onTogglePin={handleTogglePin}
              onDelete={handleDelete}
              onFocusTag={(t) => setTagFilter(t)}
            />
          </aside>
        </div>
      </main>

      {/* inspector drawer under xl */}
      <AnimatePresence>
        {selected && (
          <motion.div
            key="drawer"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 bg-ink/80 backdrop-blur-sm xl:hidden"
            onClick={() => setSelectedId(null)}
          >
            <motion.div
              initial={{ x: -40, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -40, opacity: 0 }}
              transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="absolute inset-y-0 left-0 w-full max-w-md overflow-y-auto p-4"
            >
              <Inspector
                note={selected}
                allNotes={notes}
                query={query}
                onClose={() => setSelectedId(null)}
                onEdit={handleEdit}
                onTogglePin={handleTogglePin}
                onDelete={handleDelete}
                onFocusTag={(t) => {
                  setTagFilter(t);
                  setSelectedId(null);
                }}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* floating add (mobile) */}
      <button
        onClick={() => {
          setEditing(null);
          setComposerOpen(true);
        }}
        aria-label="یادداشت تازه"
        className={`fixed bottom-5 left-5 z-30 grid h-14 w-14 place-items-center rounded-full bg-cyan text-[#04202b] shadow-[0_18px_40px_-14px_rgba(34,211,238,0.8)] transition hover:brightness-110 lg:hidden ${
          composerOpen || selectedId ? "hidden" : ""
        }`}
      >
        <Plus size={24} />
      </button>
    </div>
  );
}
