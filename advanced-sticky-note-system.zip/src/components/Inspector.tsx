"use client";

import { Download, FileText, Pin, PinOff, Trash2, X } from "lucide-react";

import { Highlight } from "@/components/Highlight";
import { bytes, clockTime, isImage, longDate, shortDate } from "@/lib/format";
import { COLORS, colorOf, type NoteDTO } from "@/lib/types";

type Props = {
  note: NoteDTO | null;
  allNotes: NoteDTO[];
  query: string;
  onClose: () => void;
  onEdit: (note: NoteDTO) => void;
  onTogglePin: (note: NoteDTO) => void;
  onDelete: (id: string) => void;
  onFocusTag: (tag: string) => void;
};

export default function Inspector({
  note,
  allNotes,
  query,
  onClose,
  onEdit,
  onTogglePin,
  onDelete,
  onFocusTag,
}: Props) {
  if (!note) {
    const total = allNotes.length;
    const pinnedCount = allNotes.filter((n) => n.pinned).length;
    const files = allNotes.reduce((s, n) => s + n.attachments.length, 0);
    const tagCounts = new Map<string, number>();
    for (const n of allNotes)
      for (const t of n.tags) tagCounts.set(t, (tagCounts.get(t) ?? 0) + 1);
    const topTags = [...tagCounts.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 12);
    const perColor = COLORS.map((c) => ({
      ...c,
      count: allNotes.filter((n) => n.color === c.key).length,
    }));
    const max = Math.max(1, ...perColor.map((p) => p.count));

    return (
      <div className="rounded-2xl border border-line bg-panel/80 p-5">
        <div className="mono-label text-cyan/70">ANALYTICS / نمای کلی</div>
        <div className="mt-4 grid grid-cols-3 gap-2">
          {[
            { k: "یادداشت", v: total },
            { k: "سنجاق‌شده", v: pinnedCount },
            { k: "پیوست", v: files },
          ].map((s) => (
            <div key={s.k} className="rounded-lg border border-line bg-ink-2 px-2 py-3 text-center">
              <div className="tnum text-2xl font-black text-cyan">{s.v.toLocaleString("fa-IR")}</div>
              <div className="mt-1 text-[10px] text-mute">{s.k}</div>
            </div>
          ))}
        </div>

        <div className="mono-label mt-6 text-mute">COLORS / توزیع رنگ</div>
        <ul className="mt-3 space-y-2.5">
          {perColor.map((c) => (
            <li key={c.key} className="flex items-center gap-3">
              <span className="w-16 shrink-0 text-[11px] text-mute">{c.label}</span>
              <span className="h-2 flex-1 overflow-hidden rounded-full bg-ink-2">
                <span
                  className="block h-full rounded-full"
                  style={{
                    width: `${Math.round((c.count / max) * 100)}%`,
                    background: c.hex,
                    boxShadow: `0 0 12px -2px ${c.hex}`,
                  }}
                />
              </span>
              <span className="tnum w-5 text-left font-mono text-[11px] text-chalk">{c.count}</span>
            </li>
          ))}
        </ul>

        {topTags.length > 0 && (
          <>
            <div className="mono-label mt-6 text-mute">TAGS / برچسب‌ها</div>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {topTags.map(([t, n]) => (
                <button
                  key={t}
                  onClick={() => onFocusTag(t)}
                  className="rounded border border-line bg-ink-2 px-2 py-1 text-[11px] text-mute transition hover:border-cyan hover:text-cyan"
                >
                  #{t}
                  <span className="tnum ms-1 font-mono text-[9px] opacity-70">{n}</span>
                </button>
              ))}
            </div>
          </>
        )}

        <div className="mt-6 rounded-lg border border-dashed border-line px-3 py-3 text-[11px] leading-6 text-mute">
          یک یادداشت را از فهرست انتخاب کنید تا متن کامل و پیوست‌هایش اینجا باز شود.
          <br />
          <span className="font-mono text-cyan">Ctrl</span> +{" "}
          <span className="font-mono text-cyan">K</span> برای جست‌وجو،{" "}
          <span className="font-mono text-cyan">Esc</span> برای بستن.
        </div>
      </div>
    );
  }

  const c = colorOf(note.color);

  return (
    <article className="overflow-hidden rounded-2xl border border-line bg-panel/90 shadow-[0_30px_70px_-40px_rgba(0,0,0,1)]">
      <div
        className="relative px-5 pb-5 pt-4"
        style={{
          background: `linear-gradient(160deg, ${c.hex}26, transparent 65%)`,
          borderBottom: `1px solid ${c.hex}33`,
        }}
      >
        <div className="flex items-center justify-between">
          <span className="mono-label" style={{ color: c.hex }}>
            NOTE / #{note.id.slice(0, 8)}
          </span>
          <button
            onClick={onClose}
            aria-label="بستن"
            className="grid h-7 w-7 place-items-center rounded-md border border-line bg-ink-2 text-mute transition hover:border-rose hover:text-rose"
          >
            <X size={14} />
          </button>
        </div>
        <h2 className="mt-2 text-2xl font-black leading-snug tracking-tight">{note.title}</h2>
        <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-mute">
          <span className="tnum font-mono">{shortDate(note.createdAt)}</span>
          <span>{longDate(note.createdAt)}</span>
          <span className="tnum font-mono">{clockTime(note.createdAt)}</span>
          {note.pinned && (
            <span className="rounded bg-amber/15 px-1.5 py-0.5 font-bold text-amber">سنجاق‌شده</span>
          )}
        </div>
        {note.tags.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-1.5">
            {note.tags.map((t) => (
              <button
                key={t}
                onClick={() => onFocusTag(t)}
                className="rounded border px-2 py-0.5 text-[11px] transition hover:brightness-125"
                style={{ color: c.hex, borderColor: `${c.hex}55`, background: c.wash }}
              >
                #{t}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="px-5 py-5">
        <p className="max-h-[38vh] overflow-y-auto whitespace-pre-wrap text-sm leading-8 text-chalk/85">
          <Highlight text={note.body || "بدون متن."} query={query} />
        </p>

        {note.attachments.length > 0 && (
          <>
            <div className="mono-label mt-6 text-mute">
              ATTACHMENTS / پیوست‌ها ({note.attachments.length})
            </div>
            <div className="mt-3 grid grid-cols-3 gap-2">
              {note.attachments
                .filter((a) => isImage(a.mime))
                .map((a) => (
                  <a
                    key={a.id}
                    href={a.data}
                    download={a.name}
                    title={`${a.name} — ${bytes(a.size)}`}
                    className="group relative block aspect-square overflow-hidden rounded-lg border border-line"
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={a.data}
                      alt={a.name}
                      className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
                    />
                    <span className="absolute inset-0 bg-gradient-to-t from-ink/90 to-transparent opacity-0 transition group-hover:opacity-100" />
                    <span className="absolute bottom-1 left-1 right-1 truncate text-[9px] text-chalk opacity-0 transition group-hover:opacity-100">
                      {a.name}
                    </span>
                  </a>
                ))}
            </div>

            <ul className="mt-2 space-y-1.5">
              {note.attachments
                .filter((a) => !isImage(a.mime))
                .map((a) => (
                  <li
                    key={a.id}
                    className="flex items-center gap-2 rounded-md border border-line bg-ink-2 px-3 py-2"
                  >
                    <FileText size={13} className="shrink-0 text-mute" />
                    <span className="min-w-0 flex-1 truncate text-xs">{a.name}</span>
                    <span className="tnum font-mono text-[10px] text-mute">{bytes(a.size)}</span>
                    <a
                      href={a.data}
                      download={a.name}
                      aria-label={`دانلود ${a.name}`}
                      className="text-mute transition hover:text-cyan"
                    >
                      <Download size={14} />
                    </a>
                  </li>
                ))}
            </ul>
          </>
        )}

        <div className="mt-6 flex flex-wrap gap-2">
          <button
            onClick={() => onEdit(note)}
            className="flex-1 rounded-lg bg-cyan px-3 py-2.5 text-sm font-black text-[#04202b] transition hover:brightness-110"
          >
            ویرایش
          </button>
          <button
            onClick={() => onTogglePin(note)}
            aria-label="سنجاق"
            className={`grid h-10 w-10 place-items-center rounded-lg border transition ${
              note.pinned
                ? "border-amber/50 bg-amber/15 text-amber"
                : "border-line bg-ink-2 text-mute hover:border-amber hover:text-amber"
            }`}
          >
            {note.pinned ? <PinOff size={15} /> : <Pin size={15} />}
          </button>
          <button
            onClick={() => onDelete(note.id)}
            aria-label="حذف"
            className="grid h-10 w-10 place-items-center rounded-lg border border-line bg-ink-2 text-mute transition hover:border-rose hover:text-rose"
          >
            <Trash2 size={15} />
          </button>
        </div>
      </div>
    </article>
  );
}
