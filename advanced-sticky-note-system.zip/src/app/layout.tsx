import type { Metadata } from "next";
import type { ReactNode } from "react";
import { JetBrains_Mono, Vazirmatn } from "next/font/google";

import "./globals.css";

const vazirmatn = Vazirmatn({
  subsets: ["arabic", "latin"],
  weight: ["300", "400", "500", "700", "900"],
  variable: "--font-vazirmatn",
  display: "swap",
});

const mono = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "700"],
  variable: "--font-jetbrains",
  display: "swap",
});

export const metadata: Metadata = {
  title: "یادداشت‌ها — LifeOS",
  description:
    "دفترچهٔ یادداشت‌های رنگی: ساخت، برچسب، جست‌وجو، سنجاق و پیوست فایل و عکس.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl" className={`${vazirmatn.variable} ${mono.variable}`}>
      <body className="min-h-screen bg-ink text-chalk antialiased">
        {children}
      </body>
    </html>
  );
}
