import { fetchNotes } from "@/app/actions";
import NoteApp from "@/components/NoteApp";
import type { NoteDTO } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function Page() {
  let initialNotes: NoteDTO[];
  try {
    initialNotes = await fetchNotes();
  } catch {
    initialNotes = [];
  }

  return <NoteApp initialNotes={initialNotes} />;
}
