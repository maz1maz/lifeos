"use server";

import { revalidatePath } from "next/cache";
import { and, desc, eq, or, sql } from "drizzle-orm";

import { db } from "@/db";
import { attachments, notes } from "@/db/schema";
import type { AttachmentDTO, NewNoteInput, NoteDTO, PendingFile } from "@/lib/types";
import { MAX_FILE_BYTES, MAX_FILES_PER_NOTE } from "@/lib/types";

function toAttachmentDTO(row: {
  id: string;
  name: string;
  mime: string;
  size: number;
  data: string;
  createdAt: Date;
}): AttachmentDTO {
  return {
    id: row.id,
    name: row.name,
    mime: row.mime,
    size: row.size,
    data: row.data,
    createdAt: row.createdAt.toISOString(),
  };
}

export async function fetchNotes(): Promise<NoteDTO[]> {
  const [rows, files] = await Promise.all([
    db
      .select()
      .from(notes)
      .orderBy(desc(notes.pinned), desc(notes.updatedAt)),
    db.select().from(attachments).orderBy(attachments.createdAt),
  ]);

  const grouped = new Map<string, AttachmentDTO[]>();
  for (const file of files) {
    const list = grouped.get(file.noteId) ?? [];
    list.push(toAttachmentDTO(file));
    grouped.set(file.noteId, list);
  }

  return rows.map((row) => ({
    id: row.id,
    title: row.title,
    body: row.body,
    color: row.color as NoteDTO["color"],
    tags: row.tags ?? [],
    pinned: row.pinned,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
    attachments: grouped.get(row.id) ?? [],
  }));
}

function sanitizeFiles(files: PendingFile[] | undefined): PendingFile[] {
  if (!files?.length) return [];
  return files
    .filter((f) => f && typeof f.data === "string" && f.data.length > 0)
    .slice(0, MAX_FILES_PER_NOTE)
    .filter((f) => Math.round((f.data.length * 3) / 4) <= MAX_FILE_BYTES)
    .map((f) => ({
      name: String(f.name).slice(0, 180),
      mime: String(f.mime || "application/octet-stream").slice(0, 120),
      size: Number(f.size) || 0,
      data: f.data,
    }));
}

export async function createNote(
  input: NewNoteInput,
  files: PendingFile[] = [],
): Promise<{ ok: true; id: string } | { ok: false; error: string }> {
  const title = input.title.trim();
  if (!title) return { ok: false, error: "عنوان یادداشت خالی است." };

  const clean = sanitizeFiles(files);

  const inserted = await db
    .insert(notes)
    .values({
      title,
      body: input.body.trim(),
      color: input.color,
      tags: input.tags.slice(0, 8),
      pinned: Boolean(input.pinned),
    })
    .returning({ id: notes.id });

  const id = inserted[0].id;

  if (clean.length) {
    await db.insert(attachments).values(
      clean.map((f) => ({ noteId: id, ...f })),
    );
  }

  revalidatePath("/");
  return { ok: true, id };
}

export async function updateNote(
  id: string,
  input: NewNoteInput,
  files: PendingFile[] = [],
): Promise<{ ok: true } | { ok: false; error: string }> {
  const title = input.title.trim();
  if (!title) return { ok: false, error: "عنوان یادداشت خالی است." };

  const clean = sanitizeFiles(files);

  await db
    .update(notes)
    .set({
      title,
      body: input.body.trim(),
      color: input.color,
      tags: input.tags.slice(0, 8),
      pinned: Boolean(input.pinned),
      updatedAt: new Date(),
    })
    .where(eq(notes.id, id));

  if (clean.length) {
    await db.insert(attachments).values(clean.map((f) => ({ noteId: id, ...f })));
  }

  revalidatePath("/");
  return { ok: true };
}

export async function togglePin(id: string, pinned: boolean) {
  await db
    .update(notes)
    .set({ pinned, updatedAt: new Date() })
    .where(eq(notes.id, id));
  revalidatePath("/");
}

export async function deleteNote(id: string) {
  await db.delete(notes).where(eq(notes.id, id));
  revalidatePath("/");
}

export async function deleteAttachment(id: string) {
  await db.delete(attachments).where(eq(attachments.id, id));
  revalidatePath("/");
}

export async function searchNotes(query: string): Promise<NoteDTO[]> {
  const q = query.trim();
  if (!q) return fetchNotes();
  const pattern = `%${q.replace(/[%_]/g, (m) => `\\${m}`)}%`;
  const rows = await db
    .select()
    .from(notes)
    .where(
      or(
        sql`${notes.title} ILIKE ${pattern}`,
        sql`${notes.body} ILIKE ${pattern}`,
        sql`array_to_string(${notes.tags}, ' ') ILIKE ${pattern}`,
      ),
    )
    .orderBy(desc(notes.pinned), desc(notes.updatedAt));
  const ids = rows.map((r) => r.id);
  const files = ids.length
    ? await db.select().from(attachments).where(
        sql`${attachments.noteId} = ANY(${ids}::uuid[])`,
      )
    : [];
  const grouped = new Map<string, AttachmentDTO[]>();
  for (const file of files) {
    const list = grouped.get(file.noteId) ?? [];
    list.push(toAttachmentDTO(file));
    grouped.set(file.noteId, list);
  }
  return rows.map((row) => ({
    id: row.id,
    title: row.title,
    body: row.body,
    color: row.color as NoteDTO["color"],
    tags: row.tags ?? [],
    pinned: row.pinned,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
    attachments: grouped.get(row.id) ?? [],
  }));
}

export async function noteCount(): Promise<number> {
  const rows = await db.select({ n: sql<number>`count(*)::int` }).from(notes);
  return rows[0]?.n ?? 0;
}

export async function getNote(
  id: string,
): Promise<{ note: NoteDTO } | null> {
  const rows = await db.select().from(notes).where(eq(notes.id, id)).limit(1);
  if (!rows.length) return null;
  const files = await db
    .select()
    .from(attachments)
    .where(and(eq(attachments.noteId, id)));
  const row = rows[0];
  return {
    note: {
      id: row.id,
      title: row.title,
      body: row.body,
      color: row.color as NoteDTO["color"],
      tags: row.tags ?? [],
      pinned: row.pinned,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
      attachments: files.map(toAttachmentDTO),
    },
  };
}
