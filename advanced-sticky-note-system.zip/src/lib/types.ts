export type AttachmentDTO = {
  id: string;
  name: string;
  mime: string;
  size: number;
  data: string;
  createdAt: string;
};

export type NoteDTO = {
  id: string;
  title: string;
  body: string;
  color: ColorKey;
  tags: string[];
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
  attachments: AttachmentDTO[];
};

export type NewNoteInput = {
  title: string;
  body: string;
  color: string;
  tags: string[];
  pinned: boolean;
};

export type PendingFile = {
  name: string;
  mime: string;
  size: number;
  data: string;
};

export type ColorKey =
  | "sky"
  | "mint"
  | "amber"
  | "rose"
  | "violet"
  | "teal";

export type ColorMeta = {
  key: ColorKey;
  label: string;
  hex: string;
  /** soft translucent wash used for card fills */
  wash: string;
  /** darker edge used against light text */
  deep: string;
};

export const COLORS: ColorMeta[] = [
  { key: "sky", label: "آسمانی", hex: "#38BDF8", wash: "rgba(56,189,248,0.10)", deep: "#0B3A55" },
  { key: "teal", label: "فیروزه‌ای", hex: "#22D3EE", wash: "rgba(34,211,238,0.10)", deep: "#08414D" },
  { key: "mint", label: "نعناعی", hex: "#34D399", wash: "rgba(52,211,153,0.10)", deep: "#0A4436" },
  { key: "amber", label: "کهربایی", hex: "#FBBF24", wash: "rgba(251,191,36,0.10)", deep: "#4D3506" },
  { key: "rose", label: "گلی", hex: "#FB7185", wash: "rgba(251,113,133,0.10)", deep: "#4E1523" },
  { key: "violet", label: "بنفش", hex: "#A78BFA", wash: "rgba(167,139,250,0.10)", deep: "#31215E" },
];

export const COLOR_MAP: Record<string, ColorMeta> = Object.fromEntries(
  COLORS.map((c) => [c.key, c]),
) as Record<string, ColorMeta>;

export function colorOf(key: string): ColorMeta {
  return COLOR_MAP[key] ?? COLOR_MAP.sky;
}

export const MAX_FILE_BYTES = 4 * 1024 * 1024;
export const MAX_FILES_PER_NOTE = 8;
