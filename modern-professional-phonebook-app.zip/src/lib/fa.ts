const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

export function toFa(value: string | number): string {
  return String(value).replace(/[0-9]/g, (d) => FA_DIGITS[Number(d)]);
}

export function pad2(n: number): string {
  return n < 10 ? `0${n}` : String(n);
}

/** ۰۱ / ۰۲ … row index for the ledger gutter */
export function faIndex(n: number): string {
  return toFa(pad2(n));
}

/** groups a phone number into readable chunks: ۰۹۱۲ ۶۰۹ ۲۸۹۸ */
export function formatPhone(raw: string): string {
  const trimmed = raw.trim();
  const hasPlus = trimmed.startsWith("+");
  const digits = trimmed.replace(/[^\d]/g, "");
  let body = digits;
  let out = "";
  if (!hasPlus && body.startsWith("0")) {
    out = `${body.slice(0, 4)} ${body.slice(4, 7)} ${body.slice(7, 11)}`.trim();
  } else if (body.startsWith("98")) {
    body = body.slice(2);
    out = `+۹۸ ${body.slice(0, 3)} ${body.slice(3, 6)} ${body.slice(6, 10)}`.trim();
  } else if (hasPlus) {
    out = `+${body}`;
  } else {
    out = trimmed;
  }
  return toFa(out.replace(/\s+/g, " ").trim());
}

export function telHref(raw: string): string {
  return `tel:${raw.replace(/[^\d+]/g, "")}`;
}

const MONTHS_FA = [
  "ژانویه",
  "فوریه",
  "مارس",
  "آوریل",
  "مه",
  "ژوئن",
  "ژوئیه",
  "اوت",
  "سپتامبر",
  "اکتبر",
  "نوامبر",
  "دسامبر",
];

export function formatDate(iso?: string | null): string {
  if (!iso) return "";
  const [y, m, d] = iso.split("-").map(Number);
  if (!y || !m || !d) return toFa(iso);
  return `${toFa(d)} ${MONTHS_FA[m - 1]} ${toFa(y)}`;
}

export function formatStamp(value: string | Date): string {
  const date = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(date.getTime())) return "";
  return toFa(
    `${pad2(date.getDate())}/${pad2(date.getMonth() + 1)}/${date.getFullYear()} — ${pad2(
      date.getHours(),
    )}:${pad2(date.getMinutes())}`,
  );
}
