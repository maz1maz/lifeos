import type { NewContact } from "@/db/schema";

/**
 * Seed ledger — names, numbers and trades taken from the client's own
 * operator directory card. Persian copy, real formatting.
 */
export const SEED_CONTACTS: NewContact[] = [
  {
    name: "کاوه نادری",
    groupName: "دوست",
    phones: ["+98 905 436 2088"],
    telegram: "id1133702832",
    email: "kaveh.naderi@outlook.com",
    notes: "هم‌کلاسی قدیمی — آخر هفته‌ها جواب می‌دهد.",
    favorite: true,
  },
  {
    name: "امید سونده (Sony)",
    groupName: "دوست",
    phones: ["0912 609 2898"],
    email: "sony.svnd@gmail.com",
    notes: "تعمیرات صوتی و تصویری.",
    favorite: true,
  },
  {
    name: "رسول مقدم",
    groupName: "دوست",
    phones: ["+98 912 157 6678"],
    notes: "حواله و حمل بار از تهران به نوشهر.",
    favorite: false,
  },
  {
    name: "رضا",
    groupName: "دوست",
    phones: ["+98 912 808 1955", "+98 935 459 8374"],
    notes: "شماره‌ی دوم فقط واتساپ.",
    favorite: false,
  },
  {
    name: "Rahpouyan (تور و بلیط لحظه آخری)",
    groupName: "خدمات",
    phones: ["+98 937 466 5553"],
    telegram: "rahpouyan_tour",
    email: "booking@rahpouyan.example",
    notes: "بلیط چارتر نوشهر ـ مشهد. تأیید رزرو تا ساعت ۱۹.",
    favorite: true,
  },
  {
    name: "مجید نعمانی ماهواره نوشهر",
    groupName: "خدمات",
    phones: ["+98 911 540 6054"],
    notes: "تنظیم آنتن و گیرنده — پشت‌بام ساختمان.",
    favorite: false,
  },
  {
    name: "مجتبی واقعی مستأجر وقت آباد",
    groupName: "همکار",
    phones: ["+98 919 633 4665"],
    birthday: "1987-04-12",
    notes: "قرارداد واحد دوم تا پایان شهریور.",
    favorite: false,
  },
  {
    name: "Abbas Palash",
    groupName: "دوست",
    phones: ["+98 938 595 7213"],
    email: "abbas.palash@gmail.com",
    notes: "مترجم انگلیسی — سفارش ترجمه فوری.",
    favorite: false,
  },
  {
    name: "مریم سلطانی",
    groupName: "خانواده",
    phones: ["0911 224 7735"],
    email: "m.soltani@mail.ir",
    birthday: "1990-11-03",
    notes: "خواهرزاده — تماس هر جمعه.",
    favorite: true,
  },
  {
    name: "دفتر فنی ساختمان ساحلی",
    groupName: "مشتری",
    phones: ["011 4422 9081", "0911 880 1243"],
    email: "office@saheli-bina.example",
    notes: "صورت‌وضعیت ماهانه تا پنجم هر ماه ارسال شود.",
    favorite: false,
  },
];
