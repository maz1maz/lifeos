"use client";

import { useRef, useState } from "react";
import { Download, FileJson, FileSpreadsheet, Upload, AlertCircle } from "lucide-react";
import { formatStamp, toFa } from "@/lib/fa";
import type { BackupRecord } from "@/db/schema";

type Props = {
  history: BackupRecord[];
  onChanged: (message: string) => void;
};

export default function BackupVault({ history, onChanged }: Props) {
  const [mode, setMode] = useState<"replace" | "merge">("replace");
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  async function restoreFile(file: File) {
    setBusy(true);
    setError(null);
    const text = await file.text();
    const response = await fetch(`/api/backup/restore?mode=${mode}`, {
      method: "POST",
      headers: {
        "Content-Type": file.name.endsWith(".csv")
          ? "text/csv; charset=utf-8"
          : "application/json",
      },
      body: text,
    });
    setBusy(false);
    const data = (await response.json().catch(() => ({}))) as {
      error?: string;
      count?: number;
    };
    if (!response.ok) {
      setError(data.error ?? "بازیابی انجام نشد.");
      return;
    }
    onChanged(`${toFa(data.count ?? 0)} مخاطب از فایل پشتیبان بازیابی شد.`);
  }

  return (
    <section className="panel relative overflow-hidden p-5 sm:p-6">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.07] mix-blend-luminosity"
        style={{
          backgroundImage: "url(images/ledger-paper.jpg)",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />

      <div className="relative">
        <div className="flex items-baseline justify-between gap-3 border-b border-[rgba(217,164,65,0.25)] pb-3">
          <h2 className="text-2xl font-black tracking-tight">پشتیبان‌گیری</h2>
          <span className="stamp px-2 py-1 text-[9px] tracking-[0.22em]">
            VAULT · گاوصندوق
          </span>
        </div>

        <p className="mt-4 text-[13px] leading-7 font-light text-[#8FA6BC]">
          از کل دفترچه نسخهٔ کامل بگیرید. فایل‌ها روی همین دستگاه ذخیره می‌شوند و هر
          بار گرفتن نسخه، رسید آن در دفتر ثبت می‌شود.
        </p>

        <div className="mt-4 grid grid-cols-2 gap-2">
          <a className="btn-ghost" href="/api/backup/export?format=json">
            <FileJson size={15} />
            خروجی JSON
          </a>
          <a className="btn-ghost" href="/api/backup/export?format=csv">
            <FileSpreadsheet size={15} />
            خروجی CSV
          </a>
        </div>

        <div className="mt-6 border-t border-[rgba(47,216,228,0.12)] pt-5">
          <div className="label-mono mb-2">بازیابی از فایل</div>

          <div className="mb-3 flex gap-2">
            {(["replace", "merge"] as const).map((m) => (
              <button
                key={m}
                type="button"
                className="chip"
                data-active={mode === m}
                onClick={() => setMode(m)}
              >
                {m === "replace" ? "جایگزینی کامل" : "افزودن به فهرست"}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            onDragOver={(e) => {
              e.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragging(false);
              const file = e.dataTransfer.files?.[0];
              if (file) void restoreFile(file);
            }}
            className="flex w-full flex-col items-center justify-center gap-2 border border-dashed px-4 py-7 text-center transition-colors"
            style={{
              borderColor: dragging ? "#2FD8E4" : "rgba(47,216,228,0.28)",
              background: dragging ? "rgba(47,216,228,0.08)" : "rgba(7,20,34,0.6)",
            }}
          >
            <Upload size={18} className="text-[#2FD8E4]" />
            <span className="text-[13px] font-light text-[#a8c3d8]">
              {busy
                ? "در حال بازیابی…"
                : "فایل پشتیبان را اینجا رها کنید یا برای انتخاب کلیک کنید"}
            </span>
            <span className="label-mono">JSON / CSV</span>
          </button>

          <input
            ref={inputRef}
            type="file"
            accept=".json,.csv,application/json,text/csv"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) void restoreFile(file);
              e.target.value = "";
            }}
          />
        </div>

        {error ? (
          <p className="mt-3 flex items-center gap-2 border border-[rgba(255,93,104,0.4)] bg-[rgba(255,93,104,0.08)] px-3 py-2 text-sm text-[#ff9aa2]">
            <AlertCircle size={15} />
            {error}
          </p>
        ) : null}

        <div className="mt-6 border-t border-[rgba(47,216,228,0.12)] pt-4">
          <div className="label-mono mb-3">دفتر رسید</div>
          {history.length === 0 ? (
            <p className="mono text-xs text-[#546d84]">هنوز رسیدی ثبت نشده است.</p>
          ) : (
            <ul className="space-y-2">
              {history.map((item) => (
                <li
                  key={item.id}
                  className="flex items-center justify-between gap-3 text-[11px]"
                >
                  <span
                    className="mono tracking-tight"
                    style={{
                      color: item.kind === "restore" ? "#2FD8E4" : "#D9A441",
                    }}
                  >
                    {item.kind === "restore" ? "RESTORE" : item.format.toUpperCase()}
                  </span>
                  <span className="flex-1 truncate font-light text-[#8FA6BC]">
                    {item.label}
                  </span>
                  <span className="mono text-[#546d84]">
                    {formatStamp(item.createdAt)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>

        <p className="mt-5 flex items-center gap-2 text-[11px] font-light text-[#546d84]">
          <Download size={13} />
          پیشنهاد می‌شود هر هفته یک نسخهٔ JSON روی حافظهٔ جانبی نگه دارید.
        </p>
      </div>
    </section>
  );
}
