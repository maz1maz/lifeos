"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Cake,
  Mail,
  Pencil,
  Phone,
  Plus,
  Search,
  Send,
  Star,
  Trash2,
  X,
} from "lucide-react";
import type { BackupRecord, Contact } from "@/db/schema";
import { faIndex, formatDate, formatPhone, formatStamp, telHref, toFa } from "@/lib/fa";
import ContactForm, { GROUPS } from "@/components/ContactForm";
import BackupVault from "@/components/BackupVault";

type SortKey = "name" | "recent" | "birthday";

const SORTS: { key: SortKey; label: string }[] = [
  { key: "name", label: "نام (الفبا)" },
  { key: "recent", label: "تازه‌ترین ثبت" },
  { key: "birthday", label: "نزدیک‌ترین تولد" },
];

type Props = {
  initialContacts: Contact[];
  initialHistory: BackupRecord[];
  total: number;
};

export default function Directory({ initialContacts, initialHistory, total }: Props) {
  const [rows, setRows] = useState<Contact[]>(initialContacts);
  const [totalCount, setTotalCount] = useState<number>(total);
  const [history, setHistory] = useState<BackupRecord[]>(initialHistory);
  const [query, setQuery] = useState("");
  const [group, setGroup] = useState("همه");
  const [sort, setSort] = useState<SortKey>("name");
  const [editing, setEditing] = useState<Contact | null>(null);
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const formRailRef = useRef<HTMLDivElement>(null);
  const firstRun = useRef(true);

  useEffect(() => {
    if (firstRun.current) {
      firstRun.current = false;
    }
  }, []);

  async function load(nextQuery = query, nextGroup = group) {
    setLoading(true);
    const params = new URLSearchParams();
    if (nextQuery.trim()) params.set("q", nextQuery.trim());
    if (nextGroup !== "همه") params.set("group", nextGroup);
    const response = await fetch(`/api/contacts?${params.toString()}`);
    const data = (await response.json()) as { rows: Contact[]; total: number };
    setRows(data.rows ?? []);
    if (typeof data.total === "number") setTotalCount(data.total);
    setLoading(false);
  }

  async function refreshHistory() {
    const response = await fetch("/api/backup");
    const data = (await response.json()) as { history: BackupRecord[] };
    setHistory(data.history ?? []);
  }

  useEffect(() => {
    const timer = setTimeout(() => {
      void load(query, group);
    }, 220);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query, group]);

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(null), 2800);
    return () => clearTimeout(timer);
  }, [toast]);

  const visible = useMemo(() => {
    const list = [...rows];
    if (sort === "name") {
      return list.sort((a, b) => a.name.localeCompare(b.name, "fa"));
    }
    if (sort === "recent") {
      return list.sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
      );
    }
    const key = (c: Contact) => {
      if (!c.birthday) return 9999;
      const [, m, d] = c.birthday.split("-").map(Number);
      return (m ?? 12) * 100 + (d ?? 31);
    };
    return list.sort((a, b) => key(a) - key(b));
  }, [rows, sort]);

  async function toggleFavorite(contact: Contact) {
    setRows((prev) =>
      prev.map((r) => (r.id === contact.id ? { ...r, favorite: !r.favorite } : r)),
    );
    await fetch(`/api/contacts/${contact.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ favorite: !contact.favorite }),
    });
  }

  async function remove(contact: Contact) {
    await fetch(`/api/contacts/${contact.id}`, { method: "DELETE" });
    setConfirmId(null);
    setToast(`«${contact.name}» از فهرست حذف شد.`);
    await load();
    await refreshHistory();
  }

  function handleSaved(message: string) {
    setToast(message);
    void load();
    void refreshHistory();
    if (typeof window !== "undefined" && window.innerWidth < 1024) {
      formRailRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }

  function handleVaultChanged(message: string) {
    setToast(message);
    void load();
    void refreshHistory();
  }

  const lastExport = history.find((h) => h.kind === "export") ?? null;

  return (
    <>
      {/* console strip */}
      <div className="mx-auto max-w-[1240px] px-4 sm:px-6">
        <div className="panel grid grid-cols-2 divide-x divide-x-reverse divide-[rgba(47,216,228,0.12)] sm:grid-cols-4">
          {[
            { label: "کل مخاطبین", value: toFa(totalCount) },
            { label: "ردیف نمایش‌داده‌شده", value: toFa(visible.length) },
            { label: "گروه‌های فعال", value: toFa(GROUPS.length) },
            {
              label: "آخرین پشتیبان",
              value: lastExport ? formatStamp(lastExport.createdAt) : "—",
              small: true,
            },
          ].map((cell) => (
            <div key={cell.label} className="px-5 py-4">
              <div className="label-mono">{cell.label}</div>
              <div
                className="mono mt-2 text-[#7DEBF2]"
                style={{ fontSize: cell.small ? "0.8rem" : "1.5rem", lineHeight: 1.1 }}
              >
                {cell.value}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="mx-auto grid max-w-[1240px] gap-6 px-4 py-8 sm:px-6 lg:grid-cols-[1fr_380px] lg:py-12">
        {/* ledger */}
        <section className="panel min-w-0 p-4 sm:p-6">
          <div className="flex flex-wrap items-baseline justify-between gap-3 border-b border-[rgba(47,216,228,0.14)] pb-3">
            <h2 className="text-2xl font-black tracking-tight">فهرست</h2>
            <span className="label-mono">
              DIRECTORY · {toFa(visible.length)} ROWS
            </span>
          </div>

          {/* toolbar */}
          <div className="mt-5 space-y-3">
            <div className="relative">
              <Search
                size={16}
                className="pointer-events-none absolute top-1/2 right-3 -translate-y-1/2 text-[#546d84]"
              />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="جستجو: نام، شماره تلفن، ایمیل، تلگرام، توضیحات…"
                className="field pr-10"
                aria-label="جستجوی مخاطب"
                type="search"
              />
              {query ? (
                <button
                  type="button"
                  onClick={() => setQuery("")}
                  aria-label="پاک‌کردن جستجو"
                  className="absolute top-1/2 left-3 -translate-y-1/2 text-[#546d84] transition-colors hover:text-[#7DEBF2]"
                >
                  <X size={15} />
                </button>
              ) : null}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {["همه", ...GROUPS].map((g) => (
                <button
                  key={g}
                  type="button"
                  className="chip"
                  data-active={group === g}
                  onClick={() => setGroup(g)}
                >
                  {g}
                </button>
              ))}
              <span className="mr-auto flex items-center gap-2">
                <label htmlFor="sort" className="label-mono">
                  مرتب‌سازی
                </label>
                <select
                  id="sort"
                  value={sort}
                  onChange={(e) => setSort(e.target.value as SortKey)}
                  className="field w-auto py-1.5 text-[12px]"
                >
                  {SORTS.map((s) => (
                    <option key={s.key} value={s.key}>
                      {s.label}
                    </option>
                  ))}
                </select>
              </span>
              <button
                type="button"
                className="btn-ghost lg:hidden"
                onClick={() =>
                  formRailRef.current?.scrollIntoView({
                    behavior: "smooth",
                    block: "start",
                  })
                }
              >
                <Plus size={14} />
                افزودن
              </button>
            </div>
          </div>

          {/* rows */}
          {visible.length === 0 ? (
            <div className="mt-10 border border-dashed border-[rgba(47,216,228,0.2)] px-6 py-14 text-center">
              <p className="text-lg font-bold">
                {query ? "چیزی با این جستجو پیدا نشد." : "هنوز مخاطبی در دفترچه نیست."}
              </p>
              <p className="mt-2 text-[13px] font-light text-[#8FA6BC]">
                {query
                  ? `برای «${query}» نتیجه‌ای در ${group === "همه" ? "هیچ گروهی" : `گروه ${group}`} ثبت نشده است.`
                  : "اولین مخاطب را از فرم کنار صفحه ثبت کنید."}
              </p>
            </div>
          ) : (
            <ul className="mt-6">
              <AnimatePresence initial={false}>
                {visible.map((contact, index) => (
                  <motion.li
                    key={contact.id}
                    layout
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, height: 0, paddingTop: 0, paddingBottom: 0 }}
                    transition={{
                      duration: 0.28,
                      delay: Math.min(index * 0.02, 0.24),
                      ease: [0.22, 1, 0.36, 1],
                    }}
                    className="group overflow-hidden border-b border-[rgba(47,216,228,0.1)] py-4 transition-colors hover:bg-[rgba(47,216,228,0.035)]"
                  >
                    <div className="flex gap-4">
                      <div className="w-9 shrink-0 border-l border-[rgba(217,164,65,0.25)] pl-2 text-left">
                        <span
                          className="mono text-[15px] transition-colors"
                          style={{ color: contact.favorite ? "#D9A441" : "#546d84" }}
                        >
                          {faIndex(index + 1)}
                        </span>
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                          <h3 className="truncate text-[17px] font-extrabold tracking-tight">
                            {contact.name}
                          </h3>
                          <span className="chip">{contact.groupName}</span>
                          {contact.birthday ? (
                            <span className="mono flex items-center gap-1 text-[11px] text-[#8FA6BC]">
                              <Cake size={12} className="text-[#D9A441]" />
                              {formatDate(contact.birthday)}
                            </span>
                          ) : null}
                        </div>

                        <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1">
                          {contact.phones.map((phone) => (
                            <a
                              key={phone}
                              href={telHref(phone)}
                              dir="ltr"
                              className="mono group/phone flex items-center gap-1.5 text-[13px] text-[#DCE7F2] transition-colors hover:text-[#7DEBF2]"
                            >
                              <Phone
                                size={12}
                                className="text-[#0E7F8A] transition-colors group-hover/phone:text-[#2FD8E4]"
                              />
                              {formatPhone(phone)}
                            </a>
                          ))}
                        </div>

                        <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-[12px] font-light text-[#8FA6BC]">
                          {contact.email ? (
                            <a
                              href={`mailto:${contact.email}`}
                              dir="ltr"
                              className="mono flex items-center gap-1.5 transition-colors hover:text-[#7DEBF2]"
                            >
                              <Mail size={12} className="text-[#0E7F8A]" />
                              {contact.email}
                            </a>
                          ) : null}
                          {contact.telegram ? (
                            <a
                              href={`https://t.me/${contact.telegram}`}
                              target="_blank"
                              rel="noreferrer"
                              dir="ltr"
                              className="mono flex items-center gap-1.5 transition-colors hover:text-[#7DEBF2]"
                            >
                              <Send size={12} className="text-[#0E7F8A]" />
                              {`t.me/${contact.telegram}`}
                            </a>
                          ) : null}
                        </div>

                        {contact.notes ? (
                          <p className="mt-2 max-w-[62ch] text-[12.5px] leading-6 font-light text-[#6f8aa3]">
                            {contact.notes}
                          </p>
                        ) : null}
                      </div>

                      <div className="flex shrink-0 flex-col items-end gap-2">
                        <button
                          type="button"
                          aria-label={
                            contact.favorite ? "حذف از برگزیده‌ها" : "افزودن به برگزیده‌ها"
                          }
                          onClick={() => void toggleFavorite(contact)}
                          className="transition-transform hover:scale-110"
                          style={{ color: contact.favorite ? "#D9A441" : "#33506a" }}
                        >
                          <Star
                            size={16}
                            fill={contact.favorite ? "#D9A441" : "none"}
                          />
                        </button>

                        {confirmId === contact.id ? (
                          <div className="flex items-center gap-1">
                            <span className="text-[11px] text-[#ff9aa2]">حذف شود؟</span>
                            <button
                              type="button"
                              className="chip"
                              data-active="true"
                              onClick={() => void remove(contact)}
                            >
                              بله
                            </button>
                            <button
                              type="button"
                              className="chip"
                              onClick={() => setConfirmId(null)}
                            >
                              انصراف
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1 opacity-70 transition-opacity group-hover:opacity-100">
                            <button
                              type="button"
                              className="chip"
                              onClick={() => {
                                setEditing(contact);
                                formRailRef.current?.scrollIntoView({
                                  behavior: "smooth",
                                  block: "start",
                                });
                              }}
                            >
                              <Pencil size={11} className="inline" />
                              ویرایش
                            </button>
                            <button
                              type="button"
                              className="chip hover:border-[rgba(255,93,104,0.5)] hover:text-[#ff9aa2]"
                              onClick={() => setConfirmId(contact.id)}
                            >
                              <Trash2 size={11} className="inline" />
                              حذف
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </motion.li>
                ))}
              </AnimatePresence>
            </ul>
          )}

          <p className="label-mono mt-5">
            {loading
              ? "در حال جستجو…"
              : `${toFa(visible.length)} از ${toFa(totalCount)} ردیف`}
          </p>
        </section>

        {/* sticky rail */}
        <aside ref={formRailRef} className="space-y-6 lg:sticky lg:top-6 lg:self-start">
          <ContactForm
            initial={editing}
            onSaved={handleSaved}
            onCancelEdit={() => setEditing(null)}
          />
          <BackupVault history={history} onChanged={handleVaultChanged} />
        </aside>
      </div>

      <AnimatePresence>
        {toast ? (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 16 }}
            transition={{ duration: 0.24 }}
            className="fixed bottom-6 left-6 z-40 max-w-[min(90vw,380px)] border border-[rgba(47,216,228,0.4)] bg-[#08182A] px-5 py-3 text-[13px] text-[#7DEBF2] shadow-[0_20px_50px_-20px_rgba(0,0,0,0.9)]"
          >
            {toast}
          </motion.div>
        ) : null}
      </AnimatePresence>
    </>
  );
}
