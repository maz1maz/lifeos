"use client";

import { useEffect, useState, type FormEvent } from "react";
import { Save, X, AlertCircle, Star } from "lucide-react";
import type { Contact } from "@/db/schema";

export const GROUPS = ["دوست", "خانواده", "همکار", "مشتری", "خدمات"];

type Props = {
  initial: Contact | null;
  onSaved: (message: string) => void;
  onCancelEdit: () => void;
};

const empty = {
  name: "",
  groupName: "دوست",
  phones: "",
  email: "",
  telegram: "",
  birthday: "",
  notes: "",
  favorite: false,
};

export default function ContactForm({ initial, onSaved, onCancelEdit }: Props) {
  const [form, setForm] = useState(empty);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (initial) {
      setForm({
        name: initial.name,
        groupName: initial.groupName,
        phones: initial.phones.join("\n"),
        email: initial.email ?? "",
        telegram: initial.telegram ?? "",
        birthday: initial.birthday ?? "",
        notes: initial.notes ?? "",
        favorite: initial.favorite,
      });
      setError(null);
    } else {
      setForm(empty);
    }
  }, [initial]);

  function update<K extends keyof typeof empty>(key: K, value: (typeof empty)[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!form.name.trim()) {
      setError("نام مخاطب را وارد کنید.");
      return;
    }
    setBusy(true);
    setError(null);

    const payload = {
      ...form,
      phones: form.phones
        .split(/[\n,،]+/)
        .map((p) => p.trim())
        .filter(Boolean),
      telegram: form.telegram.replace(/^@/, ""),
    };

    const response = await fetch(
      initial ? `/api/contacts/${initial.id}` : "/api/contacts",
      {
        method: initial ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      },
    );

    setBusy(false);
    if (!response.ok) {
      const data = (await response.json().catch(() => ({}))) as {
        error?: string;
      };
      setError(data.error ?? "ذخیره انجام نشد. دوباره تلاش کنید.");
      return;
    }

    setForm(empty);
    onSaved(initial ? "تغییرات مخاطب ذخیره شد." : "مخاطب تازه به فهرست افزوده شد.");
    if (initial) onCancelEdit();
  }

  return (
    <form onSubmit={submit} className="panel p-5 sm:p-6">
      <div className="flex items-baseline justify-between gap-3 border-b border-[rgba(47,216,228,0.14)] pb-3">
        <h2 className="text-2xl font-black tracking-tight">
          {initial ? "ویرایش" : "افزودن"}
        </h2>
        <span className="label-mono">{initial ? `ID ${initial.id}` : "NEW ENTRY"}</span>
      </div>

      <div className="mt-5 space-y-4">
        <div>
          <label htmlFor="f-name" className="label-mono mb-1.5 block">
            نام مخاطب
          </label>
          <input
            id="f-name"
            className="field"
            value={form.name}
            onChange={(e) => update("name", e.target.value)}
            placeholder="نام و نام خانوادگی یا عنوان دفتر"
          />
        </div>

        <div>
          <label htmlFor="f-group" className="label-mono mb-1.5 block">
            گروه
          </label>
          <select
            id="f-group"
            className="field"
            value={form.groupName}
            onChange={(e) => update("groupName", e.target.value)}
          >
            {GROUPS.map((g) => (
              <option key={g} value={g}>
                {g}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="f-phones" className="label-mono mb-1.5 block">
            تلفن — یک شماره در هر خط
          </label>
          <textarea
            id="f-phones"
            className="field mono text-right"
            dir="ltr"
            rows={2}
            value={form.phones}
            onChange={(e) => update("phones", e.target.value)}
            placeholder={"0912 000 0000\n+98 912 000 0000"}
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label htmlFor="f-email" className="label-mono mb-1.5 block">
              ایمیل
            </label>
            <input
              id="f-email"
              dir="ltr"
              className="field mono text-left"
              value={form.email}
              onChange={(e) => update("email", e.target.value)}
              placeholder="name@mail.ir"
            />
          </div>
          <div>
            <label htmlFor="f-tg" className="label-mono mb-1.5 block">
              تلگرام
            </label>
            <input
              id="f-tg"
              dir="ltr"
              className="field mono text-left"
              value={form.telegram}
              onChange={(e) => update("telegram", e.target.value)}
              placeholder="@username"
            />
          </div>
        </div>

        <div>
          <label htmlFor="f-bd" className="label-mono mb-1.5 block">
            تاریخ تولد
          </label>
          <input
            id="f-bd"
            type="date"
            dir="ltr"
            className="field mono text-left"
            value={form.birthday}
            onChange={(e) => update("birthday", e.target.value)}
          />
        </div>

        <div>
          <label htmlFor="f-notes" className="label-mono mb-1.5 block">
            توضیحات
          </label>
          <textarea
            id="f-notes"
            className="field"
            rows={3}
            value={form.notes}
            onChange={(e) => update("notes", e.target.value)}
            placeholder="یادداشت کوتاه دربارهٔ این مخاطب…"
          />
        </div>

        <button
          type="button"
          onClick={() => update("favorite", !form.favorite)}
          className="btn-ghost w-full"
          aria-pressed={form.favorite}
          style={
            form.favorite
              ? { color: "#D9A441", borderColor: "rgba(217,164,65,0.5)" }
              : undefined
          }
        >
          <Star size={14} fill={form.favorite ? "#D9A441" : "none"} />
          {form.favorite ? "در فهرست برگزیده‌هاست" : "افزودن به برگزیده‌ها"}
        </button>
      </div>

      {error ? (
        <p className="mt-4 flex items-center gap-2 border border-[rgba(255,93,104,0.4)] bg-[rgba(255,93,104,0.08)] px-3 py-2 text-sm text-[#ff9aa2]">
          <AlertCircle size={15} />
          {error}
        </p>
      ) : null}

      <div className="mt-5 flex gap-2">
        <button type="submit" className="btn-cyan flex-1" disabled={busy}>
          <Save size={16} />
          {busy ? "در حال ذخیره…" : "ذخیره"}
        </button>
        {initial ? (
          <button type="button" className="btn-ghost" onClick={onCancelEdit}>
            <X size={14} />
            انصراف
          </button>
        ) : null}
      </div>
    </form>
  );
}
