import { desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { backups, contacts } from "@/db/schema";
import { SEED_CONTACTS } from "@/lib/seed";
import Directory from "@/components/Directory";

export const dynamic = "force-dynamic";

async function loadData() {
  const existing = await db.select({ id: contacts.id }).from(contacts).limit(1);
  if (existing.length === 0) {
    await db.insert(contacts).values(SEED_CONTACTS);
  }

  const [rows, history, totals] = await Promise.all([
    db.select().from(contacts).orderBy(sql`${contacts.favorite} desc`),
    db.select().from(backups).orderBy(desc(backups.createdAt)).limit(8),
    db.select({ id: contacts.id }).from(contacts),
  ]);

  return { rows, history, total: totals.length };
}

export default async function HomePage() {
  const { rows, history, total } = await loadData();

  return (
    <main>
      <header className="relative isolate overflow-hidden border-b border-[rgba(47,216,228,0.14)]">
        <img
          src="images/switchboard.jpg"
          alt=""
          aria-hidden
          className="absolute inset-0 h-full w-full object-cover object-[20%_center] opacity-70"
        />
        <div
          aria-hidden
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(to left, rgba(5,13,26,0.97) 0%, rgba(5,13,26,0.9) 42%, rgba(5,13,26,0.3) 78%, rgba(5,13,26,0.55) 100%)",
          }}
        />
        <div
          aria-hidden
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(to top, rgba(5,13,26,0.95) 0%, rgba(5,13,26,0) 55%)",
          }}
        />

        <div className="relative mx-auto max-w-[1240px] px-4 pt-12 pb-10 sm:px-6 sm:pt-20 sm:pb-14">
          <div className="flex items-center gap-3">
            <span className="block h-px w-10 bg-[rgba(217,164,65,0.6)]" />
            <span className="mono text-[11px] tracking-[0.32em] text-[#D9A441]">
              داتریم واقعی / LifeOS
            </span>
          </div>

          <h1 className="mt-5 text-[clamp(3.6rem,13vw,7.5rem)] leading-[0.82] font-black tracking-tight text-[#EAF3FA]">
            مخاطبین
          </h1>

          <div className="mt-6 flex flex-wrap items-end gap-x-8 gap-y-4">
            <p className="max-w-[46ch] text-[14px] leading-8 font-light text-[#a8c3d8]">
              دفترچهٔ تلفن عملیاتی: جستجوی زنده روی نام، شماره و توضیحات، گروه‌بندی
              دوستان و خدمات، ویرایش درجا، و پشتیبان‌گیری کامل JSON / CSV با رسید ثبت‌شده.
            </p>
            <span className="mono text-[10px] tracking-[0.28em] text-[#546d84]">
              OPERATOR CONSOLE · PHONEBOOK v2.4
            </span>
          </div>
        </div>
      </header>

      <Directory initialContacts={rows} initialHistory={history} total={total} />

      <footer className="border-t border-[rgba(47,216,228,0.1)] py-8">
        <div className="mx-auto flex max-w-[1240px] flex-wrap items-center justify-between gap-3 px-4 sm:px-6">
          <span className="mono text-[10px] tracking-[0.24em] text-[#33506a]">
            DATARIM VAGHII · LIFEOS OPERATOR CONSOLE
          </span>
          <span className="text-[11px] font-light text-[#546d84]">
            داده‌ها روی همین سرور نگهداری می‌شوند؛ پیش از هر تغییر بزرگ، نسخهٔ پشتیبان
            بگیرید.
          </span>
        </div>
      </footer>
    </main>
  );
}
