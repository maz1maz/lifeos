import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "مخاطبین — دفترچهٔ تلفن داتریم واقعی / LifeOS",
  description:
    "دفترچهٔ تلفن حرفه‌ای با جستجوی زنده، گروه‌بندی، ویرایش و پشتیبان‌گیری کامل (JSON / CSV).",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link
          href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;500;800;900&family=IBM+Plex+Mono:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="grain min-h-screen bg-[#050D1A] text-[#DCE7F2] antialiased">
        {children}
      </body>
    </html>
  );
}
