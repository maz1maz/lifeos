import { NextResponse } from "next/server";
import { db } from "@/db";
import { backups, contacts } from "@/db/schema";

export const dynamic = "force-dynamic";

type Incoming = {
  name?: unknown;
  groupName?: unknown;
  group_name?: unknown;
  phones?: unknown;
  email?: unknown;
  telegram?: unknown;
  birthday?: unknown;
  notes?: unknown;
  favorite?: unknown;
};

function clean(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

function parsePhones(value: unknown): string[] {
  if (Array.isArray(value)) return value.map(clean).filter(Boolean);
  return clean(value)
    .split(/[|,،;\n]+/)
    .map((p) => p.trim())
    .filter(Boolean);
}

/** minimal RFC-4180-ish CSV reader (handles quoted cells and commas) */
function parseCsv(text: string): Record<string, string>[] {
  const rows: string[][] = [];
  let cell = "";
  let row: string[] = [];
  let inQuotes = false;
  const source = text.replace(/^\uFEFF/, "");

  for (let i = 0; i < source.length; i += 1) {
    const ch = source[i];
    if (inQuotes) {
      if (ch === '"') {
        if (source[i + 1] === '"') {
          cell += '"';
          i += 1;
        } else {
          inQuotes = false;
        }
      } else {
        cell += ch;
      }
    } else if (ch === '"') {
      inQuotes = true;
    } else if (ch === ",") {
      row.push(cell);
      cell = "";
    } else if (ch === "\n" || ch === "\r") {
      if (ch === "\r" && source[i + 1] === "\n") i += 1;
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
    } else {
      cell += ch;
    }
  }
  if (cell.length || row.length) {
    row.push(cell);
    rows.push(row);
  }

  const [header, ...body] = rows.filter((r) => r.some((c) => c.trim() !== ""));
  if (!header) return [];
  return body.map((cells) => {
    const obj: Record<string, string> = {};
    header.forEach((key, index) => {
      obj[key.trim()] = (cells[index] ?? "").trim();
    });
    return obj;
  });
}

export async function POST(request: Request) {
  const mode = new URL(request.url).searchParams.get("mode") ?? "replace";
  const contentType = request.headers.get("content-type") ?? "";
  const text = await request.text();

  let items: Incoming[] = [];
  try {
    if (contentType.includes("csv") || text.trimStart().startsWith("name,")) {
      items = parseCsv(text) as Incoming[];
    } else {
      const parsed = JSON.parse(text) as unknown;
      if (Array.isArray(parsed)) items = parsed as Incoming[];
      else if (parsed && typeof parsed === "object") {
        const obj = parsed as { contacts?: Incoming[] };
        items = Array.isArray(obj.contacts) ? obj.contacts : [];
      }
    }
  } catch {
    return NextResponse.json(
      { error: "فایل پشتیبان خوانده نشد. فرمت JSON یا CSV معتبر انتخاب کنید." },
      { status: 400 },
    );
  }

  const values = items
    .map((item) => ({
      name: clean(item.name),
      groupName: clean(item.groupName) || clean(item.group_name) || "دوست",
      phones: parsePhones(item.phones),
      email: clean(item.email) || null,
      telegram: clean(item.telegram).replace(/^@/, "") || null,
      birthday: clean(item.birthday) || null,
      notes: clean(item.notes) || null,
      favorite:
        item.favorite === true ||
        item.favorite === "true" ||
        item.favorite === "1",
    }))
    .filter((v) => v.name);

  if (!values.length) {
    return NextResponse.json(
      { error: "هیچ مخاطب معتبری در فایل پیدا نشد." },
      { status: 400 },
    );
  }

  if (mode === "replace") {
    await db.delete(contacts);
  }
  const inserted = await db.insert(contacts).values(values).returning();

  await db.insert(backups).values({
    kind: "restore",
    format: "json",
    label: `بازیابی ${inserted.length} مخاطب`,
    count: inserted.length,
  });

  return NextResponse.json({ ok: true, count: inserted.length, mode });
}
