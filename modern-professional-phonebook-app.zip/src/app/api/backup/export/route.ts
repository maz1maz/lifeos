import { NextResponse } from "next/server";
import { asc } from "drizzle-orm";
import { db } from "@/db";
import { backups, contacts } from "@/db/schema";

export const dynamic = "force-dynamic";

const CSV_HEADER = [
  "name",
  "group_name",
  "phones",
  "email",
  "telegram",
  "birthday",
  "notes",
  "favorite",
];

function csvCell(value: string | null | boolean | string[]): string {
  const raw = Array.isArray(value)
    ? value.join(" | ")
    : value === null || value === undefined
      ? ""
      : String(value);
  return `"${raw.replace(/"/g, '""')}"`;
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const format = url.searchParams.get("format") === "csv" ? "csv" : "json";
  const rows = await db.select().from(contacts).orderBy(asc(contacts.name));

  const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
  const label = `phonebook-${stamp}.${format}`;

  await db.insert(backups).values({
    kind: "export",
    format,
    label,
    count: rows.length,
  });

  if (format === "json") {
    const payload = {
      app: "Phonebook — داتریم واقعی / LifeOS",
      version: 1,
      exportedAt: new Date().toISOString(),
      count: rows.length,
      contacts: rows.map((r) => ({
        name: r.name,
        groupName: r.groupName,
        phones: r.phones,
        email: r.email,
        telegram: r.telegram,
        birthday: r.birthday,
        notes: r.notes,
        favorite: r.favorite,
      })),
    };
    return new NextResponse(JSON.stringify(payload, null, 2), {
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Content-Disposition": `attachment; filename="${label}"`,
        "Cache-Control": "no-store",
      },
    });
  }

  const lines = [CSV_HEADER.join(",")];
  for (const r of rows) {
    lines.push(
      [
        csvCell(r.name),
        csvCell(r.groupName),
        csvCell(r.phones),
        csvCell(r.email),
        csvCell(r.telegram),
        csvCell(r.birthday),
        csvCell(r.notes),
        r.favorite ? "true" : "false",
      ].join(","),
    );
  }
  const csv = "\uFEFF" + lines.join("\r\n");
  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${label}"`,
      "Cache-Control": "no-store",
    },
  });
}
