import { NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { backups, contacts } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  const [history, stats] = await Promise.all([
    db.select().from(backups).orderBy(desc(backups.createdAt)).limit(8),
    db.select({ count: contacts.id }).from(contacts),
  ]);

  return NextResponse.json({
    history,
    total: stats.length,
    last: history.find((h) => h.kind === "export") ?? history[0] ?? null,
  });
}
