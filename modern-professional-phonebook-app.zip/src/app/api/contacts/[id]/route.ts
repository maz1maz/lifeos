import { NextResponse } from "next/server";
import { eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { contacts } from "@/db/schema";

export const dynamic = "force-dynamic";

const GROUPS = ["دوست", "خانواده", "همکار", "مشتری", "خدمات"];

function clean(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

type Params = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, { params }: Params) {
  const { id } = await params;
  const numericId = Number(id);
  if (!Number.isInteger(numericId)) {
    return NextResponse.json({ error: "شناسه نامعتبر است." }, { status: 400 });
  }

  const body = (await request.json()) as Record<string, unknown>;
  const patch: Partial<typeof contacts.$inferInsert> = {};

  if ("name" in body) {
    const name = clean(body.name);
    if (!name) {
      return NextResponse.json({ error: "نام مخاطب الزامی است." }, { status: 400 });
    }
    patch.name = name;
  }
  if ("groupName" in body) {
    const group = clean(body.groupName);
    patch.groupName = GROUPS.includes(group) ? group : "دوست";
  }
  if ("phones" in body) {
    patch.phones = Array.isArray(body.phones)
      ? (body.phones as unknown[]).map(clean).filter(Boolean)
      : clean(body.phones)
          .split(/[\n,،]+/)
          .map((p) => p.trim())
          .filter(Boolean);
  }
  if ("email" in body) patch.email = clean(body.email) || null;
  if ("telegram" in body)
    patch.telegram = clean(body.telegram).replace(/^@/, "") || null;
  if ("birthday" in body) patch.birthday = clean(body.birthday) || null;
  if ("notes" in body) patch.notes = clean(body.notes) || null;
  if ("favorite" in body) patch.favorite = Boolean(body.favorite);

  const [row] = await db
    .update(contacts)
    .set(patch)
    .where(eq(contacts.id, numericId))
    .returning();

  if (!row) {
    return NextResponse.json({ error: "مخاطب پیدا نشد." }, { status: 404 });
  }
  return NextResponse.json({ row });
}

export async function DELETE(_request: Request, { params }: Params) {
  const { id } = await params;
  const numericId = Number(id);
  if (!Number.isInteger(numericId)) {
    return NextResponse.json({ error: "شناسه نامعتبر است." }, { status: 400 });
  }

  const removed = await db
    .delete(contacts)
    .where(eq(contacts.id, numericId))
    .returning({ id: contacts.id });

  if (!removed.length) {
    return NextResponse.json({ error: "مخاطب پیدا نشد." }, { status: 404 });
  }
  return NextResponse.json({ ok: true, id: numericId });
}

export async function GET(_request: Request, { params }: Params) {
  const { id } = await params;
  const numericId = Number(id);
  const [row] = await db
    .select()
    .from(contacts)
    .where(inArray(contacts.id, [numericId]));
  if (!row) {
    return NextResponse.json({ error: "مخاطب پیدا نشد." }, { status: 404 });
  }
  return NextResponse.json({ row });
}
