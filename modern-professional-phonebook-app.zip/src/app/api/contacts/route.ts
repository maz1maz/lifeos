import { NextResponse } from "next/server";
import { and, desc, ilike, or, sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { contacts } from "@/db/schema";

export const dynamic = "force-dynamic";

const GROUPS = ["دوست", "خانواده", "همکار", "مشتری", "خدمات"];

function clean(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const q = (url.searchParams.get("q") ?? "").trim();
  const group = (url.searchParams.get("group") ?? "").trim();

  const filters: SQL[] = [];
  if (group && group !== "همه") {
    filters.push(ilike(contacts.groupName, group));
  }
  if (q) {
    const like = `%${q.replace(/[%_]/g, " ")}%`;
    const search = or(
      ilike(contacts.name, like),
      ilike(contacts.email, like),
      ilike(contacts.telegram, like),
      ilike(contacts.notes, like),
      sql`${contacts.phones}::text ilike ${like}`,
    );
    if (search) filters.push(search);
  }

  const [rows, totals] = await Promise.all([
    db
      .select()
      .from(contacts)
      .where(filters.length ? and(...filters) : undefined)
      .orderBy(desc(contacts.favorite), desc(contacts.createdAt)),
    db
      .select({ value: sql<number>`count(*)::int` })
      .from(contacts),
  ]);

  return NextResponse.json({
    rows,
    count: rows.length,
    total: totals[0]?.value ?? rows.length,
  });
}

export async function POST(request: Request) {
  const body = (await request.json()) as Record<string, unknown>;
  const name = clean(body.name);
  if (!name) {
    return NextResponse.json({ error: "نام مخاطب الزامی است." }, { status: 400 });
  }

  const phones = Array.isArray(body.phones)
    ? (body.phones as unknown[]).map(clean).filter(Boolean)
    : clean(body.phones)
        .split(/[\n,،]+/)
        .map((p) => p.trim())
        .filter(Boolean);

  const groupName = GROUPS.includes(clean(body.groupName))
    ? clean(body.groupName)
    : "دوست";

  const [row] = await db
    .insert(contacts)
    .values({
      name,
      groupName,
      phones,
      email: clean(body.email) || null,
      telegram: clean(body.telegram).replace(/^@/, "") || null,
      birthday: clean(body.birthday) || null,
      notes: clean(body.notes) || null,
      favorite: Boolean(body.favorite),
    })
    .returning();

  return NextResponse.json({ row }, { status: 201 });
}
