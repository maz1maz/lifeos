import {
  boolean,
  date,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  groupName: text("group_name").notNull().default("دوست"),
  phones: text("phones").array().notNull(),
  email: text("email"),
  telegram: text("telegram"),
  birthday: date("birthday", { mode: "string" }),
  notes: text("notes"),
  favorite: boolean("favorite").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const backups = pgTable("backups", {
  id: serial("id").primaryKey(),
  kind: text("kind").notNull().default("export"),
  format: text("format").notNull(),
  label: text("label").notNull(),
  count: integer("count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type Contact = typeof contacts.$inferSelect;
export type NewContact = typeof contacts.$inferInsert;
export type BackupRecord = typeof backups.$inferSelect;
