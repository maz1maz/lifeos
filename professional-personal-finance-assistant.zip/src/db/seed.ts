import { db } from "@/db";
import { accounts, categories, debts, holdings, prices, transactions, transfers } from "@/db/schema";
import { sql } from "drizzle-orm";

type Tx = {
  d: string;
  desc: string;
  note?: string;
  ref?: string;
  cat: string;
  acc: string;
  kind: "income" | "expense";
  amount: number;
};

const ACCOUNT_SEED = [
  { key: "mellat", name: "بانک ملت — جاری", kind: "bank", openingBalance: 412_500_000 },
  { key: "card", name: "کارت اصل", kind: "card", openingBalance: 38_400_000 },
  { key: "cash", name: "صندوق خانه", kind: "cash", openingBalance: 6_250_000 },
  { key: "wallet", name: "کیف پول دیجی‌پی", kind: "wallet", openingBalance: 1_875_000 },
  { key: "saman", name: "بانک سامان — ارزی", kind: "fx", openingBalance: 24_000_000 },
];

const CATEGORY_SEED: { key: string; name: string; kind: string; tone: string; limit: number }[] = [
  { key: "rent", name: "اجاره مسکن", kind: "expense", tone: "#E0684F", limit: 65_000_000 },
  { key: "bills", name: "قبض", kind: "expense", tone: "#D8AC4E", limit: 9_500_000 },
  { key: "grocery", name: "خرید", kind: "expense", tone: "#2AD4E4", limit: 26_000_000 },
  { key: "transport", name: "حمل‌ونقل", kind: "expense", tone: "#78A0B4", limit: 12_000_000 },
  { key: "misc", name: "متفرقه", kind: "expense", tone: "#9B8BE0", limit: 9_000_000 },
  { key: "food", name: "رستوران", kind: "expense", tone: "#E39B62", limit: 11_000_000 },
  { key: "health", name: "درمان", kind: "expense", tone: "#63C7A6", limit: 8_000_000 },
  { key: "edu", name: "آموزش", kind: "expense", tone: "#7FA6E8", limit: 6_000_000 },
  { key: "salary", name: "حقوق", kind: "income", tone: "#2AD4E4", limit: 0 },
  { key: "sell", name: "فروش", kind: "income", tone: "#63C7A6", limit: 0 },
  { key: "profit", name: "سود سپرده", kind: "income", tone: "#D8AC4E", limit: 0 },
  { key: "free", name: "آزادسازی", kind: "income", tone: "#7FA6E8", limit: 0 },
];

const TX_SEED: Tx[] = [
  { d: "2026-09-01", desc: "واریز حقوق شهریور", note: "شرکت آریا‌نگار", ref: "HR-0901", cat: "salary", acc: "mellat", kind: "income", amount: 78_000_000 },
  { d: "2026-09-01", desc: "اجاره مسکن — شهریور", note: "کارت به کارت به مالک", ref: "#اجاره", cat: "rent", acc: "mellat", kind: "expense", amount: 62_000_000 },
  { d: "2026-09-02", desc: "خرید از فروشگاه سوپرمارکت", note: "#سوپرمارکت", ref: "#سوپرمارکت", cat: "grocery", acc: "card", kind: "expense", amount: 1_842_000 },
  { d: "2026-09-02", desc: "شارژ ساختمان — نیمه اول", note: "مدیر ساختمان", cat: "bills", acc: "card", kind: "expense", amount: 763_500 },
  { d: "2026-09-03", desc: "قبض برق — تابستانه", note: "دوره تیر تا شهریور", ref: "#برق", cat: "bills", acc: "mellat", kind: "expense", amount: 4_310_000 },
  { d: "2026-09-03", desc: "کرایه تاکسی اینترنتی", note: "مسیر خانه تا دفتر", cat: "transport", acc: "wallet", kind: "expense", amount: 268_000 },
  { d: "2026-09-04", desc: "ناهار همکاران — ورگل جدا", ref: "#رستوران", cat: "food", acc: "card", kind: "expense", amount: 1_271_000 },
  { d: "2026-09-05", desc: "قبض اینترنت و تلفن", note: "ماهانه", cat: "bills", acc: "mellat", kind: "expense", amount: 1_683_500 },
  { d: "2026-09-06", desc: "بنزین — باک کامل", note: "جایگاه آزادی", cat: "transport", acc: "card", kind: "expense", amount: 2_400_000 },
  { d: "2026-09-07", desc: "خرید کتاب و دفتر", note: "کتابفروشی ترنجستان", cat: "edu", acc: "card", kind: "expense", amount: 987_000 },
  { d: "2026-09-08", desc: "فروش دوربین دست‌دوم", note: "دیوار — تسویه نقدی", ref: "#فروش", cat: "sell", acc: "wallet", kind: "income", amount: 12_500_000 },
  { d: "2026-09-08", desc: "خرید از فروشگاه زنجیره‌ای", note: "#سوپرمارکت", cat: "grocery", acc: "card", kind: "expense", amount: 3_120_400 },
  { d: "2026-09-09", desc: "دندان‌پزشکی — جرم‌گیری", note: "مطب دکتر کاشانی", cat: "health", acc: "mellat", kind: "expense", amount: 4_800_000 },
  { d: "2026-09-10", desc: "اشتراک نرم‌افزار حسابداری", note: "سالانه — بخشی", cat: "misc", acc: "card", kind: "expense", amount: 1_150_000 },
  { d: "2026-09-11", desc: "خرید میوه و سبزی", note: "میدان تره‌بار", cat: "grocery", acc: "cash", kind: "expense", amount: 1_430_000 },
  { d: "2026-09-12", desc: "کارت به کارت به حساب پدر", note: "کمک هزینه", ref: "#انتقال", cat: "misc", acc: "mellat", kind: "expense", amount: 5_000_000 },
  { d: "2026-09-13", desc: "بلیت سینما و پاپ‌کورن", note: "پردیس کوروش", cat: "misc", acc: "wallet", kind: "expense", amount: 742_000 },
  { d: "2026-09-14", desc: "سوخت خودرو — گاز", note: "", cat: "transport", acc: "card", kind: "expense", amount: 640_000 },
  { d: "2026-09-15", desc: "سود سپرده کوتاه‌مدت", note: "واریز به حساب جاری", ref: "#سود", cat: "profit", acc: "mellat", kind: "income", amount: 3_240_000 },
  { d: "2026-09-15", desc: "قبض گاز — علی‌الحساب", note: "", cat: "bills", acc: "mellat", kind: "expense", amount: 921_500 },
  { d: "2026-09-16", desc: "خرید از فروشگاه سوپرمارکت", note: "#سوپرمارکت", cat: "grocery", acc: "card", kind: "expense", amount: 2_265_000 },
  { d: "2026-09-17", desc: "دوره آموزشی تحلیل مالی", note: "قسط دوم", cat: "edu", acc: "mellat", kind: "expense", amount: 3_600_000 },
  { d: "2026-09-18", desc: "شام خانوادگی — رستوران", note: "#رستوران", cat: "food", acc: "card", kind: "expense", amount: 2_087_500 },
  { d: "2026-09-19", desc: "داروخانه — ویتامین", note: "", cat: "health", acc: "card", kind: "expense", amount: 1_186_000 },
  { d: "2026-09-20", desc: "هدیه تولد دوست", note: "کادو", cat: "misc", acc: "wallet", kind: "expense", amount: 1_800_000 },
  { d: "2026-09-21", desc: "پروژه آزاد — طراحی مالی", note: "فریلنسری — تسویه کامل", ref: "#آزادسازی", cat: "free", acc: "mellat", kind: "income", amount: 18_600_000 },
  { d: "2026-09-21", desc: "کارت به کارت به حساب متقاضد", note: "بازپرداخت قرض", ref: "#انتقال", cat: "misc", acc: "card", kind: "expense", amount: 2_500_000 },
  { d: "2026-09-22", desc: "خرید پوشاک فصل", note: "پاساژ", cat: "grocery", acc: "card", kind: "expense", amount: 6_450_000 },
  { d: "2026-09-23", desc: "کرایه تاکسی — فرودگاه", note: "سفر کاری", cat: "transport", acc: "cash", kind: "expense", amount: 890_000 },
  { d: "2026-09-24", desc: "نان و لبنیات", note: "نانوایی محل", cat: "grocery", acc: "cash", kind: "expense", amount: 318_000 },
  { d: "2026-09-24", desc: "خرید از فروشگاه سوپرمارکت", note: "#سوپرمارکت", ref: "#سوپرمارکت", cat: "grocery", acc: "card", kind: "expense", amount: 1_783_500 },
];

const DEBT_SEED = [
  { party: "پدر — حسین", direction: "payable", amount: 15_000_000, dueOn: "2026-10-15", note: "کمک هزینه خرید خودرو" },
  { party: "نیما نامداری", direction: "payable", amount: 4_500_000, dueOn: "2026-10-20", note: "قرض نقدی" },
  { party: "قسط وام بانک سامان", direction: "payable", amount: 22_400_000, dueOn: "2026-10-05", note: "قسط چهارم از دوازده" },
  { party: "پیمان — سهم سفر مشهد", direction: "payable", amount: 6_800_000, dueOn: "2026-11-01", note: "هزینه هتل" },
  { party: "سارا محمدی", direction: "payable", amount: 2_300_000, dueOn: "2026-10-10", note: "خرید مشترک" },
  { party: "مانی (همکار)", direction: "receivable", amount: 9_000_000, dueOn: "2026-10-12", note: "پیش‌پرداخت پروژه" },
  { party: "آرش — پسرعمو", direction: "receivable", amount: 3_200_000, dueOn: "2026-10-30", note: "قرض برای شهریه" },
  { party: "شرکت آریا‌نگار", direction: "receivable", amount: 24_000_000, dueOn: "2026-10-01", note: "صورت‌حساب پروژه دوم" },
  { party: "شیدا رستمی", direction: "receivable", amount: 1_450_000, dueOn: "2026-09-30", note: "بلیت سفر" },
];

const HOLDING_SEED = [
  { symbol: "USD", name: "دلار آمریکا", kind: "currency", unit: "دلار", qty: 500, avgPrice: 735_000 },
  { symbol: "EUR", name: "یورو", kind: "currency", unit: "یورو", qty: 100, avgPrice: 880_000 },
  { symbol: "COIN", name: "سکه امامی", kind: "coin", unit: "عدد", qty: 2, avgPrice: 385_000_000 },
  { symbol: "GOLD18", name: "طلای ۱۸ عیار", kind: "gold", unit: "گرم", qty: 5, avgPrice: 49_000_000 },
  { symbol: "FUND1", name: "صندوق درآمد ثابت کاریزما", kind: "fund", unit: "واحد", qty: 1000, avgPrice: 52_000 },
  { symbol: "BTC", name: "بیت‌کوین", kind: "crypto", unit: "بیت‌کوین", qty: 0.05, avgPrice: 6_400_000_000 },
];

const PRICE_SEED = [
  { symbol: "USD", name: "دلار", unit: "دلار", price: 782_000, changeRial: 400 },
  { symbol: "EUR", name: "یورو", unit: "یورو", price: 918_000, changeRial: 100 },
  { symbol: "COIN", name: "سکه امامی", unit: "عدد", price: 438_000_000, changeRial: 1_250_000 },
  { symbol: "GOLD18", name: "طلا ۱۸", unit: "گرم", price: 57_400_000, changeRial: 180_000 },
  { symbol: "FUND1", name: "صندوق کاریزما", unit: "واحد", price: 58_600, changeRial: 120 },
  { symbol: "BTC", name: "بیت‌کوین", unit: "بیت‌کوین", price: 7_150_000_000, changeRial: -42_000_000 },
];

let seeded = false;

/** Idempotent: fills the ledger only when the database is empty. */
export async function ensureSeed(): Promise<void> {
  if (seeded) return;
  const res = await db.execute<{ count: string }>(sql`select count(*)::int as count from accounts`);
  const count = Number(res.rows?.[0]?.count ?? 0);
  if (count > 0) {
    seeded = true;
    return;
  }

  const accRows = await db
    .insert(accounts)
    .values(ACCOUNT_SEED.map((a) => ({ name: a.name, kind: a.kind, openingBalance: a.openingBalance })))
    .returning();
  const accByKey = new Map(ACCOUNT_SEED.map((a, i) => [a.key, accRows[i].id]));

  const catRows = await db
    .insert(categories)
    .values(
      CATEGORY_SEED.map((c) => ({ name: c.name, kind: c.kind, tone: c.tone, monthlyLimit: c.limit })),
    )
    .returning();
  const catByKey = new Map(CATEGORY_SEED.map((c, i) => [c.key, catRows[i].id]));

  await db.insert(transactions).values(
    TX_SEED.map((t) => ({
      occurredOn: t.d,
      description: t.desc,
      note: t.note ?? null,
      refCode: t.ref ?? null,
      kind: t.kind,
      amount: t.amount,
      categoryId: catByKey.get(t.cat) ?? null,
      accountId: accByKey.get(t.acc) ?? null,
    })),
  );

  await db.insert(transfers).values([
    {
      occurredOn: "2026-09-05",
      fromAccountId: accByKey.get("mellat")!,
      toAccountId: accByKey.get("card")!,
      amount: 20_000_000,
      note: "شارژ کارت برای خریدهای روزمره",
    },
    {
      occurredOn: "2026-09-16",
      fromAccountId: accByKey.get("wallet")!,
      toAccountId: accByKey.get("cash")!,
      amount: 3_000_000,
      note: "برداشت نقدی",
    },
    {
      occurredOn: "2026-09-22",
      fromAccountId: accByKey.get("mellat")!,
      toAccountId: accByKey.get("saman")!,
      amount: 15_000_000,
      note: "جهت خرید ارز",
    },
  ]);

  await db.insert(debts).values(DEBT_SEED);
  await db.insert(holdings).values(HOLDING_SEED);
  await db.insert(prices).values(PRICE_SEED);
  seeded = true;
}
