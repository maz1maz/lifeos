import {
  bigint,
  boolean,
  date,
  integer,
  numeric,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const accounts = pgTable("accounts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  kind: text("kind").notNull().default("bank"), // bank | card | cash | wallet | fx
  currency: text("currency").notNull().default("IRR"),
  openingBalance: bigint("opening_balance", { mode: "number" }).notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  kind: text("kind").notNull().default("expense"), // expense | income
  tone: text("tone").notNull().default("#2AD4E4"),
  monthlyLimit: bigint("monthly_limit", { mode: "number" }).notNull().default(0),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  occurredOn: date("occurred_on").notNull(),
  description: text("description").notNull(),
  note: text("note"),
  refCode: text("ref_code"),
  kind: text("kind").notNull().default("expense"), // expense | income
  amount: bigint("amount", { mode: "number" }).notNull(),
  categoryId: integer("category_id").references(() => categories.id),
  accountId: integer("account_id").references(() => accounts.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const transfers = pgTable("transfers", {
  id: serial("id").primaryKey(),
  occurredOn: date("occurred_on").notNull(),
  fromAccountId: integer("from_account_id")
    .notNull()
    .references(() => accounts.id),
  toAccountId: integer("to_account_id")
    .notNull()
    .references(() => accounts.id),
  amount: bigint("amount", { mode: "number" }).notNull(),
  note: text("note"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const debts = pgTable("debts", {
  id: serial("id").primaryKey(),
  party: text("party").notNull(),
  direction: text("direction").notNull().default("payable"), // payable | receivable
  amount: bigint("amount", { mode: "number" }).notNull(),
  dueOn: date("due_on"),
  note: text("note"),
  settled: boolean("settled").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const holdings = pgTable("holdings", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  name: text("name").notNull(),
  kind: text("kind").notNull().default("currency"), // currency | gold | coin | fund | crypto
  unit: text("unit").notNull().default("واحد"),
  qty: numeric("qty", { precision: 24, scale: 6, mode: "number" }).notNull().default(0),
  avgPrice: bigint("avg_price", { mode: "number" }).notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const prices = pgTable("prices", {
  symbol: text("symbol").primaryKey(),
  name: text("name").notNull(),
  unit: text("unit").notNull().default("واحد"),
  price: bigint("price", { mode: "number" }).notNull(),
  changeRial: bigint("change_rial", { mode: "number" }).notNull().default(0),
});
