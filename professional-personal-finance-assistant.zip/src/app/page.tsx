import Link from "next/link";
import { ensureSeed } from "@/db/seed";
import {
  getAccountsView,
  getDebtsView,
  getMonthView,
  getPortfolio,
  getCategoryOptions,
} from "@/lib/data";
import {
  ACCOUNT_KINDS,
  HOLDING_KINDS,
  enMonth,
  fa,
  faDate,
  faMonth,
  rial,
  rialShort,
  shiftMonth,
  toman,
} from "@/lib/format";
import {
  AllocationBars,
  CashflowChart,
  Donut,
  Gauge,
  HoldingTone,
  Sparkline,
} from "@/components/charts";
import { Kicker, Panel, Rule, StarMark, Stat } from "@/components/ui";
import {
  AccountForm,
  BudgetForm,
  DebtForm,
  DeleteTxButton,
  HoldingForm,
  ImportPanel,
  QuickTxForm,
  SettleButton,
  TransferForm,
} from "@/components/forms";

export const dynamic = "force-dynamic";

const WRAP = "mx-auto w-full max-w-[1340px] px-5 sm:px-8";

const TABS = [
  { key: "all", label: "همه" },
  { key: "income", label: "درآمد" },
  { key: "expense", label: "هزینه" },
  { key: "transfer", label: "انتقال" },
];

const NAV = [
  { href: "#ledger", label: "دفتر ماه" },
  { href: "#budget", label: "بودجه" },
  { href: "#accounts", label: "حساب‌ها" },
  { href: "#portfolio", label: "سبد سرمایه" },
  { href: "#debts", label: "بدهی و طلب" },
  { href: "#import", label: "درون‌ریزی" },
];

export default async function Home({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = await searchParams;
  const monthParam = typeof sp.month === "string" ? sp.month : "";
  const month = /^\d{4}-\d{2}$/.test(monthParam) ? monthParam : "2026-09";
  const kindFilter = typeof sp.kind === "string" && TABS.some((t) => t.key === sp.kind) ? sp.kind : "all";

  await ensureSeed();
  const [mv, av, dv, pf, cats] = await Promise.all([
    getMonthView(month),
    getAccountsView(month),
    getDebtsView(),
    getPortfolio(),
    getCategoryOptions(),
  ]);

  const totalBalance = av.reduce((s, a) => s + a.balance, 0);
  const txs = mv.txs.filter((t) =>
    kindFilter === "all" ? true : kindFilter === "income" ? t.kind === "income" : t.kind === "expense",
  );
  const topCats = mv.categoryTotals.filter((c) => c.spent > 0).slice(0, 5);
  const budgeted = mv.categoryTotals.filter((c) => c.limit > 0);
  const budgetSpent = budgeted.reduce((s, c) => s + c.spent, 0);
  const budgetLimit = budgeted.reduce((s, c) => s + c.limit, 0);

  const pfSegments = pf.items.map((h) => ({
    label: h.name,
    value: h.value,
    tone: HoldingTone(h.kind),
  }));
  const pfValue = pf.items.reduce((s, h) => s + h.value, 0);
  const pfPnl = pf.items.reduce((s, h) => s + h.pnl, 0);

  const catOpts = cats.map((c) => ({ id: c.id, name: c.name, kind: c.kind }));
  const accOpts = av.map((a) => ({ id: a.id, name: a.name }));
  const defaultDate = `${month}-24`;

  const payableTotal = dv.payable.filter((d) => !d.settled).reduce((s, d) => s + d.amount, 0);
  const receivableTotal = dv.receivable.filter((d) => !d.settled).reduce((s, d) => s + d.amount, 0);

  return (
    <main className="pb-24">
      {/* ───────────────────────── top bar ───────────────────────── */}
      <header className="sticky top-0 z-40 border-b border-hair bg-[#04121E]/92 backdrop-blur-md">
        <div className={`${WRAP} flex flex-wrap items-center gap-x-6 gap-y-3 py-3`}>
          <a href="#top" className="flex items-center gap-3">
            <StarMark size={32} />
            <span className="leading-tight">
              <span className="block font-display text-[17px] text-ink">دفتر فیروزه‌ای</span>
              <span className="block text-[9px] tracking-[0.34em] text-muted">دستیار مالی شخصی</span>
            </span>
          </a>

          <nav className="hidden flex-1 items-center gap-6 lg:flex">
            {NAV.map((n) => (
              <a
                key={n.href}
                href={n.href}
                className="border-b border-transparent pb-0.5 text-[13px] text-muted transition-colors duration-150 hover:border-turq hover:text-turq"
              >
                {n.label}
              </a>
            ))}
          </nav>

          <div className="ms-auto flex items-center gap-2">
            <Link
              href={`/?month=${shiftMonth(month, -1)}`}
              className="border border-hair px-3 py-1.5 text-[12px] text-muted transition-colors duration-150 hover:border-turq hover:text-turq"
            >
              ماه قبل
            </Link>
            <span className="min-w-[132px] px-2 text-center font-display text-[15px] tabular-nums text-ink">
              {faMonth(month)}
            </span>
            <Link
              href={`/?month=${shiftMonth(month, 1)}`}
              className="border border-hair px-3 py-1.5 text-[12px] text-muted transition-colors duration-150 hover:border-turq hover:text-turq"
            >
              ماه بعد
            </Link>
          </div>
        </div>

        <nav className="border-t border-hair/70 lg:hidden">
          <div className={`${WRAP} flex gap-5 overflow-x-auto py-2`}>
            {NAV.map((n) => (
              <a
                key={n.href}
                href={n.href}
                className="whitespace-nowrap text-[12px] text-muted transition-colors duration-150 hover:text-turq"
              >
                {n.label}
              </a>
            ))}
          </div>
        </nav>
      </header>

      {/* ───────────────────────── hero band ───────────────────────── */}
      <section id="top" className="relative isolate overflow-hidden">
        <img
          src="images/kashi.jpg"
          alt=""
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-35 [object-position:72%_45%]"
        />
        <div className="absolute inset-0 bg-[linear-gradient(198deg,rgba(4,18,30,0.82),rgba(4,18,30,0.93)_52%,rgba(4,18,30,0.99))]" />
        <div className="grain absolute inset-0" />

        <div className={`${WRAP} relative grid gap-10 pb-8 pt-14 lg:grid-cols-[1.05fr_1fr] lg:gap-16`}>
          <div className="rise">
            <Kicker>صورت مالی ماهانه — با داده واقعی دفتر شما</Kicker>
            <h1 className="font-display text-[clamp(3.2rem,9vw,6.4rem)] font-black leading-[0.86] tracking-tight text-ink">
              صورتِ<br />
              <span className="text-turq">ماه</span>
            </h1>
            <p className="mt-5 max-w-lg text-[15px] leading-8 text-muted">
              {faDate(`${month}-01`)} تا پایان {faMonth(month)} — {fa(mv.txs.length)} سند در {fa(av.length)} حساب،{" "}
              {fa(budgeted.length)} دستهٔ بودجه‌بندی‌شده و {fa(pf.items.length)} دارایی در سبد سرمایه. همهٔ اعداد هم‌زمان از
              پایگاه داده خوانده می‌شوند.
            </p>
            <div className="mt-7 flex items-center gap-6 border-t border-hair pt-5 text-[12px] text-muted">
              <span className="flex items-center gap-2">
                <span className="inline-block h-2 w-2 rotate-45 bg-turq" /> خط: ماندهٔ تجمعی ماه
              </span>
              <span className="flex items-center gap-2">
                <span className="inline-block h-2 w-2 rotate-45 bg-brick" /> میله: هزینهٔ روزانه
              </span>
            </div>
          </div>

          <div className="grid content-start gap-7 sm:grid-cols-3 lg:grid-cols-1 lg:gap-6">
            <Stat label="درآمد ماه" value={fa(mv.income)} sub={`ریال — ${toman(mv.income)}`} tone="#2AD4E4" />
            <Stat label="هزینه ماه" value={fa(mv.expense)} sub={`ریال — ${toman(mv.expense)}`} tone="#E0684F" />
            <Stat
              label="ماندهٔ خالص"
              value={fa(mv.net)}
              sub={`${rial(mv.net)} · گردش انتقال ${rialShort(mv.transferTotal)}`}
              tone="#D8AC4E"
            />
          </div>
        </div>

        <div className="relative w-full border-t border-hair/70 bg-[#04121E]/35 px-2 pb-2 pt-4">
          <CashflowChart days={mv.days} height={300} />
        </div>

        {/* category strip */}
        <div className="relative border-t border-hair bg-[#04121E]/55">
          <div className={`${WRAP} flex flex-wrap items-stretch gap-px py-4`}>
            {topCats.length === 0 ? (
              <p className="py-3 text-[13px] text-muted">هنوز هزینه‌ای در این ماه ثبت نشده است.</p>
            ) : (
              topCats.map((c) => (
                <Link
                  key={c.id}
                  href={`/?month=${month}&kind=expense`}
                  className="group min-w-[152px] flex-1 border border-hair bg-panel-flat px-4 py-3 transition-colors duration-150 hover:border-turq"
                >
                  <div className="text-[15px] text-ink">{c.name}</div>
                  <div className="mt-1 text-[13px] tabular-nums" style={{ color: c.tone }}>
                    {rialShort(c.spent)} ریال
                  </div>
                </Link>
              ))
            )}
          </div>
        </div>
      </section>

      {/* ───────────────────────── ledger band ───────────────────────── */}
      <section id="ledger" className="band-rule py-14">
        <div className={`${WRAP} grid gap-8 lg:grid-cols-[340px_minmax(0,1fr)]`}>
          <div className="lg:sticky lg:top-24 lg:self-start">
            <Panel title="تراکنش تازه" kicker="ثبت سند">
              <QuickTxForm categories={catOpts} accounts={accOpts} defaultDate={defaultDate} />
            </Panel>
          </div>

          <Panel
            title="تراکنش‌های این ماه"
            kicker={enMonth(month)}
            note={
              <span className="flex flex-wrap items-center gap-x-5 gap-y-1">
                <span>
                  درآمد <b className="tabular-nums text-[#7FE6F1]">{rial(mv.income)}</b>
                </span>
                <span>
                  هزینه <b className="tabular-nums text-[#F0A08D]">{rial(mv.expense)}</b>
                </span>
                <span>
                  مانده کل حساب‌ها <b className="tabular-nums text-[#E7C77F]">{rial(totalBalance)}</b>
                </span>
              </span>
            }
          >
            <div className="mb-5 flex flex-wrap gap-2">
              {TABS.map((t) => (
                <Link
                  key={t.key}
                  href={`/?month=${month}&kind=${t.key}`}
                  className={`border px-4 py-1.5 text-[13px] transition-colors duration-150 ${
                    kindFilter === t.key
                      ? "border-turq bg-turq/10 text-turq"
                      : "border-hair text-muted hover:border-turq/60 hover:text-ink"
                  }`}
                >
                  {t.label}
                </Link>
              ))}
            </div>

            {kindFilter === "transfer" ? (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[560px] text-[14px]">
                  <thead>
                    <tr className="border-b border-hair text-[11px] tracking-[0.16em] text-muted">
                      <th className="py-2 text-right font-normal">تاریخ</th>
                      <th className="py-2 text-right font-normal">شرح</th>
                      <th className="py-2 text-right font-normal">از حساب</th>
                      <th className="py-2 text-right font-normal">به حساب</th>
                      <th className="py-2 text-left font-normal">مبلغ</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mv.transfers.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="py-10 text-center text-[13px] text-muted">
                          سند انتقالی در این ماه ثبت نشده است.
                        </td>
                      </tr>
                    ) : (
                      mv.transfers.map((t) => (
                        <tr key={t.id} className="border-b border-hair/50 transition-colors duration-150 hover:bg-[#0C2637]/60">
                          <td className="py-3 text-muted tabular-nums">{faDate(t.occurredOn)}</td>
                          <td className="py-3 text-ink">{t.note ?? "انتقال بین حساب‌ها"}</td>
                          <td className="py-3 text-muted">{t.from}</td>
                          <td className="py-3 text-muted">{t.to}</td>
                          <td className="py-3 text-left tabular-nums text-[#7FE6F1]">{rial(t.amount)}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[680px] text-[14px]">
                  <thead>
                    <tr className="border-b border-hair text-[11px] tracking-[0.16em] text-muted">
                      <th className="py-2 text-right font-normal">تاریخ</th>
                      <th className="py-2 text-right font-normal">شرح</th>
                      <th className="py-2 text-right font-normal">دسته</th>
                      <th className="py-2 text-right font-normal">حساب</th>
                      <th className="py-2 text-left font-normal">مبلغ</th>
                      <th className="w-8" />
                    </tr>
                  </thead>
                  <tbody>
                    {txs.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="py-12 text-center text-[13px] text-muted">
                          سندی با این فیلتر در {faMonth(month)} ثبت نشده است — از فرم «تراکنش تازه» شروع کنید.
                        </td>
                      </tr>
                    ) : (
                      txs.map((t) => (
                        <tr key={t.id} className="border-b border-hair/50 transition-colors duration-150 hover:bg-[#0C2637]/60">
                          <td className="whitespace-nowrap py-3 align-top text-[12px] tabular-nums text-muted">
                            {faDate(t.occurredOn)}
                          </td>
                          <td className="py-3 align-top">
                            <div className="text-ink">{t.description}</div>
                            {t.note || t.refCode ? (
                              <div className="mt-0.5 text-[11px] text-muted">
                                {t.refCode ? <span className="text-brass">{t.refCode}</span> : null}
                                {t.refCode && t.note ? " · " : ""}
                                {t.note}
                              </div>
                            ) : null}
                          </td>
                          <td className="py-3 align-top">
                            <span className="flex items-center gap-2 text-[13px] text-muted">
                              <span className="inline-block h-2 w-2 rotate-45" style={{ background: t.tone }} />
                              {t.category}
                            </span>
                          </td>
                          <td className="py-3 align-top text-[13px] text-muted">{t.account ?? "بدون حساب"}</td>
                          <td
                            className={`whitespace-nowrap py-3 text-left align-top tabular-nums ${
                              t.kind === "income" ? "text-[#7FE6F1]" : "text-[#E9F6F9]"
                            }`}
                          >
                            {t.kind === "income" ? "+" : "−"}
                            {rial(t.amount)}
                          </td>
                          <td className="py-3 align-top text-left">
                            <DeleteTxButton id={t.id} />
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </Panel>
        </div>
      </section>

      {/* ───────────────────────── budget band ───────────────────────── */}
      <section id="budget" className="band-rule py-14">
        <div className={`${WRAP} grid gap-8 lg:grid-cols-[minmax(0,1fr)_360px]`}>
          <Panel
            title="بودجه"
            kicker={`${faMonth(month)} — ${enMonth(month)}`}
            note={
              <span className="flex flex-wrap items-center gap-x-5 gap-y-1">
                <span>
                  سقف مصوب <b className="tabular-nums text-ink">{rial(budgetLimit)}</b>
                </span>
                <span>
                  مصرف‌شده <b className="tabular-nums text-[#F0A08D]">{rial(budgetSpent)}</b>
                </span>
                <span>
                  باقی‌مانده{" "}
                  <b className="tabular-nums text-[#7FE6F1]">{rial(Math.max(0, budgetLimit - budgetSpent))}</b>
                </span>
              </span>
            }
          >
            <div className="grid gap-x-8 gap-y-7 sm:grid-cols-2 xl:grid-cols-3">
              {budgeted.map((c) => (
                <div key={c.id} className="border-t border-hair pt-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-[15px] text-ink">{c.name}</div>
                      <div className="mt-1 text-[12px] tabular-nums text-muted">
                        {rialShort(c.spent)} از {rialShort(c.limit)} ریال
                      </div>
                      <div className="mt-0.5 text-[11px] text-muted">{fa(c.count)} سند</div>
                    </div>
                    <Gauge value={c.spent} limit={c.limit} tone={c.tone} />
                  </div>
                  <div className="mt-3 h-[6px] w-full bg-[#0E2A3C]">
                    <div
                      className="chart-bar h-full"
                      style={{
                        background: c.spent > c.limit ? "#E0684F" : c.tone,
                        width: `${Math.min(100, (c.spent / (c.limit || 1)) * 100)}%`,
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </Panel>

          <div className="grid content-start gap-8">
            <Panel title="ذخیره بودجه" kicker="سقف ماهانه">
              <BudgetForm categories={catOpts.filter((c) => c.kind === "expense")} />
            </Panel>
            <Panel title="یادداشت بودجه" kicker="راهنما">
              <p className="text-[13px] leading-7 text-muted">
                سقف‌ها به‌صورت ماهانه روی هر دستهٔ هزینه ثبت می‌شوند و نیم‌دایرهٔ هر دسته، نسبت مصرف را نشان می‌دهد. دسته‌هایی
                که از سقف عبور کنند با رنگ آجری علامت می‌خورند تا پیش از پایان ماه اصلاح شوند.
              </p>
              <Rule label="قاعده" />
              <p className="text-[13px] leading-7 text-muted">
                قاعدهٔ سرانگشتی دفتر: ۵۰٪ نیاز، ۳۰٪ خواسته، ۲۰٪ پس‌انداز. برای {faMonth(month)} سقف مصوب شما{" "}
                <b className="tabular-nums text-ink">{rialShort(budgetLimit)} ریال</b> است.
              </p>
            </Panel>
          </div>
        </div>
      </section>

      {/* ───────────────────────── accounts band ───────────────────────── */}
      <section id="accounts" className="band-rule py-14">
        <div className={`${WRAP} grid gap-8 lg:grid-cols-[360px_minmax(0,1fr)]`}>
          <div className="grid content-start gap-8">
            <Panel title="افزودن حساب" kicker="بانک، کارت، نقد">
              <AccountForm />
            </Panel>
            <Panel title="انتقال بین حساب‌ها" kicker="سند داخلی">
              <TransferForm accounts={accOpts} defaultDate={defaultDate} />
            </Panel>
          </div>

          <Panel
            title="حساب‌ها"
            kicker={`${fa(av.length)} حساب فعال`}
            note={
              <span>
                ماندهٔ کل: <b className="tabular-nums text-[#E7C77F]">{rial(totalBalance)}</b> —{" "}
                <span className="text-muted">به‌روزرسانی لحظه‌ای از اسناد ثبت‌شده</span>
              </span>
            }
          >
            <ul>
              {av.map((a) => (
                <li key={a.id} className="border-t border-hair py-5 first:border-t-0 first:pt-0">
                  <div className="flex flex-wrap items-center justify-between gap-4">
                    <div className="min-w-[180px]">
                      <div className="flex items-center gap-2.5">
                        <span className="text-[16px] text-ink">{a.name}</span>
                        <span className="border border-hair px-2 py-0.5 text-[10px] tracking-[0.18em] text-muted">
                          {ACCOUNT_KINDS[a.kind] ?? a.kind}
                        </span>
                      </div>
                      <div className="mt-1.5 text-[12px] tabular-nums text-muted">
                        ورودی ماه{" "}
                        <span className={a.flow >= 0 ? "text-[#7FE6F1]" : "text-[#F0A08D]"}>{rial(a.flow)}</span>
                      </div>
                    </div>
                    <div className="flex flex-1 items-center gap-5">
                      <Sparkline values={a.spark} tone="#2AD4E4" />
                      <div className="h-[6px] w-full max-w-[240px] bg-[#0E2A3C]">
                        <div
                          className="chart-bar h-full bg-gradient-to-l from-[#2AD4E4] to-[#0E9DB4]"
                          style={{ width: `${Math.max(2, a.share * 100)}%` }}
                        />
                      </div>
                    </div>
                    <div className="text-left">
                      <div className="font-display text-[19px] tabular-nums text-ink">{fa(a.balance)}</div>
                      <div className="text-[11px] tabular-nums text-muted">ریال — {toman(a.balance)}</div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </Panel>
        </div>
      </section>

      {/* ───────────────────────── portfolio band ───────────────────────── */}
      <section id="portfolio" className="band-rule py-14">
        <div className={WRAP}>
          <Panel
            title="سبد سرمایه‌گذاری"
            kicker="ارز، طلا، سکه، صندوق، رمزارز"
            note={
              <span className="flex flex-wrap items-center gap-x-4 gap-y-1">
                <span>نرخ ارز افزایشی شده:</span>
                {pf.rates
                  .filter((r) => r.changeRial !== 0)
                  .map((r) => (
                    <span key={r.symbol} dir="ltr" className="tabular-nums">
                      <b className={r.changeRial > 0 ? "text-[#7FE6F1]" : "text-[#F0A08D]"}>{r.symbol}</b>{" "}
                      <span className="text-ink">{fa(Math.abs(r.changeRial))}</span>
                      <span className="text-muted">{r.changeRial > 0 ? " ▲" : " ▼"}</span>
                    </span>
                  ))}
                <span className="text-muted">— نرخ‌های روز بازار داخلی، به‌روزرسانی دستی</span>
              </span>
            }
          >
            <div className="grid gap-10 lg:grid-cols-[320px_minmax(0,1fr)]">
              <div>
                <div className="flex items-center gap-6">
                  <Donut segments={pfSegments} size={214} />
                  <div>
                    <div className="text-[11px] tracking-[0.24em] text-muted">ارزش کل سبد</div>
                    <div className="mt-1 font-display text-[26px] tabular-nums text-ink">{rialShort(pfValue)}</div>
                    <div className="text-[12px] text-muted">ریال — تقریبی</div>
                    <div className="mt-4 text-[11px] tracking-[0.24em] text-muted">سود / زیان تحقق‌نیافته</div>
                    <div className={`mt-1 font-display text-[22px] tabular-nums ${pfPnl >= 0 ? "text-[#7FE6F1]" : "text-[#F0A08D]"}`}>
                      {rialShort(pfPnl)}
                    </div>
                  </div>
                </div>
                <div className="mt-8">
                  <AllocationBars segments={pfSegments} />
                </div>
              </div>

              <div>
                <div className="grid gap-8 xl:grid-cols-[minmax(0,1fr)_330px]">
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-[560px] text-[14px]">
                      <thead>
                        <tr className="border-b border-hair text-[11px] tracking-[0.16em] text-muted">
                          <th className="py-2 text-right font-normal">دارایی</th>
                          <th className="py-2 text-left font-normal">تعداد</th>
                          <th className="py-2 text-left font-normal">میانگین</th>
                          <th className="py-2 text-left font-normal">قیمت روز</th>
                          <th className="py-2 text-left font-normal">ارزش</th>
                          <th className="py-2 text-left font-normal">سود/زیان</th>
                        </tr>
                      </thead>
                      <tbody>
                        {pf.items.map((h) => (
                          <tr key={h.id} className="border-b border-hair/50 transition-colors duration-150 hover:bg-[#0C2637]/60">
                            <td className="py-3">
                              <div className="flex items-center gap-2.5">
                                <span
                                  className="inline-block h-2.5 w-2.5 rotate-45"
                                  style={{ background: HoldingTone(h.kind) }}
                                />
                                <span className="text-ink">{h.name}</span>
                                <span className="text-[10px] tracking-[0.16em] text-muted">
                                  {HOLDING_KINDS[h.kind] ?? h.kind} · {h.symbol}
                                </span>
                              </div>
                            </td>
                            <td className="py-3 text-left tabular-nums text-muted">
                              {fa(h.qty)} {h.unit}
                            </td>
                            <td className="py-3 text-left tabular-nums text-muted">{rialShort(h.avgPrice)}</td>
                            <td className="py-3 text-left tabular-nums text-ink">{rialShort(h.price)}</td>
                            <td className="py-3 text-left tabular-nums text-ink">{rialShort(h.value)}</td>
                            <td
                              className={`py-3 text-left tabular-nums ${h.pnl >= 0 ? "text-[#7FE6F1]" : "text-[#F0A08D]"}`}
                            >
                              {rialShort(h.pnl)} <span className="text-[11px]">({fa(h.pnlPct)}٪)</span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    <div className="relative mt-6 overflow-hidden border border-hair">
                      <img
                        src="images/gold.jpg"
                        alt="سکه‌ها و اسکناس‌های سبد سرمایه روی سنگ تیره"
                        className="h-40 w-full object-cover opacity-70 [object-position:35%_60%]"
                      />
                      <div className="absolute inset-0 bg-[linear-gradient(270deg,rgba(4,18,30,0.95),rgba(4,18,30,0.35))]" />
                      <div className="absolute inset-0 flex flex-col justify-center px-6">
                        <div className="text-[11px] tracking-[0.28em] text-muted">ترکیب سبد</div>
                        <div className="mt-1 font-display text-[18px] text-ink">
                          {pf.items.length ? pf.items[0].name : "—"} بیشترین وزن را دارد
                        </div>
                        <div className="mt-1 text-[12px] tabular-nums text-muted">
                          {pfValue > 0 ? fa((pf.items[0].value / pfValue) * 100) : "۰"}٪ از ارزش کل · {rial(totalBalance)} نقد و
                          حساب بانکی
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <div className="mb-2 text-[11px] tracking-[0.24em] text-muted">ثبت سرمایه‌گذاری</div>
                    <HoldingForm defaultDate={defaultDate} />
                  </div>
                </div>
              </div>
            </div>
          </Panel>
        </div>
      </section>

      {/* ───────────────────────── debts band ───────────────────────── */}
      <section id="debts" className="band-rule py-14">
        <div className={`${WRAP} grid gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)_340px]`}>
          <Panel
            title="بدهی از افراد"
            kicker="چیزی که باید بدهم"
            tone="#E0684F"
            note={
              <span>
                جمع باز: <b className="tabular-nums text-[#F0A08D]">{rial(payableTotal)}</b>
              </span>
            }
          >
            <ul>
              {dv.payable.map((d) => (
                <li key={d.id} className="border-t border-hair py-4 first:border-t-0 first:pt-0">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className={`text-[15px] ${d.settled ? "text-muted line-through" : "text-ink"}`}>{d.party}</div>
                      <div className="mt-1 text-[12px] text-muted">
                        {d.note}
                        {d.dueOn ? ` — سررسید ${faDate(d.dueOn)}` : ""}
                      </div>
                      {d.settled ? (
                        <span className="mt-1 inline-block border border-[#2AD4E4]/40 px-2 py-0.5 text-[10px] tracking-[0.18em] text-[#7FE6F1]">
                          تسویه‌شده
                        </span>
                      ) : (
                        <SettleButton
                          debt={{ id: d.id, party: d.party, amount: d.amount, direction: "payable" }}
                          accounts={accOpts}
                        />
                      )}
                    </div>
                    <div className="whitespace-nowrap text-left font-display text-[17px] tabular-nums text-[#F0A08D]">
                      {rial(d.amount)}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </Panel>

          <Panel
            title="طلب از افراد"
            kicker="چیزی که باید بگیرم"
            tone="#D8AC4E"
            note={
              <span>
                جمع باز: <b className="tabular-nums text-[#E7C77F]">{rial(receivableTotal)}</b>
              </span>
            }
          >
            <ul>
              {dv.receivable.map((d) => (
                <li key={d.id} className="border-t border-hair py-4 first:border-t-0 first:pt-0">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className={`text-[15px] ${d.settled ? "text-muted line-through" : "text-ink"}`}>{d.party}</div>
                      <div className="mt-1 text-[12px] text-muted">
                        {d.note}
                        {d.dueOn ? ` — سررسید ${faDate(d.dueOn)}` : ""}
                      </div>
                      {d.settled ? (
                        <span className="mt-1 inline-block border border-[#2AD4E4]/40 px-2 py-0.5 text-[10px] tracking-[0.18em] text-[#7FE6F1]">
                          وصول‌شده
                        </span>
                      ) : (
                        <SettleButton
                          debt={{ id: d.id, party: d.party, amount: d.amount, direction: "receivable" }}
                          accounts={accOpts}
                        />
                      )}
                    </div>
                    <div className="whitespace-nowrap text-left font-display text-[17px] tabular-nums text-[#E7C77F]">
                      {rial(d.amount)}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </Panel>

          <div className="grid content-start gap-8">
            <Panel title="ثبت آیتم جدید" kicker="بدهی / طلب">
              <DebtForm />
            </Panel>
            <Panel title="خالص موضع شما" kicker="تسویه">
              <div className="text-[11px] tracking-[0.24em] text-muted">اگر امروز همه چیز تسویه شود</div>
              <div
                className={`mt-2 font-display text-[30px] tabular-nums ${
                  receivableTotal - payableTotal >= 0 ? "text-[#7FE6F1]" : "text-[#F0A08D]"
                }`}
              >
                {rialShort(receivableTotal - payableTotal)}
              </div>
              <div className="text-[12px] text-muted">ریال — ماندهٔ خالص مطالبات</div>
              <div className="mt-5 flex items-center justify-between border border-hair bg-[#04141F] px-4 py-3 text-[13px] text-muted">
                <span>گزارش تسویهٔ گروهی</span>
                <span className="text-[11px] tracking-[0.18em]">به‌زودی</span>
              </div>
            </Panel>
          </div>
        </div>
      </section>

      {/* ───────────────────────── import band ───────────────────────── */}
      <section id="import" className="band-rule py-14">
        <div className={WRAP}>
          <Panel title="درون‌ریزی صورت‌حساب بانک" kicker="CSV · TXT">
            <ImportPanel />
          </Panel>
        </div>
      </section>

      <footer className="band-rule py-10">
        <div className={`${WRAP} flex flex-wrap items-center justify-between gap-4 text-[12px] text-muted`}>
          <span className="flex items-center gap-3">
            <StarMark size={22} />
            دفتر فیروزه‌ای — حسابداری مالی حرفه‌ای برای زندگی روزمره
          </span>
          <span className="tabular-nums">
            آخرین به‌روزرسانی دفتر: {faDate(`${month}-01`)} · ماندهٔ کل {rial(totalBalance)}
          </span>
        </div>
      </footer>
    </main>
  );
}
