import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "دفتر فیروزه‌ای — دستیار مالی شخصی",
  description:
    "حسابداری مالی حرفه‌ای برای زندگی روزمره: بودجه، حساب‌ها، تراکنش‌ها، سبد سرمایه، بدهی و طلب و درون‌ریزی صورت‌حساب بانک — همه در یک دفتر.",
};

const fonts = [
  "https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;700;800&family=Noto+Kufi+Arabic:wght@400;600;700;900&display=swap",
];

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <head>
        {fonts.map((href) => (
          <link key={href} rel="stylesheet" href={href} />
        ))}
      </head>
      <body className="min-h-screen bg-lapis text-ink antialiased">{children}</body>
    </html>
  );
}
