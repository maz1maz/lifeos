import { db } from "@/db";
import { accounts } from "@/db/schema";
import { asc } from "drizzle-orm";
import { revalidatePath } from "next/cache";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(accounts).orderBy(asc(accounts.id));
  return Response.json(rows);
}

export async function POST(req: Request) {
  const body = await req.json();
  const name = String(body.name ?? "").trim();
  if (!name) return Response.json({ error: "نام حساب الزامی است" }, { status: 400 });
  const [row] = await db
    .insert(accounts)
    .values({
      name,
      kind: String(body.kind ?? "bank"),
      currency: String(body.currency ?? "IRR"),
      openingBalance: Number(body.openingBalance ?? 0),
    })
    .returning();
  revalidatePath("/", "page");
  return Response.json(row, { status: 201 });
}
