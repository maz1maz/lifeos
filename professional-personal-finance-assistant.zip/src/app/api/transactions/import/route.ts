import { db } from "@/db";
import { categories, transactions } from "@/db/schema";
import { asc } from "drizzle-orm";
import { revalidatePath } from "next/cache";

export const dynamic = "force-dynamic";

type Row = {
  occurredOn: string;
  description: string;
  amount: number;
  kind: "income" | "expense";
  categoryName?: string;
  note?: string;
};

/** Bulk import of bank-statement rows (parsed client-side from CSV/XLSX text). */
export async function POST(req: Request) {
  const body = await req.json();
  const rows = (body.rows ?? []) as Row[];
  if (!Array.isArray(rows) || rows.length === 0) {
    return Response.json({ error: "ردیفی برای درون‌ریزی یافت نشد" }, { status: 400 });
  }
  const cats = await db.select().from(categories).orderBy(asc(categories.id));
  const byName = new Map(cats.map((c) => [c.name.trim(), c.id]));

  const values = rows
    .filter((r) => r && r.description && Number(r.amount) > 0)
    .map((r) => ({
      occurredOn: r.occurredOn,
      description: r.description,
      note: r.note ?? null,
      refCode: "#درون‌ریزی",
      kind: r.kind === "income" ? "income" : ("expense" as "income" | "expense"),
      amount: Math.round(Number(r.amount)),
      categoryId: r.categoryName ? (byName.get(r.categoryName.trim()) ?? null) : null,
      accountId: null,
    }));

  if (values.length === 0) return Response.json({ error: "ردیف معتبری یافت نشد" }, { status: 400 });
  await db.insert(transactions).values(values);
  revalidatePath("/", "page");
  return Response.json({ imported: values.length }, { status: 201 });
}
