import { db } from "@/db";
import { transactions } from "@/db/schema";
import { and, desc, eq, gte, lte } from "drizzle-orm";
import { revalidatePath } from "next/cache";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const month = url.searchParams.get("month");
  const last = month
    ? `${month}-${String(new Date(Number(month.slice(0, 4)), Number(month.slice(5, 7)), 0).getDate()).padStart(2, "0")}`
    : "";
  const rows = month
    ? await db
        .select()
        .from(transactions)
        .where(and(gte(transactions.occurredOn, `${month}-01`), lte(transactions.occurredOn, last)))
        .orderBy(desc(transactions.occurredOn))
    : await db.select().from(transactions).orderBy(desc(transactions.occurredOn));
  return Response.json(rows);
}

export async function POST(req: Request) {
  const b = await req.json();
  const amount = Number(b.amount ?? 0);
  const description = String(b.description ?? "").trim();
  if (!description || !Number.isFinite(amount) || amount <= 0) {
    return Response.json({ error: "شرح و مبلغ معتبر الزامی است" }, { status: 400 });
  }
  const [row] = await db
    .insert(transactions)
    .values({
      occurredOn: String(b.occurredOn || new Date().toISOString().slice(0, 10)),
      description,
      note: b.note ? String(b.note) : null,
      refCode: b.refCode ? String(b.refCode) : null,
      kind: b.kind === "income" ? "income" : "expense",
      amount: Math.round(amount),
      categoryId: b.categoryId ? Number(b.categoryId) : null,
      accountId: b.accountId ? Number(b.accountId) : null,
    })
    .returning();
  revalidatePath("/", "page");
  return Response.json(row, { status: 201 });
}

export async function DELETE(req: Request) {
  const url = new URL(req.url);
  const id = Number(url.searchParams.get("id"));
  if (!Number.isFinite(id)) return Response.json({ error: "شناسه نامعتبر" }, { status: 400 });
  await db.delete(transactions).where(eq(transactions.id, id));
  revalidatePath("/", "page");
  return Response.json({ ok: true });
}
