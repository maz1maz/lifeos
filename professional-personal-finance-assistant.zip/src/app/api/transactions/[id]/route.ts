import { db } from "@/db";
import { transactions } from "@/db/schema";
import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";

export const dynamic = "force-dynamic";

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  await db.delete(transactions).where(eq(transactions.id, Number(id)));
  revalidatePath("/", "page");
  return Response.json({ ok: true });
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const b = await req.json();
  const [row] = await db
    .update(transactions)
    .set({
      description: b.description ? String(b.description) : undefined,
      amount: b.amount ? Math.round(Number(b.amount)) : undefined,
      note: b.note !== undefined ? String(b.note) : undefined,
    })
    .where(eq(transactions.id, Number(id)))
    .returning();
  revalidatePath("/", "page");
  return Response.json(row ?? {});
}
