import { db } from "@/db";
import { holdings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const b = await req.json();
  const symbol = String(b.symbol ?? "").trim();
  const name = String(b.name ?? "").trim();
  const qty = Number(b.qty ?? 0);
  const price = Math.round(Number(b.price ?? 0));
  const side = b.side === "sell" ? "sell" : "buy";
  if (!symbol || !Number.isFinite(qty) || qty <= 0 || price <= 0) {
    return Response.json({ error: "نماد، تعداد و قیمت واحد الزامی است" }, { status: 400 });
  }

  const existing = await db.select().from(holdings).where(eq(holdings.symbol, symbol)).limit(1);

  if (side === "sell") {
    const row = existing[0];
    if (!row) return Response.json({ error: "این دارایی در سبد نیست" }, { status: 400 });
    const newQty = Number(row.qty) - qty;
    if (newQty < 0) return Response.json({ error: "تعداد بیش از موجودی سبد است" }, { status: 400 });
    const [updated] = await db
      .update(holdings)
      .set({ qty: newQty })
      .where(eq(holdings.id, row.id))
      .returning();
    revalidatePath("/", "page");
    return Response.json(updated, { status: 200 });
  }

  if (existing[0]) {
    const row = existing[0];
    const oldQty = Number(row.qty);
    const newQty = oldQty + qty;
    const newAvg = (oldQty * Number(row.avgPrice) + qty * price) / newQty;
    const [updated] = await db
      .update(holdings)
      .set({ qty: newQty, avgPrice: Math.round(newAvg) })
      .where(eq(holdings.id, row.id))
      .returning();
    revalidatePath("/", "page");
    return Response.json(updated, { status: 200 });
  }

  const [row] = await db
    .insert(holdings)
    .values({
      symbol,
      name: name || symbol,
      kind: String(b.kind ?? "currency"),
      unit: String(b.unit ?? "واحد"),
      qty,
      avgPrice: price,
    })
    .returning();
  revalidatePath("/", "page");
  return Response.json(row, { status: 201 });
}
