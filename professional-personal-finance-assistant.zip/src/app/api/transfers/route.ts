import { db } from "@/db";
import { transfers } from "@/db/schema";
import { revalidatePath } from "next/cache";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const b = await req.json();
  const from = Number(b.fromAccountId);
  const to = Number(b.toAccountId);
  const amount = Math.round(Number(b.amount ?? 0));
  if (!from || !to || from === to) {
    return Response.json({ error: "حساب مبدأ و مقصد باید متفاوت باشند" }, { status: 400 });
  }
  if (amount <= 0) return Response.json({ error: "مبلغ نامعتبر است" }, { status: 400 });

  const [row] = await db
    .insert(transfers)
    .values({
      occurredOn: String(b.occurredOn || new Date().toISOString().slice(0, 10)),
      fromAccountId: from,
      toAccountId: to,
      amount,
      note: b.note ? String(b.note) : null,
    })
    .returning();
  revalidatePath("/", "page");
  return Response.json(row, { status: 201 });
}
