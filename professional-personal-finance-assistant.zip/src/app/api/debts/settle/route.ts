import { db } from "@/db";
import { debts, transactions } from "@/db/schema";
import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";

export const dynamic = "force-dynamic";

/** تسویه بدهی/طلب: ثبت سند حسابداری و بستن آیتم */
export async function POST(req: Request) {
  const b = await req.json();
  const id = Number(b.id);
  const amount = Math.round(Number(b.amount ?? 0));
  const accountId = b.accountId ? Number(b.accountId) : null;
  const direction = b.direction === "receivable" ? "receivable" : "payable";
  if (!id || amount <= 0 || !accountId) {
    return Response.json({ error: "حساب پرداخت/دریافت الزامی است" }, { status: 400 });
  }

  await db.insert(transactions).values({
    occurredOn: String(b.occurredOn || new Date().toISOString().slice(0, 10)),
    description:
      direction === "payable"
        ? `تسویه بدهی — ${String(b.party ?? "")}`
        : `دریافت طلب — ${String(b.party ?? "")}`,
    note: "سند تسویه",
    refCode: "#تسویه",
    kind: direction === "payable" ? "expense" : "income",
    amount,
    categoryId: null,
    accountId,
  });
  await db.update(debts).set({ settled: true }).where(eq(debts.id, id));
  revalidatePath("/", "page");
  return Response.json({ ok: true });
}
