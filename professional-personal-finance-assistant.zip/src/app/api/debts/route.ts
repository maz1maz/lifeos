import { db } from "@/db";
import { debts } from "@/db/schema";
import { revalidatePath } from "next/cache";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const b = await req.json();
  const party = String(b.party ?? "").trim();
  const amount = Math.round(Number(b.amount ?? 0));
  if (!party || amount <= 0) return Response.json({ error: "نام شخص و مبلغ الزامی است" }, { status: 400 });
  const [row] = await db
    .insert(debts)
    .values({
      party,
      direction: b.direction === "receivable" ? "receivable" : "payable",
      amount,
      dueOn: b.dueOn ? String(b.dueOn) : null,
      note: b.note ? String(b.note) : null,
    })
    .returning();
  revalidatePath("/", "page");
  return Response.json(row, { status: 201 });
}
