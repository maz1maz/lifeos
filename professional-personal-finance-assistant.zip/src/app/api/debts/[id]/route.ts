import { db } from "@/db";
import { debts } from "@/db/schema";
import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";

export const dynamic = "force-dynamic";

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const b = await req.json();
  const [row] = await db
    .update(debts)
    .set({ settled: b.settled === true })
    .where(eq(debts.id, Number(id)))
    .returning();
  revalidatePath("/", "page");
  return Response.json(row ?? {});
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  await db.delete(debts).where(eq(debts.id, Number(id)));
  revalidatePath("/", "page");
  return Response.json({ ok: true });
}
