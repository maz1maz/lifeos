import { db } from "@/db";
import { categories } from "@/db/schema";
import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const b = await req.json();
  const categoryId = Number(b.categoryId);
  const limit = Math.round(Number(b.monthlyLimit ?? 0));
  if (!categoryId || limit < 0) return Response.json({ error: "داده نامعتبر" }, { status: 400 });
  const [row] = await db
    .update(categories)
    .set({ monthlyLimit: limit })
    .where(eq(categories.id, categoryId))
    .returning();
  revalidatePath("/", "page");
  return Response.json(row ?? {});
}
