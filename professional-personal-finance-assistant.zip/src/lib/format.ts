const nf = new Intl.NumberFormat("fa-IR", { maximumFractionDigits: 0 });
const nfFrac = new Intl.NumberFormat("fa-IR", { maximumFractionDigits: 4 });

/** Persian digits with Persian group separators. */
export function fa(n: number): string {
  if (!Number.isFinite(n)) return "۰";
  return nf.format(Math.round(n));
}

export function faQty(n: number): string {
  return nfFrac.format(n);
}

/** money in ریال, right-aligned tabular columns use this */
export function rial(n: number): string {
  const sign = n < 0 ? "−" : "";
  return `${sign}${fa(Math.abs(n))} ریال`;
}

export function rialShort(n: number): string {
  const abs = Math.abs(n);
  const sign = n < 0 ? "−" : "";
  if (abs >= 1_000_000_000) return `${sign}${(abs / 1_000_000_000).toFixed(2)} میلیارد`;
  if (abs >= 1_000_000) return `${sign}${(abs / 1_000_000).toFixed(1)} میلیون`;
  return `${sign}${fa(abs)}`;
}

export function toman(n: number): string {
  return `${fa(n / 10)} تومان`;
}

const dateFmt = new Intl.DateTimeFormat("fa-IR", {
  day: "2-digit",
  month: "long",
  year: "numeric",
});
const shortDateFmt = new Intl.DateTimeFormat("fa-IR", {
  day: "2-digit",
  month: "short",
});
const monthFmt = new Intl.DateTimeFormat("fa-IR", { month: "long", year: "numeric" });
const enMonthFmt = new Intl.DateTimeFormat("en-US", { month: "long", year: "numeric" });

/** 'YYYY-MM-DD' -> '۲۴ شهریور ۱۴۰۵' */
export function faDate(iso: string): string {
  return dateFmt.format(new Date(iso + "T00:00:00"));
}

export function faDateShort(iso: string): string {
  return shortDateFmt.format(new Date(iso + "T00:00:00"));
}

/** 'YYYY-MM' -> 'شهریور ۱۴۰۵' */
export function faMonth(monthKey: string): string {
  return monthFmt.format(new Date(monthKey + "-01T00:00:00"));
}

export function enMonth(monthKey: string): string {
  return enMonthFmt.format(new Date(monthKey + "-01T00:00:00"));
}

export function shiftMonth(monthKey: string, delta: number): string {
  const [y, m] = monthKey.split("-").map(Number);
  const d = new Date(Date.UTC(y, m - 1 + delta, 1));
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
}

export function monthOf(iso: string): string {
  return iso.slice(0, 7);
}

export function daysInMonth(monthKey: string): number {
  const [y, m] = monthKey.split("-").map(Number);
  return new Date(Date.UTC(y, m, 0)).getUTCDate();
}

export const ACCOUNT_KINDS: Record<string, string> = {
  bank: "بانک",
  card: "کارت",
  cash: "نقد",
  wallet: "کیف پول",
  fx: "ارزی",
};

export const HOLDING_KINDS: Record<string, string> = {
  currency: "ارز",
  gold: "طلا",
  coin: "سکه",
  fund: "صندوق",
  crypto: "رمزارز",
};
