import { db } from "@/db";
import {
  accounts,
  categories,
  debts,
  holdings,
  prices,
  transactions,
  transfers,
} from "@/db/schema";
import { and, asc, desc, eq, gte, lte, sql } from "drizzle-orm";
import { daysInMonth, monthOf } from "@/lib/format";

export type AccountView = {
  id: number;
  name: string;
  kind: string;
  currency: string;
  openingBalance: number;
  balance: number;
  share: number;
  flow: number;
  spark: number[];
};

export type TxView = {
  id: number;
  occurredOn: string;
  description: string;
  note: string | null;
  refCode: string | null;
  kind: string;
  amount: number;
  category: string;
  tone: string;
  categoryId: number | null;
  account: string | null;
  accountId: number | null;
};

export type CategoryTotal = {
  id: number;
  name: string;
  tone: string;
  limit: number;
  spent: number;
  count: number;
};

export type DayPoint = {
  day: number;
  label: string;
  income: number;
  expense: number;
  net: number;
  balance: number;
};

export type TransferView = {
  id: number;
  occurredOn: string;
  from: string;
  to: string;
  amount: number;
  note: string | null;
};

export type DebtView = {
  id: number;
  party: string;
  amount: number;
  dueOn: string | null;
  note: string | null;
  settled: boolean;
};

export type HoldingView = {
  id: number;
  symbol: string;
  name: string;
  kind: string;
  unit: string;
  qty: number;
  avgPrice: number;
  price: number;
  changeRial: number;
  value: number;
  cost: number;
  pnl: number;
  pnlPct: number;
};

const range = (month: string) => ({
  from: `${month}-01`,
  to: `${month}-${String(daysInMonth(month)).padStart(2, "0")}`,
});

export async function getCategoryOptions() {
  return db
    .select()
    .from(categories)
    .orderBy(asc(categories.kind), asc(categories.id));
}

export async function getAccountsView(month: string): Promise<AccountView[]> {
  const { from, to } = range(month);
  const [accRows, txRows, trRows] = await Promise.all([
    db.select().from(accounts).orderBy(asc(accounts.id)),
    db
      .select({
        accountId: transactions.accountId,
        amount: transactions.amount,
        kind: transactions.kind,
        occurredOn: transactions.occurredOn,
      })
      .from(transactions)
      .where(gte(transactions.occurredOn, from)),
    db
      .select({
        fromAccountId: transfers.fromAccountId,
        toAccountId: transfers.toAccountId,
        amount: transfers.amount,
        occurredOn: transfers.occurredOn,
      })
      .from(transfers)
      .where(gte(transfers.occurredOn, from)),
  ]);

  const view = accRows.map((a) => {
    let balance = a.openingBalance;
    let flow = 0;
    for (const t of txRows) {
      if (t.accountId !== a.id) continue;
      const signed = t.kind === "income" ? Number(t.amount) : -Number(t.amount);
      balance += signed;
      if (t.occurredOn <= to) flow += signed;
    }
    for (const t of trRows) {
      if (t.fromAccountId === a.id) {
        balance -= Number(t.amount);
        if (t.occurredOn <= to) flow -= Number(t.amount);
      }
      if (t.toAccountId === a.id) {
        balance += Number(t.amount);
        if (t.occurredOn <= to) flow += Number(t.amount);
      }
    }
    // 12-point daily spark for the month
    const dim = daysInMonth(month);
    const spark: number[] = [];
    let run = a.openingBalance;
    for (let i = 0; i < 12; i++) {
      const day = Math.max(1, Math.round(((i + 1) / 12) * dim));
      for (const t of txRows) {
        const d = Number(t.occurredOn.slice(8, 10));
        if (d > (i === 0 ? 0 : Math.round((i / 12) * dim)) && d <= day && t.accountId === a.id) {
          run += t.kind === "income" ? Number(t.amount) : -Number(t.amount);
        }
      }
      spark.push(run);
    }
    return {
      id: a.id,
      name: a.name,
      kind: a.kind,
      currency: a.currency,
      openingBalance: Number(a.openingBalance),
      balance,
      flow,
      spark,
      share: 0,
    };
  });

  const total = view.reduce((s, a) => s + a.balance, 0) || 1;
  view.forEach((a) => (a.share = a.balance / total));
  return view;
}

export async function getMonthView(month: string) {
  const { from, to } = range(month);
  const txRows = await db
    .select({
      id: transactions.id,
      occurredOn: transactions.occurredOn,
      description: transactions.description,
      note: transactions.note,
      refCode: transactions.refCode,
      kind: transactions.kind,
      amount: transactions.amount,
      categoryId: transactions.categoryId,
      accountId: transactions.accountId,
      category: categories.name,
      tone: categories.tone,
      account: accounts.name,
    })
    .from(transactions)
    .leftJoin(categories, eq(transactions.categoryId, categories.id))
    .leftJoin(accounts, eq(transactions.accountId, accounts.id))
    .where(and(gte(transactions.occurredOn, from), lte(transactions.occurredOn, to)))
    .orderBy(desc(transactions.occurredOn), desc(transactions.id));

  const catRows = await db
    .select({
      id: categories.id,
      name: categories.name,
      tone: categories.tone,
      limit: categories.monthlyLimit,
      kind: categories.kind,
    })
    .from(categories)
    .orderBy(asc(categories.id));

  const transferRows = await db
    .select({
      id: transfers.id,
      occurredOn: transfers.occurredOn,
      amount: transfers.amount,
      note: transfers.note,
      fromAccountId: transfers.fromAccountId,
      toAccountId: transfers.toAccountId,
    })
    .from(transfers)
    .where(and(gte(transfers.occurredOn, from), lte(transfers.occurredOn, to)));

  const accNames = await db.select().from(accounts);
  const accName = (id: number) => accNames.find((a) => a.id === id)?.name ?? "—";

  const dim = daysInMonth(month);
  const dayBuckets = Array.from({ length: dim }, (_, i) => ({
    day: i + 1,
    label: String(i + 1),
    income: 0,
    expense: 0,
    net: 0,
    balance: 0,
  }));

  let income = 0;
  let expense = 0;
  const txs: TxView[] = txRows.map((t) => {
    const amount = Number(t.amount);
    const day = Number(t.occurredOn.slice(8, 10)) - 1;
    if (t.kind === "income") {
      income += amount;
      dayBuckets[day].income += amount;
    } else {
      expense += amount;
      dayBuckets[day].expense += amount;
    }
    return {
      id: t.id,
      occurredOn: t.occurredOn,
      description: t.description,
      note: t.note,
      refCode: t.refCode,
      kind: t.kind,
      amount,
      category: t.category ?? "بدون دسته",
      tone: t.tone ?? "#78A0B4",
      categoryId: t.categoryId,
      account: t.account,
      accountId: t.accountId,
    };
  });

  dayBuckets.forEach((b) => (b.net = b.income - b.expense));
  let cum = 0;
  for (const b of dayBuckets) {
    cum += b.net;
    b.balance = cum;
  }

  const categoryTotals: CategoryTotal[] = catRows
    .filter((c) => c.kind === "expense")
    .map((c) => {
      const rows = txs.filter((t) => t.categoryId === c.id && t.kind === "expense");
      return {
        id: c.id,
        name: c.name,
        tone: c.tone,
        limit: Number(c.limit),
        spent: rows.reduce((s, r) => s + r.amount, 0),
        count: rows.length,
      };
    })
    .sort((a, b) => b.spent - a.spent);

  const transferTotal = transferRows.reduce((s, t) => s + Number(t.amount), 0);
  const transfersView: TransferView[] = transferRows.map((t) => ({
    id: t.id,
    occurredOn: t.occurredOn,
    from: accName(t.fromAccountId),
    to: accName(t.toAccountId),
    amount: Number(t.amount),
    note: t.note,
  }));

  return {
    month,
    txs,
    income,
    expense,
    net: income - expense,
    transferTotal,
    categoryTotals,
    days: dayBuckets,
    transfers: transfersView,
  };
}

export async function getDebtsView() {
  const rows = await db.select().from(debts).orderBy(asc(debts.settled), desc(debts.dueOn));
  const payable: DebtView[] = [];
  const receivable: DebtView[] = [];
  for (const r of rows) {
    const v: DebtView = {
      id: r.id,
      party: r.party,
      amount: Number(r.amount),
      dueOn: r.dueOn,
      note: r.note,
      settled: r.settled,
    };
    if (r.direction === "payable") payable.push(v);
    else receivable.push(v);
  }
  return { payable, receivable };
}

export async function getPortfolio() {
  const [holdRows, priceRows] = await Promise.all([
    db.select().from(holdings).orderBy(asc(holdings.id)),
    db.select().from(prices),
  ]);
  const priceMap = new Map(priceRows.map((p) => [p.symbol, p]));

  const items: HoldingView[] = holdRows.map((h) => {
    const p = priceMap.get(h.symbol);
    const price = p ? Number(p.price) : Number(h.avgPrice);
    const qty = Number(h.qty);
    const value = qty * price;
    const cost = qty * Number(h.avgPrice);
    return {
      id: h.id,
      symbol: h.symbol,
      name: h.name,
      kind: h.kind,
      unit: h.unit,
      qty,
      avgPrice: Number(h.avgPrice),
      price,
      changeRial: p ? Number(p.changeRial) : 0,
      value,
      cost,
      pnl: value - cost,
      pnlPct: cost ? ((value - cost) / cost) * 100 : 0,
    };
  });

  const rates = priceRows.map((p) => ({
    symbol: p.symbol,
    name: p.name,
    unit: p.unit,
    price: Number(p.price),
    changeRial: Number(p.changeRial),
  }));

  return { items, rates };
}

export async function getTotals() {
  const row = await db.select({
    income: sql<number>`coalesce(sum(case when ${transactions.kind} = 'income' then ${transactions.amount} else 0 end), 0)`,
    expense: sql<number>`coalesce(sum(case when ${transactions.kind} = 'expense' then ${transactions.amount} else 0 end), 0)`,
  }).from(transactions);
  const r = row[0] ?? { income: 0, expense: 0 };
  return { income: Number(r.income), expense: Number(r.expense) };
}

export type MonthKey = ReturnType<typeof monthOf>;
