import type { ReactNode } from "react";

export function StarMark({ size = 34, className = "" }: { size?: number; className?: string }) {
  // Eight-point Persian شمسه star, drawn as two overlapping squares + inner rosette.
  const outer = "M32 3 L44.5 14.2 L59.5 11.5 L56.8 26.5 L68 32 L56.8 37.5 L59.5 52.5 L44.5 49.8 L32 61 L19.5 49.8 L4.5 52.5 L7.2 37.5 L-4 32 L7.2 26.5 L4.5 11.5 L19.5 14.2 Z";
  return (
    <svg viewBox="-6 -4 76 72" width={size} height={size} className={className} aria-hidden="true">
      <path d={outer} transform="translate(0,0)" fill="none" stroke="#2AD4E4" strokeWidth="1.4" strokeLinejoin="round" />
      <rect x="14" y="14" width="36" height="36" fill="none" stroke="#D8AC4E" strokeWidth="1.1" transform="rotate(45 32 32)" opacity="0.85" />
      <rect x="14" y="14" width="36" height="36" fill="none" stroke="#D8AC4E" strokeWidth="1.1" opacity="0.85" />
      <circle cx="32" cy="32" r="7.5" fill="none" stroke="#2AD4E4" strokeWidth="1.6" />
      <circle cx="32" cy="32" r="2.4" fill="#2AD4E4" />
    </svg>
  );
}

export function Panel({
  title,
  kicker,
  note,
  children,
  className = "",
  id,
  tone = "#D8AC4E",
}: {
  title: string;
  kicker?: string;
  note?: ReactNode;
  children: ReactNode;
  className?: string;
  id?: string;
  tone?: string;
}) {
  return (
    <section id={id} className={`relative bg-panel ${className}`}>
      <CornerTicks tone={tone} />
      <header className="flex flex-wrap items-baseline justify-between gap-3 border-b border-hair px-5 py-4 sm:px-7">
        <h3 className="font-display text-[22px] leading-none tracking-tight text-ink sm:text-[26px]">{title}</h3>
        {kicker ? (
          <span className="text-[10px] uppercase tracking-[0.32em] text-muted">{kicker}</span>
        ) : null}
      </header>
      {note ? <div className="border-b border-hair px-5 py-3 text-[13px] leading-6 text-muted sm:px-7">{note}</div> : null}
      <div className="px-5 py-6 sm:px-7">{children}</div>
    </section>
  );
}

export function CornerTicks({ tone = "#D8AC4E" }: { tone?: string }) {
  const base = "pointer-events-none absolute h-3 w-3";
  return (
    <>
      <span className={`${base} right-0 top-0 border-r border-t`} style={{ borderColor: tone }} />
      <span className={`${base} left-0 top-0 border-l border-t`} style={{ borderColor: tone }} />
      <span className={`${base} bottom-0 right-0 border-b border-r`} style={{ borderColor: tone }} />
      <span className={`${base} bottom-0 left-0 border-b border-l`} style={{ borderColor: tone }} />
    </>
  );
}

export function Kicker({ children }: { children: ReactNode }) {
  return <div className="mb-2 text-[10px] uppercase tracking-[0.34em] text-muted">{children}</div>;
}

export function Field({
  label,
  children,
  className = "",
}: {
  label: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label className={`block ${className}`}>
      <span className="mb-1.5 block text-[11px] tracking-[0.14em] text-muted">{label}</span>
      {children}
    </label>
  );
}

export const inputCls =
  "w-full bg-[#04141F] px-3.5 py-2.5 text-[15px] text-ink placeholder:text-[#5C869B] outline-none border border-hair transition-colors duration-150 focus:border-[#2AD4E4] focus:bg-[#06202F]";

export function Btn({
  children,
  variant = "primary",
  className = "",
  ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "brass" }) {
  const styles: Record<string, string> = {
    primary:
      "bg-gradient-to-l from-[#2AD4E4] to-[#0E9DB4] text-[#03131D] hover:from-[#4FE2EF] hover:to-[#12B4CC] shadow-[0_10px_30px_-14px_rgba(42,212,228,0.8)]",
    ghost: "border border-hair bg-[#04141F] text-ink hover:border-[#2AD4E4] hover:text-[#2AD4E4]",
    brass: "border border-[#D8AC4E]/60 bg-[#D8AC4E]/10 text-[#E7C77F] hover:bg-[#D8AC4E]/20",
  };
  return (
    <button
      {...rest}
      className={`w-full px-4 py-3 text-[15px] font-bold transition-all duration-150 active:translate-y-px disabled:opacity-50 ${styles[variant]} ${className}`}
    >
      {children}
    </button>
  );
}

export function Stat({ label, value, sub, tone }: { label: string; value: string; sub?: string; tone: string }) {
  return (
    <div className="relative border-r-2 pr-4" style={{ borderColor: tone }}>
      <div className="text-[11px] tracking-[0.24em] text-muted">{label}</div>
      <div className="mt-1 font-display text-[clamp(1.85rem,3.5vw,3.05rem)] leading-none tabular-nums text-ink [letter-spacing:-0.02em]">
        {value}
      </div>
      {sub ? <div className="mt-1.5 text-[12px] tabular-nums" style={{ color: tone }}>{sub}</div> : null}
    </div>
  );
}

export function Rule({ label }: { label?: string }) {
  return (
    <div className="my-6 flex items-center gap-4">
      <span className="h-px flex-1 bg-hair" />
      {label ? <span className="text-[10px] tracking-[0.34em] text-muted">{label}</span> : null}
      <span className="h-px flex-1 bg-hair" />
    </div>
  );
}
