import { fa, faQty, rialShort } from "@/lib/format";
import type { DayPoint, HoldingView } from "@/lib/data";

/* ------------------------------------------------------------------ *
 * Hand-built SVG chart kit — hairline geometry, kashi-kari strapwork. *
 * ------------------------------------------------------------------ */

function smoothPath(pts: { x: number; y: number }[]): string {
  if (pts.length === 0) return "";
  if (pts.length === 1) return `M ${pts[0].x} ${pts[0].y}`;
  let d = `M ${pts[0].x} ${pts[0].y}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i];
    const p1 = pts[i + 1];
    const cx = (p0.x + p1.x) / 2;
    d += ` C ${cx} ${p0.y}, ${cx} ${p1.y}, ${p1.x} ${p1.y}`;
  }
  return d;
}

export function CashflowChart({ days, height = 300 }: { days: DayPoint[]; height?: number }) {
  const W = 1200;
  const H = height;
  const padTop = 34;
  const padBottom = 30;
  const inner = H - padTop - padBottom;

  const values = days.map((d) => d.balance);
  const rawMax = Math.max(...values, 0);
  const rawMin = Math.min(...values, 0);
  const span = rawMax - rawMin || 1;
  const max = rawMax + span * 0.14;
  const min = rawMin - span * 0.14;
  const x = (i: number) => (i / Math.max(1, days.length - 1)) * W;
  const y = (v: number) => padTop + inner - ((v - min) / (max - min)) * inner;

  const pts = days.map((d, i) => ({ x: x(i), y: y(d.balance) }));
  const line = smoothPath(pts);
  const area = `${line} L ${W} ${H - padBottom} L 0 ${H - padBottom} Z`;

  const maxExp = Math.max(...days.map((d) => d.expense), 1);
  const barW = Math.max(3, (W / days.length) * 0.34);

  const ticks = [0, 0.25, 0.5, 0.75, 1].map((t) => min + (max - min) * t);
  const zeroY = y(0);

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="block w-full" role="img" aria-label="نمودار جریان نقدینگی ماه">
      <defs>
        <linearGradient id="flow-fill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#2AD4E4" stopOpacity="0.34" />
          <stop offset="60%" stopColor="#2AD4E4" stopOpacity="0.08" />
          <stop offset="100%" stopColor="#2AD4E4" stopOpacity="0" />
        </linearGradient>
      </defs>

      {ticks.map((t, i) => (
        <g key={i}>
          <line
            x1="0"
            x2={W}
            y1={y(t)}
            y2={y(t)}
            stroke="#7CC7DE"
            strokeOpacity={i === 0 || i === 4 ? 0.16 : 0.08}
            strokeWidth="1"
            strokeDasharray={i === 0 || i === 4 ? "0" : "2 6"}
          />
          <text x={W - 6} y={y(t) - 6} textAnchor="end" fill="#5C8AA0" fontSize="15" fontFamily="inherit">
            {rialShort(t)}
          </text>
        </g>
      ))}

      <line x1="0" x2={W} y1={zeroY} y2={zeroY} stroke="#D8AC4E" strokeOpacity="0.4" strokeWidth="1" strokeDasharray="6 5" />

      {days.map((d, i) =>
        d.expense > 0 ? (
          <rect
            key={`b${i}`}
            x={x(i) - barW / 2}
            y={H - padBottom - (d.expense / maxExp) * (inner * 0.42)}
            width={barW}
            height={(d.expense / maxExp) * (inner * 0.42)}
            fill="#E0684F"
            fillOpacity="0.42"
          />
        ) : null,
      )}

      <path d={area} fill="url(#flow-fill)" className="chart-fade" />
      <path
        d={line}
        fill="none"
        stroke="#2AD4E4"
        strokeWidth="2.5"
        strokeLinecap="round"
        pathLength={1}
        className="chart-draw"
      />

      {pts.map((p, i) =>
        i % 5 === 0 ? <circle key={`p${i}`} cx={p.x} cy={p.y} r="3.5" fill="#04121E" stroke="#2AD4E4" strokeWidth="1.5" /> : null,
      )}

      {days.map((d, i) =>
        i % 5 === 2 ? (
          <text key={`t${i}`} x={x(i)} y={H - 8} textAnchor="middle" fill="#5C8AA0" fontSize="15">
            {fa(d.day)}
          </text>
        ) : null,
      )}
    </svg>
  );
}

export function Donut({
  segments,
  size = 220,
}: {
  segments: { label: string; value: number; tone: string }[];
  size?: number;
}) {
  const total = segments.reduce((s, x) => s + x.value, 0) || 1;
  const r = size / 2 - 16;
  const c = 2 * Math.PI * r;
  const cx = size / 2;
  const cy = size / 2;
  let offset = 0;

  return (
    <svg viewBox={`0 0 ${size} ${size}`} width={size} height={size} role="img" aria-label="ترکیب سبد سرمایه">
      <circle cx={cx} cy={cy} r={r} fill="none" stroke="#123247" strokeWidth="22" />
      <g transform={`rotate(-90 ${cx} ${cy})`}>
        {segments.map((s, i) => {
          const len = (s.value / total) * c;
          const el = (
            <circle
              key={i}
              cx={cx}
              cy={cy}
              r={r}
              fill="none"
              stroke={s.tone}
              strokeWidth="22"
              strokeDasharray={`${Math.max(0, len - 2)} ${c - Math.max(0, len - 2)}`}
              strokeDashoffset={-offset}
              className="chart-seg"
            />
          );
          offset += len;
          return el;
        })}
      </g>
      <circle cx={cx} cy={cy} r={r + 12} fill="none" stroke="#D8AC4E" strokeOpacity="0.35" strokeWidth="1" />
      <circle cx={cx} cy={cy} r={r - 12} fill="none" stroke="#D8AC4E" strokeOpacity="0.25" strokeWidth="1" />
    </svg>
  );
}

export function Gauge({ value, limit, tone }: { value: number; limit: number; tone: string }) {
  const pct = limit > 0 ? Math.min(1, value / limit) : 0;
  const r = 42;
  const c = Math.PI * r;
  const over = value > limit && limit > 0;
  const dash = `${(pct * c).toFixed(2)} ${c.toFixed(2)}`;
  return (
    <svg viewBox="0 0 120 68" width="120" height="68" role="img" aria-label="مصرف بودجه">
      <path d={`M 18 60 A ${r} ${r} 0 0 1 102 60`} fill="none" stroke="#123247" strokeWidth="9" strokeLinecap="round" />
      <path
        d={`M 18 60 A ${r} ${r} 0 0 1 102 60`}
        fill="none"
        stroke={over ? "#E0684F" : tone}
        strokeWidth="9"
        strokeLinecap="round"
        strokeDasharray={dash}
        className="chart-fade"
      />
      <text x="60" y="58" textAnchor="middle" fill={over ? "#E0684F" : "#E9F6F9"} fontSize="17" fontWeight="700">
        {fa(Math.round((limit > 0 ? value / limit : 0) * 100))}٪
      </text>
    </svg>
  );
}

export function Sparkline({ values, tone = "#2AD4E4" }: { values: number[]; tone?: string }) {
  const W = 132;
  const H = 34;
  const max = Math.max(...values);
  const min = Math.min(...values);
  const span = max - min || 1;
  const pts = values.map((v, i) => ({
    x: (i / Math.max(1, values.length - 1)) * W,
    y: H - 3 - ((v - min) / span) * (H - 8),
  }));
  const d = smoothPath(pts);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width={W} height={H} className="shrink-0" aria-hidden="true">
      <path d={`${d} L ${W} ${H} L 0 ${H} Z`} fill={tone} fillOpacity="0.1" />
      <path d={d} fill="none" stroke={tone} strokeWidth="1.6" strokeLinecap="round" pathLength={1} className="chart-draw" />
    </svg>
  );
}

export function AllocationBars({
  segments,
}: {
  segments: { label: string; value: number; tone: string }[];
}) {
  const total = segments.reduce((s, x) => s + x.value, 0) || 1;
  return (
    <ul className="space-y-3">
      {segments.map((s, i) => (
        <li key={i}>
          <div className="flex items-baseline justify-between text-[13px]">
            <span className="flex items-center gap-2 text-ink">
              <span className="inline-block h-2.5 w-2.5 rotate-45" style={{ background: s.tone }} />
              {s.label}
            </span>
            <span className="tabular-nums text-muted">{rialShort(s.value)}</span>
          </div>
          <div className="mt-1.5 h-[6px] w-full bg-[#0E2A3C]">
            <div
              className="chart-bar h-full"
              style={{ background: s.tone, width: `${Math.max(1.5, (s.value / total) * 100)}%` }}
            />
          </div>
        </li>
      ))}
    </ul>
  );
}

export function HoldingTone(kind: string) {
  return (
    { currency: "#2AD4E4", gold: "#D8AC4E", coin: "#E3B76A", fund: "#63C7A6", crypto: "#9B8BE0" } as Record<
      string,
      string
    >
  )[kind] ?? "#78A0B4";
}

export function QtyBar({ qty }: { qty: number }) {
  return <span className="tabular-nums text-[13px] text-muted">{faQty(qty)}</span>;
}
