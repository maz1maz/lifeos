"use client";

import { useCallback, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Btn, Field, inputCls } from "@/components/ui";
import { fa } from "@/lib/format";

type Opt = { id: number; name: string };

async function call(url: string, method: string, body?: unknown) {
  const res = await fetch(url, {
    method,
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as { error?: string }).error ?? "خطا در برقراری ارتباط");
  return data;
}

function useAction() {
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const run = useCallback(
    async (fn: () => Promise<string>) => {
      setPending(true);
      setErr(null);
      setMsg(null);
      try {
        const m = await fn();
        setMsg(m);
        router.refresh();
      } catch (e) {
        setErr(e instanceof Error ? e.message : "خطای ناشناخته");
      } finally {
        setPending(false);
      }
    },
    [router],
  );

  return { pending, msg, err, run, setMsg, setErr };
}

function Notice({ msg, err }: { msg: string | null; err: string | null }) {
  if (!msg && !err) return null;
  return (
    <p
      className={`mt-3 border-r-2 px-3 py-2 text-[13px] ${err ? "border-[#E0684F] bg-[#E0684F]/8 text-[#F0A08D]" : "border-[#2AD4E4] bg-[#2AD4E4]/8 text-[#7FE6F1]"}`}
      role="status"
    >
      {err ?? msg}
    </p>
  );
}

const dateInput = `${inputCls} [color-scheme:dark]`;

/* ------------------------- ثبت تراکنش تازه ------------------------- */
export function QuickTxForm({
  categories,
  accounts,
  defaultDate,
}: {
  categories: (Opt & { kind?: string })[];
  accounts: Opt[];
  defaultDate: string;
}) {
  const { pending, msg, err, run } = useAction();
  const formRef = useRef<HTMLFormElement>(null);
  const [kind, setKind] = useState<"expense" | "income">("expense");

  const cats = categories.filter((c) => !c.kind || c.kind === kind);

  return (
    <form
      ref={formRef}
      onSubmit={async (e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        await run(async () => {
          await call("/api/transactions", "POST", {
            description: fd.get("description"),
            amount: fd.get("amount"),
            kind,
            categoryId: fd.get("categoryId"),
            accountId: fd.get("accountId"),
            occurredOn: fd.get("occurredOn"),
            note: fd.get("note"),
          });
          formRef.current?.reset();
          return "تراکنش با موفقیت ثبت شد و دفاتر به‌روز شد.";
        });
      }}
      className="space-y-4"
    >
      <div className="grid grid-cols-2 gap-2">
        {(["expense", "income"] as const).map((k) => (
          <button
            key={k}
            type="button"
            onClick={() => setKind(k)}
            className={`border px-3 py-2.5 text-[14px] transition-colors duration-150 ${
              kind === k
                ? k === "expense"
                  ? "border-[#E0684F] bg-[#E0684F]/12 text-[#F0A08D]"
                  : "border-[#2AD4E4] bg-[#2AD4E4]/12 text-[#7FE6F1]"
                : "border-hair text-muted hover:border-[#2AD4E4]/60 hover:text-ink"
            }`}
          >
            {k === "expense" ? "هزینه" : "درآمد"}
          </button>
        ))}
      </div>

      <Field label="شرح">
        <input name="description" required placeholder="خرید از فروشگاه سوپرمارکت" className={inputCls} />
      </Field>
      <Field label="مبلغ (ریال)">
        <input name="amount" required type="number" min={1} placeholder="1,842,000" className={`${inputCls} tabular-nums`} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="دسته">
          <select name="categoryId" className={inputCls}>
            {cats.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </Field>
        <Field label="حساب">
          <select name="accountId" className={inputCls}>
            {accounts.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name}
              </option>
            ))}
          </select>
        </Field>
      </div>
      <Field label="تاریخ">
        <input name="occurredOn" type="date" defaultValue={defaultDate} className={dateInput} />
      </Field>
      <Field label="یادداشت، تگ‌ها، یا ویرگل جدا">
        <input name="note" placeholder="#سوپرمارکت" className={inputCls} />
      </Field>
      <Btn type="submit" disabled={pending}>
        {pending ? "در حال ثبت…" : "ثبت تراکنش"}
      </Btn>
      <Notice msg={msg} err={err} />
    </form>
  );
}

/* ------------------------------ بودجه ------------------------------ */
export function BudgetForm({ categories }: { categories: Opt[] }) {
  const { pending, msg, err, run } = useAction();
  const ref = useRef<HTMLFormElement>(null);
  return (
    <form
      ref={ref}
      onSubmit={async (e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        await run(async () => {
          await call("/api/budgets", "POST", {
            categoryId: fd.get("categoryId"),
            monthlyLimit: fd.get("monthlyLimit"),
          });
          ref.current?.reset();
          return "سقف بودجه ذخیره شد.";
        });
      }}
      className="space-y-4"
    >
      <Field label="دسته (با total__barی کل)">
        <select name="categoryId" className={inputCls}>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </Field>
      <Field label="سقف بودجه، ریال">
        <input name="monthlyLimit" type="number" min={0} required placeholder="26,000,000" className={`${inputCls} tabular-nums`} />
      </Field>
      <Btn type="submit" disabled={pending}>
        {pending ? "در حال ذخیره…" : "ذخیره بودجه"}
      </Btn>
      <Notice msg={msg} err={err} />
    </form>
  );
}

/* ------------------------------ حساب‌ها ----------------------------- */
export function AccountForm() {
  const { pending, msg, err, run } = useAction();
  const ref = useRef<HTMLFormElement>(null);
  return (
    <form
      ref={ref}
      onSubmit={async (e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        await run(async () => {
          await call("/api/accounts", "POST", {
            name: fd.get("name"),
            kind: fd.get("kind"),
            openingBalance: fd.get("openingBalance"),
          });
          ref.current?.reset();
          return "حساب جدید افزوده شد.";
        });
      }}
      className="space-y-4"
    >
      <Field label="نام حساب">
        <input name="name" required placeholder="بانک سپه — جاری" className={inputCls} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="نوع">
          <select name="kind" className={inputCls}>
            <option value="bank">بانک</option>
            <option value="card">کارت</option>
            <option value="cash">نقد</option>
            <option value="wallet">کیف پول</option>
            <option value="fx">ارزی</option>
          </select>
        </Field>
        <Field label="مانده اولیه">
          <input name="openingBalance" type="number" placeholder="0" className={`${inputCls} tabular-nums`} />
        </Field>
      </div>
      <Btn type="submit" disabled={pending}>
        {pending ? "در حال ثبت…" : "افزودن حساب"}
      </Btn>
      <Notice msg={msg} err={err} />
    </form>
  );
}

/* --------------------- انتقال بین حساب‌ها --------------------------- */
export function TransferForm({ accounts, defaultDate }: { accounts: Opt[]; defaultDate: string }) {
  const { pending, msg, err, run } = useAction();
  const ref = useRef<HTMLFormElement>(null);
  return (
    <form
      ref={ref}
      onSubmit={async (e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        await run(async () => {
          await call("/api/transfers", "POST", {
            note: fd.get("note"),
            fromAccountId: fd.get("fromAccountId"),
            toAccountId: fd.get("toAccountId"),
            occurredOn: fd.get("occurredOn"),
            amount: fd.get("amount"),
          });
          ref.current?.reset();
          return "سند انتقال ثبت شد.";
        });
      }}
      className="space-y-4"
    >
      <Field label="شرح انتقال">
        <input name="note" required placeholder="شارژ کارت برای خریدهای روزمره" className={inputCls} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="از حساب">
          <select name="fromAccountId" className={inputCls}>
            {accounts.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name}
              </option>
            ))}
          </select>
        </Field>
        <Field label="به حساب">
          <select name="toAccountId" className={inputCls} defaultValue={accounts[1]?.id}>
            {accounts.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name}
              </option>
            ))}
          </select>
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Field label="تاریخ">
          <input name="occurredOn" type="date" defaultValue={defaultDate} className={dateInput} />
        </Field>
        <Field label="مبلغ">
          <input name="amount" type="number" min={1} required placeholder="20,000,000" className={`${inputCls} tabular-nums`} />
        </Field>
      </div>
      <Btn type="submit" disabled={pending}>
        {pending ? "در حال ثبت…" : "ثبت انتقال"}
      </Btn>
      <Notice msg={msg} err={err} />
    </form>
  );
}

/* ----------------------- سرمایه‌گذاری / سبد ------------------------- */
export function HoldingForm({ defaultDate }: { defaultDate: string }) {
  const { pending, msg, err, run } = useAction();
  const ref = useRef<HTMLFormElement>(null);
  const [side, setSide] = useState<"buy" | "sell">("buy");
  const [deal, setDeal] = useState("۰ ریال");

  const recalc = () => {
    const f = ref.current;
    if (!f) return;
    const fd = new FormData(f);
    const qty = Number(fd.get("qty") ?? 0);
    const price = Number(fd.get("price") ?? 0);
    const fee = Number(fd.get("fee") ?? 0);
    const reward = Number(fd.get("reward") ?? 0);
    const total = side === "buy" ? qty * price + fee : qty * price - fee + reward;
    setDeal(`${fa(Math.max(0, Math.round(total)))} ریال`);
  };
  return (
    <form
      ref={ref}
      onSubmit={async (e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        await run(async () => {
          await call("/api/holdings", "POST", {
            side,
            symbol: fd.get("symbol"),
            name: fd.get("name"),
            kind: fd.get("kind"),
            unit: fd.get("unit"),
            qty: fd.get("qty"),
            price: fd.get("price"),
          });
          ref.current?.reset();
          return side === "buy" ? "خرید در سبد ثبت شد." : "فروش از سبد ثبت شد.";
        });
      }}
      className="space-y-4"
    >
      <div className="grid grid-cols-2 gap-2">
        {(["buy", "sell"] as const).map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => setSide(s)}
            className={`border px-3 py-2.5 text-[14px] transition-colors duration-150 ${
              side === s
                ? "border-[#2AD4E4] bg-[#2AD4E4]/12 text-[#7FE6F1]"
                : "border-hair text-muted hover:border-[#2AD4E4]/60 hover:text-ink"
            }`}
          >
            {s === "buy" ? "خرید" : "فروش"}
          </button>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Field label="نوع دارایی">
          <select name="kind" className={inputCls}>
            <option value="currency">ارز</option>
            <option value="gold">طلا</option>
            <option value="coin">سکه</option>
            <option value="fund">صندوق</option>
            <option value="crypto">رمزارز</option>
          </select>
        </Field>
        <Field label="نماد">
          <input name="symbol" required placeholder="USD" className={inputCls} dir="ltr" />
        </Field>
      </div>
      <Field label="نام دارایی">
        <input name="name" placeholder="دلار آمریکا" className={inputCls} />
      </Field>
      <div className="grid grid-cols-3 gap-3">
        <Field label="تعداد">
          <input name="qty" type="number" step="any" min={0} required placeholder="500" className={`${inputCls} tabular-nums`} onChange={recalc} />
        </Field>
        <Field label="قیمت واحد">
          <input name="price" type="number" min={1} required placeholder="782000" className={`${inputCls} tabular-nums`} onChange={recalc} />
        </Field>
        <Field label="واحد">
          <input name="unit" defaultValue="واحد" className={inputCls} />
        </Field>
      </div>
      <div className="grid grid-cols-3 gap-3">
        <Field label="کارمزد">
          <input name="fee" type="number" min={0} placeholder="0" className={`${inputCls} tabular-nums`} onChange={recalc} />
        </Field>
        <Field label="پاداش">
          <input name="reward" type="number" min={0} placeholder="0" className={`${inputCls} tabular-nums`} onChange={recalc} />
        </Field>
        <Field label="تاریخ">
          <input name="occurredOn" type="date" defaultValue={defaultDate} className={dateInput} />
        </Field>
      </div>
      <div className="flex items-baseline justify-between border-t border-hair pt-3 text-[13px]">
        <span className="text-muted">{side === "buy" ? "ارزش معامله با کارمزد" : "خالص فروش پس از کارمزد"}</span>
        <span className="tabular-nums text-ink">{deal}</span>
      </div>
      <Btn type="submit" disabled={pending}>
        {pending ? "در حال ثبت…" : "ثبت سرمایه‌گذاری"}
      </Btn>
      <Notice msg={msg} err={err} />
    </form>
  );
}

/* ------------------------ بدهی / طلب جدید --------------------------- */
export function DebtForm() {
  const { pending, msg, err, run } = useAction();
  const ref = useRef<HTMLFormElement>(null);
  const [dir, setDir] = useState<"payable" | "receivable">("payable");
  return (
    <form
      ref={ref}
      onSubmit={async (e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        await run(async () => {
          await call("/api/debts", "POST", {
            direction: dir,
            party: fd.get("party"),
            amount: fd.get("amount"),
            dueOn: fd.get("dueOn"),
            note: fd.get("note"),
          });
          ref.current?.reset();
          return "آیتم جدید ثبت شد.";
        });
      }}
      className="space-y-4"
    >
      <div className="grid grid-cols-2 gap-2">
        {(["payable", "receivable"] as const).map((d) => (
          <button
            key={d}
            type="button"
            onClick={() => setDir(d)}
            className={`border px-3 py-2.5 text-[14px] transition-colors duration-150 ${
              dir === d
                ? d === "payable"
                  ? "border-[#E0684F] bg-[#E0684F]/12 text-[#F0A08D]"
                  : "border-[#D8AC4E] bg-[#D8AC4E]/12 text-[#E7C77F]"
                : "border-hair text-muted hover:border-[#2AD4E4]/60 hover:text-ink"
            }`}
          >
            {d === "payable" ? "بدهی من به دیگران" : "طلب من از دیگران"}
          </button>
        ))}
      </div>
      <Field label="نام شخص / مرجع">
        <input name="party" required placeholder="نیما نامداری" className={inputCls} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="مبلغ">
          <input name="amount" type="number" min={1} required placeholder="4,500,000" className={`${inputCls} tabular-nums`} />
        </Field>
        <Field label="سررسید">
          <input name="dueOn" type="date" className={dateInput} />
        </Field>
      </div>
      <Field label="یادداشت">
        <input name="note" placeholder="قرض نقدی" className={inputCls} />
      </Field>
      <Btn type="submit" disabled={pending}>
        {pending ? "در حال ثبت…" : "ثبت آیتم"}
      </Btn>
      <Notice msg={msg} err={err} />
    </form>
  );
}

/* --------------------------- دکمه‌های ردیف --------------------------- */
export function DeleteTxButton({ id }: { id: number }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  return (
    <button
      type="button"
      aria-label="حذف تراکنش"
      disabled={busy}
      onClick={async () => {
        setBusy(true);
        await call(`/api/transactions/${id}`, "DELETE").catch(() => null);
        router.refresh();
        setBusy(false);
      }}
      className="text-[#E0684F]/80 transition-colors duration-150 hover:text-[#E0684F] disabled:opacity-40"
    >
      ✕
    </button>
  );
}

export function SettleButton({
  debt,
  accounts,
}: {
  debt: { id: number; party: string; amount: number; direction: string };
  accounts: Opt[];
}) {
  const { pending, msg, err, run } = useAction();
  const [open, setOpen] = useState(false);
  const [accountId, setAccountId] = useState<number | "">(accounts[0]?.id ?? "");

  return (
    <div className="mt-3">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="w-full border border-hair bg-[#04141F] px-3 py-2 text-[13px] text-muted transition-colors duration-150 hover:border-[#2AD4E4] hover:text-[#2AD4E4]"
      >
        {open ? "بستن" : "تسویه"}
      </button>
      {open ? (
        <div className="mt-2 space-y-2 border border-hair bg-[#04141F] p-3">
          <select
            value={accountId}
            onChange={(e) => setAccountId(Number(e.target.value))}
            className={inputCls}
          >
            {accounts.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name}
              </option>
            ))}
          </select>
          <Btn
            variant="brass"
            disabled={pending || accountId === ""}
            onClick={async () => {
              await run(async () => {
                await call("/api/debts/settle", "POST", {
                  id: debt.id,
                  party: debt.party,
                  amount: debt.amount,
                  direction: debt.direction,
                  accountId,
                });
                return "سند تسویه ثبت شد.";
              });
            }}
          >
            {pending ? "در حال ثبت…" : "ثبت سند تسویه"}
          </Btn>
          <Notice msg={msg} err={err} />
        </div>
      ) : null}
    </div>
  );
}

/* ------------------- درون‌ریزی صورت‌حساب بانک ----------------------- */
type ImportRow = { occurredOn: string; description: string; amount: number; kind: "income" | "expense"; categoryName?: string };

export function ImportPanel() {
  const { pending, msg, err, run } = useAction();
  const [rows, setRows] = useState<ImportRow[]>([]);
  const [fileName, setFileName] = useState("");

  function parse(text: string): ImportRow[] {
    const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
    const out: ImportRow[] = [];
    for (const line of lines) {
      const sep = line.includes("\t") ? "\t" : line.includes(";") ? ";" : ",";
      const cols = line.split(sep).map((c) => c.trim().replace(/^"|"$/g, ""));
      if (cols.length < 3) continue;
      const [a, b, c, d, e] = cols;
      if (/تاریخ|date/i.test(a) && /مبلغ|amount/i.test(c)) continue; // header
      const amount = Number(String(c).replace(/[^\d.-]/g, ""));
      if (!b || !Number.isFinite(amount) || amount === 0) continue;
      const iso = /^\d{4}-\d{2}-\d{2}$/.test(a) ? a : new Date().toISOString().slice(0, 10);
      out.push({
        occurredOn: iso,
        description: b,
        amount: Math.abs(amount),
        kind: /درآمد|credit|واریز/i.test(d ?? "") || amount > 0 ? "income" : "expense",
        categoryName: e?.trim() || undefined,
      });
    }
    return out;
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_1.1fr]">
      <div>
        <p className="max-w-xl text-[14px] leading-7 text-muted">
          فایل <span className="text-ink">CSV</span> یا <span className="text-ink">TXT</span> صورت‌حساب را انتخاب کنید؛ ستون‌ها به
          ترتیب <span className="text-ink">تاریخ (YYYY-MM-DD)</span>، <span className="text-ink">شرح</span>،
          <span className="text-ink"> مبلغ</span>، <span className="text-ink">نوع (درآمد/هزینه)</span> و
          <span className="text-ink"> دسته</span> باشد. فایل‌های XLSX را پیش از انتخاب به CSV ذخیره کنید.
        </p>
        <div className="mt-5 flex flex-wrap items-center gap-4">
          <label className="cursor-pointer border border-hair bg-[#04141F] px-4 py-2.5 text-[14px] text-ink transition-colors duration-150 hover:border-[#2AD4E4]">
            انتخاب فایل
            <input
              type="file"
              accept=".csv,.txt,.tsv,text/csv,text/plain"
              className="hidden"
              onChange={async (e) => {
                const f = e.target.files?.[0];
                if (!f) return;
                setFileName(f.name);
                setRows(parse(await f.text()));
              }}
            />
          </label>
          <span dir="ltr" className="text-[13px] text-muted">
            {fileName || "No file chosen"}
          </span>
        </div>
        <Btn
          className="mt-6"
          disabled={pending || rows.length === 0}
          onClick={() =>
            run(async () => {
              const r = await call("/api/transactions/import", "POST", { rows });
              setRows([]);
              setFileName("");
              return `${r.imported} ردیف در دفتر ثبت شد.`;
            })
          }
        >
          {pending ? "در حال درون‌ریزی…" : `درون‌ریزی ${rows.length ? rows.toLocaleString("fa-IR") : ""} ردیف`}
        </Btn>
        <Notice msg={msg} err={err} />
      </div>

      <div className="border border-hair bg-[#04141F]">
        <div className="border-b border-hair px-4 py-3 text-[11px] tracking-[0.24em] text-muted">پیش‌نمایش درون‌ریزی</div>
        <div className="max-h-64 overflow-auto">
          {rows.length === 0 ? (
            <p className="px-4 py-10 text-center text-[13px] text-muted">
              هنوز فایلی خوانده نشده است — نمونهٔ یک صورت‌حساب واقعی را بارگذاری کنید.
            </p>
          ) : (
            <table className="w-full text-[13px]">
              <tbody>
                {rows.slice(0, 40).map((r, i) => (
                  <tr key={i} className="border-b border-hair/60 last:border-0">
                    <td className="px-3 py-2 tabular-nums text-muted">{r.occurredOn}</td>
                    <td className="px-3 py-2 text-ink">{r.description}</td>
                    <td className={`px-3 py-2 text-left tabular-nums ${r.kind === "income" ? "text-[#7FE6F1]" : "text-[#F0A08D]"}`}>
                      {r.amount.toLocaleString("fa-IR")}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
