"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";

type Doc = {
  id: number;
  title: string;
  docType: string;
  category: string;
  docNumber: string;
  issueDate: string;
  expiryDate: string;
  description: string;
  tags: string;
  fileName: string;
  mimeType: string;
  fileSize: number;
  fileUrl: string;
  isFavorite: boolean;
  createdAt: string;
  updatedAt: string;
};

const DOC_TYPES = [
  "شناسنامه",
  "کارت ملی",
  "پاسپورت",
  "گواهینامه رانندگی",
  "سند ملک",
  "سند خودرو",
  "مدرک تحصیلی",
  "کارت پایان خدمت",
  "بیمه",
  "قرارداد",
  "فیش حقوقی",
  "گواهی اشتغال",
  "پرونده پزشکی",
  "گذرنامه تحصیلی",
  "سایر",
];

const CATEGORIES = ["عمومی", "هویتی", "مالی", "ملکی", "خودرو", "تحصیلی", "درمانی", "شغلی", "حقوقی", "خانوادگی"];

const SORTS = [
  { v: "newest", l: "جدیدترین" },
  { v: "oldest", l: "قدیمی‌ترین" },
  { v: "title", l: "عنوان (الفبا)" },
  { v: "size", l: "حجم فایل" },
  { v: "expiry", l: "نزدیک‌ترین انقضا" },
];

function formatBytes(n: number) {
  if (!n || n <= 0) return "بدون فایل";
  if (n < 1024) return `${n} بایت`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  if (n < 1024 * 1024 * 1024) return `${(n / 1024 / 1024).toFixed(2)} MB`;
  return `${(n / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

function fileKind(mime: string, name: string) {
  const m = (mime || "").toLowerCase();
  const n = (name || "").toLowerCase();
  if (m.startsWith("image/")) return "image";
  if (m === "application/pdf" || n.endsWith(".pdf")) return "pdf";
  if (m.startsWith("video/") || /\.(mp4|mkv|mov|avi|webm)$/.test(n)) return "video";
  if (m.startsWith("audio/") || /\.(mp3|wav|ogg|m4a|flac)$/.test(n)) return "audio";
  if (m.includes("word") || /\.(doc|docx|odt|rtf)$/.test(n)) return "word";
  if (m.includes("sheet") || m.includes("excel") || /\.(xls|xlsx|csv|ods)$/.test(n)) return "excel";
  if (m.includes("presentation") || /\.(ppt|pptx|odp)$/.test(n)) return "ppt";
  if (m.includes("zip") || m.includes("rar") || m.includes("7z") || /\.(zip|rar|7z|tar|gz)$/.test(n)) return "zip";
  if (m.startsWith("text/") || /\.(txt|md|json|xml|log|srt)$/.test(n)) return "text";
  if (/\.(jpg|jpeg|png|gif|webp|bmp|svg|heic)$/.test(n)) return "image";
  return "other";
}

function kindMeta(kind: string) {
  switch (kind) {
    case "image":
      return { label: "تصویر", bg: "from-emerald-400/25 to-emerald-600/10", bd: "border-emerald-400/40", tx: "text-emerald-300", icon: "◈" };
    case "pdf":
      return { label: "PDF", bg: "from-rose-500/25 to-rose-700/10", bd: "border-rose-400/40", tx: "text-rose-300", icon: "⬣" };
    case "video":
      return { label: "ویدیو", bg: "from-violet-500/25 to-violet-700/10", bd: "border-violet-400/40", tx: "text-violet-300", icon: "▶" };
    case "audio":
      return { label: "صوت", bg: "from-amber-400/25 to-amber-600/10", bd: "border-amber-400/40", tx: "text-amber-300", icon: "♪" };
    case "word":
      return { label: "Word", bg: "from-blue-500/25 to-blue-700/10", bd: "border-blue-400/40", tx: "text-blue-300", icon: "W" };
    case "excel":
      return { label: "Excel", bg: "from-green-500/25 to-green-700/10", bd: "border-green-400/40", tx: "text-green-300", icon: "X" };
    case "ppt":
      return { label: "پاورپوینت", bg: "from-orange-500/25 to-orange-700/10", bd: "border-orange-400/40", tx: "text-orange-300", icon: "P" };
    case "zip":
      return { label: "فشرده", bg: "from-yellow-400/20 to-yellow-600/10", bd: "border-yellow-400/40", tx: "text-yellow-300", icon: "▦" };
    case "text":
      return { label: "متن", bg: "from-slate-400/20 to-slate-600/10", bd: "border-slate-400/40", tx: "text-slate-300", icon: "≡" };
    default:
      return { label: "فایل", bg: "from-cyan-500/20 to-cyan-700/10", bd: "border-cyan-400/40", tx: "text-cyan-300", icon: "❏" };
  }
}

function expiryStatus(expiry: string) {
  if (!expiry) return null;
  const d = new Date(expiry);
  if (isNaN(d.getTime())) return null;
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  const diff = Math.ceil((d.getTime() - now.getTime()) / 86400000);
  if (diff < 0) return { tone: "expired" as const, text: `منقضی شده (${Math.abs(diff)} روز پیش)`, days: diff };
  if (diff === 0) return { tone: "warning" as const, text: "امروز منقضی می‌شود", days: diff };
  if (diff <= 90) return { tone: "warning" as const, text: `${diff} روز تا انقضا`, days: diff };
  return { tone: "ok" as const, text: "معتبر", days: diff };
}

function toFaDate(iso: string) {
  if (!iso) return "—";
  try {
    const d = new Date(iso.includes("T") ? iso : iso + "T00:00:00");
    if (isNaN(d.getTime())) return iso;
    return new Intl.DateTimeFormat("fa-IR", { year: "numeric", month: "long", day: "numeric" }).format(d);
  } catch {
    return iso;
  }
}

const emptyForm = {
  title: "",
  docType: "کارت ملی",
  customType: "",
  category: "هویتی",
  docNumber: "",
  issueDate: "",
  expiryDate: "",
  description: "",
  tags: "",
  isFavorite: false,
};

export default function ArchivePage() {
  const [docs, setDocs] = useState<Doc[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [filterType, setFilterType] = useState("همه");
  const [filterCat, setFilterCat] = useState("همه");
  const [favOnly, setFavOnly] = useState(false);
  const [sortBy, setSortBy] = useState("newest");
  const [viewMode, setViewMode] = useState<"list" | "grid">("list");

  const [form, setForm] = useState(emptyForm);
  const [file, setFile] = useState<File | null>(null);
  const [dragOn, setDragOn] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const [detail, setDetail] = useState<Doc | null>(null);
  const [editing, setEditing] = useState<Doc | null>(null);
  const [editFile, setEditFile] = useState<File | null>(null);
  const [editForm, setEditForm] = useState<any>(null);
  const [confirmDel, setConfirmDel] = useState<Doc | null>(null);
  const [busyId, setBusyId] = useState<number | null>(null);

  const [toast, setToast] = useState<{ msg: string; ok: boolean } | null>(null);
  const toastTimer = useRef<any>(null);
  const showToast = (msg: string, ok = true) => {
    setToast({ msg, ok });
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 3200);
  };

  useEffect(() => {
    const t = setTimeout(() => setDebounced(search.trim()), 350);
    return () => clearTimeout(t);
  }, [search]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const q = new URLSearchParams();
      if (debounced) q.set("search", debounced);
      if (filterType !== "همه") q.set("type", filterType);
      if (filterCat !== "همه") q.set("category", filterCat);
      if (favOnly) q.set("fav", "1");
      const r = await fetch(`/api/documents?${q.toString()}`);
      const j = await r.json();
      if (j.ok) setDocs(j.data);
      else showToast(j.error || "خطا در دریافت", false);
    } catch {
      showToast("ارتباط با سرور برقرار نشد", false);
    } finally {
      setLoading(false);
    }
  }, [debounced, filterType, filterCat, favOnly]);

  useEffect(() => {
    load();
  }, [load]);

  const sorted = useMemo(() => {
    const arr = [...docs];
    if (sortBy === "oldest") arr.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    else if (sortBy === "title") arr.sort((a, b) => a.title.localeCompare(b.title, "fa"));
    else if (sortBy === "size") arr.sort((a, b) => (b.fileSize || 0) - (a.fileSize || 0));
    else if (sortBy === "expiry") {
      arr.sort((a, b) => {
        const da = a.expiryDate ? new Date(a.expiryDate).getTime() : Infinity;
        const db = b.expiryDate ? new Date(b.expiryDate).getTime() : Infinity;
        return da - db;
      });
    } else arr.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return arr;
  }, [docs, sortBy]);

  const stats = useMemo(() => {
    const total = docs.length;
    const fav = docs.filter((d) => d.isFavorite).length;
    const size = docs.reduce((s, d) => s + (d.fileSize || 0), 0);
    let expiring = 0;
    let expired = 0;
    docs.forEach((d) => {
      const st = expiryStatus(d.expiryDate);
      if (st?.tone === "warning") expiring++;
      if (st?.tone === "expired") expired++;
    });
    const withFile = docs.filter((d) => d.fileUrl).length;
    return { total, fav, size, expiring, expired, withFile };
  }, [docs]);

  const allTypes = useMemo(() => {
    const s = new Set(docs.map((d) => d.docType).filter(Boolean));
    DOC_TYPES.forEach((t) => s.add(t));
    return ["همه", ...Array.from(s)];
  }, [docs]);

  const resetAdd = () => {
    setForm(emptyForm);
    setFile(null);
    if (fileRef.current) fileRef.current.value = "";
  };

  const handleAdd = async (e?: React.FormEvent) => {
    e?.preventDefault();
    const finalType = form.docType === "سایر" && form.customType.trim() ? form.customType.trim() : form.docType;
    if (!form.title.trim()) return showToast("عنوان مدرک الزامی است", false);
    if (!finalType) return showToast("نوع سند را انتخاب کنید", false);
    setSaving(true);
    try {
      const fd = new FormData();
      fd.set("title", form.title.trim());
      fd.set("docType", finalType);
      fd.set("category", form.category);
      fd.set("docNumber", form.docNumber.trim());
      fd.set("issueDate", form.issueDate);
      fd.set("expiryDate", form.expiryDate);
      fd.set("description", form.description.trim());
      fd.set("tags", form.tags.trim());
      fd.set("isFavorite", form.isFavorite ? "1" : "0");
      if (file) fd.set("file", file);
      const r = await fetch("/api/documents", { method: "POST", body: fd });
      const j = await r.json();
      if (!j.ok) return showToast(j.error || "خطا در ذخیره", false);
      showToast(`«${j.data.title}» با موفقیت ذخیره شد`);
      resetAdd();
      load();
    } catch {
      showToast("خطا در ذخیره‌سازی", false);
    } finally {
      setSaving(false);
    }
  };

  const openEdit = (d: Doc) => {
    setEditing(d);
    setEditFile(null);
    setEditForm({
      title: d.title,
      docType: DOC_TYPES.includes(d.docType) ? d.docType : "سایر",
      customType: DOC_TYPES.includes(d.docType) ? "" : d.docType,
      category: d.category,
      docNumber: d.docNumber || "",
      issueDate: d.issueDate || "",
      expiryDate: d.expiryDate || "",
      description: d.description || "",
      tags: d.tags || "",
      isFavorite: !!d.isFavorite,
    });
    setDetail(null);
  };

  const submitEdit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!editing || !editForm) return;
    const finalType = editForm.docType === "سایر" && editForm.customType?.trim() ? editForm.customType.trim() : editForm.docType;
    if (!String(editForm.title || "").trim()) return showToast("عنوان الزامی است", false);
    setSaving(true);
    try {
      const fd = new FormData();
      fd.set("title", String(editForm.title).trim());
      fd.set("docType", finalType);
      fd.set("category", editForm.category);
      fd.set("docNumber", editForm.docNumber || "");
      fd.set("issueDate", editForm.issueDate || "");
      fd.set("expiryDate", editForm.expiryDate || "");
      fd.set("description", editForm.description || "");
      fd.set("tags", editForm.tags || "");
      fd.set("isFavorite", editForm.isFavorite ? "1" : "0");
      if (editFile) fd.set("file", editFile);
      const r = await fetch(`/api/documents/${editing.id}`, { method: "PUT", body: fd });
      const j = await r.json();
      if (!j.ok) return showToast(j.error || "خطا در ویرایش", false);
      showToast("تغییرات با موفقیت ذخیره شد");
      setEditing(null);
      setEditFile(null);
      load();
    } catch {
      showToast("خطا در ویرایش", false);
    } finally {
      setSaving(false);
    }
  };

  const doDelete = async () => {
    if (!confirmDel) return;
    setBusyId(confirmDel.id);
    try {
      const r = await fetch(`/api/documents/${confirmDel.id}`, { method: "DELETE" });
      const j = await r.json();
      if (!j.ok) return showToast(j.error || "خطا در حذف", false);
      showToast("مدرک حذف شد");
      setConfirmDel(null);
      setDetail(null);
      load();
    } catch {
      showToast("خطا در حذف", false);
    } finally {
      setBusyId(null);
    }
  };

  const toggleFav = async (d: Doc) => {
    try {
      const r = await fetch(`/api/documents/${d.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isFavorite: !d.isFavorite }),
      });
      const j = await r.json();
      if (j.ok) {
        setDocs((p) => p.map((x) => (x.id === d.id ? { ...x, isFavorite: !d.isFavorite } : x)));
        if (detail?.id === d.id) setDetail({ ...detail, isFavorite: !d.isFavorite });
      }
    } catch {}
  };

  const seedSamples = async () => {
    setSaving(true);
    try {
      const samples = [
        { title: "پورتفوی ملینا", docType: "عمومی", category: "عمومی", docNumber: "2323232", description: "نمونه آرشیو — شناسه پیوست", tags: "مهم, بایگانی" },
        { title: "شناسنامه — صفحه اول", docType: "شناسنامه", category: "هویتی", docNumber: "0045123789", issueDate: "1400-03-12", description: "اسکن شناسنامه جدید", tags: "هویتی, اصل" },
        { title: "سند ملک سعادت‌آباد", docType: "سند ملک", category: "ملکی", docNumber: "ملک-8821", issueDate: "1399-11-02", expiryDate: "", description: "سند تک‌برگ، پلاک ۱۲۴", tags: "ملک, مهم" },
      ];
      for (const s of samples) {
        const fd = new FormData();
        Object.entries(s).forEach(([k, v]) => fd.set(k, v as string));
        await fetch("/api/documents", { method: "POST", body: fd });
      }
      showToast("نمونه‌ها اضافه شدند");
      load();
    } finally {
      setSaving(false);
    }
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOn(false);
    const f = e.dataTransfer.files?.[0];
    if (f) {
      if (f.size > 50 * 1024 * 1024) return showToast("حجم فایل بیشتر از ۵۰ مگابایت است", false);
      setFile(f);
    }
  };

  return (
    <div className="min-h-screen pb-16">
      <div className="mx-auto w-full max-w-6xl px-3 sm:px-5 pt-5">
        {/* Header — like screenshot */}
        <header className="glass-card anim-fade-up rounded-2xl px-6 py-7 sm:px-10 relative overflow-hidden">
          <div className="pointer-events-none absolute -left-20 -top-24 h-64 w-64 rounded-full bg-cyan-500/15 blur-3xl" />
          <div className="pointer-events-none absolute right-10 top-0 h-40 w-72 bg-blue-600/15 blur-3xl" />
          <div className="relative flex flex-col gap-5 md:flex-row md:items-start md:justify-between">
            <div className="text-left order-1" dir="ltr" style={{ display: "none" }} />
            <div className="flex-1">
              <p className="text-[13px] text-cyan-300/90 font-medium">داده‌های واقعی LifeOS</p>
              <h1 className="mt-1 text-4xl sm:text-5xl font-black tracking-tight text-white">مدارک</h1>
              <p className="mt-3 max-w-xl text-[13.5px] leading-7 text-slate-300/90">
                آرشیو حرفه‌ای مدارک شخصی — ذخیره و مدیریت <b className="text-cyan-200">همه گونه فایل</b> (عکس، PDF، ویدیو، صوت، Word، Excel، فشرده و…)
                با جستجو، پیش‌نمایش، یادآور انقضا، علاقه‌مندی و ویرایش کامل.
              </p>
              <div className="mt-4 flex flex-wrap items-center gap-2 text-[12px]">
                <span className="chip px-3 py-1.5 text-slate-200">📦 {stats.total} مدرک</span>
                <span className="chip px-3 py-1.5 text-slate-200">★ {stats.fav} علاقه‌مندی</span>
                <span className="chip px-3 py-1.5 text-slate-200">💾 {formatBytes(stats.size)}</span>
                {stats.expired > 0 && <span className="chip px-3 py-1.5 border-rose-400/50 text-rose-200 bg-rose-500/10">⚠ {stats.expired} منقضی‌شده</span>}
                {stats.expiring > 0 && <span className="chip px-3 py-1.5 border-amber-400/50 text-amber-200 bg-amber-500/10">⏳ {stats.expiring} رو به انقضا</span>}
                <button onClick={load} className="btn-ghost px-3 py-1.5 text-cyan-200 text-[12px]">↻ به‌روزرسانی</button>
              </div>
            </div>
            <div className="shrink-0 flex md:flex-col gap-2 items-stretch">
              <div className="glass-card rounded-xl px-5 py-4 text-center min-w-[150px]">
                <div className="text-3xl font-black text-white">{stats.total}</div>
                <div className="mt-1 text-[12px] text-slate-400">کل مدارک</div>
              </div>
              <div className="glass-card rounded-xl px-5 py-4 text-center min-w-[150px]">
                <div className="text-3xl font-black text-cyan-300">{stats.withFile}</div>
                <div className="mt-1 text-[12px] text-slate-400">دارای فایل پیوست</div>
              </div>
            </div>
          </div>
        </header>

        {/* Stats strip */}
        <div className="mt-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
          {[
            { t: "علاقه‌مندی‌ها", v: String(stats.fav), s: "ستاره‌دارها", c: "text-amber-300", i: "★" },
            { t: "حجم آرشیو", v: formatBytes(stats.size), s: "مجموع پیوست‌ها", c: "text-cyan-300", i: "◍" },
            { t: "رو به انقضا", v: String(stats.expiring), s: "کمتر از ۹۰ روز", c: "text-orange-300", i: "◷" },
            { t: "منقضی‌شده", v: String(stats.expired), s: "نیاز به تمدید", c: "text-rose-300", i: "⚠" },
          ].map((k) => (
            <div key={k.t} className="glass-card anim-fade-up rounded-2xl p-4 flex items-center gap-3">
              <div className={`grid h-11 w-11 place-items-center rounded-xl border border-cyan-400/20 bg-cyan-400/10 text-xl ${k.c}`}>{k.i}</div>
              <div>
                <div className="text-[12px] text-slate-400">{k.t}</div>
                <div className="text-lg font-extrabold text-white leading-6">{k.v}</div>
                <div className="text-[11px] text-slate-500">{k.s}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Main two columns */}
        <div className="mt-4 grid gap-4 lg:grid-cols-[380px_1fr] items-start">
          {/* Add form — right in RTL = first */}
          <section className="glass-card anim-fade-up rounded-2xl p-5 sm:p-6 lg:sticky lg:top-4">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-extrabold text-white">افزودن</h2>
              <span className="text-[11px] px-2.5 py-1 rounded-full border border-cyan-400/30 bg-cyan-400/10 text-cyan-200">فرم جدید</span>
            </div>

            <form onSubmit={handleAdd} className="mt-4 space-y-3">
              <div>
                <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="عنوان *" className="field text-right" />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <select value={form.docType} onChange={(e) => setForm({ ...form, docType: e.target.value })} className="field">
                  {DOC_TYPES.map((t) => (
                    <option key={t}>{t}</option>
                  ))}
                </select>
                <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="field">
                  {CATEGORIES.map((t) => (
                    <option key={t}>{t}</option>
                  ))}
                </select>
              </div>
              {form.docType === "سایر" && (
                <input value={form.customType} onChange={(e) => setForm({ ...form, customType: e.target.value })} placeholder="نوع سفارشی سند…" className="field" />
              )}
              <input value={form.docNumber} onChange={(e) => setForm({ ...form, docNumber: e.target.value })} placeholder="شماره / شناسه سند" className="field" dir="ltr" style={{ textAlign: "right" }} />
              <div className="grid grid-cols-2 gap-2">
                <label className="block">
                  <span className="mb-1 block text-[11px] text-slate-400">تاریخ صدور</span>
                  <input type="date" value={form.issueDate} onChange={(e) => setForm({ ...form, issueDate: e.target.value })} className="field" dir="ltr" />
                </label>
                <label className="block">
                  <span className="mb-1 block text-[11px] text-slate-400">تاریخ انقضا</span>
                  <input type="date" value={form.expiryDate} onChange={(e) => setForm({ ...form, expiryDate: e.target.value })} className="field" dir="ltr" />
                </label>
              </div>
              <input value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} placeholder="برچسب‌ها (با ویرگول جدا کنید)" className="field" />
              <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="توضیحات" rows={3} className="field resize-y" />

              {/* Dropzone — all file types */}
              <div
                onDragOver={(e) => { e.preventDefault(); setDragOn(true); }}
                onDragLeave={() => setDragOn(false)}
                onDrop={onDrop}
                onClick={() => fileRef.current?.click()}
                className={`cursor-pointer rounded-xl border-2 border-dashed border-cyan-500/30 bg-[#041627]/80 p-4 text-center transition-all ${dragOn ? "drop-active" : "hover:border-cyan-300/60"}`}
              >
                <input ref={fileRef} type="file" className="hidden" onChange={(e) => {
                  const f = e.target.files?.[0] || null;
                  if (f && f.size > 50 * 1024 * 1024) { showToast("حجم فایل بیشتر از ۵۰ مگ است", false); return; }
                  setFile(f);
                }} />
                {!file ? (
                  <div>
                    <div className="text-3xl">📁</div>
                    <div className="mt-1 text-[13px] font-bold text-cyan-100">انتخاب یا رها کردن فایل — همه فرمت‌ها</div>
                    <div className="mt-1 text-[11px] leading-5 text-slate-400">JPG • PNG • PDF • MP4 • MP3 • DOCX • XLSX • ZIP • TXT و…<br />حداکثر ۵۰ مگابایت</div>
                    <div className="mt-2 inline-block rounded-lg border border-cyan-400/40 bg-cyan-400/10 px-3 py-1.5 text-[12px] text-cyan-200">📎 انتخاب فایل</div>
                  </div>
                ) : (
                  <div className="flex items-center justify-between gap-2 text-right" onClick={(e) => e.stopPropagation()}>
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-cyan-400/15 text-cyan-200">❏</div>
                      <div className="min-w-0">
                        <div className="truncate text-[13px] font-bold text-white" dir="ltr">{file.name}</div>
                        <div className="text-[11px] text-slate-400">{formatBytes(file.size)} • {file.type || "نامشخص"}</div>
                      </div>
                    </div>
                    <button type="button" onClick={() => { setFile(null); if (fileRef.current) fileRef.current.value = ""; }} className="shrink-0 rounded-lg px-2 py-1 text-rose-300 hover:bg-rose-500/10">✕</button>
                  </div>
                )}
              </div>

              <label className="flex cursor-pointer items-center justify-between rounded-xl border border-white/10 bg-white/[0.02] px-3 py-2.5 text-[13px]">
                <span className="text-slate-200">★ افزودن به علاقه‌مندی‌ها</span>
                <input type="checkbox" checked={form.isFavorite} onChange={(e) => setForm({ ...form, isFavorite: e.target.checked })} className="h-5 w-5 accent-cyan-400" />
              </label>

              <button disabled={saving} className="btn-cyan w-full py-3 text-[15px]">
                {saving ? "در حال ذخیره…" : "ذخیره"}
              </button>
              <button type="button" onClick={resetAdd} className="btn-ghost w-full py-2 text-[13px] text-slate-300">پاک کردن فرم</button>
            </form>
          </section>

          {/* List */}
          <section className="glass-card anim-fade-up rounded-2xl p-5 sm:p-6 min-h-[520px]">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h2 className="text-2xl font-extrabold text-white">فهرست</h2>
              <div className="flex items-center gap-2">
                <span className="rounded-full bg-cyan-400/15 border border-cyan-400/30 px-3 py-1 text-[12px] text-cyan-200">{sorted.length} مورد</span>
                <div className="flex rounded-lg overflow-hidden border border-cyan-500/30 text-[12px]">
                  <button onClick={() => setViewMode("list")} className={`px-3 py-1.5 ${viewMode === "list" ? "bg-cyan-400/20 text-cyan-100" : "text-slate-400"}`}>☰ لیست</button>
                  <button onClick={() => setViewMode("grid")} className={`px-3 py-1.5 ${viewMode === "grid" ? "bg-cyan-400/20 text-cyan-100" : "text-slate-400"}`}>▦ گرید</button>
                </div>
              </div>
            </div>

            {/* Search */}
            <div className="mt-4 relative">
              <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="🔍 جستجو در عنوان، شماره، توضیح، برچسب…" className="field !py-3 !rounded-xl pr-4" />
              {search && <button onClick={() => setSearch("")} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white">✕</button>}
            </div>

            {/* Filters */}
            <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-2">
              <select value={filterType} onChange={(e) => setFilterType(e.target.value)} className="field !text-[12.5px]">
                {allTypes.map((t) => <option key={t} value={t}>{t === "همه" ? "همه نوع‌ها" : t}</option>)}
              </select>
              <select value={filterCat} onChange={(e) => setFilterCat(e.target.value)} className="field !text-[12.5px]">
                {["همه", ...CATEGORIES].map((t) => <option key={t} value={t}>{t === "همه" ? "همه دسته‌ها" : t}</option>)}
              </select>
              <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="field !text-[12.5px]">
                {SORTS.map((s) => <option key={s.v} value={s.v}>{s.l}</option>)}
              </select>
              <button onClick={() => setFavOnly(!favOnly)} className={`rounded-[10px] border px-2 text-[12.5px] transition-all ${favOnly ? "border-amber-300 bg-amber-400/15 text-amber-200" : "border-cyan-500/30 text-slate-300 hover:border-cyan-300"}`}>
                {favOnly ? "★ فقط علاقه‌مندی‌ها" : "☆ علاقه‌مندی‌ها"}
              </button>
            </div>

            {(filterType !== "همه" || filterCat !== "همه" || favOnly || debounced) && (
              <div className="mt-2 flex items-center gap-2 text-[12px] text-slate-400">
                <span>فیلتر فعال است</span>
                <button onClick={() => { setFilterType("همه"); setFilterCat("همه"); setFavOnly(false); setSearch(""); }} className="text-cyan-300 hover:underline">حذف همه فیلترها ✕</button>
              </div>
            )}

            {/* Content */}
            <div className="mt-4">
              {loading ? (
                <div className="space-y-2">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="animate-pulse rounded-xl border border-white/5 bg-white/[0.03] p-4">
                      <div className="h-4 w-1/3 rounded bg-white/10" />
                      <div className="mt-2 h-3 w-2/3 rounded bg-white/5" />
                    </div>
                  ))}
                </div>
              ) : sorted.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-cyan-500/25 bg-cyan-500/[0.03] px-6 py-14 text-center">
                  <div className="text-5xl">🗂️</div>
                  <div className="mt-3 text-lg font-extrabold text-white">هنوز مدرکی ثبت نشده</div>
                  <p className="mx-auto mt-1 max-w-sm text-[13px] leading-6 text-slate-400">از فرم «افزودن» سمت راست اولین مدرک را ثبت کنید، یا نمونه‌های آماده را اضافه کنید.</p>
                  <button onClick={seedSamples} disabled={saving} className="btn-ghost mt-4 px-5 py-2.5 text-[13px] text-cyan-200">✦ افزودن ۳ نمونه آماده</button>
                </div>
              ) : viewMode === "list" ? (
                <div className="space-y-2.5">
                  {sorted.map((d) => {
                    const kind = fileKind(d.mimeType, d.fileName);
                    const km = kindMeta(kind);
                    const ex = expiryStatus(d.expiryDate);
                    return (
                      <article key={d.id} className="doc-row anim-fade-up rounded-xl border border-cyan-500/15 bg-[#041627]/60 p-3.5">
                        <div className="flex items-start gap-3">
                          {/* thumb */}
                          <button onClick={() => setDetail(d)} className="shrink-0">
                            {kind === "image" && d.fileUrl ? (
                              <img src={d.fileUrl} alt={d.title} className="h-14 w-14 rounded-xl border border-white/10 object-cover" />
                            ) : (
                              <span className={`grid h-14 w-14 place-items-center rounded-xl border bg-gradient-to-br text-lg font-black ${km.bg} ${km.bd} ${km.tx}`}>
                                {km.icon}
                                <span className="sr-only">{km.label}</span>
                              </span>
                            )}
                          </button>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-start justify-between gap-2">
                              <div className="min-w-0">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <button onClick={() => setDetail(d)} className="truncate text-[15px] font-extrabold text-white hover:text-cyan-200 text-right">{d.title}</button>
                                  <button onClick={() => toggleFav(d)} title="علاقه‌مندی" className={`text-[15px] ${d.isFavorite ? "text-amber-300" : "text-slate-600 hover:text-amber-200"}`}>{d.isFavorite ? "★" : "☆"}</button>
                                </div>
                                <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px]">
                                  <span className="rounded-full border border-cyan-400/40 bg-cyan-400/10 px-2 py-0.5 text-cyan-200">{d.docType}</span>
                                  <span className="text-slate-500">{d.category}</span>
                                  {d.docNumber && <span className="text-slate-400" dir="ltr">{d.docNumber}</span>}
                                  {d.fileName && <span className="text-slate-500">• {km.label} • {formatBytes(d.fileSize)}</span>}
                                  {ex && (
                                    <span className={`rounded-full border px-2 py-0.5 ${ex.tone === "expired" ? "border-rose-400/50 bg-rose-500/10 text-rose-200" : ex.tone === "warning" ? "border-amber-400/50 bg-amber-500/10 text-amber-200" : "border-emerald-400/40 bg-emerald-500/10 text-emerald-200"}`}>
                                      {ex.tone === "ok" ? "✓ معتبر" : ex.text}
                                    </span>
                                  )}
                                </div>
                                {d.description && <p className="mt-1.5 line-clamp-2 text-[12.5px] leading-6 text-slate-400">{d.description}</p>}
                                {d.tags && (
                                  <div className="mt-1.5 flex flex-wrap gap-1">
                                    {d.tags.split(/[,،]/).map((t) => t.trim()).filter(Boolean).slice(0, 4).map((t) => (
                                      <span key={t} className="rounded-md bg-white/[0.04] px-1.5 py-0.5 text-[11px] text-slate-400">#{t}</span>
                                    ))}
                                  </div>
                                )}
                              </div>
                              <div className="flex shrink-0 items-center gap-1">
                                <button onClick={() => setDetail(d)} title="نمایش" className="rounded-lg px-2 py-1.5 text-[13px] text-cyan-300 hover:bg-cyan-400/10 underline underline-offset-4">نمایش</button>
                                <button onClick={() => openEdit(d)} title="ویرایش" className="rounded-lg border border-cyan-500/30 bg-cyan-400/10 px-2.5 py-1 text-[11.5px] text-cyan-200 hover:bg-cyan-400/20">ویرایش</button>
                                <button onClick={() => setConfirmDel(d)} title="حذف" className="rounded-lg px-1.5 py-1 text-[14px] text-rose-400 hover:bg-rose-500/10">✕</button>
                              </div>
                            </div>
                            {(d.fileUrl || d.fileName) && (
                              <div className="mt-2 flex flex-wrap items-center gap-2 border-t border-white/5 pt-2">
                                {d.fileUrl ? (
                                  <>
                                    <a href={d.fileUrl} download={d.fileName} className="text-[12px] text-indigo-300 hover:text-indigo-200 underline underline-offset-4">⬇ بارگرفتن پیوست</a>
                                    <span className="truncate text-[11px] text-slate-500" dir="ltr">{d.fileName}</span>
                                  </>
                                ) : (
                                  <span className="text-[11px] text-slate-500">بدون فایل پیوست</span>
                                )}
                                {d.expiryDate && <span className="mr-auto text-[11px] text-slate-500">انقضا: {toFaDate(d.expiryDate)}</span>}
                              </div>
                            )}
                          </div>
                        </div>
                      </article>
                    );
                  })}
                </div>
              ) : (
                <div className="grid gap-3 sm:grid-cols-2">
                  {sorted.map((d) => {
                    const kind = fileKind(d.mimeType, d.fileName);
                    const km = kindMeta(kind);
                    return (
                      <article key={d.id} className="doc-row anim-fade-up overflow-hidden rounded-2xl border border-cyan-500/15 bg-[#041627]/60">
                        <button onClick={() => setDetail(d)} className="block w-full">
                          {kind === "image" && d.fileUrl ? (
                            <img src={d.fileUrl} alt={d.title} className="h-36 w-full object-cover" />
                          ) : (
                            <span className={`grid h-28 w-full place-items-center bg-gradient-to-br text-3xl font-black ${km.bg} ${km.tx}`}>{km.icon} <span className="mt-1 block text-[11px] font-medium opacity-80">{km.label} {d.fileName ? "• " + formatBytes(d.fileSize) : ""}</span></span>
                          )}
                        </button>
                        <div className="p-3.5">
                          <div className="flex items-start justify-between gap-2">
                            <div className="truncate text-[14px] font-extrabold text-white">{d.title}</div>
                            <button onClick={() => toggleFav(d)} className={d.isFavorite ? "text-amber-300" : "text-slate-600"}>{d.isFavorite ? "★" : "☆"}</button>
                          </div>
                          <div className="mt-1 flex flex-wrap gap-1 text-[11px]">
                            <span className="rounded-full border border-cyan-400/40 bg-cyan-400/10 px-2 py-0.5 text-cyan-200">{d.docType}</span>
                            <span className="text-slate-500">{d.category}</span>
                          </div>
                          <div className="mt-2.5 flex items-center gap-1.5">
                            <button onClick={() => setDetail(d)} className="flex-1 rounded-lg bg-cyan-400/10 border border-cyan-500/30 py-1.5 text-[12px] text-cyan-200">نمایش</button>
                            <button onClick={() => openEdit(d)} className="flex-1 rounded-lg border border-white/10 py-1.5 text-[12px] text-slate-200">ویرایش</button>
                            {d.fileUrl && <a href={d.fileUrl} download={d.fileName} className="rounded-lg border border-white/10 px-2.5 py-1.5 text-[13px]">⬇</a>}
                            <button onClick={() => setConfirmDel(d)} className="rounded-lg px-2 py-1.5 text-rose-400">✕</button>
                          </div>
                        </div>
                      </article>
                    );
                  })}
                </div>
              )}
            </div>
          </section>
        </div>

        <footer className="mt-6 text-center text-[11.5px] text-slate-600">
          LifeOS • آرشیو امن مدارک شخصی — همه فایل‌ها روی همین سرور ذخیره می‌شوند • {new Date().toLocaleDateString("fa-IR")}
        </footer>
      </div>

      {/* Detail modal */}
      {detail && (
        <div className="fixed inset-0 z-50 grid place-items-center overflow-y-auto bg-black/70 p-3 backdrop-blur-sm" onClick={() => setDetail(null)}>
          <div className="anim-pop w-full max-w-3xl overflow-hidden rounded-2xl border border-cyan-500/30 bg-[#071c33] shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between border-b border-white/10 px-5 py-3.5">
              <div className="flex items-center gap-2 min-w-0">
                <button onClick={() => toggleFav(detail)} className={`text-xl ${detail.isFavorite ? "text-amber-300" : "text-slate-500"}`}>{detail.isFavorite ? "★" : "☆"}</button>
                <div className="min-w-0">
                  <div className="truncate text-[16px] font-extrabold text-white">{detail.title}</div>
                  <div className="text-[11.5px] text-slate-400">{detail.docType} • {detail.category} {detail.docNumber ? `• ${detail.docNumber}` : ""}</div>
                </div>
              </div>
              <button onClick={() => setDetail(null)} className="rounded-lg px-2.5 py-1.5 text-slate-400 hover:bg-white/5 hover:text-white">✕</button>
            </div>
            <div className="grid gap-0 md:grid-cols-[1fr_300px]">
              <div className="bg-black/40 p-4 min-h-[280px] grid place-items-center">
                <PreviewBlock doc={detail} />
              </div>
              <div className="space-y-3 p-5 text-[13px] leading-6">
                <InfoRow k="نوع سند" v={detail.docType} />
                <InfoRow k="دسته" v={detail.category} />
                <InfoRow k="شماره سند" v={detail.docNumber || "—"} ltr />
                <InfoRow k="تاریخ صدور" v={detail.issueDate ? toFaDate(detail.issueDate) : "—"} />
                <InfoRow k="تاریخ انقضا" v={detail.expiryDate ? toFaDate(detail.expiryDate) : "—"} />
                {detail.expiryDate && (() => { const s = expiryStatus(detail.expiryDate); return s ? <div className={`rounded-lg border px-3 py-2 text-[12px] ${s.tone === "expired" ? "border-rose-400/40 bg-rose-500/10 text-rose-200" : s.tone === "warning" ? "border-amber-400/40 bg-amber-500/10 text-amber-200" : "border-emerald-400/40 bg-emerald-500/10 text-emerald-200"}`}>{s.tone === "ok" ? "✓ سند معتبر است" : s.text}</div> : null; })()}
                <div>
                  <div className="text-[11px] text-slate-500">توضیحات</div>
                  <div className="mt-0.5 text-slate-200">{detail.description || "—"}</div>
                </div>
                {detail.tags && <div><div className="text-[11px] text-slate-500">برچسب‌ها</div><div className="mt-1 flex flex-wrap gap-1">{detail.tags.split(/[,،]/).map((t) => t.trim()).filter(Boolean).map((t) => <span key={t} className="rounded-md bg-cyan-400/10 border border-cyan-400/20 px-2 py-0.5 text-[11.5px] text-cyan-200">#{t}</span>)}</div></div>}
                {detail.fileName && <div><div className="text-[11px] text-slate-500">فایل پیوست</div><div className="mt-0.5 truncate text-slate-200" dir="ltr">{detail.fileName} • {formatBytes(detail.fileSize)}</div><div className="text-[11px] text-slate-500" dir="ltr">{detail.mimeType}</div></div>}
                <div className="flex flex-wrap gap-2 pt-1">
                  {detail.fileUrl && <a href={detail.fileUrl} download={detail.fileName} className="btn-cyan px-4 py-2 text-[13px]">⬇ دانلود فایل</a>}
                  {detail.fileUrl && <a href={detail.fileUrl} target="_blank" className="btn-ghost px-4 py-2 text-[13px] text-cyan-200">↗ باز کردن در تب جدید</a>}
                </div>
                <div className="flex gap-2 border-t border-white/10 pt-3">
                  <button onClick={() => openEdit(detail)} className="flex-1 rounded-lg border border-cyan-400/40 bg-cyan-400/10 py-2 text-[13px] text-cyan-100">✎ ویرایش</button>
                  <button onClick={() => setConfirmDel(detail)} className="rounded-lg border border-rose-400/40 bg-rose-500/10 px-4 py-2 text-[13px] text-rose-200">حذف</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit modal */}
      {editing && editForm && (
        <div className="fixed inset-0 z-50 grid place-items-center overflow-y-auto bg-black/70 p-3 backdrop-blur-sm" onClick={() => setEditing(null)}>
          <form onSubmit={submitEdit} className="anim-pop w-full max-w-lg rounded-2xl border border-cyan-500/30 bg-[#071c33] p-5 sm:p-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-extrabold text-white">✎ ویرایش مدرک</h3>
              <button type="button" onClick={() => setEditing(null)} className="text-slate-400 hover:text-white">✕</button>
            </div>
            <div className="mt-4 space-y-2.5">
              <input value={editForm.title} onChange={(e) => setEditForm({ ...editForm, title: e.target.value })} className="field" placeholder="عنوان *" />
              <div className="grid grid-cols-2 gap-2">
                <select value={editForm.docType} onChange={(e) => setEditForm({ ...editForm, docType: e.target.value })} className="field">
                  {DOC_TYPES.map((t) => <option key={t}>{t}</option>)}
                </select>
                <select value={editForm.category} onChange={(e) => setEditForm({ ...editForm, category: e.target.value })} className="field">
                  {CATEGORIES.map((t) => <option key={t}>{t}</option>)}
                </select>
              </div>
              {editForm.docType === "سایر" && <input value={editForm.customType} onChange={(e) => setEditForm({ ...editForm, customType: e.target.value })} className="field" placeholder="نوع سفارشی…" />}
              <input value={editForm.docNumber} onChange={(e) => setEditForm({ ...editForm, docNumber: e.target.value })} className="field" placeholder="شماره سند" />
              <div className="grid grid-cols-2 gap-2">
                <label className="block"><span className="mb-1 block text-[11px] text-slate-400">صدور</span><input type="date" value={editForm.issueDate} onChange={(e) => setEditForm({ ...editForm, issueDate: e.target.value })} className="field" dir="ltr" /></label>
                <label className="block"><span className="mb-1 block text-[11px] text-slate-400">انقضا</span><input type="date" value={editForm.expiryDate} onChange={(e) => setEditForm({ ...editForm, expiryDate: e.target.value })} className="field" dir="ltr" /></label>
              </div>
              <input value={editForm.tags} onChange={(e) => setEditForm({ ...editForm, tags: e.target.value })} className="field" placeholder="برچسب‌ها" />
              <textarea value={editForm.description} onChange={(e) => setEditForm({ ...editForm, description: e.target.value })} className="field" rows={3} placeholder="توضیحات" />
              <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
                <div className="text-[12px] text-slate-300">فایل فعلی: <span className="text-slate-400" dir="ltr">{editing.fileName || "بدون فایل"}</span></div>
                <label className="btn-ghost mt-2 flex cursor-pointer items-center justify-center gap-2 px-3 py-2 text-[13px] text-cyan-200">
                  📎 {editFile ? `فایل جدید: ${editFile.name}` : "تعویض فایل (اختیاری — همه فرمت‌ها)"}
                  <input type="file" className="hidden" onChange={(e) => setEditFile(e.target.files?.[0] || null)} />
                </label>
                {editFile && <button type="button" onClick={() => setEditFile(null)} className="mt-1 text-[12px] text-rose-300">حذف فایل جدید ✕</button>}
              </div>
              <label className="flex items-center justify-between text-[13px] text-slate-200">
                <span>★ علاقه‌مندی</span>
                <input type="checkbox" checked={!!editForm.isFavorite} onChange={(e) => setEditForm({ ...editForm, isFavorite: e.target.checked })} className="h-5 w-5 accent-cyan-400" />
              </label>
            </div>
            <div className="mt-4 flex gap-2">
              <button disabled={saving} className="btn-cyan flex-1 py-2.5 text-[14px]">{saving ? "در حال ذخیره…" : "✓ ذخیره تغییرات"}</button>
              <button type="button" onClick={() => setEditing(null)} className="btn-ghost px-5 py-2.5 text-[13px] text-slate-300">انصراف</button>
            </div>
          </form>
        </div>
      )}

      {/* Delete confirm */}
      {confirmDel && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4 backdrop-blur-sm" onClick={() => setConfirmDel(null)}>
          <div className="anim-pop w-full max-w-sm rounded-2xl border border-rose-400/30 bg-[#1a0f18] p-6 text-center" onClick={(e) => e.stopPropagation()}>
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-rose-500/15 text-2xl">🗑</div>
            <h3 className="mt-3 text-lg font-extrabold text-white">حذف مدرک؟</h3>
            <p className="mt-1 text-[13px] leading-6 text-slate-400">«{confirmDel.title}» و فایل پیوست آن برای همیشه حذف می‌شود. این عمل قابل بازگشت نیست.</p>
            <div className="mt-4 flex gap-2">
              <button onClick={doDelete} disabled={busyId === confirmDel.id} className="flex-1 rounded-xl bg-rose-500 py-2.5 text-[14px] font-bold text-white hover:bg-rose-400 disabled:opacity-60">{busyId === confirmDel.id ? "در حال حذف…" : "بله، حذف کن"}</button>
              <button onClick={() => setConfirmDel(null)} className="flex-1 rounded-xl border border-white/15 py-2.5 text-[14px] text-slate-200">انصراف</button>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <div className={`anim-toast fixed bottom-5 left-1/2 z-[60] -translate-x-1/2 rounded-xl border px-5 py-3 text-[13.5px] font-bold shadow-2xl ${toast.ok ? "border-emerald-400/40 bg-[#06281f]/95 text-emerald-200" : "border-rose-400/40 bg-[#2a1015]/95 text-rose-200"}`}>
          {toast.ok ? "✓ " : "⚠ "}{toast.msg}
        </div>
      )}
    </div>
  );
}

function InfoRow({ k, v, ltr }: { k: string; v: string; ltr?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-2 border-b border-white/5 pb-2">
      <span className="text-[11.5px] text-slate-500">{k}</span>
      <span className="font-bold text-slate-100" dir={ltr ? "ltr" : "rtl"}>{v}</span>
    </div>
  );
}

function PreviewBlock({ doc }: { doc: Doc }) {
  const kind = fileKind(doc.mimeType, doc.fileName);
  if (!doc.fileUrl) {
    return (
      <div className="py-10 text-center">
        <div className="text-5xl opacity-60">📭</div>
        <div className="mt-2 text-[13px] text-slate-400">فایلی پیوست نشده — فقط اطلاعات متنی ذخیره شده</div>
      </div>
    );
  }
  if (kind === "image") return <img src={doc.fileUrl} alt={doc.title} className="max-h-[420px] w-auto max-w-full rounded-xl border border-white/10 object-contain" />;
  if (kind === "pdf") return <iframe src={doc.fileUrl} className="h-[420px] w-full rounded-xl border border-white/10 bg-white" title={doc.title} />;
  if (kind === "video") return <video src={doc.fileUrl} controls className="max-h-[420px] w-full rounded-xl border border-white/10 bg-black" />;
  if (kind === "audio")
    return (
      <div className="w-full px-4 text-center">
        <div className="text-6xl">🎵</div>
        <div className="mt-2 text-[13px] text-slate-300" dir="ltr">{doc.fileName}</div>
        <audio src={doc.fileUrl} controls className="mt-4 w-full" />
      </div>
    );
  if (kind === "text") return <iframe src={doc.fileUrl} className="h-[420px] w-full rounded-xl border border-white/10 bg-white" title={doc.title} />;
  const km = kindMeta(kind);
  return (
    <div className="py-10 text-center">
      <div className={`mx-auto grid h-20 w-20 place-items-center rounded-2xl border bg-gradient-to-br text-3xl font-black ${km.bg} ${km.bd} ${km.tx}`}>{km.icon}</div>
      <div className="mt-3 text-[14px] font-bold text-white" dir="ltr">{doc.fileName}</div>
      <div className="mt-1 text-[12px] text-slate-400">{km.label} • {formatBytes(doc.fileSize)}</div>
      <a href={doc.fileUrl} download={doc.fileName} className="btn-cyan mt-4 inline-block px-6 py-2.5 text-[13px]">⬇ دانلود برای مشاهده</a>
      <div className="mt-2 text-[11px] text-slate-500">پیش‌نمایش مستقیم برای این فرمت پشتیبانی نمی‌شود</div>
    </div>
  );
}
