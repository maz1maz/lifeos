import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { documents } from "@/db/schema";
import { desc, ilike, or, eq, and } from "drizzle-orm";
import { promises as fs } from "fs";
import path from "path";
import crypto from "crypto";

export const dynamic = "force-dynamic";

const UPLOAD_DIR = path.join(process.cwd(), "public", "uploads");

async function ensureUploadDir() {
  try {
    await fs.mkdir(UPLOAD_DIR, { recursive: true });
  } catch {}
}

function sanitizeFileName(name: string) {
  return name.replace(/[^\w.\-()\[\] ]+/g, "_").slice(0, 120);
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const search = (searchParams.get("search") || "").trim();
    const type = (searchParams.get("type") || "").trim();
    const category = (searchParams.get("category") || "").trim();
    const fav = searchParams.get("fav") === "1";

    const conditions = [];
    if (search) {
      const pattern = `%${search}%`;
      conditions.push(
        or(
          ilike(documents.title, pattern),
          ilike(documents.docNumber, pattern),
          ilike(documents.description, pattern),
          ilike(documents.tags, pattern),
          ilike(documents.fileName, pattern)
        )
      );
    }
    if (type && type !== "همه") conditions.push(eq(documents.docType, type));
    if (category && category !== "همه") conditions.push(eq(documents.category, category));
    if (fav) conditions.push(eq(documents.isFavorite, true));

    const rows =
      conditions.length > 0
        ? await db.select().from(documents).where(and(...conditions)).orderBy(desc(documents.createdAt))
        : await db.select().from(documents).orderBy(desc(documents.createdAt));

    return NextResponse.json({ ok: true, data: rows });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || "خطا در دریافت" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureUploadDir();
    const form = await req.formData();

    const title = String(form.get("title") || "").trim();
    if (!title) return NextResponse.json({ ok: false, error: "عنوان الزامی است" }, { status: 400 });

    const docType = String(form.get("docType") || "عمومی").trim() || "عمومی";
    const category = String(form.get("category") || "عمومی").trim() || "عمومی";
    const docNumber = String(form.get("docNumber") || "").trim();
    const issueDate = String(form.get("issueDate") || "").trim();
    const expiryDate = String(form.get("expiryDate") || "").trim();
    const description = String(form.get("description") || "").trim();
    const tags = String(form.get("tags") || "").trim();
    const isFavorite = String(form.get("isFavorite") || "") === "1" || String(form.get("isFavorite") || "") === "true";

    let fileName = "";
    let mimeType = "";
    let fileSize = 0;
    let fileUrl = "";

    const file = form.get("file") as File | null;
    if (file && typeof file === "object" && "arrayBuffer" in file && file.size > 0) {
      if (file.size > 50 * 1024 * 1024) {
        return NextResponse.json({ ok: false, error: "حجم فایل نباید بیشتر از ۵۰ مگابایت باشد" }, { status: 400 });
      }
      const buf = Buffer.from(await file.arrayBuffer());
      const ext = path.extname(file.name || "") || "";
      const safe = sanitizeFileName(path.basename(file.name || "file", ext));
      const unique = `${Date.now()}-${crypto.randomBytes(6).toString("hex")}${ext}`;
      const diskName = `${safe.replace(ext, "") || "file"}-${unique}`;
      await fs.writeFile(path.join(UPLOAD_DIR, diskName), buf);
      fileName = file.name || diskName;
      mimeType = file.type || "application/octet-stream";
      fileSize = file.size;
      fileUrl = `/uploads/${diskName}`;
    }

    const inserted = await db
      .insert(documents)
      .values({
        title,
        docType,
        category,
        docNumber,
        issueDate,
        expiryDate,
        description,
        tags,
        fileName,
        mimeType,
        fileSize,
        fileUrl,
        isFavorite,
      })
      .returning();

    return NextResponse.json({ ok: true, data: inserted[0] });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || "خطا در ذخیره" }, { status: 500 });
  }
}
