import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { documents } from "@/db/schema";
import { eq } from "drizzle-orm";
import { promises as fs } from "fs";
import path from "path";
import crypto from "crypto";

export const dynamic = "force-dynamic";

const UPLOAD_DIR = path.join(process.cwd(), "public", "uploads");

function sanitizeFileName(name: string) {
  return name.replace(/[^\w.\-()\[\] ]+/g, "_").slice(0, 120);
}

export async function GET(_: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const rows = await db.select().from(documents).where(eq(documents.id, Number(id)));
    if (!rows[0]) return NextResponse.json({ ok: false, error: "یافت نشد" }, { status: 404 });
    return NextResponse.json({ ok: true, data: rows[0] });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || "خطا" }, { status: 500 });
  }
}

export async function DELETE(_: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const rows = await db.select().from(documents).where(eq(documents.id, Number(id)));
    const existing = rows[0];
    if (!existing) return NextResponse.json({ ok: false, error: "یافت نشد" }, { status: 404 });

    // try remove physical file
    if (existing.fileUrl?.startsWith("/uploads/")) {
      try {
        await fs.unlink(path.join(process.cwd(), "public", existing.fileUrl));
      } catch {}
    }
    await db.delete(documents).where(eq(documents.id, Number(id)));
    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || "خطا در حذف" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const numId = Number(id);
    const rows = await db.select().from(documents).where(eq(documents.id, numId));
    const existing = rows[0];
    if (!existing) return NextResponse.json({ ok: false, error: "یافت نشد" }, { status: 404 });

    const contentType = req.headers.get("content-type") || "";

    let patch: Record<string, any> = {};

    if (contentType.includes("multipart/form-data")) {
      const form = await req.formData();
      const get = (k: string) => {
        const v = form.get(k);
        return v === null ? undefined : String(v);
      };
      const title = get("title");
      if (title !== undefined) patch.title = title.trim();
      if (get("docType") !== undefined) patch.docType = (get("docType") || "عمومی").trim();
      if (get("category") !== undefined) patch.category = (get("category") || "عمومی").trim();
      if (get("docNumber") !== undefined) patch.docNumber = (get("docNumber") || "").trim();
      if (get("issueDate") !== undefined) patch.issueDate = (get("issueDate") || "").trim();
      if (get("expiryDate") !== undefined) patch.expiryDate = (get("expiryDate") || "").trim();
      if (get("description") !== undefined) patch.description = (get("description") || "").trim();
      if (get("tags") !== undefined) patch.tags = (get("tags") || "").trim();
      const favRaw = get("isFavorite");
      if (favRaw !== undefined) patch.isFavorite = favRaw === "1" || favRaw === "true";

      const file = form.get("file") as File | null;
      if (file && typeof file === "object" && "arrayBuffer" in file && file.size > 0) {
        if (file.size > 50 * 1024 * 1024) {
          return NextResponse.json({ ok: false, error: "حجم فایل بیشتر از ۵۰ مگابایت است" }, { status: 400 });
        }
        await fs.mkdir(UPLOAD_DIR, { recursive: true });
        // delete old
        if (existing.fileUrl?.startsWith("/uploads/")) {
          try {
            await fs.unlink(path.join(process.cwd(), "public", existing.fileUrl));
          } catch {}
        }
        const buf = Buffer.from(await file.arrayBuffer());
        const ext = path.extname(file.name || "") || "";
        const safe = sanitizeFileName(path.basename(file.name || "file", ext));
        const unique = `${Date.now()}-${crypto.randomBytes(6).toString("hex")}${ext}`;
        const diskName = `${safe.replace(ext, "") || "file"}-${unique}`;
        await fs.writeFile(path.join(UPLOAD_DIR, diskName), buf);
        patch.fileName = file.name || diskName;
        patch.mimeType = file.type || "application/octet-stream";
        patch.fileSize = file.size;
        patch.fileUrl = `/uploads/${diskName}`;
      }
    } else {
      const body = await req.json();
      const allowed = ["title", "docType", "category", "docNumber", "issueDate", "expiryDate", "description", "tags", "isFavorite"] as const;
      for (const k of allowed) {
        if (body[k] !== undefined) patch[k] = body[k];
      }
      if (patch.title !== undefined && !String(patch.title).trim()) {
        return NextResponse.json({ ok: false, error: "عنوان الزامی است" }, { status: 400 });
      }
    }

    patch.updatedAt = new Date();

    const updated = await db.update(documents).set(patch).where(eq(documents.id, numId)).returning();
    return NextResponse.json({ ok: true, data: updated[0] });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || "خطا در ویرایش" }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return PUT(req, { params });
}
