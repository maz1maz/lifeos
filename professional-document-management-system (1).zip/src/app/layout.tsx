import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "آرشیو مدارک شخصی | LifeOS",
  description: "آرشیو حرفه‌ای مدارک شخصی — ذخیره، مشاهده، ویرایش و مدیریت همه گونه فایل",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body className="antialiased">{children}</body>
    </html>
  );
}
