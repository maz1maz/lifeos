import { pgTable, serial, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";

export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  docType: text("doc_type").notNull().default("عمومی"),
  category: text("category").notNull().default("عمومی"),
  docNumber: text("doc_number").default(""),
  issueDate: text("issue_date").default(""),
  expiryDate: text("expiry_date").default(""),
  description: text("description").default(""),
  tags: text("tags").default(""),
  fileName: text("file_name").default(""),
  mimeType: text("mime_type").default(""),
  fileSize: integer("file_size").default(0),
  fileUrl: text("file_url").default(""),
  isFavorite: boolean("is_favorite").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type DocumentRow = typeof documents.$inferSelect;
export type NewDocumentRow = typeof documents.$inferInsert;
