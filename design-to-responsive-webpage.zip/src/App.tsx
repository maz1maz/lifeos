import { useEffect, useRef, useState } from "react";
import type { CSSProperties, KeyboardEvent as ReactKeyboardEvent } from "react";
import {
  ArrowLeft,
  Check,
  ChevronDown,
  Heart,
  Info,
  Minus,
  Play,
  Plus,
  X,
} from "lucide-react";
import {
  fixtures,
  leagueOptions,
  liveDays,
  liveGroups,
  previousFixtures,
  standings,
  teams,
  toPersianNumber,
} from "./data/football";
import type {
  Fixture,
  FormResult,
  LeagueOption,
  LiveDay,
  LiveGroup,
  LiveMatch,
  Team,
} from "./data/football";

type TabId = "table" | "matches" | "statistics" | "news" | "history";

type MatchDetails = {
  home: Team;
  away: Team;
  score?: [number, number];
  time: string;
  date: string;
  competition: string;
  venue?: string;
  status: "upcoming" | "finished" | "live";
};

const tabs: { id: TabId; label: string }[] = [
  { id: "table", label: "جدول" },
  { id: "matches", label: "بازی‌ها" },
  { id: "statistics", label: "آمار" },
  { id: "news", label: "اخبار و ویدیوها" },
  { id: "history", label: "ادوار گذشته" },
];

const resultLabels: Record<FormResult, string> = {
  W: "پیروزی",
  D: "تساوی",
  L: "شکست",
};

function TeamBadge({ team, small = false }: { team: Team; small?: boolean }) {
  const [imageFailed, setImageFailed] = useState(false);
  const image = team.flag
    ? `https://flagcdn.com/w80/${team.flag}.png`
    : team.logo
      ? `https://images.fotmob.com/image_resources/logo/teamlogo/${team.logo}.png`
      : undefined;

  return (
    <span
      className={`team-badge${small ? " team-badge-small" : ""}${team.flag ? " team-badge-flag" : ""}`}
      style={{ "--badge-accent": team.accent } as CSSProperties}
      aria-hidden="true"
    >
      {image && !imageFailed ? (
        <img src={image} alt="" loading="lazy" onError={() => setImageFailed(true)} />
      ) : (
        <span className="team-badge-fallback">{team.short}</span>
      )}
    </span>
  );
}

function LeagueBadge({ league, large = false }: { league: LeagueOption; large?: boolean }) {
  const [imageFailed, setImageFailed] = useState(false);

  return (
    <span
      className={`league-badge${large ? " league-badge-large" : ""}`}
      style={{ "--league-accent": league.color } as CSSProperties}
      aria-hidden="true"
    >
      {league.logo && !imageFailed ? (
        <img
          src={`https://images.fotmob.com/image_resources/logo/leaguelogo/${league.logo}.png`}
          alt=""
          onError={() => setImageFailed(true)}
        />
      ) : (
        <span>{league.mark}</span>
      )}
    </span>
  );
}

function LeagueHeader({
  league,
  onLeagueChange,
  activeTab,
  onTabChange,
}: {
  league: LeagueOption;
  onLeagueChange: (league: LeagueOption) => void;
  activeTab: TabId;
  onTabChange: (tab: TabId) => void;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [followedLeagues, setFollowedLeagues] = useState<Record<string, boolean>>(() => {
    try {
      return JSON.parse(window.localStorage.getItem("followed-leagues") || "{}") as Record<string, boolean>;
    } catch {
      return {};
    }
  });
  const following = Boolean(followedLeagues[league.id]);
  const selectorRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!menuOpen) return;

    const onPointerDown = (event: PointerEvent) => {
      if (!selectorRef.current?.contains(event.target as Node)) setMenuOpen(false);
    };
    const onEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setMenuOpen(false);
        triggerRef.current?.focus();
      }
    };

    document.addEventListener("pointerdown", onPointerDown);
    document.addEventListener("keydown", onEscape);
    return () => {
      document.removeEventListener("pointerdown", onPointerDown);
      document.removeEventListener("keydown", onEscape);
    };
  }, [menuOpen]);

  const toggleFollowing = () => {
    setFollowedLeagues((current) => {
      const next = { ...current, [league.id]: !current[league.id] };
      try {
        window.localStorage.setItem("followed-leagues", JSON.stringify(next));
      } catch {
        // The follow control still works if storage is unavailable.
      }
      return next;
    });
  };

  const onMenuKeyDown = (event: ReactKeyboardEvent<HTMLDivElement>) => {
    if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;
    event.preventDefault();
    const choices = Array.from(selectorRef.current?.querySelectorAll<HTMLButtonElement>("[data-league-option]") ?? []);
    const current = choices.indexOf(document.activeElement as HTMLButtonElement);
    const next = event.key === "ArrowDown" ? (current + 1) % choices.length : (current - 1 + choices.length) % choices.length;
    choices[next]?.focus();
  };

  return (
    <header className="league-hero" id="top">
      <div className="hero-topline">
        <div className="league-selector" ref={selectorRef}>
          <div className="league-identity">
            <LeagueBadge league={league} large />
            <button
              ref={triggerRef}
              type="button"
              className="league-trigger"
              aria-label={`انتخاب لیگ، ${league.name}`}
              aria-expanded={menuOpen}
              aria-haspopup="menu"
              aria-controls="league-menu"
              onClick={() => setMenuOpen((open) => !open)}
            >
              <span>{league.name}</span>
              <ChevronDown className={menuOpen ? "chevron-open" : ""} size={25} strokeWidth={2.7} />
            </button>
          </div>

          {menuOpen && (
            <div className="league-menu" id="league-menu" role="menu" aria-label="انتخاب لیگ" onKeyDown={onMenuKeyDown}>
              {leagueOptions.map((option) => (
                <button
                  key={option.id}
                  type="button"
                  role="menuitemradio"
                  aria-checked={league.id === option.id}
                  data-league-option
                  className={`league-menu-option${league.id === option.id ? " is-selected" : ""}`}
                  onClick={() => {
                    onLeagueChange(option);
                    setMenuOpen(false);
                    triggerRef.current?.focus();
                  }}
                >
                  <LeagueBadge league={option} />
                  <span>{option.name}</span>
                  {league.id === option.id && <Check size={15} className="selected-check" />}
                </button>
              ))}
            </div>
          )}
        </div>

        <button type="button" className={`follow-button${following ? " is-following" : ""}`} aria-pressed={following} onClick={toggleFollowing}>
          <Heart size={20} strokeWidth={2.3} fill={following ? "currentColor" : "none"} />
          <span>{following ? "دنبال می‌کنید" : "دنبال کنید"}</span>
        </button>
      </div>

      <nav className="league-tabs" aria-label="بخش‌های لیگ" role="tablist">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            id={`tab-${tab.id}`}
            type="button"
            role="tab"
            aria-selected={activeTab === tab.id}
            aria-controls="league-panel"
            tabIndex={activeTab === tab.id ? 0 : -1}
            className={`league-tab${activeTab === tab.id ? " is-active" : ""}`}
            onClick={() => onTabChange(tab.id)}
            onKeyDown={(event) => {
              if (event.key !== "ArrowRight" && event.key !== "ArrowLeft") return;
              event.preventDefault();
              const current = tabs.findIndex((item) => item.id === activeTab);
              const next = (current + (event.key === "ArrowLeft" ? 1 : -1) + tabs.length) % tabs.length;
              onTabChange(tabs[next].id);
              document.getElementById(`tab-${tabs[next].id}`)?.focus();
            }}
          >
            {tab.label}
          </button>
        ))}
      </nav>
    </header>
  );
}

function FormBadges({ results }: { results: FormResult[] }) {
  return (
    <div className="form-badges" aria-label="نتایج پنج بازی اخیر">
      {results.map((result, index) => (
        <span key={`${result}-${index}`} className={`form-badge form-${result.toLowerCase()}`} title={resultLabels[result]} aria-label={resultLabels[result]}>
          {result}
        </span>
      ))}
    </div>
  );
}

function StandingsTable() {
  return (
    <div className="standings-scroll" data-reveal>
      <table className="standings-table">
        <caption className="visually-hidden">جدول رده‌بندی لیگ برتر ایران، فصل جاری</caption>
        <colgroup>
          <col className="col-rank" />
          <col className="col-team" />
          <col className="col-played" />
          <col className="col-won" />
          <col className="col-drawn" />
          <col className="col-lost" />
          <col className="col-goals" />
          <col className="col-difference" />
          <col className="col-points" />
          <col className="col-form" />
        </colgroup>
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col" className="team-heading">تیم</th>
            <th scope="col">بازی</th>
            <th scope="col" className="hide-small">برد</th>
            <th scope="col" className="hide-small">مساوی</th>
            <th scope="col" className="hide-small">باخت</th>
            <th scope="col" className="hide-medium">گل +/-</th>
            <th scope="col">تفاضل</th>
            <th scope="col">امتیاز</th>
            <th scope="col" className="form-heading hide-medium">بازی‌های اخیر</th>
          </tr>
        </thead>
        <tbody>
          {standings.map((row, index) => {
            const team = teams[row.team];
            const difference = row.for - row.against;
            return (
              <tr key={row.team} style={{ "--row-index": Math.min(index, 11) } as CSSProperties}>
                <td className={`rank-cell${index < 4 ? " rank-top" : ""}${index > 13 ? " rank-bottom" : ""}`}>
                  {toPersianNumber(index + 1)}
                </td>
                <th scope="row" className="team-column">
                  <span className="table-team"><TeamBadge team={team} /><span>{team.name}</span></span>
                </th>
                <td>{toPersianNumber(row.played)}</td>
                <td className="hide-small">{toPersianNumber(row.won)}</td>
                <td className="hide-small">{toPersianNumber(row.drawn)}</td>
                <td className="hide-small">{toPersianNumber(row.lost)}</td>
                <td className="hide-medium"><bdi dir="ltr">{toPersianNumber(`${row.for}-${row.against}`)}</bdi></td>
                <td><bdi dir="ltr">{toPersianNumber(difference)}</bdi></td>
                <td className="points-cell">{toPersianNumber(row.points)}</td>
                <td className="hide-medium"><FormBadges results={row.form} /></td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <p className="table-footnote">چهار تیم برتر سهمیه رقابت‌های آسیایی را کسب می‌کنند.</p>
    </div>
  );
}

const leagueStats = [
  { label: "مجموع گل‌های زده شده", value: "۱۰۳" },
  { label: "متوسط گل در هر بازی", value: "۱.۷۵" },
  { label: "متوسط دقیقه هر گل", value: "۵۱.۵۵" },
  { label: "میانگین کارت زرد در هر بازی", value: "۳.۰۲", card: "yellow" },
  { label: "میانگین کارت قرمز در هر بازی", value: "۰.۱۹", card: "red" },
];

const goalPeriods = [
  { label: "۰′", value: "۱۰", height: 31 },
  { label: "۱۵′", value: "۱۲", height: 37 },
  { label: "۳۰′", value: "۲۳", height: 73 },
  { label: "HT", value: "۱۷", height: 54 },
  { label: "۶۰′", value: "۱۱", height: 33 },
  { label: "FT", value: "۳۰", height: 96 },
];

function StatsPanel() {
  return (
    <aside className="stats-panel" aria-labelledby="stats-panel-heading" data-reveal>
      <h3 id="stats-panel-heading">آمار لیگ برتر ایران (فصل جاری)</h3>
      <dl className="stats-list">
        {leagueStats.map((stat, index) => (
          <div className={`stat-line${index % 2 === 0 ? " stat-line-shaded" : ""}`} key={stat.label}>
            <dt>{stat.label}</dt>
            <dd>
              {stat.card && <span className={`card-indicator card-${stat.card}`} aria-hidden="true" />}
              {stat.value}
            </dd>
          </div>
        ))}
      </dl>
      <h4 className="chart-title">پراکندگی دقایق گل‌ها</h4>
      <div className="goal-chart" role="img" aria-label="گل‌های به ثمر رسیده در بازه‌های مختلف بازی: ۱۰، ۱۲، ۲۳، ۱۷، ۱۱ و ۳۰ گل">
        {goalPeriods.map((period, index) => (
          <div className="goal-period" key={period.label}>
            <span className="bar-value">{period.value}</span>
            <span
              className={`goal-bar${index === goalPeriods.length - 1 ? " goal-bar-final" : ""}`}
              style={{ "--bar-height": `${period.height}px` } as CSSProperties}
            />
            <span className="bar-label">{period.label}</span>
          </div>
        ))}
      </div>
      <div className="stats-panel-bottom">آمار فصل ۱۴۰۵ - ۱۴۰۶</div>
    </aside>
  );
}

function StandingsSection() {
  return (
    <section className="standings-section" aria-labelledby="standings-heading">
      <h2 className="section-heading" id="standings-heading" data-reveal>جدول لیگ برتر ایران (خلیج فارس)</h2>
      <div className="standings-layout">
        <StandingsTable />
        <StatsPanel />
      </div>
    </section>
  );
}

function FixtureRow({ fixture, date, week, onSelect }: {
  fixture: Fixture;
  date: string;
  week?: string;
  onSelect: (match: MatchDetails) => void;
}) {
  const home = teams[fixture.home];
  const away = teams[fixture.away];
  const homeLost = fixture.score && fixture.score[0] < fixture.score[1];
  const awayLost = fixture.score && fixture.score[1] < fixture.score[0];

  return (
    <li>
      <button
        type="button"
        className="fixture-row"
        aria-label={`${home.name} و ${away.name}، ${fixture.score ? `نتیجه ${toPersianNumber(fixture.score[0])} به ${toPersianNumber(fixture.score[1])}` : `ساعت ${fixture.time}`}، جزئیات مسابقه`}
        onClick={() => onSelect({
          home,
          away,
          score: fixture.score,
          time: fixture.time,
          date,
          competition: `لیگ برتر ایران${week ? ` - ${week}` : ""}`,
          venue: fixture.venue,
          status: fixture.score ? "finished" : "upcoming",
        })}
      >
        <span className="fixture-time">{fixture.time}</span>
        <span className={`fixture-team fixture-home${homeLost ? " team-muted" : ""}`}>
          <span className="fixture-team-name">{home.name}</span>
          <TeamBadge team={home} />
        </span>
        <span className="fixture-score" dir="ltr">
          {fixture.score ? (
            <><span className={homeLost ? "score-muted" : ""}>{toPersianNumber(fixture.score[0])}</span><span className="score-separator">-</span><span className={awayLost ? "score-muted" : ""}>{toPersianNumber(fixture.score[1])}</span></>
          ) : (
            <span>-</span>
          )}
        </span>
        <span className={`fixture-team fixture-away${awayLost ? " team-muted" : ""}`}>
          <TeamBadge team={away} />
          <span className="fixture-team-name">{away.name}</span>
        </span>
        <span className="fixture-action">
          {fixture.hasHighlights && <span className="play-ring"><Play size={12} fill="currentColor" strokeWidth={1.8} /></span>}
        </span>
      </button>
    </li>
  );
}

function FixturesSection({ onSelect }: { onSelect: (match: MatchDetails) => void }) {
  const [showPrevious, setShowPrevious] = useState(false);
  const groups = showPrevious ? [...previousFixtures, ...fixtures] : fixtures;

  return (
    <section className="fixtures-section" aria-labelledby="fixtures-heading">
      <div className="fixtures-intro" data-reveal>
        <h2 id="fixtures-heading">بازی‌های لیگ برتر ایران</h2>
        <p>لیست بازی‌های لیگ برتر ایران شامل بازی‌های هفته آینده لیگ برتر ایران و تاریخ و ساعت بازی‌های بعدی لیگ برتر ایران</p>
      </div>
      <button type="button" className="previous-toggle" aria-expanded={showPrevious} onClick={() => setShowPrevious((current) => !current)}>
        {showPrevious ? <Minus size={20} /> : <Plus size={20} />}
        <span>{showPrevious ? "پنهان کردن بازی‌های قبل" : "مشاهده بازی‌های قبل"}</span>
      </button>
      <div className="fixture-groups" data-reveal>
        {groups.map((group) => (
          <div className="fixture-group" key={group.date}>
            <div className={`fixture-date${group.week ? " has-week" : ""}`}>
              <strong>{group.week}</strong>
              <span>{group.date}</span>
            </div>
            <ul className="fixture-list">
              {group.matches.map((fixture) => (
                <FixtureRow
                  key={`${fixture.home}-${fixture.away}`}
                  fixture={fixture}
                  date={group.date}
                  week={group.week}
                  onSelect={onSelect}
                />
              ))}
            </ul>
          </div>
        ))}
      </div>
    </section>
  );
}

function CompetitionMark({ type }: { type: LiveGroup["symbol"] }) {
  return (
    <span className={`competition-mark competition-mark-${type}`} aria-hidden="true">
      <span className="competition-mark-curve" />
      <span className="competition-mark-dot" />
    </span>
  );
}

function LiveScores({ onSelect }: { onSelect: (match: MatchDetails) => void }) {
  const [day, setDay] = useState<LiveDay>("today");
  const [aiEnabled, setAiEnabled] = useState(true);
  const [liveOnly, setLiveOnly] = useState(false);
  const groups = liveGroups[day]
    .map((group) => ({ ...group, matches: liveOnly ? group.matches.filter((match) => match.status === "live") : group.matches }))
    .filter((group) => group.matches.length > 0);

  return (
    <section className="live-section" id="live-results" aria-labelledby="live-heading">
      <div className="live-controls" data-reveal>
        <div className="live-controls-top">
          <h2 id="live-heading">نتایج زنده</h2>
          <span>آخرین تغییرات: ۱۱:۳۸</span>
        </div>
        <div className="live-controls-bottom">
          <nav className="live-day-tabs" aria-label="انتخاب روز مسابقات">
            {liveDays.map((option) => (
              <button
                key={option.id}
                type="button"
                aria-current={day === option.id ? "date" : undefined}
                className={`live-day${day === option.id ? " is-active" : ""}`}
                onClick={() => setDay(option.id)}
              >
                {option.label}
              </button>
            ))}
          </nav>
          <div className="live-options">
            <div className="live-option">
              <Info size={18} aria-label="نمایش اطلاعات هوش مصنوعی" />
              <span>هوش مصنوعی</span>
              <button type="button" role="switch" aria-checked={aiEnabled} className={`toggle-switch${aiEnabled ? " is-on" : ""}`} aria-label="هوش مصنوعی" onClick={() => setAiEnabled((current) => !current)}><span /></button>
            </div>
            <div className="live-option">
              <span>زنده</span>
              <button type="button" role="switch" aria-checked={liveOnly} className={`toggle-switch${liveOnly ? " is-on" : ""}`} aria-label="فقط بازی‌های زنده" onClick={() => setLiveOnly((current) => !current)}><span /></button>
            </div>
          </div>
        </div>
      </div>

      <div className="live-groups" aria-live="polite">
        {groups.length ? groups.map((group) => (
          <div className="live-competition" key={`${day}-${group.title}`}>
            <div className="live-competition-heading">
              <span className="live-competition-name"><CompetitionMark type={group.symbol} /><span>{group.title}</span></span>
              <span className="live-competition-date">{group.date}</span>
            </div>
            <ul className="live-match-list">
              {group.matches.map((match: LiveMatch, index) => (
                <li key={`${match.home.name}-${match.away.name}-${index}`}>
                  <button
                    type="button"
                    className="live-match-row"
                    onClick={() => onSelect({ ...match, competition: group.title, date: group.date })}
                    aria-label={`${match.home.name} و ${match.away.name}، ${match.score ? `نتیجه ${toPersianNumber(match.score[0])} به ${toPersianNumber(match.score[1])}` : `ساعت ${match.time}`}، جزئیات مسابقه`}
                  >
                    <span className="live-match-time">{match.time}</span>
                    <span className="live-match-team live-match-home"><span>{match.home.name}</span><TeamBadge team={match.home} small /></span>
                    <span className="live-match-score" dir="ltr">{match.score ? `${toPersianNumber(match.score[0])} - ${toPersianNumber(match.score[1])}` : "-"}</span>
                    <span className="live-match-team live-match-away"><TeamBadge team={match.away} small /><span>{match.away.name}</span></span>
                    <span className="live-match-more" aria-hidden="true">{match.status === "upcoming" && <><i /><i /><i /></>}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )) : (
          <div className="live-empty">در این روز مسابقه زنده‌ای در جریان نیست. برای دیدن همه بازی‌ها، فیلتر زنده را خاموش کنید.</div>
        )}
      </div>
    </section>
  );
}

function StatisticsSection() {
  const leaders = [
    { name: "امیرحسین حسین‌زاده", club: teams.tractor, goals: "۶" },
    { name: "علی علیپور", club: teams.persepolis, goals: "۵" },
    { name: "مهدی لیموچی", club: teams.sepahan, goals: "۴" },
    { name: "رضا اسدی", club: teams.golgohar, goals: "۴" },
  ];

  return (
    <section className="secondary-section" aria-labelledby="statistics-heading">
      <h2 className="section-heading" id="statistics-heading" data-reveal>آمار لیگ برتر ایران</h2>
      <div className="secondary-layout">
        <div className="leaderboard" data-reveal>
          <h3>برترین گلزنان</h3>
          <ol>
            {leaders.map((player, index) => (
              <li key={player.name}>
                <span className="leader-position">{toPersianNumber(index + 1)}</span>
                <TeamBadge team={player.club} />
                <span className="leader-name">{player.name}<small>{player.club.name}</small></span>
                <strong>{player.goals} گل</strong>
              </li>
            ))}
          </ol>
        </div>
        <StatsPanel />
      </div>
    </section>
  );
}

function NewsSection() {
  const stories = [
    { category: "لیگ برتر", title: "رقابت در بالای جدول لیگ برتر به هفته‌های حساس رسید", time: "۲ ساعت پیش" },
    { category: "تراکتور", title: "نگاهی به عملکرد بهترین خط دفاعی فصل تا پایان هفته هفتم", time: "۵ ساعت پیش" },
    { category: "استقلال", title: "برنامه مسابقات هفته هشتم لیگ برتر ایران اعلام شد", time: "دیروز" },
    { category: "ویدیو", title: "تمام گل‌های دیدارهای هفته هفتم لیگ برتر", time: "دیروز" },
  ];

  return (
    <section className="secondary-section editorial-section" aria-labelledby="news-heading">
      <h2 className="section-heading" id="news-heading" data-reveal>اخبار و ویدیوهای لیگ برتر ایران</h2>
      <div className="editorial-list" data-reveal>
        {stories.map((story) => (
          <article className="editorial-item" key={story.title}>
            <div><span className="editorial-category">{story.category}</span><h3>{story.title}</h3></div>
            <time>{story.time}</time>
          </article>
        ))}
      </div>
    </section>
  );
}

function HistorySection() {
  const [season, setSeason] = useState("۱۴۰۴ - ۱۴۰۵");
  const seasons = [
    { year: "۱۴۰۴ - ۱۴۰۵", champion: teams.tractor, runnerUp: teams.sepahan },
    { year: "۱۴۰۳ - ۱۴۰۴", champion: teams.persepolis, runnerUp: teams.esteghlal },
    { year: "۱۴۰۲ - ۱۴۰۳", champion: teams.persepolis, runnerUp: teams.sepahan },
  ];
  const selected = seasons.find((item) => item.year === season)!;

  return (
    <section className="secondary-section history-section" aria-labelledby="history-heading">
      <h2 className="section-heading" id="history-heading" data-reveal>ادوار گذشته لیگ برتر ایران</h2>
      <div className="season-navigation" aria-label="فصل مسابقات">
        {seasons.map((item) => <button key={item.year} type="button" className={season === item.year ? "is-active" : ""} onClick={() => setSeason(item.year)}>{item.year}</button>)}
      </div>
      <div className="season-result" data-reveal>
        <span className="season-label">قهرمان فصل {selected.year}</span>
        <div className="season-champion"><TeamBadge team={selected.champion} /><strong>{selected.champion.name}</strong></div>
        <div className="season-runner">نایب‌قهرمان: <TeamBadge team={selected.runnerUp} small /> {selected.runnerUp.name}</div>
      </div>
    </section>
  );
}

function UnavailableSection({ league, onReturn }: { league: LeagueOption; onReturn: () => void }) {
  return (
    <section className="unavailable-section" data-reveal>
      <LeagueBadge league={league} large />
      <h2>اطلاعات {league.name}</h2>
      <p>جدول و مسابقات این رقابت به‌زودی در این بخش نمایش داده می‌شود.</p>
      <button type="button" onClick={onReturn}>بازگشت به لیگ برتر ایران <ArrowLeft size={18} /></button>
    </section>
  );
}

function MatchDialog({ match, onClose }: { match: MatchDetails; onClose: () => void }) {
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
      if (event.key === "Tab") {
        event.preventDefault();
        closeRef.current?.focus();
      }
    };
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", onKeyDown);
      previousFocus?.focus();
    };
  }, [onClose]);

  return (
    <div className="dialog-backdrop" onClick={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <div className="match-dialog" role="dialog" aria-modal="true" aria-labelledby="dialog-heading">
        <button ref={closeRef} type="button" className="dialog-close" onClick={onClose} aria-label="بستن جزئیات مسابقه"><X size={21} /></button>
        <p className="dialog-competition">{match.competition}</p>
        <h2 id="dialog-heading">جزئیات مسابقه</h2>
        <div className="dialog-teams">
          <div><TeamBadge team={match.home} /><strong>{match.home.name}</strong></div>
          <span className="dialog-score" dir="ltr">{match.score ? `${toPersianNumber(match.score[0])} - ${toPersianNumber(match.score[1])}` : "-"}</span>
          <div><TeamBadge team={match.away} /><strong>{match.away.name}</strong></div>
        </div>
        <dl className="dialog-details">
          <div><dt>تاریخ</dt><dd>{match.date}</dd></div>
          <div><dt>زمان</dt><dd>{match.status === "finished" ? "پایان بازی" : match.time}</dd></div>
          {match.venue && <div><dt>ورزشگاه</dt><dd>{match.venue}</dd></div>}
        </dl>
      </div>
    </div>
  );
}

function useScrollReveal(dependency: string) {
  useEffect(() => {
    const elements = document.querySelectorAll<HTMLElement>("[data-reveal]:not(.is-visible)");
    if (!("IntersectionObserver" in window)) {
      elements.forEach((element) => element.classList.add("is-visible"));
      return;
    }

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.06, rootMargin: "0px 0px -18px 0px" });

    elements.forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, [dependency]);
}

export default function App() {
  const [league, setLeague] = useState<LeagueOption>(leagueOptions[0]);
  const [activeTab, setActiveTab] = useState<TabId>("table");
  const [selectedMatch, setSelectedMatch] = useState<MatchDetails | null>(null);

  useScrollReveal(`${activeTab}-${league.id}`);

  return (
    <main className="app-shell" dir="rtl">
      <div className="page-container">
        <LeagueHeader league={league} onLeagueChange={setLeague} activeTab={activeTab} onTabChange={setActiveTab} />

        <div id="league-panel" role="tabpanel" aria-labelledby={`tab-${activeTab}`}>
          {league.id !== "iran" ? (
            <UnavailableSection league={league} onReturn={() => setLeague(leagueOptions[0])} />
          ) : activeTab === "table" ? (
            <StandingsSection />
          ) : activeTab === "matches" ? (
            <FixturesSection onSelect={setSelectedMatch} />
          ) : activeTab === "statistics" ? (
            <StatisticsSection />
          ) : activeTab === "news" ? (
            <NewsSection />
          ) : (
            <HistorySection />
          )}
        </div>

        <LiveScores onSelect={setSelectedMatch} />

        <footer className="page-footer">
          <span>لیگ برتر ایران</span>
          <a href="#top">بازگشت به بالا <ArrowLeft size={16} /></a>
        </footer>
      </div>
      {selectedMatch && <MatchDialog match={selectedMatch} onClose={() => setSelectedMatch(null)} />}
    </main>
  );
}