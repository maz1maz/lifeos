export type Team = {
  name: string;
  logo?: number;
  flag?: string;
  accent: string;
  short: string;
};

export const teams = {
  tractor: { name: "تراکتور", logo: 176352, accent: "#d92632", short: "ت" },
  esteghlal: { name: "استقلال", logo: 101614, accent: "#1b74c8", short: "ا" },
  persepolis: { name: "پرسپولیس", logo: 101610, accent: "#d72b35", short: "پ" },
  aluminium: { name: "آلومینیوم اراک", logo: 664861, accent: "#438b73", short: "آ" },
  sepahan: { name: "سپاهان", logo: 101611, accent: "#dfae20", short: "س" },
  golgohar: { name: "گل گهر", logo: 389880, accent: "#3754a4", short: "گ" },
  foolad: { name: "فولاد", logo: 139914, accent: "#e23838", short: "ف" },
  paykan: { name: "پیکان", logo: 101619, accent: "#b8dfdc", short: "پ" },
  nassaji: { name: "نساجی مازندران", logo: 392200, accent: "#b82534", short: "ن" },
  chadormalu: { name: "چادرملو اردکان", logo: 1396532, accent: "#2d50ae", short: "چ" },
  malavan: { name: "ملوان", logo: 101612, accent: "#4189c6", short: "م" },
  zobahan: { name: "ذوب آهن", logo: 101618, accent: "#238b69", short: "ذ" },
  sanatnaft: { name: "صنعت نفت آبادان", logo: 101624, accent: "#dfce17", short: "ص" },
  esteghlalkh: { name: "استقلال خوزستان", logo: 394619, accent: "#395ac0", short: "ا" },
  shamsazar: { name: "شمس آذر قزوین", logo: 1303998, accent: "#488b75", short: "ش" },
  mesbabak: { name: "مس شهر بابک", logo: 961464, accent: "#a16c3a", short: "م" },
  fajr: { name: "فجر سپاسی", logo: 101623, accent: "#d5a735", short: "ف" },
} satisfies Record<string, Team>;

export type TeamKey = keyof typeof teams;
export type FormResult = "W" | "D" | "L";

export type Standing = {
  team: TeamKey;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  for: number;
  against: number;
  points: number;
  form: FormResult[];
};

export const standings: Standing[] = [
  { team: "tractor", played: 7, won: 5, drawn: 1, lost: 1, for: 8, against: 1, points: 16, form: ["W", "W", "D", "W", "L"] },
  { team: "esteghlal", played: 7, won: 4, drawn: 3, lost: 0, for: 9, against: 1, points: 15, form: ["W", "D", "D", "D", "W"] },
  { team: "persepolis", played: 6, won: 4, drawn: 1, lost: 1, for: 13, against: 3, points: 13, form: ["W", "L", "W", "D", "W"] },
  { team: "aluminium", played: 6, won: 3, drawn: 3, lost: 0, for: 8, against: 3, points: 12, form: ["D", "W", "D", "W", "D"] },
  { team: "sepahan", played: 6, won: 3, drawn: 1, lost: 2, for: 5, against: 4, points: 10, form: ["L", "L", "W", "D", "W"] },
  { team: "golgohar", played: 7, won: 3, drawn: 1, lost: 3, for: 7, against: 7, points: 10, form: ["W", "L", "L", "L", "W"] },
  { team: "foolad", played: 6, won: 2, drawn: 3, lost: 1, for: 5, against: 3, points: 9, form: ["D", "W", "D", "L", "W"] },
  { team: "paykan", played: 7, won: 2, drawn: 2, lost: 3, for: 5, against: 6, points: 8, form: ["W", "D", "L", "W", "L"] },
  { team: "nassaji", played: 7, won: 2, drawn: 2, lost: 3, for: 4, against: 6, points: 8, form: ["D", "W", "W", "L", "D"] },
  { team: "chadormalu", played: 7, won: 2, drawn: 2, lost: 3, for: 4, against: 9, points: 8, form: ["L", "L", "D", "W", "W"] },
  { team: "malavan", played: 7, won: 2, drawn: 2, lost: 3, for: 6, against: 8, points: 8, form: ["W", "L", "D", "D", "W"] },
  { team: "zobahan", played: 7, won: 1, drawn: 4, lost: 2, for: 5, against: 6, points: 7, form: ["D", "D", "L", "W", "D"] },
  { team: "sanatnaft", played: 7, won: 1, drawn: 3, lost: 3, for: 5, against: 8, points: 6, form: ["L", "D", "W", "D", "L"] },
  { team: "esteghlalkh", played: 7, won: 1, drawn: 3, lost: 3, for: 5, against: 10, points: 6, form: ["D", "L", "D", "W", "L"] },
  { team: "shamsazar", played: 7, won: 1, drawn: 2, lost: 4, for: 4, against: 9, points: 5, form: ["L", "D", "L", "W", "L"] },
  { team: "mesbabak", played: 7, won: 0, drawn: 3, lost: 4, for: 3, against: 12, points: 3, form: ["D", "L", "L", "D", "L"] },
];

export type LeagueOption = {
  id: string;
  name: string;
  logo?: number;
  mark: string;
  color: string;
};

export const leagueOptions: LeagueOption[] = [
  { id: "iran", name: "لیگ برتر ایران", logo: 523, mark: "ایران", color: "#41b7e5" },
  { id: "england", name: "لیگ برتر انگلیس", logo: 47, mark: "PL", color: "#ad6cbd" },
  { id: "germany", name: "بوندسلیگا آلمان", logo: 54, mark: "BL", color: "#e23142" },
  { id: "spain", name: "لالیگا اسپانیا", logo: 87, mark: "LL", color: "#ef4a4a" },
  { id: "italy", name: "سری آ ایتالیا", logo: 55, mark: "A", color: "#33a2e2" },
  { id: "world", name: "جام جهانی", logo: 290, mark: "FIFA", color: "#3d6bd4" },
  { id: "france", name: "لیگ یک فرانسه", logo: 53, mark: "L1", color: "#aab4c8" },
  { id: "azadegan", name: "لیگ آزادگان", mark: "آ", color: "#c6397a" },
  { id: "asiaElite", name: "لیگ نخبگان آسیا", logo: 9467, mark: "AFC", color: "#9f7cca" },
  { id: "champions", name: "لیگ قهرمانان اروپا", logo: 42, mark: "UCL", color: "#4c61c7" },
  { id: "europa", name: "لیگ اروپا", logo: 73, mark: "UEL", color: "#dc9e3d" },
  { id: "asian", name: "جام ملت‌های آسیا", logo: 289, mark: "AFC", color: "#55b190" },
];

export type Fixture = {
  home: TeamKey;
  away: TeamKey;
  time: string;
  score?: [number, number];
  venue?: string;
  hasHighlights?: boolean;
};

export type FixtureGroup = {
  date: string;
  week?: string;
  matches: Fixture[];
};

export const previousFixtures: FixtureGroup[] = [
  {
    date: "۱۴۰۵/۰۶/۱۸",
    week: "هفته ۶",
    matches: [
      { home: "persepolis", away: "foolad", time: "۱۹:۰۰", score: [2, 1], venue: "ورزشگاه آزادی", hasHighlights: true },
      { home: "sepahan", away: "zobahan", time: "۱۸:۳۰", score: [1, 1], venue: "ورزشگاه نقش جهان", hasHighlights: true },
    ],
  },
];

export const fixtures: FixtureGroup[] = [
  {
    date: "۱۴۰۵/۰۶/۱۹",
    week: "هفته ۷",
    matches: [
      { home: "esteghlalkh", away: "tractor", time: "۱۹:۰۰", score: [1, 0], venue: "ورزشگاه شهدای فولاد", hasHighlights: true },
      { home: "shamsazar", away: "golgohar", time: "۱۹:۰۰", score: [2, 3], venue: "ورزشگاه سردار آزادگان", hasHighlights: true },
      { home: "esteghlal", away: "paykan", time: "۱۹:۰۰", score: [1, 0], venue: "ورزشگاه آزادی", hasHighlights: true },
    ],
  },
  {
    date: "۱۴۰۵/۰۶/۲۱",
    matches: [
      { home: "sanatnaft", away: "chadormalu", time: "۲۰:۰۰", score: [1, 2], venue: "ورزشگاه تختی آبادان", hasHighlights: true },
    ],
  },
  {
    date: "۱۴۰۵/۰۶/۲۲",
    matches: [
      { home: "mesbabak", away: "nassaji", time: "۱۹:۰۰", score: [1, 1], venue: "ورزشگاه شهید سلیمانی", hasHighlights: true },
    ],
  },
  {
    date: "۱۴۰۵/۰۷/۱۶",
    week: "هفته ۸",
    matches: [
      { home: "aluminium", away: "malavan", time: "۱۶:۰۰", venue: "ورزشگاه امام خمینی اراک" },
      { home: "nassaji", away: "zobahan", time: "۱۶:۰۰", venue: "ورزشگاه شهید وطنی" },
      { home: "tractor", away: "esteghlal", time: "۱۷:۰۰", venue: "ورزشگاه یادگار امام" },
      { home: "sepahan", away: "fajr", time: "۱۸:۱۵", venue: "ورزشگاه نقش جهان" },
      { home: "foolad", away: "mesbabak", time: "۱۹:۰۰", venue: "ورزشگاه شهدای فولاد" },
    ],
  },
  {
    date: "۱۴۰۵/۰۷/۱۷",
    matches: [
      { home: "persepolis", away: "paykan", time: "۱۸:۱۵", venue: "ورزشگاه آزادی" },
      { home: "golgohar", away: "sanatnaft", time: "۱۹:۰۰", venue: "ورزشگاه شهید سلیمانی" },
      { home: "shamsazar", away: "esteghlalkh", time: "۱۹:۰۰", venue: "ورزشگاه سردار آزادگان" },
    ],
  },
];

export type LiveMatch = {
  home: Team;
  away: Team;
  time: string;
  status: "upcoming" | "live" | "finished";
  score?: [number, number];
};

export type LiveGroup = {
  title: string;
  date: string;
  symbol: "asia" | "europe" | "iran";
  matches: LiveMatch[];
};

const country = (name: string, flag: string, short: string): Team => ({
  name,
  flag,
  short,
  accent: "#64798a",
});

const uzbekistan = country("امید ازبکستان", "uz", "از");
const saudi = country("امید عربستان", "sa", "عر");
const bahrain = country("بحرین", "bh", "بح");
const kuwait = country("کویت", "kw", "کو");
const serbia = country("صربستان", "rs", "صر");
const greece = country("یونان", "gr", "یو");
const netherlands = country("هلند", "nl", "هل");
const germany = country("آلمان", "de", "آل");
const norway = country("نروژ", "no", "نو");
const denmark = country("دانمارک", "dk", "دا");
const portugal = country("پرتغال", "pt", "پر");
const wales = country("ولز", "gb-wls", "ول");
const kosovo = country("کوزوو", "xk", "کو");
const ireland = country("جمهوری ایرلند", "ie", "ای");
const andorra = country("آندورا", "ad", "آن");
const malta = country("مالت", "mt", "ما");

export const liveDays = [
  { id: "day", label: "سه‌شنبه، ۳ مهر" },
  { id: "yesterday", label: "دیروز" },
  { id: "today", label: "امروز" },
  { id: "tomorrow", label: "فردا" },
  { id: "saturday", label: "شنبه، ۴ مهر" },
] as const;

export type LiveDay = (typeof liveDays)[number]["id"];

export const liveGroups: Record<LiveDay, LiveGroup[]> = {
  today: [
    {
      title: "فوتبال آسیایی ناگویا - یک چهارم نهایی",
      date: "۱۴۰۵/۰۷/۰۳",
      symbol: "asia",
      matches: [{ home: uzbekistan, away: saudi, time: "۰۸:۳۰", status: "upcoming" }],
    },
    {
      title: "هندبال آسیایی ناگویا",
      date: "۱۴۰۵/۰۷/۰۳",
      symbol: "asia",
      matches: [{ home: bahrain, away: kuwait, time: "۰۸:۰۰", status: "upcoming" }],
    },
    {
      title: "لیگ ملت‌های اروپا (A) - گروهی",
      date: "۱۴۰۵/۰۷/۰۲",
      symbol: "europe",
      matches: [
        { home: serbia, away: greece, time: "۲۲:۱۵", status: "upcoming" },
        { home: netherlands, away: germany, time: "۲۲:۱۵", status: "upcoming" },
        { home: norway, away: denmark, time: "۲۲:۱۵", status: "upcoming" },
        { home: portugal, away: wales, time: "۲۲:۱۵", status: "upcoming" },
      ],
    },
    {
      title: "لیگ ملت‌های اروپا (B) - گروهی",
      date: "۱۴۰۵/۰۷/۰۲",
      symbol: "europe",
      matches: [{ home: kosovo, away: ireland, time: "۲۲:۱۵", status: "upcoming" }],
    },
    {
      title: "لیگ ملت‌های اروپا (D) - گروهی",
      date: "۱۴۰۵/۰۷/۰۲",
      symbol: "europe",
      matches: [{ home: andorra, away: malta, time: "۱۹:۳۰", status: "upcoming" }],
    },
  ],
  yesterday: [
    {
      title: "لیگ ملت‌های اروپا (A) - گروهی",
      date: "۱۴۰۵/۰۷/۰۲",
      symbol: "europe",
      matches: [
        { home: portugal, away: germany, time: "پایان", status: "finished", score: [2, 1] },
        { home: denmark, away: serbia, time: "پایان", status: "finished", score: [1, 1] },
        { home: netherlands, away: wales, time: "پایان", status: "finished", score: [3, 0] },
      ],
    },
  ],
  tomorrow: [
    {
      title: "لیگ ملت‌های اروپا (B) - گروهی",
      date: "۱۴۰۵/۰۷/۰۴",
      symbol: "europe",
      matches: [
        { home: ireland, away: kosovo, time: "۲۰:۴۵", status: "upcoming" },
        { home: greece, away: norway, time: "۲۲:۱۵", status: "upcoming" },
      ],
    },
  ],
  day: [
    {
      title: "فوتبال آسیایی ناگویا - یک چهارم نهایی",
      date: "۱۴۰۵/۰۷/۰۳",
      symbol: "asia",
      matches: [
        { home: uzbekistan, away: saudi, time: "۰۸:۳۰", status: "upcoming" },
        { home: bahrain, away: kuwait, time: "۱۱:۰۰", status: "upcoming" },
      ],
    },
  ],
  saturday: [
    {
      title: "لیگ برتر ایران - هفته ۸",
      date: "۱۴۰۵/۰۷/۰۴",
      symbol: "iran",
      matches: [
        { home: teams.tractor, away: teams.esteghlal, time: "۱۷:۰۰", status: "upcoming" },
        { home: teams.sepahan, away: teams.persepolis, time: "۱۹:۰۰", status: "upcoming" },
      ],
    },
  ],
};

export const toPersianNumber = (value: number | string) =>
  String(value).replace(/[0-9]/g, (digit) => "۰۱۲۳۴۵۶۷۸۹"[Number(digit)]);