"use client";

import { useState } from "react";
import { ProviderPanel } from "./ProviderPanel";
import { LifePanel } from "./LifePanel";

type Tab = "spotify" | "youtube" | "life";

export function Dashboard() {
  const [tab, setTab] = useState<Tab>("spotify");
  const [refreshKey, setRefreshKey] = useState(0);

  const bump = () => setRefreshKey((k) => k + 1);

  const tabs: { id: Tab; label: string; color: string }[] = [
    { id: "spotify", label: "🎵 Spotify", color: "#1DB954" },
    { id: "youtube", label: "▶ YouTube", color: "#FF0000" },
    { id: "life", label: "🗂️ تاریخچهٔ من", color: "#38bdf8" },
  ];

  return (
    <main className="mx-auto max-w-5xl px-4 py-8">
      <header className="mb-6">
        <h1 className="bg-gradient-to-l from-sky-400 via-emerald-400 to-red-400 bg-clip-text text-3xl font-black text-transparent">
          مرکز رسانهٔ شخصی
        </h1>
        <p className="mt-1 text-sm text-slate-400">
          جستجو، پخش، دیده‌شده، پلی‌لیست و ثبت در تاریخچهٔ شخصی — همه‌چیز یکجا.
        </p>
      </header>

      <nav className="mb-6 flex flex-wrap gap-2">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className="rounded-2xl px-5 py-2.5 text-sm font-bold transition"
            style={
              tab === t.id
                ? { background: t.color, color: "#fff" }
                : { background: "rgba(255,255,255,0.05)", color: "#94a3b8" }
            }
          >
            {t.label}
          </button>
        ))}
      </nav>

      <div className="animate-fade-up">
        {tab === "spotify" && <ProviderPanel provider="spotify" onSaved={bump} />}
        {tab === "youtube" && <ProviderPanel provider="youtube" onSaved={bump} />}
        {tab === "life" && <LifePanel refreshKey={refreshKey} />}
      </div>

      <footer className="mt-10 text-center text-xs text-slate-600">
        ساخته‌شده با Next.js · Drizzle · PostgreSQL — برای اتصال واقعی کلیدهای API را در env قرار دهید.
      </footer>
    </main>
  );
}
