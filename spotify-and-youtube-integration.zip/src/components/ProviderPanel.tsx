"use client";

import { useEffect, useState, useCallback } from "react";
import type { MediaItem, ProviderStatus } from "@/lib/types";
import { MediaCard } from "./MediaCard";

interface FeedResponse {
  status: ProviderStatus;
  recent?: MediaItem[];
  playlists?: MediaItem[];
  items?: MediaItem[];
}

export function ProviderPanel({
  provider,
  onSaved,
}: {
  provider: "spotify" | "youtube";
  onSaved?: () => void;
}) {
  const isSpotify = provider === "spotify";
  const accent = isSpotify ? "#1DB954" : "#FF0000";
  const label = isSpotify ? "Spotify" : "YouTube";

  const [status, setStatus] = useState<ProviderStatus | null>(null);
  const [recent, setRecent] = useState<MediaItem[]>([]);
  const [playlists, setPlaylists] = useState<MediaItem[]>([]);
  const [results, setResults] = useState<MediaItem[] | null>(null);
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);

  const loadFeed = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/media/${provider}`);
      const data: FeedResponse = await res.json();
      setStatus(data.status);
      setRecent(data.recent ?? []);
      setPlaylists(data.playlists ?? []);
    } finally {
      setLoading(false);
    }
  }, [provider]);

  useEffect(() => {
    loadFeed();
  }, [loadFeed]);

  async function search(e: React.FormEvent) {
    e.preventDefault();
    if (!q.trim()) {
      setResults(null);
      return;
    }
    setSearching(true);
    try {
      const res = await fetch(`/api/media/${provider}?q=${encodeURIComponent(q)}`);
      const data: FeedResponse = await res.json();
      setResults(data.items ?? []);
    } finally {
      setSearching(false);
    }
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div
        className="flex flex-wrap items-center justify-between gap-3 rounded-3xl border border-white/10 p-5"
        style={{ background: `linear-gradient(135deg, ${accent}22, transparent)` }}
      >
        <div>
          <p className="text-xs" style={{ color: accent }}>
            اتصال و داده‌های حساب
          </p>
          <h2 className="text-2xl font-black">{label}</h2>
        </div>
        <span
          className="rounded-full border px-3 py-1.5 text-xs font-semibold"
          style={{ borderColor: `${accent}55`, color: accent }}
        >
          {status ? (status.connected ? "● متصل (واقعی)" : "○ حالت دمو") : "..."}
        </span>
      </div>

      {status && (
        <p className="rounded-2xl border border-white/5 bg-white/[0.02] px-4 py-3 text-xs text-slate-400">
          {status.message}
        </p>
      )}

      {/* Search */}
      <form onSubmit={search} className="flex gap-2">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder={`جستجو در ${label}...`}
          className="flex-1 rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm outline-none placeholder:text-slate-500 focus:border-white/25"
        />
        <button
          type="submit"
          disabled={searching}
          className="rounded-2xl px-5 py-3 text-sm font-bold text-white disabled:opacity-60"
          style={{ background: accent }}
        >
          {searching ? "..." : "جستجو"}
        </button>
      </form>

      {/* Results */}
      {results !== null && (
        <section className="animate-fade-up rounded-3xl border border-white/10 bg-white/[0.02] p-4">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-lg font-bold">نتیجهٔ جستجو</h3>
            <button
              onClick={() => {
                setResults(null);
                setQ("");
              }}
              className="text-xs text-slate-400 hover:text-slate-200"
            >
              بستن ✕
            </button>
          </div>
          {results.length === 0 ? (
            <p className="py-6 text-center text-sm text-slate-500">نتیجه‌ای یافت نشد.</p>
          ) : (
            <div className="grid gap-2">
              {results.map((it) => (
                <MediaCard key={it.externalId} item={it} onSaved={onSaved} />
              ))}
            </div>
          )}
        </section>
      )}

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Recent */}
        <section className="rounded-3xl border border-white/10 bg-white/[0.02] p-4">
          <h3 className="mb-3 text-lg font-bold">
            {isSpotify ? "اخیراً پخش‌شده" : "پرطرفدار / اخیر"}
          </h3>
          {loading ? (
            <p className="py-6 text-center text-sm text-slate-500">در حال بارگذاری...</p>
          ) : (
            <div className="grid max-h-[520px] gap-2 overflow-y-auto pl-1">
              {recent.map((it) => (
                <MediaCard key={it.externalId} item={it} onSaved={onSaved} />
              ))}
            </div>
          )}
        </section>

        {/* Playlists */}
        <section className="rounded-3xl border border-white/10 bg-white/[0.02] p-4">
          <h3 className="mb-3 text-lg font-bold">پلی‌لیست‌ها</h3>
          {loading ? (
            <p className="py-6 text-center text-sm text-slate-500">در حال بارگذاری...</p>
          ) : (
            <div className="grid max-h-[520px] gap-2 overflow-y-auto pl-1">
              {playlists.map((it) => (
                <MediaCard key={it.externalId} item={it} onSaved={onSaved} />
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
