"use client";

import { useState } from "react";
import type { MediaItem } from "@/lib/types";

const kindLabel: Record<string, string> = {
  track: "آهنگ",
  video: "ویدیو",
  playlist: "پلی‌لیست",
  album: "آلبوم",
};

export function MediaCard({
  item,
  onSaved,
}: {
  item: MediaItem;
  onSaved?: () => void;
}) {
  const [state, setState] = useState<"idle" | "saving" | "done">("idle");

  async function save() {
    setState("saving");
    try {
      const res = await fetch("/api/life", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(item),
      });
      if (!res.ok) throw new Error();
      setState("done");
      onSaved?.();
      setTimeout(() => setState("idle"), 2000);
    } catch {
      setState("idle");
    }
  }

  const accent = item.provider === "spotify" ? "#1DB954" : "#FF0000";

  return (
    <div className="group flex items-center gap-3 rounded-2xl border border-white/5 bg-white/[0.03] p-3 transition hover:border-white/15 hover:bg-white/[0.06]">
      <div
        className="grid h-14 w-14 shrink-0 place-items-center overflow-hidden rounded-xl"
        style={{ background: `${accent}22` }}
      >
        {item.thumbnail ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={item.thumbnail} alt="" className="h-full w-full object-cover" />
        ) : (
          <span style={{ color: accent }}>{item.kind === "playlist" ? "≡" : "♪"}</span>
        )}
      </div>

      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span
            className="rounded-full px-2 py-0.5 text-[10px] font-semibold"
            style={{ background: `${accent}22`, color: accent }}
          >
            {kindLabel[item.kind] ?? item.kind}
          </span>
          <p className="truncate font-semibold text-slate-100">{item.title}</p>
        </div>
        {item.subtitle && (
          <p className="mt-0.5 truncate text-xs text-slate-400">{item.subtitle}</p>
        )}
      </div>

      <div className="flex shrink-0 items-center gap-2">
        {item.url && (
          <a
            href={item.url}
            target="_blank"
            rel="noreferrer"
            className="rounded-lg border border-white/10 px-3 py-1.5 text-xs text-slate-300 transition hover:bg-white/10"
          >
            پخش ▶
          </a>
        )}
        <button
          onClick={save}
          disabled={state !== "idle"}
          className="rounded-lg px-3 py-1.5 text-xs font-semibold text-white transition disabled:opacity-70"
          style={{ background: state === "done" ? "#16a34a" : accent }}
        >
          {state === "saving" ? "..." : state === "done" ? "ثبت شد ✓" : "ثبت در LifeOS"}
        </button>
      </div>
    </div>
  );
}
