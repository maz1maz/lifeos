"use client";

import { useEffect, useState, useCallback } from "react";
import type { LifeEvent } from "@/db/schema";

const kindLabel: Record<string, string> = {
  track: "آهنگ",
  video: "ویدیو",
  playlist: "پلی‌لیست",
  album: "آلبوم",
};

export function LifePanel({ refreshKey }: { refreshKey: number }) {
  const [items, setItems] = useState<LifeEvent[]>([]);
  const [filter, setFilter] = useState<"all" | "spotify" | "youtube">("all");
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const qs = filter === "all" ? "" : `?provider=${filter}`;
      const res = await fetch(`/api/life${qs}`);
      const data = await res.json();
      setItems(data.items ?? []);
    } finally {
      setLoading(false);
    }
  }, [filter]);

  useEffect(() => {
    load();
  }, [load, refreshKey]);

  async function remove(id: number) {
    await fetch(`/api/life?id=${id}`, { method: "DELETE" });
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  const spotifyCount = items.filter((i) => i.provider === "spotify").length;
  const youtubeCount = items.filter((i) => i.provider === "youtube").length;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-3">
        <Stat label="کل ثبت‌ها" value={items.length} color="#38bdf8" />
        <Stat label="Spotify" value={spotifyCount} color="#1DB954" />
        <Stat label="YouTube" value={youtubeCount} color="#FF0000" />
      </div>

      <div className="flex gap-2">
        {(["all", "spotify", "youtube"] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-xl px-4 py-2 text-sm font-semibold transition ${
              filter === f
                ? "bg-white/15 text-white"
                : "border border-white/10 text-slate-400 hover:bg-white/5"
            }`}
          >
            {f === "all" ? "همه" : f === "spotify" ? "Spotify" : "YouTube"}
          </button>
        ))}
      </div>

      <section className="rounded-3xl border border-white/10 bg-white/[0.02] p-4">
        <h3 className="mb-3 text-lg font-bold">تاریخچهٔ شخصی من (LifeOS)</h3>
        {loading ? (
          <p className="py-8 text-center text-sm text-slate-500">در حال بارگذاری...</p>
        ) : items.length === 0 ? (
          <p className="py-8 text-center text-sm text-slate-500">
            هنوز چیزی ثبت نشده. از تب‌های Spotify یا YouTube روی «ثبت در LifeOS» بزنید.
          </p>
        ) : (
          <div className="grid gap-2">
            {items.map((it) => {
              const accent = it.provider === "spotify" ? "#1DB954" : "#FF0000";
              return (
                <div
                  key={it.id}
                  className="flex items-center gap-3 rounded-2xl border border-white/5 bg-white/[0.03] p-3"
                >
                  <div
                    className="grid h-12 w-12 shrink-0 place-items-center overflow-hidden rounded-xl"
                    style={{ background: `${accent}22` }}
                  >
                    {it.thumbnail ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={it.thumbnail} alt="" className="h-full w-full object-cover" />
                    ) : (
                      <span style={{ color: accent }}>♪</span>
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span
                        className="rounded-full px-2 py-0.5 text-[10px] font-semibold"
                        style={{ background: `${accent}22`, color: accent }}
                      >
                        {kindLabel[it.kind] ?? it.kind}
                      </span>
                      <p className="truncate font-semibold">{it.title}</p>
                    </div>
                    {it.subtitle && (
                      <p className="mt-0.5 truncate text-xs text-slate-400">{it.subtitle}</p>
                    )}
                    <p className="mt-0.5 text-[10px] text-slate-500">
                      {new Date(it.createdAt).toLocaleString("fa-IR")}
                    </p>
                  </div>
                  <div className="flex shrink-0 gap-2">
                    {it.url && (
                      <a
                        href={it.url}
                        target="_blank"
                        rel="noreferrer"
                        className="rounded-lg border border-white/10 px-3 py-1.5 text-xs text-slate-300 hover:bg-white/10"
                      >
                        باز کردن
                      </a>
                    )}
                    <button
                      onClick={() => remove(it.id)}
                      className="rounded-lg border border-red-500/30 px-3 py-1.5 text-xs text-red-300 hover:bg-red-500/10"
                    >
                      حذف
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}

function Stat({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div
      className="rounded-2xl border border-white/10 p-4"
      style={{ background: `linear-gradient(135deg, ${color}18, transparent)` }}
    >
      <p className="text-3xl font-black" style={{ color }}>
        {value}
      </p>
      <p className="mt-1 text-xs text-slate-400">{label}</p>
    </div>
  );
}
