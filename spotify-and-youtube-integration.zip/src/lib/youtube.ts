import type { MediaItem, ProviderStatus } from "./types";
import { youtubeRecent, youtubePlaylists, demoSearch } from "./demoData";

// YouTube Data API v3 با API Key عمومی برای جستجو/پلی‌لیست کار می‌کند.
const apiKey = () => process.env.YOUTUBE_API_KEY?.trim();

export function youtubeStatus(): ProviderStatus {
  if (apiKey()) {
    return { connected: true, demo: false, message: "به YouTube API متصل است." };
  }
  return {
    connected: false,
    demo: true,
    message: "حالت دمو — برای اتصال واقعی، YOUTUBE_API_KEY را تنظیم کنید.",
  };
}

async function yfetch(path: string) {
  const sep = path.includes("?") ? "&" : "?";
  const res = await fetch(`https://www.googleapis.com/youtube/v3${path}${sep}key=${apiKey()}`, {
    cache: "no-store",
  });
  if (!res.ok) throw new Error(`YouTube API ${res.status}`);
  return res.json();
}

const thumbOf = (t?: any) => t?.medium?.url ?? t?.default?.url;

export async function youtubeRecentlyWatched(): Promise<MediaItem[]> {
  // تاریخچهٔ تماشا از طریق API عمومی در دسترس نیست؛ پرطرفدارها را نشان می‌دهیم.
  if (!apiKey()) return youtubeRecent;
  try {
    const data = await yfetch(
      "/videos?part=snippet&chart=mostPopular&maxResults=20&regionCode=US",
    );
    return (data.items ?? []).map((v: any) => ({
      provider: "youtube" as const,
      kind: "video" as const,
      externalId: v.id,
      title: v.snippet.title,
      subtitle: v.snippet.channelTitle,
      url: `https://www.youtube.com/watch?v=${v.id}`,
      thumbnail: thumbOf(v.snippet.thumbnails),
    }));
  } catch {
    return youtubeRecent;
  }
}

export async function youtubeUserPlaylists(): Promise<MediaItem[]> {
  return youtubePlaylists;
}

export async function youtubeSearch(q: string): Promise<MediaItem[]> {
  if (!apiKey()) return demoSearch("youtube", q);
  try {
    const data = await yfetch(
      `/search?part=snippet&type=video&maxResults=12&q=${encodeURIComponent(q)}`,
    );
    return (data.items ?? []).map((v: any) => ({
      provider: "youtube" as const,
      kind: "video" as const,
      externalId: v.id?.videoId,
      title: v.snippet.title,
      subtitle: v.snippet.channelTitle,
      url: `https://www.youtube.com/watch?v=${v.id?.videoId}`,
      thumbnail: thumbOf(v.snippet.thumbnails),
    }));
  } catch {
    return demoSearch("youtube", q);
  }
}
