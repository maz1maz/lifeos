export type Provider = "spotify" | "youtube";
export type MediaKind = "track" | "video" | "playlist" | "album";

export interface MediaItem {
  provider: Provider;
  kind: MediaKind;
  externalId: string;
  title: string;
  subtitle?: string;
  url?: string;
  thumbnail?: string;
  meta?: Record<string, unknown>;
}

export interface ProviderStatus {
  connected: boolean;
  demo: boolean;
  message: string;
}
