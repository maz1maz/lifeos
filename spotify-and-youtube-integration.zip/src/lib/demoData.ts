import type { MediaItem } from "./types";

const img = (seed: string, color: string) =>
  `data:image/svg+xml;utf8,${encodeURIComponent(
    `<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='${color}'/><stop offset='1' stop-color='#0b1220'/></linearGradient></defs><rect width='120' height='120' rx='14' fill='url(#g)'/><text x='60' y='70' font-size='44' text-anchor='middle' fill='white' font-family='sans-serif'>${seed}</text></svg>`,
  )}`;

export const spotifyRecent: MediaItem[] = [
  { provider: "spotify", kind: "track", externalId: "s1", title: "Elaheh Naaz", subtitle: "Moein · Moein", url: "https://open.spotify.com", thumbnail: img("♪", "#1DB954") },
  { provider: "spotify", kind: "track", externalId: "s2", title: "Ayeneha (Maskh)", subtitle: "Farhad Mehrad · Mard-E Tanha", url: "https://open.spotify.com", thumbnail: img("♪", "#1DB954") },
  { provider: "spotify", kind: "track", externalId: "s3", title: "Gol Vajeh", subtitle: "Hayedeh · Gol Vajeh", url: "https://open.spotify.com", thumbnail: img("♪", "#1DB954") },
  { provider: "spotify", kind: "track", externalId: "s4", title: "Saghi", subtitle: "Elaheh · Saghi", url: "https://open.spotify.com", thumbnail: img("♪", "#1DB954") },
  { provider: "spotify", kind: "track", externalId: "s5", title: "Farangis", subtitle: "Siavash Ghomayshi · Farangis", url: "https://open.spotify.com", thumbnail: img("♪", "#1DB954") },
  { provider: "spotify", kind: "track", externalId: "s6", title: "Divar", subtitle: "Faramarz Aslani · Age Yeh Rooz", url: "https://open.spotify.com", thumbnail: img("♪", "#1DB954") },
];

export const spotifyPlaylists: MediaItem[] = [
  { provider: "spotify", kind: "playlist", externalId: "p1", title: "Persian Chill", subtitle: "۳۴ آهنگ", url: "https://open.spotify.com", thumbnail: img("≡", "#1DB954") },
  { provider: "spotify", kind: "playlist", externalId: "p2", title: "Focus Flow", subtitle: "۵۸ آهنگ", url: "https://open.spotify.com", thumbnail: img("≡", "#1DB954") },
  { provider: "spotify", kind: "playlist", externalId: "p3", title: "Nostalgia 80s", subtitle: "۲۱ آهنگ", url: "https://open.spotify.com", thumbnail: img("≡", "#1DB954") },
];

export const youtubeRecent: MediaItem[] = [
  { provider: "youtube", kind: "video", externalId: "y1", title: "How the Web Actually Works", subtitle: "Fireship", url: "https://youtube.com", thumbnail: img("▶", "#FF0000") },
  { provider: "youtube", kind: "video", externalId: "y2", title: "A Deep Dive into Postgres", subtitle: "Hussein Nasser", url: "https://youtube.com", thumbnail: img("▶", "#FF0000") },
  { provider: "youtube", kind: "video", externalId: "y3", title: "Lofi Beats to Code To", subtitle: "Chillhop Music", url: "https://youtube.com", thumbnail: img("▶", "#FF0000") },
  { provider: "youtube", kind: "video", externalId: "y4", title: "Next.js 15 Full Course", subtitle: "Traversy Media", url: "https://youtube.com", thumbnail: img("▶", "#FF0000") },
  { provider: "youtube", kind: "video", externalId: "y5", title: "The Art of Simplicity", subtitle: "The Futur", url: "https://youtube.com", thumbnail: img("▶", "#FF0000") },
  { provider: "youtube", kind: "video", externalId: "y6", title: "Documentary: The Universe", subtitle: "PBS Space Time", url: "https://youtube.com", thumbnail: img("▶", "#FF0000") },
];

export const youtubePlaylists: MediaItem[] = [
  { provider: "youtube", kind: "playlist", externalId: "yp1", title: "Watch Later", subtitle: "۱۲ ویدیو", url: "https://youtube.com", thumbnail: img("≡", "#FF0000") },
  { provider: "youtube", kind: "playlist", externalId: "yp2", title: "Programming", subtitle: "۴۵ ویدیو", url: "https://youtube.com", thumbnail: img("≡", "#FF0000") },
  { provider: "youtube", kind: "playlist", externalId: "yp3", title: "Music Mix", subtitle: "۸۹ ویدیو", url: "https://youtube.com", thumbnail: img("≡", "#FF0000") },
];

export function demoSearch(provider: "spotify" | "youtube", q: string): MediaItem[] {
  const base = provider === "spotify" ? spotifyRecent : youtubeRecent;
  const kind = provider === "spotify" ? "track" : "video";
  const color = provider === "spotify" ? "#1DB954" : "#FF0000";
  const icon = provider === "spotify" ? "♪" : "▶";
  return Array.from({ length: 6 }).map((_, i) => ({
    provider,
    kind: kind as MediaItem["kind"],
    externalId: `${provider}-q-${i}`,
    title: `${q} — نتیجهٔ ${i + 1}`,
    subtitle: base[i % base.length].subtitle,
    url: base[i % base.length].url,
    thumbnail: img(icon, color),
  }));
}
