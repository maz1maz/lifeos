import type { MediaItem, ProviderStatus } from "./types";
import { spotifyRecent, spotifyPlaylists, demoSearch } from "./demoData";

// اگر توکن دسترسی واقعی کاربر در env تنظیم شده باشد از API واقعی استفاده می‌کنیم،
// در غیر این‌صورت دادهٔ دمو برمی‌گردانیم تا سایت همیشه کار کند (رفع خطای Bad Request).
const token = () => process.env.SPOTIFY_ACCESS_TOKEN?.trim();

export function spotifyStatus(): ProviderStatus {
  if (token()) {
    return { connected: true, demo: false, message: "به حساب Spotify متصل است." };
  }
  return {
    connected: false,
    demo: true,
    message: "حالت دمو — برای اتصال واقعی، SPOTIFY_ACCESS_TOKEN را تنظیم کنید.",
  };
}

async function sfetch(path: string) {
  const res = await fetch(`https://api.spotify.com/v1${path}`, {
    headers: { Authorization: `Bearer ${token()}` },
    cache: "no-store",
  });
  if (!res.ok) throw new Error(`Spotify API ${res.status}`);
  return res.json();
}

const thumbOf = (images?: { url: string }[]) => images?.[0]?.url;

export async function spotifyRecentlyPlayed(): Promise<MediaItem[]> {
  if (!token()) return spotifyRecent;
  try {
    const data = await sfetch("/me/player/recently-played?limit=20");
    return (data.items ?? []).map((it: any) => ({
      provider: "spotify" as const,
      kind: "track" as const,
      externalId: it.track.id,
      title: it.track.name,
      subtitle: `${it.track.artists?.map((a: any) => a.name).join(", ")} · ${it.track.album?.name ?? ""}`,
      url: it.track.external_urls?.spotify,
      thumbnail: thumbOf(it.track.album?.images),
    }));
  } catch {
    return spotifyRecent;
  }
}

export async function spotifyUserPlaylists(): Promise<MediaItem[]> {
  if (!token()) return spotifyPlaylists;
  try {
    const data = await sfetch("/me/playlists?limit=30");
    return (data.items ?? []).map((p: any) => ({
      provider: "spotify" as const,
      kind: "playlist" as const,
      externalId: p.id,
      title: p.name,
      subtitle: `${p.tracks?.total ?? 0} آهنگ`,
      url: p.external_urls?.spotify,
      thumbnail: thumbOf(p.images),
    }));
  } catch {
    return spotifyPlaylists;
  }
}

export async function spotifySearch(q: string): Promise<MediaItem[]> {
  if (!token()) return demoSearch("spotify", q);
  try {
    const data = await sfetch(`/search?type=track&limit=12&q=${encodeURIComponent(q)}`);
    return (data.tracks?.items ?? []).map((t: any) => ({
      provider: "spotify" as const,
      kind: "track" as const,
      externalId: t.id,
      title: t.name,
      subtitle: `${t.artists?.map((a: any) => a.name).join(", ")} · ${t.album?.name ?? ""}`,
      url: t.external_urls?.spotify,
      thumbnail: thumbOf(t.album?.images),
    }));
  } catch {
    return demoSearch("spotify", q);
  }
}
