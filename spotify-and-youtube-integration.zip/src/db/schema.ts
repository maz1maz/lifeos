import {
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
  jsonb,
  index,
} from "drizzle-orm/pg-core";

// یکپارچه‌سازی تاریخچهٔ شخصی رسانه (LifeOS)
export const lifeEvents = pgTable(
  "life_events",
  {
    id: serial("id").primaryKey(),
    provider: varchar("provider", { length: 32 }).notNull(), // spotify | youtube
    kind: varchar("kind", { length: 32 }).notNull(), // track | video | playlist | album
    externalId: varchar("external_id", { length: 128 }).notNull(),
    title: text("title").notNull(),
    subtitle: text("subtitle"),
    url: text("url"),
    thumbnail: text("thumbnail"),
    note: text("note"),
    metadata: jsonb("metadata"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => ({
    providerIdx: index("life_events_provider_idx").on(t.provider),
    createdIdx: index("life_events_created_idx").on(t.createdAt),
  }),
);

export type LifeEvent = typeof lifeEvents.$inferSelect;
export type NewLifeEvent = typeof lifeEvents.$inferInsert;
