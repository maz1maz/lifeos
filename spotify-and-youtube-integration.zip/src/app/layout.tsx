import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "مرکز رسانه — LifeOS",
  description: "مدیریت یکپارچهٔ Spotify و YouTube: جستجو، پخش/دیده‌شده، پلی‌لیست و تاریخچهٔ شخصی.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body className="min-h-screen bg-[#060b16] text-slate-100 antialiased">{children}</body>
    </html>
  );
}
