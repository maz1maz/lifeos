import { NextRequest, NextResponse } from "next/server";
import {
  spotifyStatus,
  spotifyRecentlyPlayed,
  spotifyUserPlaylists,
  spotifySearch,
} from "@/lib/spotify";
import {
  youtubeStatus,
  youtubeRecentlyWatched,
  youtubeUserPlaylists,
  youtubeSearch,
} from "@/lib/youtube";

export const dynamic = "force-dynamic";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ provider: string }> },
) {
  const { provider } = await params;
  const url = new URL(req.url);
  const q = url.searchParams.get("q")?.trim() ?? "";

  try {
    if (provider === "spotify") {
      if (q) return NextResponse.json({ status: spotifyStatus(), items: await spotifySearch(q) });
      const [recent, playlists] = await Promise.all([
        spotifyRecentlyPlayed(),
        spotifyUserPlaylists(),
      ]);
      return NextResponse.json({ status: spotifyStatus(), recent, playlists });
    }

    if (provider === "youtube") {
      if (q) return NextResponse.json({ status: youtubeStatus(), items: await youtubeSearch(q) });
      const [recent, playlists] = await Promise.all([
        youtubeRecentlyWatched(),
        youtubeUserPlaylists(),
      ]);
      return NextResponse.json({ status: youtubeStatus(), recent, playlists });
    }

    return NextResponse.json({ error: "provider نامعتبر است" }, { status: 400 });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "خطای ناشناخته" },
      { status: 500 },
    );
  }
}
