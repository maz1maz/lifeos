import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { lifeEvents } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const provider = new URL(req.url).searchParams.get("provider");
  const base = db.select().from(lifeEvents).orderBy(desc(lifeEvents.createdAt)).limit(100);
  const rows =
    provider === "spotify" || provider === "youtube"
      ? await db
          .select()
          .from(lifeEvents)
          .where(eq(lifeEvents.provider, provider))
          .orderBy(desc(lifeEvents.createdAt))
          .limit(100)
      : await base;
  return NextResponse.json({ items: rows });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { provider, kind, externalId, title, subtitle, url, thumbnail, note, metadata } = body;
    if (!provider || !kind || !title) {
      return NextResponse.json({ error: "اطلاعات ناقص است" }, { status: 400 });
    }
    const [row] = await db
      .insert(lifeEvents)
      .values({
        provider,
        kind,
        externalId: externalId ?? "",
        title,
        subtitle: subtitle ?? null,
        url: url ?? null,
        thumbnail: thumbnail ?? null,
        note: note ?? null,
        metadata: metadata ?? null,
      })
      .returning();
    return NextResponse.json({ item: row });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "خطا در ثبت" },
      { status: 500 },
    );
  }
}

export async function DELETE(req: NextRequest) {
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "id لازم است" }, { status: 400 });
  await db.delete(lifeEvents).where(eq(lifeEvents.id, id));
  return NextResponse.json({ ok: true });
}
