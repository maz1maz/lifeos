import { db } from "@/db";
import { contacts } from "@/db/schema";
import { demoContacts } from "@/lib/contacts";

export async function ensureDemoContacts() {
  const existing = await db.select({ id: contacts.id }).from(contacts).limit(1);
  if (existing.length > 0) return { seeded: false };
  const rows = demoContacts();
  await db.insert(contacts).values(rows);
  return { seeded: true, count: rows.length };
}

export async function resetDemoContacts() {
  await db.delete(contacts);
  const rows = demoContacts();
  await db.insert(contacts).values(rows);
  return { count: rows.length };
}
