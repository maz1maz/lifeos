export const RELATIONSHIPS = [
  { value: "friend", label: "دوست" },
  { value: "family", label: "خانواده" },
  { value: "colleague", label: "همکار" },
  { value: "client", label: "مشتری" },
  { value: "acquaintance", label: "آشنا" },
  { value: "other", label: "سایر" },
] as const;

export type RelationshipValue = (typeof RELATIONSHIPS)[number]["value"];

export type ContactDTO = {
  id: number;
  name: string;
  relationship: string;
  phones: string;
  email: string;
  telegram: string;
  website: string;
  company: string;
  address: string;
  birthday: string;
  reminderDate: string;
  notes: string;
  tags: string;
  favorite: boolean;
  createdAt: string;
  updatedAt: string;
};

export type ContactInput = {
  name: string;
  relationship: string;
  phones: string;
  email: string;
  telegram: string;
  website: string;
  company: string;
  address: string;
  birthday: string;
  reminderDate: string;
  notes: string;
  tags: string;
  favorite: boolean;
};

export const emptyContactForm = (): ContactInput => ({
  name: "",
  relationship: "friend",
  phones: "",
  email: "",
  telegram: "",
  website: "",
  company: "",
  address: "",
  birthday: "",
  reminderDate: "",
  notes: "",
  tags: "",
  favorite: false,
});

export function relationshipLabel(value: string) {
  return RELATIONSHIPS.find((item) => item.value === value)?.label ?? value;
}

export function relationshipTone(value: string) {
  switch (value) {
    case "family":
      return { bar: "#fb7185", glow: "rgba(251,113,133,0.35)" };
    case "colleague":
      return { bar: "#fbbf24", glow: "rgba(251,191,36,0.35)" };
    case "client":
      return { bar: "#34d399", glow: "rgba(52,211,153,0.35)" };
    case "acquaintance":
      return { bar: "#c084fc", glow: "rgba(192,132,252,0.35)" };
    case "other":
      return { bar: "#94a3b8", glow: "rgba(148,163,184,0.35)" };
    default:
      return { bar: "#22d3ee", glow: "rgba(34,211,238,0.35)" };
  }
}

export function toIso(value: Date | string | null | undefined) {
  if (!value) return "";
  if (typeof value === "string") return value;
  return value.toISOString();
}

export function serializeContact(row: {
  id: number;
  name: string;
  relationship: string;
  phones: string;
  email: string;
  telegram: string;
  website: string;
  company: string;
  address: string;
  birthday: string;
  reminderDate: string;
  notes: string;
  tags: string;
  favorite: boolean;
  createdAt: Date | string;
  updatedAt: Date | string;
}): ContactDTO {
  return {
    id: row.id,
    name: row.name,
    relationship: row.relationship,
    phones: row.phones ?? "",
    email: row.email ?? "",
    telegram: row.telegram ?? "",
    website: row.website ?? "",
    company: row.company ?? "",
    address: row.address ?? "",
    birthday: row.birthday ?? "",
    reminderDate: row.reminderDate ?? "",
    notes: row.notes ?? "",
    tags: row.tags ?? "",
    favorite: Boolean(row.favorite),
    createdAt: toIso(row.createdAt),
    updatedAt: toIso(row.updatedAt),
  };
}

export function sanitizeQuery(value: string) {
  return value.trim().replace(/[%_]/g, " ").slice(0, 120);
}

export function normalizePhone(value: string) {
  return value.replace(/[^\d+]/g, "");
}

export function splitPhones(value: string) {
  return value
    .split(/[,،\n|/]+/)
    .map((part) => part.trim())
    .filter(Boolean);
}

export function contactToPayload(input: Partial<ContactInput>): ContactInput {
  const base = emptyContactForm();
  return {
    name: (input.name ?? base.name).trim(),
    relationship: input.relationship?.trim() || "friend",
    phones: (input.phones ?? "").trim(),
    email: (input.email ?? "").trim(),
    telegram: (input.telegram ?? "").trim(),
    website: (input.website ?? "").trim(),
    company: (input.company ?? "").trim(),
    address: (input.address ?? "").trim(),
    birthday: (input.birthday ?? "").trim(),
    reminderDate: (input.reminderDate ?? "").trim(),
    notes: (input.notes ?? "").trim(),
    tags: (input.tags ?? "").trim(),
    favorite: Boolean(input.favorite),
  };
}

export function isBirthdayThisMonth(birthday: string) {
  if (!birthday || birthday.length < 7) return false;
  const month = birthday.slice(5, 7);
  const now = String(new Date().getMonth() + 1).padStart(2, "0");
  return month === now;
}

export function formatFaDate(iso: string) {
  if (!iso) return "";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return new Intl.DateTimeFormat("fa-IR", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(date);
}

export function formatShortDate(value: string) {
  if (!value) return "";
  const [year, month, day] = value.split("-");
  if (!year || !month || !day) return value;
  return `${year}/${month}/${day}`;
}

export function csvEscape(value: string) {
  if (/[",\n]/.test(value)) return `"${value.replace(/"/g, '""')}"`;
  return value;
}

export const CSV_HEADERS = [
  "name",
  "relationship",
  "phones",
  "email",
  "telegram",
  "website",
  "company",
  "address",
  "birthday",
  "reminderDate",
  "notes",
  "tags",
  "favorite",
] as const;

export function contactsToCsv(rows: ContactDTO[]) {
  const header = CSV_HEADERS.join(",");
  const body = rows
    .map((row) =>
      [
        row.name,
        row.relationship,
        row.phones,
        row.email,
        row.telegram,
        row.website,
        row.company,
        row.address,
        row.birthday,
        row.reminderDate,
        row.notes,
        row.tags,
        row.favorite ? "true" : "false",
      ]
        .map((value) => csvEscape(String(value ?? "")))
        .join(","),
    )
    .join("\n");
  return `${header}\n${body}\n`;
}

function parseCsvLine(line: string) {
  const out: string[] = [];
  let current = "";
  let quoted = false;
  for (let i = 0; i < line.length; i += 1) {
    const ch = line[i];
    if (quoted) {
      if (ch === '"' && line[i + 1] === '"') {
        current += '"';
        i += 1;
      } else if (ch === '"') {
        quoted = false;
      } else {
        current += ch;
      }
    } else if (ch === '"') {
      quoted = true;
    } else if (ch === ",") {
      out.push(current);
      current = "";
    } else {
      current += ch;
    }
  }
  out.push(current);
  return out;
}

export function parseContactsCsv(text: string): ContactInput[] {
  const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/).filter((line) => line.trim());
  if (lines.length < 2) return [];
  const headers = parseCsvLine(lines[0]).map((h) => h.trim());
  return lines.slice(1).map((line) => {
    const cols = parseCsvLine(line);
    const rec: Record<string, string> = {};
    headers.forEach((key, index) => {
      rec[key] = cols[index] ?? "";
    });
    return contactToPayload({
      name: rec.name || rec["نام"] || "",
      relationship: rec.relationship || "friend",
      phones: rec.phones || rec.phone || rec["تلفن"] || "",
      email: rec.email || rec["ایمیل"] || "",
      telegram: rec.telegram || "",
      website: rec.website || "",
      company: rec.company || "",
      address: rec.address || "",
      birthday: rec.birthday || "",
      reminderDate: rec.reminderDate || rec.reminder_date || "",
      notes: rec.notes || "",
      tags: rec.tags || "",
      favorite: rec.favorite === "true" || rec.favorite === "1",
    });
  }).filter((row) => row.name);
}

export function parseImportPayload(raw: unknown): ContactInput[] {
  if (Array.isArray(raw)) {
    return raw
      .map((item) => contactToPayload((item ?? {}) as Partial<ContactInput>))
      .filter((row) => row.name);
  }
  if (raw && typeof raw === "object" && Array.isArray((raw as { contacts?: unknown }).contacts)) {
    return parseImportPayload((raw as { contacts: unknown[] }).contacts);
  }
  return [];
}

export function downloadBlob(filename: string, content: string, mime: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

export function telegramHref(value: string) {
  const trimmed = value.trim();
  if (!trimmed) return "";
  if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) return trimmed;
  if (trimmed.startsWith("t.me/")) return `https://${trimmed}`;
  if (trimmed.startsWith("@")) return `https://t.me/${trimmed.slice(1)}`;
  return `https://t.me/${trimmed.replace(/^\/+/, "")}`;
}

export function websiteHref(value: string) {
  const trimmed = value.trim();
  if (!trimmed) return "";
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  return `https://${trimmed}`;
}

export function firstPhone(value: string) {
  return splitPhones(value)[0] ?? "";
}

export function matchesQuery(contact: ContactDTO, query: string) {
  const q = query.trim().toLowerCase();
  if (!q) return true;
  const hay = [
    contact.name,
    contact.phones,
    contact.email,
    contact.telegram,
    contact.notes,
    contact.company,
    contact.address,
    contact.tags,
    contact.website,
    relationshipLabel(contact.relationship),
    contact.relationship,
  ]
    .join(" ")
    .toLowerCase();
  return hay.includes(q);
}

export function demoContacts(): ContactInput[] {
  const month = String(new Date().getMonth() + 1).padStart(2, "0");
  return [
    {
      name: "88",
      relationship: "friend",
      phones: "+98 905 436 2088",
      email: "",
      telegram: "https://t.me/id1133702832",
      website: "",
      company: "",
      address: "",
      birthday: `1996-${month}-08`,
      reminderDate: "",
      notes: "مخاطب اولیه LifeOS",
      tags: "telegram",
      favorite: true,
    },
    {
      name: "امید ستوده Sony",
      relationship: "friend",
      phones: "0912 609 2898",
      email: "omid.sotoudeh@example.com",
      telegram: "",
      website: "",
      company: "Sony",
      address: "تهران",
      birthday: "1991-11-02",
      reminderDate: "",
      notes: "",
      tags: "tech",
      favorite: false,
    },
    {
      name: "رسول مقدم",
      relationship: "friend",
      phones: "+989121576678",
      email: "",
      telegram: "",
      website: "",
      company: "",
      address: "",
      birthday: `1988-${month}-21`,
      reminderDate: "",
      notes: "",
      tags: "",
      favorite: false,
    },
    {
      name: "رضا",
      relationship: "friend",
      phones: "+989128081955, +989354598374",
      email: "",
      telegram: "",
      website: "",
      company: "",
      address: "",
      birthday: "",
      reminderDate: "",
      notes: "دو شماره فعال",
      tags: "",
      favorite: true,
    },
    {
      name: "رهپویان (تور و بلیط لحظه آخری) Rahpouyan",
      relationship: "client",
      phones: "+989374665553",
      email: "info@rahpouyan.ir",
      telegram: "",
      website: "rahpouyan.ir",
      company: "رهپویان",
      address: "",
      birthday: "",
      reminderDate: "",
      notes: "تور و بلیط لحظه آخری",
      tags: "سفر, بلیط",
      favorite: false,
    },
    {
      name: "مجید نعیمیانی ماهواره نوشهر",
      relationship: "client",
      phones: "+989115406054",
      email: "",
      telegram: "",
      website: "",
      company: "ماهواره نوشهر",
      address: "نوشهر",
      birthday: "",
      reminderDate: "",
      notes: "",
      tags: "کسب‌وکار",
      favorite: false,
    },
    {
      name: "محبوبه وفایی مستاجر یافت آباد",
      relationship: "acquaintance",
      phones: "+989196334665",
      email: "",
      telegram: "",
      website: "",
      company: "",
      address: "یافت‌آباد، تهران",
      birthday: "1994-03-12",
      reminderDate: "",
      notes: "مستاجر",
      tags: "",
      favorite: false,
    },
    {
      name: "Abbas Palash",
      relationship: "friend",
      phones: "+98 938 595 7213",
      email: "abbas.palash@example.com",
      telegram: "",
      website: "",
      company: "",
      address: "",
      birthday: "1985-07-19",
      reminderDate: "",
      notes: "",
      tags: "",
      favorite: false,
    },
    {
      name: "سارا محمدی",
      relationship: "family",
      phones: "+98 912 111 2233",
      email: "sara.mohammadi@example.com",
      telegram: "@sara_m",
      website: "",
      company: "",
      address: "اصفهان",
      birthday: `1993-${month}-04`,
      reminderDate: "",
      notes: "خواهرزاده",
      tags: "خانواده",
      favorite: true,
    },
    {
      name: "علی رضایی",
      relationship: "colleague",
      phones: "021-88776655, +989121234567",
      email: "ali.rezaei@novatech.ir",
      telegram: "",
      website: "",
      company: "نوا تک",
      address: "ونک، تهران",
      birthday: "1987-01-30",
      reminderDate: "",
      notes: "همکار محصول",
      tags: "کار",
      favorite: false,
    },
    {
      name: "دکتر نوری",
      relationship: "acquaintance",
      phones: "+98 913 555 0190",
      email: "",
      telegram: "",
      website: "",
      company: "کلینیک نور",
      address: "شیراز",
      birthday: "",
      reminderDate: "",
      notes: "دندانپزشک",
      tags: "پزشکی",
      favorite: false,
    },
    {
      name: "مریم کاظمی",
      relationship: "colleague",
      phones: "+989366002211",
      email: "maryam.kazemi@example.com",
      telegram: "@maryamk",
      website: "",
      company: "استودیو بامداد",
      address: "تهران",
      birthday: "1990-09-09",
      reminderDate: "",
      notes: "طراح رابط کاربری",
      tags: "طراحی",
      favorite: true,
    },
    {
      name: "حسام کرمی",
      relationship: "friend",
      phones: "0935 700 4488",
      email: "",
      telegram: "https://t.me/hesamkarami",
      website: "",
      company: "",
      address: "کرج",
      birthday: "1992-12-01",
      reminderDate: "",
      notes: "کوهنوردی آخر هفته",
      tags: "ورزش",
      favorite: false,
    },
    {
      name: "شرکت آفتاب‌گردان",
      relationship: "client",
      phones: "021-44002020, +989121009900",
      email: "hello@aftabgardan.co",
      telegram: "",
      website: "https://aftabgardan.co",
      company: "آفتاب‌گردان",
      address: "سعادت‌آباد",
      birthday: "",
      reminderDate: "",
      notes: "قرارداد پشتیبانی سالانه",
      tags: "مشتری, قرارداد",
      favorite: true,
    },
    {
      name: "نیلوفر احمدی",
      relationship: "family",
      phones: "+98 916 303 7788",
      email: "niloofar@example.com",
      telegram: "",
      website: "",
      company: "",
      address: "اهواز",
      birthday: "1998-05-17",
      reminderDate: "",
      notes: "",
      tags: "خانواده",
      favorite: false,
    },
    {
      name: "بهروز شاکری",
      relationship: "colleague",
      phones: "+989123009911",
      email: "behrooz@example.com",
      telegram: "",
      website: "",
      company: "پارس‌داده",
      address: "مشهد",
      birthday: "1984-02-25",
      reminderDate: "",
      notes: "مدیر فنی",
      tags: "کار",
      favorite: false,
    },
    {
      name: "گلناز فتحی",
      relationship: "friend",
      phones: "0910 222 3344",
      email: "golnaz.fathi@example.com",
      telegram: "@golnazf",
      website: "",
      company: "",
      address: "رشت",
      birthday: `1995-${month}-28`,
      reminderDate: "",
      notes: "عکاسی",
      tags: "هنر",
      favorite: false,
    },
    {
      name: "کامران یوسفی",
      relationship: "other",
      phones: "+98 21 6655 1212",
      email: "office@yousefi.law",
      telegram: "",
      website: "",
      company: "دفتر حقوقی یوسفی",
      address: "انقلاب، تهران",
      birthday: "",
      reminderDate: "",
      notes: "وکیل قراردادها",
      tags: "حقوقی",
      favorite: false,
    },
  ];
}
