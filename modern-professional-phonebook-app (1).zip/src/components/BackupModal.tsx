"use client";

import { formatFaDate } from "@/lib/contacts";
import { IconDownload, IconShield, IconUpload } from "@/components/ui";

export type BackupRow = {
  id: number;
  label: string;
  contactCount: number;
  createdAt: string;
};

type Props = {
  open: boolean;
  backups: BackupRow[];
  busy: boolean;
  onClose: () => void;
  onCreate: () => void;
  onRestore: (backup: BackupRow) => void;
  onDelete: (backup: BackupRow) => void;
  onDownloadJson: () => void;
  onDownloadCsv: () => void;
  onDownloadBackup: (backup: BackupRow) => void;
  onImportFile: (file: File, mode: "merge" | "replace") => void;
  onResetDemo: () => void;
};

export function BackupModal({
  open,
  backups,
  busy,
  onClose,
  onCreate,
  onRestore,
  onDelete,
  onDownloadJson,
  onDownloadCsv,
  onDownloadBackup,
  onImportFile,
  onResetDemo,
}: Props) {
  if (!open) return null;

  return (
    <div className="modal-backdrop fixed inset-0 z-[60] grid place-items-center px-4 py-8">
      <div className="panel panel-strong max-h-[90vh] w-full max-w-3xl overflow-hidden rounded-[28px]">
        <div className="flex items-center justify-between border-b border-cyan-400/15 px-6 py-5">
          <div>
            <p className="text-sm text-cyan-200/70">امنیت داده</p>
            <h2 className="mt-1 text-2xl font-extrabold">پشتیبان‌گیری و درون‌ریزی</h2>
          </div>
          <button type="button" className="ghost-btn" onClick={onClose}>
            بستن
          </button>
        </div>

        <div className="scroll-thin max-h-[calc(90vh-88px)] overflow-y-auto px-6 py-5">
          <div className="grid gap-3 sm:grid-cols-2">
            <button type="button" className="save-btn flex items-center justify-center gap-2" onClick={onCreate} disabled={busy}>
              <IconShield />
              ایجاد نسخه پشتیبان
            </button>
            <button type="button" className="ghost-btn flex items-center justify-center gap-2" onClick={onDownloadJson} disabled={busy}>
              <IconDownload />
              دانلود JSON
            </button>
            <button type="button" className="ghost-btn flex items-center justify-center gap-2" onClick={onDownloadCsv} disabled={busy}>
              <IconDownload />
              دانلود CSV
            </button>
            <label className="ghost-btn flex cursor-pointer items-center justify-center gap-2">
              <IconUpload />
              درون‌ریزی فایل (ادغام)
              <input
                type="file"
                accept=".json,.csv,application/json,text/csv"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) onImportFile(file, "merge");
                  e.target.value = "";
                }}
              />
            </label>
          </div>

          <p className="mt-4 text-sm leading-7 text-sky-100/65">
            نسخه پشتیبان روی سرور ذخیره می‌شود و هر زمان قابل بازیابی است. فایل JSON یا CSV را هم می‌توانید دانلود
            یا دوباره درون‌ریزی کنید.
          </p>

          <h3 className="mt-6 mb-3 text-lg font-bold">تاریخچه نسخه‌ها</h3>
          {backups.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-cyan-400/20 px-4 py-8 text-center text-sm text-sky-200/60">
              هنوز نسخه پشتیبانی ساخته نشده است.
            </div>
          ) : (
            <div className="space-y-2">
              {backups.map((item) => (
                <div
                  key={item.id}
                  className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-cyan-400/15 bg-black/20 px-4 py-3"
                >
                  <div>
                    <p className="font-semibold">{item.label}</p>
                    <p className="text-xs text-sky-200/60">
                      {item.contactCount} مخاطب · {formatFaDate(item.createdAt)}
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button type="button" className="ghost-btn text-sm" onClick={() => onRestore(item)} disabled={busy}>
                      بازیابی
                    </button>
                    <button type="button" className="ghost-btn text-sm" onClick={() => onDownloadBackup(item)}>
                      دانلود
                    </button>
                    <button type="button" className="ghost-btn text-sm !text-rose-300" onClick={() => onDelete(item)}>
                      حذف
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="mt-8 rounded-2xl border border-rose-400/20 bg-rose-500/5 p-4">
            <p className="font-semibold text-rose-100">منطقه حساس</p>
            <p className="mt-1 text-sm text-rose-100/70">
              بازنشانی، همه مخاطبین فعلی را با داده نمونه LifeOS جایگزین می‌کند.
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <button type="button" className="ghost-btn !border-rose-300/30 !text-rose-200" onClick={onResetDemo}>
                بازنشانی داده نمونه
              </button>
              <label className="ghost-btn !border-rose-300/30 !text-rose-200 cursor-pointer">
                درون‌ریزی با جایگزینی کامل
                <input
                  type="file"
                  accept=".json,.csv,application/json,text/csv"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) onImportFile(file, "replace");
                    e.target.value = "";
                  }}
                />
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
