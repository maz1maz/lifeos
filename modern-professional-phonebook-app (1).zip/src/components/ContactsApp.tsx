"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  contactsToCsv,
  downloadBlob,
  emptyContactForm,
  isBirthdayThisMonth,
  matchesQuery,
  parseContactsCsv,
  parseImportPayload,
  type ContactDTO,
  type ContactInput,
} from "@/lib/contacts";
import { BackupModal, type BackupRow } from "@/components/BackupModal";
import { ContactForm } from "@/components/ContactForm";
import { ContactList } from "@/components/ContactList";
import {
  ConfirmDialog,
  IconCake,
  IconShield,
  IconStar,
  IconUsers,
  Toast,
} from "@/components/ui";

type ConfirmState = {
  title: string;
  message: string;
  confirmLabel?: string;
  danger?: boolean;
  action: () => Promise<void> | void;
};

export function ContactsApp() {
  const [contacts, setContacts] = useState<ContactDTO[]>([]);
  const [backups, setBackups] = useState<BackupRow[]>([]);
  const [form, setForm] = useState<ContactInput>(emptyContactForm());
  const [editingId, setEditingId] = useState<number | null>(null);
  const [showMore, setShowMore] = useState(false);
  const [query, setQuery] = useState("");
  const [relationship, setRelationship] = useState("all");
  const [favOnly, setFavOnly] = useState(false);
  const [sort, setSort] = useState<"new" | "name" | "fav">("new");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [backupOpen, setBackupOpen] = useState(false);
  const [busyBackup, setBusyBackup] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: "ok" | "err" } | null>(null);
  const [confirm, setConfirm] = useState<ConfirmState | null>(null);
  const [mobileTab, setMobileTab] = useState<"list" | "form">("list");
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const notify = useCallback((message: string, type: "ok" | "err" = "ok") => {
    setToast({ message, type });
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2800);
  }, []);

  const loadContacts = useCallback(async () => {
    const res = await fetch("/api/contacts", { cache: "no-store" });
    const data = (await res.json()) as { contacts?: ContactDTO[]; error?: string };
    if (!res.ok) throw new Error(data.error || "خطا در دریافت مخاطبین");
    setContacts(data.contacts ?? []);
  }, []);

  const loadBackups = useCallback(async () => {
    const res = await fetch("/api/backups", { cache: "no-store" });
    const data = (await res.json()) as { backups?: BackupRow[]; error?: string };
    if (!res.ok) throw new Error(data.error || "خطا در دریافت پشتیبان");
    setBackups(data.backups ?? []);
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        await Promise.all([loadContacts(), loadBackups()]);
      } catch (error) {
        if (!cancelled) notify(error instanceof Error ? error.message : "خطای شبکه", "err");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [loadBackups, loadContacts, notify]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        const input = document.querySelector<HTMLInputElement>('input[placeholder^="جستجو"]');
        input?.focus();
      }
      if (event.key === "Escape") {
        setBackupOpen(false);
        setConfirm(null);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const filtered = useMemo(() => {
    const rows = contacts.filter((contact) => {
      if (favOnly && !contact.favorite) return false;
      if (relationship !== "all" && contact.relationship !== relationship) return false;
      return matchesQuery(contact, query);
    });
    const copy = [...rows];
    if (sort === "name") {
      copy.sort((a, b) => a.name.localeCompare(b.name, "fa"));
    } else if (sort === "fav") {
      copy.sort((a, b) => Number(b.favorite) - Number(a.favorite) || a.name.localeCompare(b.name, "fa"));
    }
    return copy;
  }, [contacts, favOnly, query, relationship, sort]);

  const birthdayCount = useMemo(
    () => contacts.filter((c) => isBirthdayThisMonth(c.birthday)).length,
    [contacts],
  );
  const favoriteCount = useMemo(() => contacts.filter((c) => c.favorite).length, [contacts]);

  function patchForm(patch: Partial<ContactInput>) {
    setForm((prev) => ({ ...prev, ...patch }));
  }

  function startEdit(contact: ContactDTO) {
    setEditingId(contact.id);
    setForm({
      name: contact.name,
      relationship: contact.relationship,
      phones: contact.phones,
      email: contact.email,
      telegram: contact.telegram,
      website: contact.website,
      company: contact.company,
      address: contact.address,
      birthday: contact.birthday,
      reminderDate: contact.reminderDate,
      notes: contact.notes,
      tags: contact.tags,
      favorite: contact.favorite,
    });
    setShowMore(
      Boolean(contact.telegram || contact.company || contact.address || contact.website || contact.tags || contact.favorite),
    );
    setMobileTab("form");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function cancelEdit() {
    setEditingId(null);
    setForm(emptyContactForm());
    setShowMore(false);
  }

  async function saveContact() {
    if (!form.name.trim()) {
      notify("نام مخاطب را وارد کنید", "err");
      return;
    }
    setSaving(true);
    try {
      const duplicate = contacts.find((item) => {
        if (editingId && item.id === editingId) return false;
        if (!form.phones.trim()) return false;
        return item.phones.replace(/\s/g, "") === form.phones.replace(/\s/g, "") && item.phones.trim();
      });
      const url = editingId ? `/api/contacts/${editingId}` : "/api/contacts";
      const res = await fetch(url, {
        method: editingId ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = (await res.json()) as { contact?: ContactDTO; error?: string };
      if (!res.ok || !data.contact) throw new Error(data.error || "ذخیره ناموفق بود");
      if (editingId) {
        setContacts((prev) => prev.map((item) => (item.id === data.contact!.id ? data.contact! : item)));
        notify("مخاطب به‌روزرسانی شد");
      } else {
        setContacts((prev) => [data.contact!, ...prev]);
        notify(duplicate ? "ذخیره شد · شماره مشابه وجود دارد" : "مخاطب ذخیره شد");
      }
      cancelEdit();
      setMobileTab("list");
    } catch (error) {
      notify(error instanceof Error ? error.message : "ذخیره ناموفق بود", "err");
    } finally {
      setSaving(false);
    }
  }

  async function toggleFav(contact: ContactDTO) {
    try {
      const res = await fetch(`/api/contacts/${contact.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...contact, favorite: !contact.favorite }),
      });
      const data = (await res.json()) as { contact?: ContactDTO; error?: string };
      if (!res.ok || !data.contact) throw new Error(data.error || "خطا");
      setContacts((prev) => prev.map((item) => (item.id === data.contact!.id ? data.contact! : item)));
    } catch (error) {
      notify(error instanceof Error ? error.message : "خطا در علاقه‌مندی", "err");
    }
  }

  function askDelete(contact: ContactDTO) {
    setConfirm({
      title: "حذف مخاطب",
      message: `«${contact.name}» برای همیشه حذف شود؟`,
      confirmLabel: "حذف",
      danger: true,
      action: async () => {
        const res = await fetch(`/api/contacts/${contact.id}`, { method: "DELETE" });
        const data = (await res.json()) as { error?: string };
        if (!res.ok) throw new Error(data.error || "حذف ناموفق بود");
        setContacts((prev) => prev.filter((item) => item.id !== contact.id));
        if (editingId === contact.id) cancelEdit();
        notify("مخاطب حذف شد");
      },
    });
  }

  async function copyText(value: string) {
    try {
      await navigator.clipboard.writeText(value);
      notify("شماره کپی شد");
    } catch {
      notify("کپی پشتیبانی نشد", "err");
    }
  }

  async function createBackup() {
    setBusyBackup(true);
    try {
      const res = await fetch("/api/backups", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      const data = (await res.json()) as { backup?: BackupRow; error?: string };
      if (!res.ok || !data.backup) throw new Error(data.error || "پشتیبان ساخته نشد");
      setBackups((prev) => [data.backup!, ...prev]);
      notify("نسخه پشتیبان ذخیره شد");
    } catch (error) {
      notify(error instanceof Error ? error.message : "خطا در پشتیبان", "err");
    } finally {
      setBusyBackup(false);
    }
  }

  function restoreBackup(backup: BackupRow) {
    setConfirm({
      title: "بازیابی نسخه پشتیبان",
      message: `مخاطبین فعلی با نسخه «${backup.label}» جایگزین می‌شود.`,
      confirmLabel: "بازیابی",
      danger: true,
      action: async () => {
        setBusyBackup(true);
        try {
          const res = await fetch(`/api/backups/${backup.id}/restore`, { method: "POST" });
          const data = (await res.json()) as { contacts?: ContactDTO[]; error?: string };
          if (!res.ok) throw new Error(data.error || "بازیابی ناموفق بود");
          setContacts(data.contacts ?? []);
          cancelEdit();
          notify("بازیابی انجام شد");
        } finally {
          setBusyBackup(false);
        }
      },
    });
  }

  function deleteBackup(backup: BackupRow) {
    setConfirm({
      title: "حذف نسخه پشتیبان",
      message: `نسخه «${backup.label}» حذف شود؟`,
      confirmLabel: "حذف",
      danger: true,
      action: async () => {
        const res = await fetch(`/api/backups/${backup.id}`, { method: "DELETE" });
        const data = (await res.json()) as { error?: string };
        if (!res.ok) throw new Error(data.error || "حذف ناموفق بود");
        setBackups((prev) => prev.filter((item) => item.id !== backup.id));
        notify("نسخه پشتیبان حذف شد");
      },
    });
  }

  function downloadJson() {
    downloadBlob(
      `lifeos-contacts-${Date.now()}.json`,
      JSON.stringify({ contacts }, null, 2),
      "application/json",
    );
    notify("فایل JSON آماده شد");
  }

  function downloadCsv() {
    downloadBlob(`lifeos-contacts-${Date.now()}.csv`, contactsToCsv(contacts), "text/csv;charset=utf-8");
    notify("فایل CSV آماده شد");
  }

  async function downloadBackup(backup: BackupRow) {
    const res = await fetch(`/api/backups/${backup.id}`);
    const data = (await res.json()) as { backup?: { payload: string; label: string }; error?: string };
    if (!res.ok || !data.backup) {
      notify(data.error || "دانلود ناموفق بود", "err");
      return;
    }
    downloadBlob(`backup-${backup.id}.json`, data.backup.payload, "application/json");
  }

  async function importFile(file: File, mode: "merge" | "replace") {
    try {
      const text = await file.text();
      let incoming: ContactInput[] = [];
      if (file.name.toLowerCase().endsWith(".csv") || file.type.includes("csv")) {
        incoming = parseContactsCsv(text);
      } else {
        incoming = parseImportPayload(JSON.parse(text));
      }
      if (incoming.length === 0) {
        notify("فایل مخاطب معتبری ندارد", "err");
        return;
      }
      const run = async () => {
        const res = await fetch("/api/contacts/import", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ contacts: incoming, mode }),
        });
        const data = (await res.json()) as { contacts?: ContactDTO[]; imported?: number; error?: string };
        if (!res.ok) throw new Error(data.error || "درون‌ریزی ناموفق بود");
        setContacts(data.contacts ?? []);
        notify(`${data.imported ?? incoming.length} مخاطب درون‌ریزی شد`);
      };
      if (mode === "replace") {
        setConfirm({
          title: "جایگزینی کامل",
          message: "همه مخاطبین فعلی پاک می‌شوند و فایل جدید جایگزین می‌گردد.",
          confirmLabel: "جایگزینی",
          danger: true,
          action: run,
        });
      } else {
        await run();
      }
    } catch (error) {
      notify(error instanceof Error ? error.message : "خواندن فایل ناموفق بود", "err");
    }
  }

  function resetDemo() {
    setConfirm({
      title: "بازنشانی داده نمونه",
      message: "همه مخاطبین فعلی حذف و داده نمونه LifeOS بارگذاری می‌شود.",
      confirmLabel: "بازنشانی",
      danger: true,
      action: async () => {
        const res = await fetch("/api/contacts/reset", { method: "POST" });
        const data = (await res.json()) as { contacts?: ContactDTO[]; error?: string };
        if (!res.ok) throw new Error(data.error || "بازنشانی ناموفق بود");
        setContacts(data.contacts ?? []);
        cancelEdit();
        notify("داده نمونه بارگذاری شد");
      },
    });
  }

  async function runConfirm() {
    if (!confirm) return;
    const current = confirm;
    setConfirm(null);
    try {
      await current.action();
    } catch (error) {
      notify(error instanceof Error ? error.message : "عملیات ناموفق بود", "err");
    }
  }

  return (
    <main className="relative mx-auto min-h-screen w-full max-w-7xl px-4 py-6 lg:px-8 lg:py-8">
      <header className="panel mb-5 overflow-hidden rounded-[28px] px-6 py-6 lg:px-8">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <div className="text-right">
            <p className="text-sm font-medium text-cyan-300/80">LifeOS داده‌های واقعی</p>
            <h1 className="mt-1 text-4xl font-black tracking-tight lg:text-5xl">مخاطبین</h1>
            <p className="mt-2 text-sm text-sky-200/60">دفترچه تلفن حرفه‌ای با جستجو، بک‌آپ و مدیریت کامل</p>
          </div>
          <div className="flex flex-wrap gap-2 lg:justify-end">
            <div className="stat-pill">
              <IconUsers className="h-4 w-4 text-cyan-300" />
              <div>
                <p className="text-[11px] text-sky-200/60">مخاطبین</p>
                <p className="text-sm font-bold">{loading ? "…" : contacts.length}</p>
              </div>
            </div>
            <div className="stat-pill">
              <IconStar filled className="h-4 w-4 text-amber-300" />
              <div>
                <p className="text-[11px] text-sky-200/60">علاقه‌مندی</p>
                <p className="text-sm font-bold">{favoriteCount}</p>
              </div>
            </div>
            <div className="stat-pill">
              <IconCake className="h-4 w-4 text-pink-300" />
              <div>
                <p className="text-[11px] text-sky-200/60">تولد این ماه</p>
                <p className="text-sm font-bold">{birthdayCount}</p>
              </div>
            </div>
            <button type="button" className="ghost-btn flex items-center gap-2" onClick={() => setBackupOpen(true)}>
              <IconShield />
              پشتیبان و درون‌ریزی
            </button>
          </div>
        </div>
      </header>

      <div className="mb-4 grid grid-cols-2 gap-2 lg:hidden">
        <button
          type="button"
          className={`chip h-11 w-full ${mobileTab === "form" ? "active" : ""}`}
          onClick={() => setMobileTab("form")}
        >
          افزودن
        </button>
        <button
          type="button"
          className={`chip h-11 w-full ${mobileTab === "list" ? "active" : ""}`}
          onClick={() => setMobileTab("list")}
        >
          فهرست
        </button>
      </div>

      <div className="grid items-start gap-5 lg:grid-cols-[minmax(0,1fr)_380px]" dir="ltr">
        <div className={mobileTab === "list" ? "block" : "hidden lg:block"} dir="rtl">
          <ContactList
            contacts={contacts}
            filtered={filtered}
            query={query}
            relationship={relationship}
            favOnly={favOnly}
            sort={sort}
            editingId={editingId}
            onQuery={setQuery}
            onRelationship={setRelationship}
            onFavOnly={setFavOnly}
            onSort={setSort}
            onEdit={startEdit}
            onDelete={askDelete}
            onToggleFav={toggleFav}
            onCopy={copyText}
          />
        </div>
        <div className={mobileTab === "form" ? "block" : "hidden lg:block"} dir="rtl">
          <ContactForm
            form={form}
            editingId={editingId}
            saving={saving}
            showMore={showMore}
            onChange={patchForm}
            onToggleMore={() => setShowMore((v) => !v)}
            onSubmit={saveContact}
            onCancel={cancelEdit}
          />
        </div>
      </div>

      <p className="mt-6 text-center text-xs text-sky-200/35">
        میانبر جستجو Ctrl/⌘ + K · داده‌ها روی PostgreSQL ذخیره می‌شوند
      </p>

      <BackupModal
        open={backupOpen}
        backups={backups}
        busy={busyBackup}
        onClose={() => setBackupOpen(false)}
        onCreate={createBackup}
        onRestore={restoreBackup}
        onDelete={deleteBackup}
        onDownloadJson={downloadJson}
        onDownloadCsv={downloadCsv}
        onDownloadBackup={downloadBackup}
        onImportFile={importFile}
        onResetDemo={resetDemo}
      />

      {confirm ? (
        <ConfirmDialog
          title={confirm.title}
          message={confirm.message}
          confirmLabel={confirm.confirmLabel}
          danger={confirm.danger}
          onCancel={() => setConfirm(null)}
          onConfirm={runConfirm}
        />
      ) : null}
      {toast ? <Toast message={toast.message} type={toast.type} /> : null}
    </main>
  );
}
