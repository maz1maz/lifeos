"use client";

import { RELATIONSHIPS, type ContactInput } from "@/lib/contacts";
import { FieldLabel, IconStar } from "@/components/ui";

type Props = {
  form: ContactInput;
  editingId: number | null;
  saving: boolean;
  showMore: boolean;
  onChange: (patch: Partial<ContactInput>) => void;
  onToggleMore: () => void;
  onSubmit: () => void;
  onCancel: () => void;
};

export function ContactForm({
  form,
  editingId,
  saving,
  showMore,
  onChange,
  onToggleMore,
  onSubmit,
  onCancel,
}: Props) {
  return (
    <section className="panel panel-strong sticky top-5 z-20 rounded-[28px] p-5 lg:p-6">
      <div className="mb-5 flex items-center justify-between">
        <h2 className="text-2xl font-extrabold tracking-tight">
          {editingId ? "ویرایش" : "افزودن"}
        </h2>
        {editingId ? (
          <button type="button" className="ghost-btn text-sm" onClick={onCancel}>
            انصراف
          </button>
        ) : null}
      </div>

      <form
        className="space-y-3"
        onSubmit={(event) => {
          event.preventDefault();
          onSubmit();
        }}
      >
        <label className="block">
          <FieldLabel>نام مخاطب</FieldLabel>
          <input
            className="field"
            placeholder="نام مخاطب"
            value={form.name}
            onChange={(e) => onChange({ name: e.target.value })}
            autoComplete="name"
          />
        </label>

        <div className="grid grid-cols-[1fr_1.15fr] gap-3">
          <label className="select-wrap block">
            <FieldLabel>نسبت</FieldLabel>
            <select
              className="field"
              value={form.relationship}
              onChange={(e) => onChange({ relationship: e.target.value })}
            >
              {RELATIONSHIPS.map((item) => (
                <option key={item.value} value={item.value}>
                  {item.label}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <FieldLabel>تلفن</FieldLabel>
            <input
              className="field"
              placeholder="تلفن"
              value={form.phones}
              onChange={(e) => onChange({ phones: e.target.value })}
              autoComplete="tel"
              dir="ltr"
              style={{ textAlign: "right" }}
            />
          </label>
        </div>

        <label className="block">
          <FieldLabel>ایمیل</FieldLabel>
          <input
            className="field"
            placeholder="ایمیل"
            value={form.email}
            onChange={(e) => onChange({ email: e.target.value })}
            autoComplete="email"
            dir="ltr"
            style={{ textAlign: "right" }}
          />
        </label>

        <div className="grid grid-cols-2 gap-3">
          <label className="block">
            <FieldLabel>تاریخ تولد</FieldLabel>
            <input
              type="date"
              className="field"
              value={form.birthday}
              onChange={(e) => onChange({ birthday: e.target.value })}
              title="تاریخ تولد"
            />
          </label>
          <label className="block">
            <FieldLabel>تاریخ یادآوری</FieldLabel>
            <input
              type="date"
              className="field"
              value={form.reminderDate}
              onChange={(e) => onChange({ reminderDate: e.target.value })}
              title="تاریخ یادآوری"
            />
          </label>
        </div>

        <label className="block">
          <FieldLabel>توضیحات</FieldLabel>
          <textarea
            className="field"
            placeholder="توضیحات"
            value={form.notes}
            onChange={(e) => onChange({ notes: e.target.value })}
            rows={3}
          />
        </label>

        <button
          type="button"
          className="text-sm text-cyan-300/80 hover:text-cyan-200"
          onClick={onToggleMore}
        >
          {showMore ? "بستن جزئیات بیشتر" : "اطلاعات بیشتر · تلگرام، شرکت، برچسب"}
        </button>

        {showMore ? (
          <div className="space-y-3 rounded-2xl border border-cyan-400/15 bg-black/20 p-3">
            <label className="block">
              <FieldLabel>تلگرام</FieldLabel>
              <input
                className="field"
                placeholder="تلگرام  @username یا لینک"
                value={form.telegram}
                onChange={(e) => onChange({ telegram: e.target.value })}
                dir="ltr"
                style={{ textAlign: "right" }}
              />
            </label>
            <label className="block">
              <FieldLabel>شرکت</FieldLabel>
              <input
                className="field"
                placeholder="شرکت / سازمان"
                value={form.company}
                onChange={(e) => onChange({ company: e.target.value })}
              />
            </label>
            <label className="block">
              <FieldLabel>آدرس</FieldLabel>
              <input
                className="field"
                placeholder="آدرس"
                value={form.address}
                onChange={(e) => onChange({ address: e.target.value })}
              />
            </label>
            <label className="block">
              <FieldLabel>وبسایت</FieldLabel>
              <input
                className="field"
                placeholder="وبسایت"
                value={form.website}
                onChange={(e) => onChange({ website: e.target.value })}
                dir="ltr"
                style={{ textAlign: "right" }}
              />
            </label>
            <label className="block">
              <FieldLabel>برچسب‌ها</FieldLabel>
              <input
                className="field"
                placeholder="برچسب‌ها با ویرگول"
                value={form.tags}
                onChange={(e) => onChange({ tags: e.target.value })}
              />
            </label>
            <button
              type="button"
              className={`ghost-btn flex w-full items-center justify-center gap-2 ${
                form.favorite ? "border-amber-300/50 text-amber-200" : ""
              }`}
              onClick={() => onChange({ favorite: !form.favorite })}
            >
              <IconStar filled={form.favorite} />
              {form.favorite ? "در علاقه‌مندی‌ها" : "افزودن به علاقه‌مندی‌ها"}
            </button>
          </div>
        ) : null}

        <button type="submit" className="save-btn mt-2" disabled={saving}>
          {saving ? "در حال ذخیره..." : editingId ? "به‌روزرسانی" : "ذخیره"}
        </button>
      </form>
    </section>
  );
}
