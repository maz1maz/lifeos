"use client";

import type { ReactNode } from "react";

export function IconSearch({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden>
      <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="1.8" />
      <path d="M20 20L16.5 16.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}

export function IconStar({ filled, className = "h-4 w-4" }: { filled?: boolean; className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" aria-hidden>
      <path
        d="M12 3.6l2.3 4.7 5.2.8-3.8 3.7.9 5.2L12 15.9 7.4 18l.9-5.2L4.5 9.1l5.2-.8L12 3.6z"
        fill={filled ? "currentColor" : "none"}
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function IconPhone({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden>
      <path
        d="M7.5 3.8h3.2l1 4.1-2 1.2a12.8 12.8 0 006.2 6.2l1.2-2 4.1 1v3.1c0 .7-.6 1.4-1.4 1.4C10.6 18.8 5.2 13.4 5.2 5.2c0-.8.6-1.4 1.3-1.4z"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function IconCopy({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden>
      <rect x="8" y="8" width="11" height="12" rx="2" stroke="currentColor" strokeWidth="1.7" />
      <path d="M6 16V6.8A1.8 1.8 0 017.8 5H15" stroke="currentColor" strokeWidth="1.7" />
    </svg>
  );
}

export function IconShield({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden>
      <path
        d="M12 3.5l7.5 3v6.2c0 4.3-3 7.4-7.5 8.8C7.5 20.1 4.5 17 4.5 12.7V6.5L12 3.5z"
        stroke="currentColor"
        strokeWidth="1.7"
      />
      <path d="M8.8 12.2l2.2 2.2 4.2-4.4" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  );
}

export function IconDownload({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden>
      <path d="M12 4v10" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
      <path d="M8 11l4 4 4-4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
      <path d="M5 19h14" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}

export function IconUpload({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden>
      <path d="M12 20V10" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
      <path d="M8 13l4-4 4 4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
      <path d="M5 5h14" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}

export function IconCake({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden>
      <path d="M4 13h16v6a2 2 0 01-2 2H6a2 2 0 01-2-2v-6z" stroke="currentColor" strokeWidth="1.6" />
      <path d="M4 13c2 1.4 3.5 1.4 5.5 0s3.5-1.4 5.5 0 3.4 1.4 5 0" stroke="currentColor" strokeWidth="1.6" />
      <path d="M8 13V9h8v4M10 9V7m4 2V7" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  );
}

export function IconUsers({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden>
      <circle cx="9" cy="8" r="3" stroke="currentColor" strokeWidth="1.7" />
      <path d="M4.5 18.5c.7-3 2.6-4.5 4.5-4.5s3.8 1.5 4.5 4.5" stroke="currentColor" strokeWidth="1.7" />
      <circle cx="16.5" cy="9" r="2.3" stroke="currentColor" strokeWidth="1.7" />
      <path d="M15 14.2c1.8.2 3.4 1.5 4.2 4.3" stroke="currentColor" strokeWidth="1.7" />
    </svg>
  );
}

export function Toast({
  message,
  type = "ok",
}: {
  message: string;
  type?: "ok" | "err";
}) {
  return (
    <div
      className={`toast pointer-events-none fixed bottom-6 left-1/2 z-[80] max-w-[90vw] -translate-x-1/2 rounded-2xl border px-4 py-3 text-sm shadow-2xl ${
        type === "err"
          ? "border-rose-400/30 bg-[#2a1018] text-rose-100"
          : "border-cyan-300/30 bg-[#08202c] text-cyan-50"
      }`}
    >
      {message}
    </div>
  );
}

export function ConfirmDialog({
  title,
  message,
  confirmLabel = "تأیید",
  danger,
  onCancel,
  onConfirm,
}: {
  title: string;
  message: string;
  confirmLabel?: string;
  danger?: boolean;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  return (
    <div className="modal-backdrop fixed inset-0 z-[70] grid place-items-center px-4">
      <div className="panel panel-strong w-full max-w-md rounded-3xl p-6">
        <h3 className="text-xl font-bold">{title}</h3>
        <p className="mt-3 text-sm leading-7 text-sky-100/75">{message}</p>
        <div className="mt-6 flex gap-3">
          <button
            type="button"
            className="save-btn !w-auto flex-1 px-4"
            style={danger ? { background: "linear-gradient(180deg,#fb7185,#e11d48)", color: "#fff" } : undefined}
            onClick={onConfirm}
          >
            {confirmLabel}
          </button>
          <button type="button" className="ghost-btn flex-1" onClick={onCancel}>
            انصراف
          </button>
        </div>
      </div>
    </div>
  );
}

export function EmptyState({ title, hint }: { title: string; hint: string }) {
  return (
    <div className="px-4 py-16 text-center">
      <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl border border-cyan-400/20 bg-cyan-400/5 text-cyan-200">
        <IconUsers className="h-7 w-7" />
      </div>
      <p className="mt-4 text-lg font-semibold">{title}</p>
      <p className="mt-2 text-sm text-sky-200/60">{hint}</p>
    </div>
  );
}

export function FieldLabel({ children }: { children: ReactNode }) {
  return <span className="sr-only">{children}</span>;
}
