"use client";

import type { ContactDTO } from "@/lib/contacts";
import {
  firstPhone,
  formatShortDate,
  isBirthdayThisMonth,
  relationshipLabel,
  relationshipTone,
  splitPhones,
  telegramHref,
  websiteHref,
} from "@/lib/contacts";
import { EmptyState, IconCopy, IconPhone, IconSearch, IconStar } from "@/components/ui";

type Props = {
  contacts: ContactDTO[];
  filtered: ContactDTO[];
  query: string;
  relationship: string;
  favOnly: boolean;
  sort: "new" | "name" | "fav";
  editingId: number | null;
  onQuery: (value: string) => void;
  onRelationship: (value: string) => void;
  onFavOnly: (value: boolean) => void;
  onSort: (value: "new" | "name" | "fav") => void;
  onEdit: (contact: ContactDTO) => void;
  onDelete: (contact: ContactDTO) => void;
  onToggleFav: (contact: ContactDTO) => void;
  onCopy: (value: string) => void;
};

export function ContactList({
  contacts,
  filtered,
  query,
  relationship,
  favOnly,
  sort,
  editingId,
  onQuery,
  onRelationship,
  onFavOnly,
  onSort,
  onEdit,
  onDelete,
  onToggleFav,
  onCopy,
}: Props) {
  return (
    <section className="panel min-h-[640px] rounded-[28px] p-5 lg:p-6">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-2xl font-extrabold tracking-tight">فهرست</h2>
        <div className="text-sm text-sky-200/70">
          {filtered.length} از {contacts.length} مخاطب
        </div>
      </div>

      <div className="relative mb-3">
        <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-sky-300/70">
          <IconSearch />
        </span>
        <input
          className="field pr-10"
          placeholder="جستجو در نام، تلفن، ایمیل، شرکت..."
          value={query}
          onChange={(e) => onQuery(e.target.value)}
        />
      </div>

      <div className="mb-4 flex flex-wrap gap-2">
        <button
          type="button"
          className={`chip ${relationship === "all" && !favOnly ? "active" : ""}`}
          onClick={() => {
            onRelationship("all");
            onFavOnly(false);
          }}
        >
          همه
        </button>
        <button
          type="button"
          className={`chip ${favOnly ? "active" : ""}`}
          onClick={() => onFavOnly(!favOnly)}
        >
          علاقه‌مندی
        </button>
        {[
          ["friend", "دوست"],
          ["family", "خانواده"],
          ["colleague", "همکار"],
          ["client", "مشتری"],
          ["acquaintance", "آشنا"],
          ["other", "سایر"],
        ].map(([value, label]) => (
          <button
            key={value}
            type="button"
            className={`chip ${relationship === value ? "active" : ""}`}
            onClick={() => onRelationship(relationship === value ? "all" : value)}
          >
            {label}
          </button>
        ))}
        <select
          className="chip bg-transparent"
          value={sort}
          onChange={(e) => onSort(e.target.value as "new" | "name" | "fav")}
        >
          <option value="new">جدیدترین</option>
          <option value="name">نام</option>
          <option value="fav">علاقه‌مندی اول</option>
        </select>
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          title={contacts.length === 0 ? "هنوز مخاطبی نیست" : "نتیجه‌ای پیدا نشد"}
          hint={
            contacts.length === 0
              ? "از فرم افزودن، اولین مخاطب را ذخیره کنید."
              : "عبارت جستجو یا فیلتر را تغییر دهید."
          }
        />
      ) : (
        <div>
          {filtered.map((contact) => {
            const tone = relationshipTone(contact.relationship);
            const phones = splitPhones(contact.phones);
            const tel = firstPhone(contact.phones);
            const tg = telegramHref(contact.telegram);
            const web = websiteHref(contact.website);
            return (
              <article
                key={contact.id}
                className={`contact-row ${editingId === contact.id ? "active" : ""}`}
                style={{ ["--accent" as string]: tone.bar }}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-[17px] font-bold leading-7 text-white">{contact.name}</h3>
                      {contact.favorite ? (
                        <span className="text-amber-300">
                          <IconStar filled className="h-3.5 w-3.5" />
                        </span>
                      ) : null}
                      {isBirthdayThisMonth(contact.birthday) ? (
                        <span className="rounded-full bg-pink-400/15 px-2 py-0.5 text-[11px] text-pink-200">
                          تولد این ماه
                        </span>
                      ) : null}
                    </div>
                    <p className="mt-1 text-[13px] text-sky-200/70">
                      {relationshipLabel(contact.relationship)}
                      {phones.length ? ` · ${phones.join("  ·  ")}` : ""}
                    </p>
                    {contact.company ? (
                      <p className="mt-1 text-[12px] text-sky-300/55">{contact.company}</p>
                    ) : null}
                    {contact.email ? (
                      <p className="mt-1 text-[12px] text-cyan-200/70" dir="ltr">
                        {contact.email}
                      </p>
                    ) : null}
                    {tg ? (
                      <a
                        href={tg}
                        target="_blank"
                        rel="noreferrer"
                        className="mt-1 inline-block text-[12px] text-cyan-300/80 hover:text-cyan-200"
                        dir="ltr"
                      >
                        {contact.telegram}
                      </a>
                    ) : null}
                    {contact.notes ? (
                      <p className="mt-1 line-clamp-2 text-[12px] text-sky-100/45">{contact.notes}</p>
                    ) : null}
                    <div className="mt-2 flex flex-wrap gap-2 text-[11px] text-sky-200/50">
                      {contact.birthday ? <span>تولد {formatShortDate(contact.birthday)}</span> : null}
                      {contact.address ? <span>{contact.address}</span> : null}
                      {web ? (
                        <a href={web} target="_blank" rel="noreferrer" className="text-cyan-300/70">
                          وبسایت
                        </a>
                      ) : null}
                    </div>
                  </div>
                  <div className="flex shrink-0 items-center gap-1 pt-1">
                    <button
                      type="button"
                      className="x-btn !text-amber-300"
                      title="علاقه‌مندی"
                      onClick={() => onToggleFav(contact)}
                    >
                      <IconStar filled={contact.favorite} className="h-4 w-4" />
                    </button>
                    {tel ? (
                      <>
                        <a className="x-btn !text-cyan-300" href={`tel:${tel}`} title="تماس">
                          <IconPhone className="mx-auto h-4 w-4" />
                        </a>
                        <button
                          type="button"
                          className="x-btn !text-sky-200"
                          title="کپی شماره"
                          onClick={() => onCopy(tel)}
                        >
                          <IconCopy className="mx-auto h-4 w-4" />
                        </button>
                      </>
                    ) : null}
                    <button type="button" className="edit-chip" onClick={() => onEdit(contact)}>
                      ویرایش
                    </button>
                    <button type="button" className="x-btn" onClick={() => onDelete(contact)} title="حذف">
                      ×
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
}
