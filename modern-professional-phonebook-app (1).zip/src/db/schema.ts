import {
  boolean,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  relationship: text("relationship").notNull().default("friend"),
  phones: text("phones").notNull().default(""),
  email: text("email").notNull().default(""),
  telegram: text("telegram").notNull().default(""),
  website: text("website").notNull().default(""),
  company: text("company").notNull().default(""),
  address: text("address").notNull().default(""),
  birthday: text("birthday").notNull().default(""),
  reminderDate: text("reminder_date").notNull().default(""),
  notes: text("notes").notNull().default(""),
  tags: text("tags").notNull().default(""),
  favorite: boolean("favorite").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const backups = pgTable("backups", {
  id: serial("id").primaryKey(),
  label: text("label").notNull(),
  contactCount: integer("contact_count").notNull(),
  payload: text("payload").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export type Contact = typeof contacts.$inferSelect;
export type NewContact = typeof contacts.$inferInsert;
export type Backup = typeof backups.$inferSelect;
