import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Vazirmatn } from "next/font/google";
import "./globals.css";

const vazir = Vazirmatn({
  subsets: ["arabic", "latin"],
  weight: ["300", "400", "500", "600", "700", "800"],
  variable: "--font-vazir",
  display: "swap",
});

export const metadata: Metadata = {
  title: "مخاطبین | دفترچه تلفن حرفه‌ای LifeOS",
  description:
    "دفترچه تلفن مدرن با جستجو، پشتیبان‌گیری، درون‌ریزی و مدیریت کامل مخاطبین.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl" className={vazir.variable}>
      <body className={`${vazir.className} antialiased`}>{children}</body>
    </html>
  );
}
