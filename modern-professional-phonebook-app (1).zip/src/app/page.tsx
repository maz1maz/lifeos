import { ContactsApp } from "@/components/ContactsApp";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return <ContactsApp />;
}
