import { desc } from "drizzle-orm";
import { db } from "@/db";
import { contacts } from "@/db/schema";
import { contactToPayload, serializeContact } from "@/lib/contacts";
import { ensureDemoContacts } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureDemoContacts();
    const rows = await db.select().from(contacts).orderBy(desc(contacts.createdAt), desc(contacts.id));
    return Response.json({ contacts: rows.map(serializeContact) });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "خواندن مخاطبین ناموفق بود" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const payload = contactToPayload(body);
    if (!payload.name) {
      return Response.json({ error: "نام مخاطب الزامی است" }, { status: 400 });
    }
    const [created] = await db.insert(contacts).values(payload).returning();
    return Response.json({ contact: serializeContact(created) }, { status: 201 });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "ذخیره مخاطب ناموفق بود" }, { status: 500 });
  }
}
