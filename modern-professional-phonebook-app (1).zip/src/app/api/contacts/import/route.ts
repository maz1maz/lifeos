import { db } from "@/db";
import { contacts } from "@/db/schema";
import { contactToPayload, parseImportPayload, serializeContact } from "@/lib/contacts";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { contacts?: unknown; mode?: string };
    const incoming = parseImportPayload(body.contacts ?? body).map((row) => contactToPayload(row));
    if (incoming.length === 0) {
      return Response.json({ error: "هیچ مخاطب معتبری برای درون‌ریزی پیدا نشد" }, { status: 400 });
    }

    if (body.mode === "replace") {
      await db.delete(contacts);
    }

    await db.insert(contacts).values(incoming);
    const rows = await db.select().from(contacts).orderBy(desc(contacts.createdAt), desc(contacts.id));
    return Response.json({
      imported: incoming.length,
      contacts: rows.map(serializeContact),
    });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "درون‌ریزی ناموفق بود" }, { status: 500 });
  }
}
