import { db } from "@/db";
import { contacts } from "@/db/schema";
import { serializeContact } from "@/lib/contacts";
import { resetDemoContacts } from "@/lib/seed";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST() {
  try {
    await resetDemoContacts();
    const rows = await db.select().from(contacts).orderBy(desc(contacts.createdAt), desc(contacts.id));
    return Response.json({ contacts: rows.map(serializeContact) });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "بازنشانی داده نمونه ناموفق بود" }, { status: 500 });
  }
}
