import { eq } from "drizzle-orm";
import { db } from "@/db";
import { contacts } from "@/db/schema";
import { contactToPayload, serializeContact } from "@/lib/contacts";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

function parseId(raw: string) {
  const id = Number(raw);
  if (!Number.isInteger(id) || id <= 0) return null;
  return id;
}

export async function PATCH(request: Request, ctx: Ctx) {
  try {
    const { id: raw } = await ctx.params;
    const id = parseId(raw);
    if (!id) return Response.json({ error: "شناسه نامعتبر است" }, { status: 400 });

    const body = (await request.json()) as Record<string, unknown>;
    const existing = await db.select().from(contacts).where(eq(contacts.id, id)).limit(1);
    if (!existing[0]) return Response.json({ error: "مخاطب پیدا نشد" }, { status: 404 });

    const merged = contactToPayload({
      ...existing[0],
      ...body,
      name: typeof body.name === "string" ? body.name : existing[0].name,
      favorite:
        typeof body.favorite === "boolean" ? body.favorite : existing[0].favorite,
    });

    if (!merged.name) {
      return Response.json({ error: "نام مخاطب الزامی است" }, { status: 400 });
    }

    const [updated] = await db
      .update(contacts)
      .set({ ...merged, updatedAt: new Date() })
      .where(eq(contacts.id, id))
      .returning();

    return Response.json({ contact: serializeContact(updated) });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "ویرایش مخاطب ناموفق بود" }, { status: 500 });
  }
}

export async function DELETE(_request: Request, ctx: Ctx) {
  try {
    const { id: raw } = await ctx.params;
    const id = parseId(raw);
    if (!id) return Response.json({ error: "شناسه نامعتبر است" }, { status: 400 });

    const deleted = await db.delete(contacts).where(eq(contacts.id, id)).returning({ id: contacts.id });
    if (!deleted[0]) return Response.json({ error: "مخاطب پیدا نشد" }, { status: 404 });
    return Response.json({ ok: true });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "حذف مخاطب ناموفق بود" }, { status: 500 });
  }
}
