import { eq } from "drizzle-orm";
import { db } from "@/db";
import { backups } from "@/db/schema";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

function parseId(raw: string) {
  const id = Number(raw);
  if (!Number.isInteger(id) || id <= 0) return null;
  return id;
}

export async function GET(_request: Request, ctx: Ctx) {
  try {
    const id = parseId((await ctx.params).id);
    if (!id) return Response.json({ error: "شناسه نامعتبر است" }, { status: 400 });
    const rows = await db.select().from(backups).where(eq(backups.id, id)).limit(1);
    if (!rows[0]) return Response.json({ error: "نسخه پشتیبان پیدا نشد" }, { status: 404 });
    return Response.json({
      backup: {
        id: rows[0].id,
        label: rows[0].label,
        contactCount: rows[0].contactCount,
        createdAt:
          rows[0].createdAt instanceof Date ? rows[0].createdAt.toISOString() : rows[0].createdAt,
        payload: rows[0].payload,
      },
    });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "خواندن نسخه پشتیبان ناموفق بود" }, { status: 500 });
  }
}

export async function DELETE(_request: Request, ctx: Ctx) {
  try {
    const id = parseId((await ctx.params).id);
    if (!id) return Response.json({ error: "شناسه نامعتبر است" }, { status: 400 });
    const deleted = await db.delete(backups).where(eq(backups.id, id)).returning({ id: backups.id });
    if (!deleted[0]) return Response.json({ error: "نسخه پشتیبان پیدا نشد" }, { status: 404 });
    return Response.json({ ok: true });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "حذف نسخه پشتیبان ناموفق بود" }, { status: 500 });
  }
}
