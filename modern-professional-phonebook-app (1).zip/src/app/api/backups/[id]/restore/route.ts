import { eq, desc } from "drizzle-orm";
import { db } from "@/db";
import { backups, contacts } from "@/db/schema";
import { contactToPayload, parseImportPayload, serializeContact } from "@/lib/contacts";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(_request: Request, ctx: Ctx) {
  try {
    const id = Number((await ctx.params).id);
    if (!Number.isInteger(id) || id <= 0) {
      return Response.json({ error: "شناسه نامعتبر است" }, { status: 400 });
    }

    const rows = await db.select().from(backups).where(eq(backups.id, id)).limit(1);
    if (!rows[0]) return Response.json({ error: "نسخه پشتیبان پیدا نشد" }, { status: 404 });

    let parsed: unknown;
    try {
      parsed = JSON.parse(rows[0].payload);
    } catch {
      return Response.json({ error: "فایل پشتیبان خراب است" }, { status: 400 });
    }

    const incoming = parseImportPayload(parsed).map((row) => contactToPayload(row));
    await db.delete(contacts);
    if (incoming.length > 0) {
      await db.insert(contacts).values(incoming);
    }

    const restored = await db.select().from(contacts).orderBy(desc(contacts.createdAt), desc(contacts.id));
    return Response.json({ contacts: restored.map(serializeContact) });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "بازیابی نسخه پشتیبان ناموفق بود" }, { status: 500 });
  }
}
