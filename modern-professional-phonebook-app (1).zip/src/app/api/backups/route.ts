import { desc } from "drizzle-orm";
import { db } from "@/db";
import { backups, contacts } from "@/db/schema";
import { serializeContact } from "@/lib/contacts";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db.select().from(backups).orderBy(desc(backups.createdAt), desc(backups.id));
    return Response.json({
      backups: rows.map((row) => ({
        id: row.id,
        label: row.label,
        contactCount: row.contactCount,
        createdAt: row.createdAt instanceof Date ? row.createdAt.toISOString() : row.createdAt,
      })),
    });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "خواندن نسخه‌های پشتیبان ناموفق بود" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json().catch(() => ({}))) as { label?: string };
    const rows = await db.select().from(contacts);
    const payload = JSON.stringify(rows.map(serializeContact));
    const stamp = new Intl.DateTimeFormat("fa-IR", {
      dateStyle: "medium",
      timeStyle: "short",
    }).format(new Date());
    const label = (body.label ?? "").trim() || `پشتیبان ${stamp}`;

    const [created] = await db
      .insert(backups)
      .values({
        label,
        contactCount: rows.length,
        payload,
      })
      .returning();

    return Response.json(
      {
        backup: {
          id: created.id,
          label: created.label,
          contactCount: created.contactCount,
          createdAt:
            created.createdAt instanceof Date
              ? created.createdAt.toISOString()
              : created.createdAt,
        },
      },
      { status: 201 },
    );
  } catch (error) {
    console.error(error);
    return Response.json({ error: "ایجاد نسخه پشتیبان ناموفق بود" }, { status: 500 });
  }
}
