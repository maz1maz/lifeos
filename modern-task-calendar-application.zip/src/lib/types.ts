export type EventType = "task" | "reminder" | "event";
export type Priority = "low" | "normal" | "high";

export type CalEvent = {
  id: number;
  title: string;
  description: string | null;
  date: string; // YYYY-MM-DD gregorian
  time: string | null;
  type: EventType;
  color: string;
  priority: Priority;
  completed: boolean;
  remindMinutes: number | null;
  createdAt: string;
};

export type NoteData = {
  id: number;
  date: string;
  content: string;
  updatedAt: string;
} | null;

export const EVENT_COLORS: Record<string, { bg: string; text: string; dot: string; ring: string }> =
  {
    cyan: { bg: "bg-cyan-500/15", text: "text-cyan-300", dot: "bg-cyan-400", ring: "ring-cyan-400/40" },
    amber: {
      bg: "bg-amber-500/15",
      text: "text-amber-300",
      dot: "bg-amber-400",
      ring: "ring-amber-400/40",
    },
    violet: {
      bg: "bg-violet-500/15",
      text: "text-violet-300",
      dot: "bg-violet-400",
      ring: "ring-violet-400/40",
    },
    emerald: {
      bg: "bg-emerald-500/15",
      text: "text-emerald-300",
      dot: "bg-emerald-400",
      ring: "ring-emerald-400/40",
    },
    rose: { bg: "bg-rose-500/15", text: "text-rose-300", dot: "bg-rose-400", ring: "ring-rose-400/40" },
    blue: { bg: "bg-blue-500/15", text: "text-blue-300", dot: "bg-blue-400", ring: "ring-blue-400/40" },
  };

export const TYPE_LABELS: Record<EventType, string> = {
  task: "کار",
  reminder: "یادآوری",
  event: "رویداد",
};

export const TYPE_DEFAULT_COLOR: Record<EventType, string> = {
  task: "cyan",
  reminder: "amber",
  event: "violet",
};

export const PRIORITY_LABELS: Record<Priority, string> = {
  low: "کم",
  normal: "متوسط",
  high: "زیاد",
};
