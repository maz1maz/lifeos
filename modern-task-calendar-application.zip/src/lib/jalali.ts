import { toJalaali, toGregorian, jalaaliMonthLength, isValidJalaaliDate } from "jalaali-js";

export const PERSIAN_MONTHS = [
  "فروردین",
  "اردیبهشت",
  "خرداد",
  "تیر",
  "مرداد",
  "شهریور",
  "مهر",
  "آبان",
  "آذر",
  "دی",
  "بهمن",
  "اسفند",
];

export const GREGORIAN_MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

// Persian week starts on Saturday.
export const PERSIAN_WEEKDAYS_SHORT = ["ش", "ی", "د", "س", "چ", "پ", "ج"];
export const PERSIAN_WEEKDAYS_LONG = [
  "شنبه",
  "یک‌شنبه",
  "دوشنبه",
  "سه‌شنبه",
  "چهارشنبه",
  "پنج‌شنبه",
  "جمعه",
];

export type JDate = { jy: number; jm: number; jd: number };
export type GDate = { gy: number; gm: number; gd: number };

export function toFaDigits(input: string | number): string {
  const fa = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];
  return String(input).replace(/[0-9]/g, (d) => fa[Number(d)]);
}

/** Local date -> ISO YYYY-MM-DD (no timezone shift). */
export function dateToISO(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function isoToDate(iso: string): Date {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, m - 1, d);
}

export function gregorianToJalali(d: Date): JDate {
  return toJalaali(d.getFullYear(), d.getMonth() + 1, d.getDate());
}

export function jalaliToDate(jy: number, jm: number, jd: number): Date {
  const g = toGregorian(jy, jm, jd);
  return new Date(g.gy, g.gm - 1, g.gd);
}

/**
 * Persian day-of-week index where Saturday = 0 ... Friday = 6.
 * JS getDay(): Sunday=0 .. Saturday=6.
 */
export function persianDayOfWeek(d: Date): number {
  return (d.getDay() + 1) % 7;
}

export type CalendarCell = {
  iso: string;
  date: Date;
  jy: number;
  jm: number;
  jd: number;
  gd: number; // gregorian day
  gm: number; // gregorian month (1-12)
  inCurrentMonth: boolean;
  isToday: boolean;
  isFriday: boolean;
  weekOfYear: number;
  occasion?: string;
  isHoliday: boolean;
};

/** Build a 6x7 grid for a Jalali month. */
export function buildJalaliMonthGrid(jy: number, jm: number, todayIso: string): CalendarCell[] {
  const firstDay = jalaliToDate(jy, jm, 1);
  const startOffset = persianDayOfWeek(firstDay); // how many days before day 1
  const gridStart = new Date(firstDay);
  gridStart.setDate(gridStart.getDate() - startOffset);

  const cells: CalendarCell[] = [];
  for (let i = 0; i < 42; i++) {
    const d = new Date(gridStart);
    d.setDate(gridStart.getDate() + i);
    const j = gregorianToJalali(d);
    const iso = dateToISO(d);
    const occ = getJalaliOccasion(j.jm, j.jd);
    cells.push({
      iso,
      date: d,
      jy: j.jy,
      jm: j.jm,
      jd: j.jd,
      gd: d.getDate(),
      gm: d.getMonth() + 1,
      inCurrentMonth: j.jm === jm && j.jy === jy,
      isToday: iso === todayIso,
      isFriday: d.getDay() === 5,
      weekOfYear: getWeekOfYear(d),
      occasion: occ?.title,
      isHoliday: !!occ?.holiday || d.getDay() === 5,
    });
  }
  return cells;
}

/** Build a 6x7 grid for a Gregorian month (week starts Saturday). */
export function buildGregorianMonthGrid(gy: number, gm: number, todayIso: string): CalendarCell[] {
  const firstDay = new Date(gy, gm - 1, 1);
  const startOffset = persianDayOfWeek(firstDay);
  const gridStart = new Date(firstDay);
  gridStart.setDate(gridStart.getDate() - startOffset);

  const cells: CalendarCell[] = [];
  for (let i = 0; i < 42; i++) {
    const d = new Date(gridStart);
    d.setDate(gridStart.getDate() + i);
    const j = gregorianToJalali(d);
    const iso = dateToISO(d);
    const occ = getJalaliOccasion(j.jm, j.jd);
    cells.push({
      iso,
      date: d,
      jy: j.jy,
      jm: j.jm,
      jd: j.jd,
      gd: d.getDate(),
      gm: d.getMonth() + 1,
      inCurrentMonth: d.getMonth() + 1 === gm && d.getFullYear() === gy,
      isToday: iso === todayIso,
      isFriday: d.getDay() === 5,
      weekOfYear: getWeekOfYear(d),
      occasion: occ?.title,
      isHoliday: !!occ?.holiday || d.getDay() === 5,
    });
  }
  return cells;
}

export function getWeekOfYear(d: Date): number {
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const dayNum = (date.getUTCDay() + 6) % 7;
  date.setUTCDate(date.getUTCDate() - dayNum + 3);
  const firstThursday = date.getTime();
  date.setUTCMonth(0, 1);
  if (date.getUTCDay() !== 4) {
    date.setUTCMonth(0, 1 + ((4 - date.getUTCDay() + 7) % 7));
  }
  return 1 + Math.ceil((firstThursday - date.getTime()) / (7 * 24 * 3600 * 1000));
}

export function addJalaliMonth(jy: number, jm: number, delta: number): { jy: number; jm: number } {
  let total = jy * 12 + (jm - 1) + delta;
  const newYear = Math.floor(total / 12);
  const newMonth = (total % 12) + 1;
  return { jy: newYear, jm: newMonth };
}

export { jalaaliMonthLength, isValidJalaaliDate };

// --- Persian occasions (solar Hijri, fixed by month/day) ---
type Occasion = { title: string; holiday: boolean };
const OCCASIONS: Record<string, Occasion> = {
  "1-1": { title: "جشن نوروز / آغاز سال نو", holiday: true },
  "1-2": { title: "عید نوروز", holiday: true },
  "1-3": { title: "عید نوروز", holiday: true },
  "1-4": { title: "عید نوروز", holiday: true },
  "1-12": { title: "روز جمهوری اسلامی", holiday: true },
  "1-13": { title: "روز طبیعت (سیزده‌به‌در)", holiday: true },
  "2-2": { title: "روز زمین پاک", holiday: false },
  "2-10": { title: "روز ملی خلیج فارس", holiday: false },
  "3-14": { title: "رحلت امام خمینی", holiday: true },
  "3-15": { title: "قیام ۱۵ خرداد", holiday: true },
  "4-1": { title: "روز اصناف", holiday: false },
  "5-6": { title: "روز کارمند", holiday: false },
  "6-31": { title: "روز شعر و ادب فارسی", holiday: false },
  "7-8": { title: "روز بزرگداشت مولوی", holiday: false },
  "7-13": { title: "روز نیروی انتظامی", holiday: false },
  "8-8": { title: "روز نوجوان", holiday: false },
  "8-13": { title: "روز دانش‌آموز", holiday: false },
  "9-1": { title: "روز بزرگداشت شیخ مفید", holiday: false },
  "9-5": { title: "روز بسیج مستضعفان", holiday: false },
  "9-30": { title: "شب یلدا", holiday: false },
  "10-13": { title: "روز مقاومت", holiday: false },
  "11-19": { title: "روز نیروی هوایی", holiday: false },
  "11-22": { title: "پیروزی انقلاب اسلامی", holiday: true },
  "12-5": { title: "روز بزرگداشت خواجه نصیر", holiday: false },
  "12-29": { title: "روز ملی‌شدن صنعت نفت", holiday: true },
};

export function getJalaliOccasion(jm: number, jd: number): Occasion | undefined {
  return OCCASIONS[`${jm}-${jd}`];
}
