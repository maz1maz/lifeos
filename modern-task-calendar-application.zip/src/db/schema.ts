import {
  pgTable,
  serial,
  text,
  varchar,
  boolean,
  timestamp,
  date,
  integer,
} from "drizzle-orm/pg-core";

// Events: tasks, reminders, and general events.
// `date` is stored as canonical Gregorian YYYY-MM-DD so it renders in both calendars.
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").default(""),
  date: date("date").notNull(), // Gregorian YYYY-MM-DD
  time: varchar("time", { length: 5 }).default(""), // HH:MM (optional)
  type: varchar("type", { length: 20 }).notNull().default("task"), // task | reminder | event
  color: varchar("color", { length: 20 }).notNull().default("cyan"),
  priority: varchar("priority", { length: 10 }).notNull().default("normal"), // low | normal | high
  completed: boolean("completed").notNull().default(false),
  remindMinutes: integer("remind_minutes"), // minutes before to remind (optional)
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// One free-form note per day.
export const notes = pgTable("notes", {
  id: serial("id").primaryKey(),
  date: date("date").notNull().unique(), // Gregorian YYYY-MM-DD
  content: text("content").notNull().default(""),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export type EventRow = typeof events.$inferSelect;
export type NoteRow = typeof notes.$inferSelect;
