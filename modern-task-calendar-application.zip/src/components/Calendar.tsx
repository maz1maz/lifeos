"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  PERSIAN_MONTHS,
  GREGORIAN_MONTHS,
  PERSIAN_WEEKDAYS_SHORT,
  PERSIAN_WEEKDAYS_LONG,
  buildJalaliMonthGrid,
  buildGregorianMonthGrid,
  gregorianToJalali,
  addJalaliMonth,
  dateToISO,
  isoToDate,
  toFaDigits,
  persianDayOfWeek,
  type CalendarCell,
} from "@/lib/jalali";
import { CalEvent, EVENT_COLORS, TYPE_LABELS } from "@/lib/types";
import EventModal from "./EventModal";

type Mode = "jalali" | "gregorian";

export default function Calendar() {
  const today = useMemo(() => new Date(), []);
  const todayIso = dateToISO(today);
  const todayJ = gregorianToJalali(today);

  const [mode, setMode] = useState<Mode>("jalali");
  const [jy, setJy] = useState(todayJ.jy);
  const [jm, setJm] = useState(todayJ.jm);
  const [gy, setGy] = useState(today.getFullYear());
  const [gm, setGm] = useState(today.getMonth() + 1);

  const [selectedIso, setSelectedIso] = useState(todayIso);
  const [events, setEvents] = useState<CalEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<CalEvent | null>(null);
  const [search, setSearch] = useState("");
  const [filters, setFilters] = useState<Record<string, boolean>>({
    task: true,
    reminder: true,
    event: true,
  });

  // Note state
  const [noteText, setNoteText] = useState("");
  const [noteSaving, setNoteSaving] = useState(false);
  const [noteStatus, setNoteStatus] = useState("");

  // Build grid for current month
  const cells: CalendarCell[] = useMemo(() => {
    return mode === "jalali"
      ? buildJalaliMonthGrid(jy, jm, todayIso)
      : buildGregorianMonthGrid(gy, gm, todayIso);
  }, [mode, jy, jm, gy, gm, todayIso]);

  // Range for fetching events (first cell to last cell)
  const rangeFrom = cells[0]?.iso;
  const rangeTo = cells[cells.length - 1]?.iso;

  const loadEvents = useCallback(async () => {
    if (!rangeFrom || !rangeTo) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/events?from=${rangeFrom}&to=${rangeTo}`);
      const data = await res.json();
      setEvents(data.events ?? []);
    } catch {
      setEvents([]);
    } finally {
      setLoading(false);
    }
  }, [rangeFrom, rangeTo]);

  useEffect(() => {
    loadEvents();
  }, [loadEvents]);

  // Load note for selected day
  useEffect(() => {
    let cancelled = false;
    setNoteStatus("");
    fetch(`/api/notes?date=${selectedIso}`)
      .then((r) => r.json())
      .then((d) => {
        if (!cancelled) setNoteText(d.note?.content ?? "");
      })
      .catch(() => {
        if (!cancelled) setNoteText("");
      });
    return () => {
      cancelled = true;
    };
  }, [selectedIso]);

  const eventsByDate = useMemo(() => {
    const map = new Map<string, CalEvent[]>();
    for (const ev of events) {
      if (!filters[ev.type]) continue;
      if (search && !ev.title.toLowerCase().includes(search.toLowerCase())) continue;
      const arr = map.get(ev.date) ?? [];
      arr.push(ev);
      map.set(ev.date, arr);
    }
    return map;
  }, [events, filters, search]);

  const selectedEvents = eventsByDate.get(selectedIso) ?? [];
  const selectedDate = isoToDate(selectedIso);
  const selJ = gregorianToJalali(selectedDate);
  const selWeekday = PERSIAN_WEEKDAYS_LONG[persianDayOfWeek(selectedDate)];

  // Navigation
  function navMonth(delta: number) {
    if (mode === "jalali") {
      const n = addJalaliMonth(jy, jm, delta);
      setJy(n.jy);
      setJm(n.jm);
    } else {
      let total = gy * 12 + (gm - 1) + delta;
      setGy(Math.floor(total / 12));
      setGm((total % 12) + 1);
    }
  }

  function goToday() {
    setJy(todayJ.jy);
    setJm(todayJ.jm);
    setGy(today.getFullYear());
    setGm(today.getMonth() + 1);
    setSelectedIso(todayIso);
  }

  function toggleMode() {
    // Keep the currently displayed period roughly aligned
    if (mode === "jalali") {
      const mid = isoToDate(cells[15]?.iso ?? todayIso);
      setGy(mid.getFullYear());
      setGm(mid.getMonth() + 1);
      setMode("gregorian");
    } else {
      const mid = isoToDate(cells[15]?.iso ?? todayIso);
      const mj = gregorianToJalali(mid);
      setJy(mj.jy);
      setJm(mj.jm);
      setMode("jalali");
    }
  }

  const headerMain =
    mode === "jalali"
      ? `${PERSIAN_MONTHS[jm - 1]} ${toFaDigits(jy)}`
      : `${GREGORIAN_MONTHS[gm - 1]} ${gy}`;

  const headerSub = useMemo(() => {
    if (mode === "jalali") {
      const mid = isoToDate(cells[15]?.iso ?? todayIso);
      const gMonthsInView = new Set(cells.filter((c) => c.inCurrentMonth).map((c) => c.gm));
      const arr = [...gMonthsInView].sort((a, b) => a - b);
      const names = arr.map((m) => GREGORIAN_MONTHS[m - 1]).join(" - ");
      return `${names} ${mid.getFullYear()}`;
    }
    const first = cells.find((c) => c.inCurrentMonth)!;
    return `${PERSIAN_MONTHS[first.jm - 1]} ${toFaDigits(first.jy)}`;
  }, [mode, cells, todayIso]);

  function openNew(iso: string) {
    setSelectedIso(iso);
    setEditing(null);
    setModalOpen(true);
  }

  function openEdit(ev: CalEvent) {
    setSelectedIso(ev.date);
    setEditing(ev);
    setModalOpen(true);
  }

  function handleSaved(ev: CalEvent) {
    setEvents((prev) => {
      const idx = prev.findIndex((e) => e.id === ev.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = ev;
        return copy;
      }
      return [...prev, ev];
    });
    setModalOpen(false);
  }

  function handleDeleted(id: number) {
    setEvents((prev) => prev.filter((e) => e.id !== id));
    setModalOpen(false);
  }

  async function toggleComplete(ev: CalEvent) {
    const optimistic = { ...ev, completed: !ev.completed };
    setEvents((prev) => prev.map((e) => (e.id === ev.id ? optimistic : e)));
    try {
      await fetch(`/api/events/${ev.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ completed: optimistic.completed }),
      });
    } catch {
      setEvents((prev) => prev.map((e) => (e.id === ev.id ? ev : e)));
    }
  }

  async function saveNote() {
    setNoteSaving(true);
    setNoteStatus("");
    try {
      await fetch(`/api/notes`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date: selectedIso, content: noteText }),
      });
      setNoteStatus("ذخیره شد ✓");
      setTimeout(() => setNoteStatus(""), 2000);
    } catch {
      setNoteStatus("خطا در ذخیره");
    } finally {
      setNoteSaving(false);
    }
  }

  // Stats
  const totalTasks = events.filter((e) => e.type === "task").length;
  const doneTasks = events.filter((e) => e.type === "task" && e.completed).length;
  const totalReminders = events.filter((e) => e.type === "reminder").length;

  const btn =
    "rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-medium text-slate-200 transition hover:bg-white/10 active:scale-95";

  return (
    <main className="mx-auto max-w-[1400px] px-4 py-6 lg:px-8">
      {/* Header */}
      <header className="glass overflow-hidden rounded-2xl border border-white/10 shadow-xl">
        <div className="relative flex flex-wrap items-center justify-between gap-4 bg-gradient-to-l from-cyan-500/10 via-transparent to-violet-500/10 p-5 sm:p-6">
          <div className="flex flex-wrap items-center gap-2">
            <button onClick={() => navMonth(-1)} className={btn}>
              ماه قبل
            </button>
            <button onClick={goToday} className={btn}>
              امروز
            </button>
            <button onClick={() => navMonth(1)} className={btn}>
              ماه بعد
            </button>
            <button
              onClick={toggleMode}
              className="rounded-xl bg-violet-600 px-4 py-2 text-sm font-bold text-white shadow-lg shadow-violet-600/30 transition hover:bg-violet-500 active:scale-95"
            >
              {mode === "jalali" ? "نمایش میلادی" : "نمایش شمسی"}
            </button>
          </div>

          <div className="text-left">
            <p className="text-sm font-medium text-cyan-300">تقویم شمسی و میلادی با داده‌های واقعی</p>
            <h1 className="mt-1 text-3xl font-black tracking-tight text-white sm:text-4xl">
              {headerMain}
            </h1>
            <p className="mt-1 text-sm text-slate-400" dir="ltr">
              {headerSub}
            </p>
          </div>
        </div>

        {/* stats bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-white/5 bg-black/20 px-6 py-3 text-sm">
          <div className="flex items-center gap-2 text-slate-300">
            <span className="inline-flex h-2 w-2 rounded-full bg-emerald-400" />
            LifeOS همگام است · {toFaDigits(events.length)} مورد در این ماه
          </div>
          <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400">
            <span>کارها: {toFaDigits(doneTasks)}/{toFaDigits(totalTasks)}</span>
            <span>یادآوری‌ها: {toFaDigits(totalReminders)}</span>
          </div>
        </div>
      </header>

      <div className="mt-5 grid grid-cols-1 gap-5 lg:grid-cols-[320px_1fr]">
        {/* Sidebar */}
        <aside className="glass h-fit rounded-2xl border border-white/10 p-5 shadow-xl lg:sticky lg:top-6">
          <div className="border-b border-white/10 pb-4">
            <h2 className="text-lg font-bold text-white">
              {toFaDigits(selJ.jd)} {PERSIAN_MONTHS[selJ.jm - 1]} {toFaDigits(selJ.jy)}
            </h2>
            <p className="mt-1 text-sm text-slate-400">{selWeekday}</p>
            <p className="text-xs text-slate-500" dir="ltr">
              {selectedDate.toLocaleDateString("en-US", {
                weekday: "long",
                day: "numeric",
                month: "long",
                year: "numeric",
              })}
            </p>
          </div>

          {/* selected day events */}
          <div className="border-b border-white/10 py-4">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-200">برنامه‌های روز</h3>
              <button
                onClick={() => openNew(selectedIso)}
                className="rounded-lg bg-cyan-500/15 px-2.5 py-1 text-xs font-medium text-cyan-300 transition hover:bg-cyan-500/25"
              >
                + افزودن
              </button>
            </div>
            {selectedEvents.length === 0 ? (
              <p className="text-sm text-slate-500">موردی برای این روز ثبت نشده است.</p>
            ) : (
              <ul className="space-y-2">
                {selectedEvents
                  .slice()
                  .sort((a, b) => (a.time || "").localeCompare(b.time || ""))
                  .map((ev) => {
                    const c = EVENT_COLORS[ev.color] ?? EVENT_COLORS.cyan;
                    return (
                      <li
                        key={ev.id}
                        className={`group flex items-start gap-2 rounded-xl border border-white/10 ${c.bg} p-2.5`}
                      >
                        <button
                          onClick={() => toggleComplete(ev)}
                          className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md border transition ${
                            ev.completed
                              ? "border-emerald-400 bg-emerald-500 text-slate-900"
                              : "border-white/30 hover:border-white/60"
                          }`}
                          aria-label="انجام شد"
                        >
                          {ev.completed && (
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                              <path d="M20 6 9 17l-5-5" strokeLinecap="round" strokeLinejoin="round" />
                            </svg>
                          )}
                        </button>
                        <button
                          onClick={() => openEdit(ev)}
                          className="flex-1 text-right"
                        >
                          <div
                            className={`text-sm font-medium ${
                              ev.completed ? "text-slate-500 line-through" : "text-white"
                            }`}
                          >
                            {ev.title}
                          </div>
                          <div className="mt-0.5 flex items-center gap-2 text-[11px] text-slate-400">
                            <span className={c.text}>{TYPE_LABELS[ev.type]}</span>
                            {ev.time && <span dir="ltr">{ev.time}</span>}
                            {ev.priority === "high" && (
                              <span className="text-rose-400">● مهم</span>
                            )}
                          </div>
                        </button>
                      </li>
                    );
                  })}
              </ul>
            )}
          </div>

          {/* Note */}
          <div className="pt-4">
            <h3 className="mb-2 text-sm font-bold text-slate-200">یادداشت این روز</h3>
            <textarea
              value={noteText}
              onChange={(e) => setNoteText(e.target.value)}
              placeholder="قرار، حس‌وحال یا نکته‌ای از این روز..."
              rows={4}
              className="w-full resize-none rounded-xl border border-white/10 bg-black/30 px-3 py-2.5 text-sm text-white outline-none transition focus:border-cyan-400/50"
            />
            <div className="mt-2 flex items-center justify-between">
              <span className="text-xs text-emerald-400">{noteStatus || "\u00A0"}</span>
              <button
                onClick={saveNote}
                disabled={noteSaving}
                className="rounded-xl bg-cyan-500 px-4 py-2 text-sm font-bold text-slate-900 transition hover:bg-cyan-400 disabled:opacity-50"
              >
                {noteSaving ? "..." : "ذخیرهٔ یادداشت"}
              </button>
            </div>
          </div>
        </aside>

        {/* Calendar grid */}
        <section className="glass rounded-2xl border border-white/10 p-3 shadow-xl sm:p-4">
          {/* toolbar */}
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <div className="relative flex-1 min-w-[180px]">
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="جستجو در رویدادها..."
                className="w-full rounded-xl border border-white/10 bg-black/30 px-4 py-2 text-sm text-white outline-none transition focus:border-cyan-400/50"
              />
            </div>
            <div className="flex items-center gap-1.5">
              {(["task", "reminder", "event"] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setFilters((f) => ({ ...f, [t]: !f[t] }))}
                  className={`rounded-lg px-3 py-1.5 text-xs font-medium transition ${
                    filters[t]
                      ? "bg-white/10 text-white"
                      : "bg-transparent text-slate-500 line-through"
                  }`}
                >
                  {TYPE_LABELS[t]}
                </button>
              ))}
            </div>
          </div>

          {/* weekday header */}
          <div className="grid grid-cols-7 gap-1.5">
            {PERSIAN_WEEKDAYS_SHORT.map((w, i) => (
              <div
                key={w}
                className={`pb-2 text-center text-xs font-bold ${
                  i === 6 ? "text-rose-400/80" : "text-slate-400"
                }`}
              >
                {w}
              </div>
            ))}
          </div>

          {/* days */}
          <div className="grid grid-cols-7 gap-1.5">
            {cells.map((cell) => {
              const dayEvents = eventsByDate.get(cell.iso) ?? [];
              const isSelected = cell.iso === selectedIso;
              const bigNum = mode === "jalali" ? cell.jd : cell.gd;
              const smallDate =
                mode === "jalali"
                  ? `${cell.gm}/${cell.gd}`
                  : `${toFaDigits(cell.jm)}/${toFaDigits(cell.jd)}`;
              return (
                <div
                  key={cell.iso}
                  onClick={() => setSelectedIso(cell.iso)}
                  onDoubleClick={() => openNew(cell.iso)}
                  className={`group relative min-h-[92px] cursor-pointer rounded-xl border p-1.5 transition sm:min-h-[104px] ${
                    isSelected
                      ? "border-violet-400/60 bg-violet-500/15 ring-1 ring-violet-400/40"
                      : cell.isToday
                        ? "border-cyan-400/40 bg-cyan-500/10"
                        : "border-white/5 bg-white/[0.02] hover:border-white/15 hover:bg-white/[0.05]"
                  } ${!cell.inCurrentMonth ? "opacity-40" : ""}`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex flex-col items-end">
                      <span
                        className={`text-base font-bold leading-none ${
                          cell.isToday
                            ? "text-cyan-300"
                            : cell.isHoliday
                              ? "text-rose-400"
                              : "text-slate-200"
                        }`}
                      >
                        {toFaDigits(bigNum)}
                      </span>
                      <span className="mt-1 text-[10px] text-slate-500" dir={mode === "jalali" ? "ltr" : "rtl"}>
                        {smallDate}
                      </span>
                    </div>
                    {cell.isToday && (
                      <span className="rounded-md bg-cyan-500 px-1.5 py-0.5 text-[9px] font-bold text-slate-900">
                        امروز
                      </span>
                    )}
                  </div>

                  {cell.occasion && (
                    <div className="mt-1 truncate text-[10px] text-rose-300/90" title={cell.occasion}>
                      {cell.occasion}
                    </div>
                  )}

                  <div className="mt-1 space-y-0.5">
                    {dayEvents.slice(0, 3).map((ev) => {
                      const c = EVENT_COLORS[ev.color] ?? EVENT_COLORS.cyan;
                      return (
                        <div
                          key={ev.id}
                          onClick={(e) => {
                            e.stopPropagation();
                            openEdit(ev);
                          }}
                          className={`flex items-center gap-1 rounded px-1 py-0.5 text-[10px] ${c.bg} ${
                            ev.completed ? "opacity-50" : ""
                          }`}
                        >
                          <span className={`h-1.5 w-1.5 shrink-0 rounded-full ${c.dot}`} />
                          <span
                            className={`truncate ${
                              ev.completed ? "text-slate-500 line-through" : "text-slate-200"
                            }`}
                          >
                            {ev.title}
                          </span>
                        </div>
                      );
                    })}
                    {dayEvents.length > 3 && (
                      <div className="px-1 text-[10px] text-slate-400">
                        +{toFaDigits(dayEvents.length - 3)} مورد دیگر
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* legend */}
          <div className="mt-4 flex flex-wrap items-center justify-end gap-4 border-t border-white/5 pt-3 text-xs text-slate-400">
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-cyan-400" /> کار
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-amber-400" /> یادآوری
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-violet-400" /> رویداد
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-rose-400" /> مناسبت / تعطیل
            </span>
            <span className="text-slate-500">دابل‌کلیک روی روز = افزودن سریع</span>
          </div>
        </section>
      </div>

      {loading && (
        <div className="pointer-events-none fixed bottom-4 left-4 rounded-lg bg-black/70 px-3 py-1.5 text-xs text-slate-300">
          در حال بارگذاری...
        </div>
      )}

      {modalOpen && (
        <EventModal
          dateIso={selectedIso}
          event={editing}
          onClose={() => setModalOpen(false)}
          onSaved={handleSaved}
          onDeleted={handleDeleted}
        />
      )}
    </main>
  );
}
