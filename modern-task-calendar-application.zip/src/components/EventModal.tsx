"use client";

import { useEffect, useState } from "react";
import {
  CalEvent,
  EventType,
  Priority,
  EVENT_COLORS,
  TYPE_LABELS,
  TYPE_DEFAULT_COLOR,
  PRIORITY_LABELS,
} from "@/lib/types";
import { gregorianToJalali, PERSIAN_MONTHS, toFaDigits, isoToDate } from "@/lib/jalali";

type Props = {
  dateIso: string;
  event: CalEvent | null; // null = new
  onClose: () => void;
  onSaved: (ev: CalEvent) => void;
  onDeleted: (id: number) => void;
};

const COLORS = ["cyan", "amber", "violet", "emerald", "rose", "blue"];

export default function EventModal({ dateIso, event, onClose, onSaved, onDeleted }: Props) {
  const [title, setTitle] = useState(event?.title ?? "");
  const [description, setDescription] = useState(event?.description ?? "");
  const [type, setType] = useState<EventType>(event?.type ?? "task");
  const [time, setTime] = useState(event?.time ?? "");
  const [color, setColor] = useState(event?.color ?? "cyan");
  const [priority, setPriority] = useState<Priority>(event?.priority ?? "normal");
  const [remind, setRemind] = useState<string>(
    event?.remindMinutes != null ? String(event.remindMinutes) : "",
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const j = gregorianToJalali(isoToDate(dateIso));
  const jalaliLabel = `${toFaDigits(j.jd)} ${PERSIAN_MONTHS[j.jm - 1]} ${toFaDigits(j.jy)}`;

  function pickType(t: EventType) {
    setType(t);
    // only change color if user hasn't diverged from a default
    if (COLORS.includes(color) && Object.values(TYPE_DEFAULT_COLOR).includes(color)) {
      setColor(TYPE_DEFAULT_COLOR[t]);
    }
  }

  async function save() {
    if (!title.trim()) {
      setError("عنوان را وارد کنید");
      return;
    }
    setSaving(true);
    setError("");
    try {
      const payload = {
        title: title.trim(),
        description,
        date: dateIso,
        time,
        type,
        color,
        priority,
        remindMinutes: remind === "" ? null : Number(remind),
      };
      const res = event
        ? await fetch(`/api/events/${event.id}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          })
        : await fetch(`/api/events`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "خطا");
      onSaved(data.event);
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطا در ذخیره");
    } finally {
      setSaving(false);
    }
  }

  async function remove() {
    if (!event) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/events/${event.id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("خطا در حذف");
      onDeleted(event.id);
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطا");
      setSaving(false);
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="glass animate-scale-in w-full max-w-lg rounded-2xl border border-white/10 p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-5 flex items-start justify-between">
          <div>
            <h2 className="text-lg font-bold text-white">
              {event ? "ویرایش" : "افزودن مورد جدید"}
            </h2>
            <p className="mt-1 text-sm text-slate-400">{jalaliLabel}</p>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 transition hover:bg-white/10 hover:text-white"
            aria-label="بستن"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M18 6 6 18M6 6l12 12" strokeLinecap="round" />
            </svg>
          </button>
        </div>

        {/* Type selector */}
        <div className="mb-4 grid grid-cols-3 gap-2">
          {(["task", "reminder", "event"] as EventType[]).map((t) => (
            <button
              key={t}
              onClick={() => pickType(t)}
              className={`rounded-xl border px-3 py-2 text-sm font-medium transition ${
                type === t
                  ? "border-cyan-400/50 bg-cyan-500/15 text-cyan-200"
                  : "border-white/10 bg-white/5 text-slate-300 hover:bg-white/10"
              }`}
            >
              {TYPE_LABELS[t]}
            </button>
          ))}
        </div>

        <input
          autoFocus
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="عنوان..."
          className="mb-3 w-full rounded-xl border border-white/10 bg-black/30 px-4 py-2.5 text-sm text-white outline-none transition focus:border-cyan-400/50"
        />

        <textarea
          value={description ?? ""}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="توضیحات (اختیاری)..."
          rows={2}
          className="mb-4 w-full resize-none rounded-xl border border-white/10 bg-black/30 px-4 py-2.5 text-sm text-white outline-none transition focus:border-cyan-400/50"
        />

        <div className="mb-4 grid grid-cols-2 gap-3">
          <div>
            <label className="mb-1.5 block text-xs text-slate-400">ساعت</label>
            <input
              type="time"
              value={time ?? ""}
              onChange={(e) => setTime(e.target.value)}
              className="w-full rounded-xl border border-white/10 bg-black/30 px-3 py-2 text-sm text-white outline-none focus:border-cyan-400/50 [color-scheme:dark]"
            />
          </div>
          <div>
            <label className="mb-1.5 block text-xs text-slate-400">اولویت</label>
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value as Priority)}
              className="w-full rounded-xl border border-white/10 bg-black/30 px-3 py-2 text-sm text-white outline-none focus:border-cyan-400/50 [color-scheme:dark]"
            >
              {(["low", "normal", "high"] as Priority[]).map((p) => (
                <option key={p} value={p}>
                  {PRIORITY_LABELS[p]}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="mb-4">
          <label className="mb-1.5 block text-xs text-slate-400">یادآوری</label>
          <select
            value={remind}
            onChange={(e) => setRemind(e.target.value)}
            className="w-full rounded-xl border border-white/10 bg-black/30 px-3 py-2 text-sm text-white outline-none focus:border-cyan-400/50 [color-scheme:dark]"
          >
            <option value="">بدون یادآوری</option>
            <option value="0">در زمان مقرر</option>
            <option value="10">۱۰ دقیقه قبل</option>
            <option value="30">۳۰ دقیقه قبل</option>
            <option value="60">۱ ساعت قبل</option>
            <option value="1440">۱ روز قبل</option>
          </select>
        </div>

        <div className="mb-5">
          <label className="mb-2 block text-xs text-slate-400">رنگ</label>
          <div className="flex gap-2">
            {COLORS.map((c) => (
              <button
                key={c}
                onClick={() => setColor(c)}
                className={`h-8 w-8 rounded-full ${EVENT_COLORS[c].dot} transition ${
                  color === c ? "ring-2 ring-white ring-offset-2 ring-offset-[#0b1120]" : "opacity-60"
                }`}
                aria-label={c}
              />
            ))}
          </div>
        </div>

        {error && <p className="mb-3 text-sm text-rose-400">{error}</p>}

        <div className="flex items-center gap-2">
          <button
            onClick={save}
            disabled={saving}
            className="flex-1 rounded-xl bg-cyan-500 py-2.5 text-sm font-bold text-slate-900 transition hover:bg-cyan-400 disabled:opacity-50"
          >
            {saving ? "در حال ذخیره..." : "ذخیره"}
          </button>
          {event && (
            <button
              onClick={remove}
              disabled={saving}
              className="rounded-xl border border-rose-500/40 bg-rose-500/10 px-4 py-2.5 text-sm font-medium text-rose-300 transition hover:bg-rose-500/20 disabled:opacity-50"
            >
              حذف
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
