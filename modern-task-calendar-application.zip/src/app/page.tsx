import Calendar from "@/components/Calendar";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-[radial-gradient(1200px_600px_at_80%_-10%,rgba(56,189,248,0.08),transparent),radial-gradient(1000px_500px_at_10%_10%,rgba(139,92,246,0.08),transparent)]">
      <Calendar />
    </div>
  );
}
