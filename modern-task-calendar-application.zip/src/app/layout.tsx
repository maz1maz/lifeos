import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Vazirmatn } from "next/font/google";
import "./globals.css";

const vazir = Vazirmatn({
  subsets: ["arabic", "latin"],
  variable: "--font-vazir",
  display: "swap",
});

export const metadata: Metadata = {
  title: "تقویم حرفه‌ای | LifeOS",
  description: "تقویم شمسی و میلادی حرفه‌ای با مدیریت کار، یادآوری و یادداشت روزانه.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl" className={vazir.variable}>
      <body className="min-h-screen bg-[#070b18] font-sans text-slate-100 antialiased">
        {children}
      </body>
    </html>
  );
}
