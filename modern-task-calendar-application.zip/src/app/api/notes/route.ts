import { db } from "@/db";
import { notes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const date = searchParams.get("date");
  if (!date) return Response.json({ error: "date is required" }, { status: 400 });
  try {
    const [row] = await db.select().from(notes).where(eq(notes.date, date));
    return Response.json({ note: row ?? null });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "failed to load note" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { date, content } = body;
    if (!date) return Response.json({ error: "date is required" }, { status: 400 });

    const [existing] = await db.select().from(notes).where(eq(notes.date, date));
    if (existing) {
      const [row] = await db
        .update(notes)
        .set({ content: content ?? "", updatedAt: new Date() })
        .where(eq(notes.date, date))
        .returning();
      return Response.json({ note: row });
    }
    const [row] = await db
      .insert(notes)
      .values({ date, content: content ?? "" })
      .returning();
    return Response.json({ note: row }, { status: 201 });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "failed to save note" }, { status: 500 });
  }
}
