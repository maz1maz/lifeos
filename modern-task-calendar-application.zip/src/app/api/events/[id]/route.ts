import { db } from "@/db";
import { events } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const numId = Number(id);
  if (!Number.isFinite(numId)) {
    return Response.json({ error: "invalid id" }, { status: 400 });
  }
  try {
    const body = await req.json();
    const allowed: Record<string, unknown> = {};
    for (const key of [
      "title",
      "description",
      "date",
      "time",
      "type",
      "color",
      "priority",
      "completed",
      "remindMinutes",
    ]) {
      if (key in body) allowed[key] = body[key];
    }
    if (Object.keys(allowed).length === 0) {
      return Response.json({ error: "nothing to update" }, { status: 400 });
    }
    const [row] = await db.update(events).set(allowed).where(eq(events.id, numId)).returning();
    if (!row) return Response.json({ error: "not found" }, { status: 404 });
    return Response.json({ event: row });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "failed to update event" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const numId = Number(id);
  if (!Number.isFinite(numId)) {
    return Response.json({ error: "invalid id" }, { status: 400 });
  }
  try {
    const [row] = await db.delete(events).where(eq(events.id, numId)).returning();
    if (!row) return Response.json({ error: "not found" }, { status: 404 });
    return Response.json({ ok: true });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "failed to delete event" }, { status: 500 });
  }
}
