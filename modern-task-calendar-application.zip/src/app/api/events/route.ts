import { db } from "@/db";
import { events } from "@/db/schema";
import { and, gte, lte, asc } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const from = searchParams.get("from");
  const to = searchParams.get("to");

  try {
    let rows;
    if (from && to) {
      rows = await db
        .select()
        .from(events)
        .where(and(gte(events.date, from), lte(events.date, to)))
        .orderBy(asc(events.date), asc(events.time));
    } else {
      rows = await db.select().from(events).orderBy(asc(events.date), asc(events.time));
    }
    return Response.json({ events: rows });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "failed to load events" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { title, description, date, time, type, color, priority, remindMinutes } = body;
    if (!title || !date) {
      return Response.json({ error: "title and date are required" }, { status: 400 });
    }
    const [row] = await db
      .insert(events)
      .values({
        title: String(title).slice(0, 500),
        description: description ? String(description) : "",
        date,
        time: time || "",
        type: type || "task",
        color: color || "cyan",
        priority: priority || "normal",
        remindMinutes: remindMinutes ?? null,
      })
      .returning();
    return Response.json({ event: row }, { status: 201 });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "failed to create event" }, { status: 500 });
  }
}
