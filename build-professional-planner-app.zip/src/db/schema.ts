import { boolean, date, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";

export const tasks = pgTable("tasks", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  dueDate: date("due_date"),
  dueTime: text("due_time"),
  priority: text("priority").notNull().default("medium"),
  repeat: text("repeat").notNull().default("none"),
  tags: text("tags").notNull().default(""),
  reminderEnabled: boolean("reminder_enabled").notNull().default(false),
  reminderAt: timestamp("reminder_at"),
  completed: boolean("completed").notNull().default(false),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export type TaskRow = typeof tasks.$inferSelect;
