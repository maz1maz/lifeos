export function faDigits(input: string | number): string {
  return String(input).replace(/\d/g, (d) => String.fromCharCode(0x06f0 + Number(d)));
}

export function toISODate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function todayISO(): string {
  return toISODate(new Date());
}

export function parseISODate(iso: string): Date {
  const parts = iso.split("-").map(Number);
  const y = parts[0] ?? 1970;
  const m = parts[1] ?? 1;
  const d = parts[2] ?? 1;
  return new Date(y, m - 1, d);
}

export function addDaysISO(iso: string, days: number): string {
  const d = parseISODate(iso);
  d.setDate(d.getDate() + days);
  return toISODate(d);
}

export function addMonthsISO(iso: string, months: number): string {
  const d = parseISODate(iso);
  d.setMonth(d.getMonth() + months);
  return toISODate(d);
}

export function shiftISOByRepeat(iso: string, repeat: string): string {
  if (repeat === "daily") return addDaysISO(iso, 1);
  if (repeat === "weekly") return addDaysISO(iso, 7);
  if (repeat === "monthly") return addMonthsISO(iso, 1);
  return iso;
}

export function daysFromToday(iso: string): number {
  const a = parseISODate(iso).getTime();
  const b = parseISODate(todayISO()).getTime();
  return Math.round((a - b) / 86400000);
}

const fullFmt = new Intl.DateTimeFormat("fa-IR", {
  weekday: "long",
  day: "numeric",
  month: "long",
  year: "numeric",
});
const shortFmt = new Intl.DateTimeFormat("fa-IR", { day: "numeric", month: "long" });
const timeFmt = new Intl.DateTimeFormat("fa-IR", { hour: "2-digit", minute: "2-digit" });

export function jalaliFull(iso: string): string {
  return fullFmt.format(parseISODate(iso));
}

export function jalaliShort(iso: string): string {
  return shortFmt.format(parseISODate(iso));
}

export function jalaliToday(): string {
  return fullFmt.format(new Date());
}

export function faTime(hhmm: string | null): string {
  if (!hhmm) return "";
  const parts = hhmm.split(":").map(Number);
  const d = new Date();
  d.setHours(parts[0] ?? 0, parts[1] ?? 0, 0, 0);
  return timeFmt.format(d);
}

export function formatReminder(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return `${shortFmt.format(d)}، ${timeFmt.format(d)}`;
}

export function dueLabel(iso: string): string {
  const diff = daysFromToday(iso);
  if (diff === 0) return "امروز";
  if (diff === 1) return "فردا";
  if (diff === -1) return "دیروز";
  return jalaliShort(iso);
}

export function isOverdue(dueDate: string | null, completed: boolean): boolean {
  return !completed && !!dueDate && daysFromToday(dueDate) < 0;
}

export function toLocalInputParts(iso: string | null): { date: string; time: string } {
  if (!iso) return { date: "", time: "" };
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return { date: "", time: "" };
  const time = `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
  return { date: toISODate(d), time };
}
