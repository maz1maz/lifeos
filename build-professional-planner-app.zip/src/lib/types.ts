export type Priority = "low" | "medium" | "high";
export type Repeat = "none" | "daily" | "weekly" | "monthly";

export interface Task {
  id: string;
  title: string;
  description: string | null;
  dueDate: string | null;
  dueTime: string | null;
  priority: Priority;
  repeat: Repeat;
  tags: string;
  reminderEnabled: boolean;
  reminderAt: string | null;
  completed: boolean;
  completedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface TaskPayload {
  title: string;
  description: string | null;
  dueDate: string | null;
  dueTime: string | null;
  priority: Priority;
  repeat: Repeat;
  tags: string;
  reminderEnabled: boolean;
  reminderAt: string | null;
}

export type FilterKey = "open" | "today" | "reminders" | "done" | "all";
export type SortKey = "due" | "priority" | "created";

export const PRIORITY_LABELS: Record<Priority, string> = {
  low: "کم",
  medium: "متوسط",
  high: "زیاد",
};

export const REPEAT_LABELS: Record<Repeat, string> = {
  none: "بدون تکرار",
  daily: "روزانه",
  weekly: "هفتگی",
  monthly: "ماهانه",
};
