import type { TaskRow } from "@/db/schema";
import type { Priority, Repeat, Task } from "./types";

const PRIORITIES: Priority[] = ["low", "medium", "high"];
const REPEATS: Repeat[] = ["none", "daily", "weekly", "monthly"];

export function serializeTask(row: TaskRow): Task {
  return {
    id: row.id,
    title: row.title,
    description: row.description,
    dueDate: row.dueDate,
    dueTime: row.dueTime,
    priority: PRIORITIES.includes(row.priority as Priority)
      ? (row.priority as Priority)
      : "medium",
    repeat: REPEATS.includes(row.repeat as Repeat) ? (row.repeat as Repeat) : "none",
    tags: row.tags,
    reminderEnabled: row.reminderEnabled,
    reminderAt: row.reminderAt ? row.reminderAt.toISOString() : null,
    completed: row.completed,
    completedAt: row.completedAt ? row.completedAt.toISOString() : null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}
