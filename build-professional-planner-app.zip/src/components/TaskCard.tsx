"use client";

import type { ReactNode } from "react";
import type { Task } from "@/lib/types";
import { PRIORITY_LABELS, REPEAT_LABELS } from "@/lib/types";
import {
  dueLabel,
  faDigits,
  faTime,
  formatReminder,
  isOverdue,
} from "@/lib/format";
import {
  IconAlert,
  IconBell,
  IconCalendar,
  IconCheck,
  IconClock,
  IconHash,
  IconPencil,
  IconRepeat,
  IconTrash,
} from "./icons";

interface Props {
  task: Task;
  index: number;
  onToggle: (task: Task) => void;
  onEdit: (task: Task) => void;
  onDelete: (task: Task) => void;
}

function Chip({
  children,
  tone = "neutral",
}: {
  children: ReactNode;
  tone?: "neutral" | "teal" | "rose" | "amber" | "sky";
}) {
  const tones: Record<string, string> = {
    neutral: "border-line bg-night-750 text-fog-300",
    teal: "border-teal-400/25 bg-teal-400/10 text-teal-200",
    rose: "border-rose-400/25 bg-rose-500/10 text-rose-300",
    amber: "border-amber-400/25 bg-amber-400/10 text-amber-200",
    sky: "border-sky-400/25 bg-sky-400/10 text-sky-200",
  };
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-md border px-2 py-1 text-xs leading-4 ${tones[tone]}`}
    >
      {children}
    </span>
  );
}

const PRIORITY_TONE: Record<Task["priority"], "rose" | "amber" | "sky"> = {
  high: "rose",
  medium: "amber",
  low: "sky",
};

export default function TaskCard({ task, index, onToggle, onEdit, onDelete }: Props) {
  const overdue = isOverdue(task.dueDate, task.completed);
  const todayish = !task.completed && task.dueDate !== null && dueLabel(task.dueDate) === "امروز";
  const tags = task.tags
    .split(",")
    .map((t) => t.trim())
    .filter(Boolean);

  return (
    <li
      className="animate-rise-in group rounded-xl border border-line bg-night-850/90 p-4 transition hover:border-line-strong hover:bg-night-800/90 sm:p-5"
      style={{ animationDelay: `${Math.min(index, 8) * 40}ms` }}
    >
      <div className="flex items-start gap-3.5">
        <button
          type="button"
          role="checkbox"
          aria-checked={task.completed}
          aria-label={task.completed ? "بازگرداندن کار به حالت باز" : "انجام شد"}
          onClick={() => onToggle(task)}
          className={`mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full border-2 transition-all ${
            task.completed
              ? "animate-check-pop border-teal-400 bg-teal-400 text-night-950"
              : "border-fog-500/70 text-transparent hover:border-teal-300 hover:bg-teal-400/10"
          }`}
        >
          {task.completed && <IconCheck className="animate-draw-stroke h-3.5 w-3.5" strokeWidth={3} />}
        </button>

        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-3">
            <h3
              className={`min-w-0 break-words text-base font-semibold leading-7 transition ${
                task.completed ? "text-fog-400 line-through decoration-fog-500/60" : "text-fog-50"
              }`}
            >
              {task.title}
            </h3>
            <div className="flex shrink-0 gap-1 opacity-100 transition sm:opacity-0 sm:group-hover:opacity-100 sm:group-focus-within:opacity-100">
              <button
                type="button"
                onClick={() => onEdit(task)}
                aria-label="ویرایش کار"
                className="rounded-lg p-2 text-fog-400 transition hover:bg-night-750 hover:text-teal-200"
              >
                <IconPencil className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => onDelete(task)}
                aria-label="حذف کار"
                className="rounded-lg p-2 text-fog-400 transition hover:bg-rose-500/10 hover:text-rose-300"
              >
                <IconTrash className="h-4 w-4" />
              </button>
            </div>
          </div>

          {task.description && (
            <p className={`mt-1 break-words text-sm leading-6 ${task.completed ? "text-fog-500 line-through" : "text-fog-300"}`}>
              {task.description}
            </p>
          )}

          <div className="mt-3 flex flex-wrap items-center gap-2">
            {task.dueDate && (
              <Chip tone={overdue ? "rose" : todayish ? "teal" : "neutral"}>
                {overdue ? (
                  <IconAlert className="h-3.5 w-3.5" />
                ) : (
                  <IconCalendar className="h-3.5 w-3.5" />
                )}
                {overdue ? `عقب‌افتاده · ${dueLabel(task.dueDate)}` : dueLabel(task.dueDate)}
              </Chip>
            )}
            {task.dueTime && (
              <Chip>
                <IconClock className="h-3.5 w-3.5" />
                {faTime(task.dueTime)}
              </Chip>
            )}
            <Chip tone={PRIORITY_TONE[task.priority]}>
              <span className="h-1.5 w-1.5 rounded-full bg-current" />
              اولویت {PRIORITY_LABELS[task.priority]}
            </Chip>
            {task.repeat !== "none" && (
              <Chip tone="sky">
                <IconRepeat className="h-3.5 w-3.5" />
                {REPEAT_LABELS[task.repeat]}
              </Chip>
            )}
            {task.reminderEnabled && task.reminderAt && (
              <Chip tone="amber">
                <IconBell className="h-3.5 w-3.5" />
                یادآوری {formatReminder(task.reminderAt)}
              </Chip>
            )}
            {tags.map((tag) => (
              <Chip key={tag}>
                <IconHash className="h-3 w-3" />
                {faDigits(tag)}
              </Chip>
            ))}
          </div>
        </div>
      </div>
    </li>
  );
}
