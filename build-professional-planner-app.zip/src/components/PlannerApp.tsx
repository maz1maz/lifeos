"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import type { FilterKey, SortKey, Task, TaskPayload } from "@/lib/types";
import { faDigits, jalaliToday, todayISO } from "@/lib/format";
import { useToast } from "./toast";
import TaskCard from "./TaskCard";
import TaskFormDrawer from "./TaskFormDrawer";
import ConfirmDialog from "./ConfirmDialog";
import {
  IconAlert,
  IconBell,
  IconCalendar,
  IconCheckCircle,
  IconChevronDown,
  IconCircleDot,
  IconClipboard,
  IconInbox,
  IconPlus,
  IconSearch,
  IconSun,
} from "./icons";

const HEADERS = { "Content-Type": "application/json" } as const;

const PRIORITY_RANK: Record<Task["priority"], number> = { high: 0, medium: 1, low: 2 };

const FILTERS: { key: FilterKey; label: string }[] = [
  { key: "open", label: "باز" },
  { key: "today", label: "امروز" },
  { key: "reminders", label: "یادآوری‌ها" },
  { key: "done", label: "انجام‌شده" },
  { key: "all", label: "همه" },
];

function dueSortValue(t: Task): number {
  if (!t.dueDate) return Number.MAX_SAFE_INTEGER - 1;
  const base = new Date(`${t.dueDate}T${t.dueTime ?? "23:59"}`).getTime();
  return Number.isNaN(base) ? Number.MAX_SAFE_INTEGER - 1 : base;
}

export default function PlannerApp() {
  const { push } = useToast();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<FilterKey>("open");
  const [sort, setSort] = useState<SortKey>("due");
  const [query, setQuery] = useState("");
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [editing, setEditing] = useState<Task | null>(null);
  const [deleting, setDeleting] = useState<Task | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/tasks");
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "خطا در دریافت داده‌ها");
      setTasks(data.tasks as Task[]);
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطای ناشناخته");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const stats = useMemo(() => {
    const today = todayISO();
    return {
      open: tasks.filter((t) => !t.completed).length,
      today: tasks.filter((t) => !t.completed && t.dueDate === today).length,
      reminders: tasks.filter((t) => !t.completed && t.reminderEnabled).length,
      done: tasks.filter((t) => t.completed).length,
    };
  }, [tasks]);

  const counts = useMemo<Record<FilterKey, number>>(() => {
    const today = todayISO();
    return {
      open: tasks.filter((t) => !t.completed).length,
      today: tasks.filter((t) => !t.completed && t.dueDate === today).length,
      reminders: tasks.filter((t) => !t.completed && t.reminderEnabled).length,
      done: tasks.filter((t) => t.completed).length,
      all: tasks.length,
    };
  }, [tasks]);

  const visible = useMemo(() => {
    const today = todayISO();
    const q = query.trim();
    let list = tasks;
    if (filter === "open") list = list.filter((t) => !t.completed);
    else if (filter === "today") list = list.filter((t) => !t.completed && t.dueDate === today);
    else if (filter === "reminders") list = list.filter((t) => !t.completed && t.reminderEnabled);
    else if (filter === "done") list = list.filter((t) => t.completed);
    if (q) {
      list = list.filter(
        (t) =>
          t.title.includes(q) ||
          (t.description ?? "").includes(q) ||
          t.tags.includes(q),
      );
    }
    const sorted = [...list];
    if (sort === "created") {
      sorted.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
    } else if (sort === "priority") {
      sorted.sort(
        (a, b) =>
          PRIORITY_RANK[a.priority] - PRIORITY_RANK[b.priority] ||
          dueSortValue(a) - dueSortValue(b),
      );
    } else {
      sorted.sort((a, b) => {
        const doneDiff = Number(a.completed) - Number(b.completed);
        if (doneDiff !== 0) return doneDiff;
        return dueSortValue(a) - dueSortValue(b);
      });
    }
    return sorted;
  }, [tasks, filter, sort, query]);

  async function handleSubmit(payload: TaskPayload) {
    try {
      if (editing) {
        const res = await fetch(`/api/tasks/${editing.id}`, {
          method: "PATCH",
          headers: HEADERS,
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error ?? "خطا در ذخیرهٔ تغییرات");
        setTasks((prev) => prev.map((t) => (t.id === editing.id ? (data.task as Task) : t)));
        push("success", "تغییرات با موفقیت ذخیره شد");
      } else {
        const res = await fetch("/api/tasks", {
          method: "POST",
          headers: HEADERS,
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error ?? "خطا در ثبت کار");
        setTasks((prev) => [data.task as Task, ...prev]);
        push("success", "کار تازه ثبت شد");
      }
      setDrawerOpen(false);
      setEditing(null);
    } catch (e) {
      push("error", e instanceof Error ? e.message : "خطای ناشناخته");
      throw e;
    }
  }

  async function handleToggle(task: Task) {
    const nextCompleted = !task.completed;
    setTasks((prev) =>
      prev.map((t) => (t.id === task.id ? { ...t, completed: nextCompleted } : t)),
    );
    try {
      const res = await fetch(`/api/tasks/${task.id}`, {
        method: "PATCH",
        headers: HEADERS,
        body: JSON.stringify({ completed: nextCompleted }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "خطا در به‌روزرسانی");
      if (data.next) {
        setTasks((prev) => [data.next as Task, ...prev]);
        push("success", "انجام شد؛ نمونهٔ بعدی تکرار ساخته شد");
      } else {
        push("success", nextCompleted ? "کار انجام شد" : "کار دوباره باز شد");
      }
    } catch (e) {
      push("error", e instanceof Error ? e.message : "خطای ناشناخته");
      void load();
    }
  }

  async function handleDelete() {
    if (!deleting) return;
    setDeleteBusy(true);
    try {
      const res = await fetch(`/api/tasks/${deleting.id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("حذف ناموفق بود");
      setTasks((prev) => prev.filter((t) => t.id !== deleting.id));
      push("success", "کار حذف شد");
      setDeleting(null);
    } catch {
      push("error", "حذف کار ناموفق بود");
    } finally {
      setDeleteBusy(false);
    }
  }

  function openCreate() {
    setEditing(null);
    setDrawerOpen(true);
  }
  function openEdit(task: Task) {
    setEditing(task);
    setDrawerOpen(true);
  }

  const emptyMessage = (() => {
    if (query.trim()) return { title: "نتیجه‌ای پیدا نشد", text: `برای «${query.trim()}» موردی یافت نشد. عبارت دیگری امتحان کنید.` };
    if (tasks.length === 0)
      return { title: "هنوز کاری ثبت نشده", text: "نخستین کار خود را بسازید تا برنامه‌ریزی آغاز شود." };
    if (filter === "open") return { title: "کاری باز نیست", text: "همهٔ کارها انجام شده‌اند یا فهرست خالی است." };
    if (filter === "today") return { title: "برای امروز کاری ندارید", text: "سررسید هیچ کار بازی روی امروز تنظیم نشده است." };
    if (filter === "reminders") return { title: "یادآوری فعالی نیست", text: "هیچ کار بازی یادآوری فعال ندارد." };
    if (filter === "done") return { title: "هنوز کاری انجام نشده", text: "پس از انجام کارها، اینجا نمایش داده می‌شوند." };
    return { title: "فهرست خالی است", text: "هنوز هیچ کاری ثبت نشده است." };
  })();

  const statCards = [
    { label: "کار باز", value: stats.open, icon: <IconCircleDot className="h-5 w-5" />, tone: "border-teal-400/25 bg-teal-400/10 text-teal-300" },
    { label: "سررسید امروز", value: stats.today, icon: <IconSun className="h-5 w-5" />, tone: "border-amber-400/25 bg-amber-400/10 text-amber-300" },
    { label: "یادآوری فعال", value: stats.reminders, icon: <IconBell className="h-5 w-5" />, tone: "border-sky-400/25 bg-sky-400/10 text-sky-300" },
    { label: "انجام‌شده", value: stats.done, icon: <IconCheckCircle className="h-5 w-5" />, tone: "border-fog-500/25 bg-fog-500/10 text-fog-300" },
  ];

  return (
    <div className="mx-auto w-full max-w-6xl px-4 pb-20 pt-8 sm:px-6 lg:pt-10">
      <header className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="grid h-12 w-12 place-items-center rounded-2xl border border-teal-400/30 bg-teal-400/10 text-teal-300 shadow-lg shadow-teal-400/5">
            <IconClipboard className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold tracking-tight text-fog-50 sm:text-3xl">
              پلنر حرفه‌ای
            </h1>
            <p className="mt-1 text-sm text-fog-400">
              کارها و یادآوری‌ها، با ذخیره‌سازی واقعی در پایگاه داده
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 rounded-xl border border-line bg-night-850 px-4 py-2.5 text-sm text-fog-300">
          <IconCalendar className="h-4 w-4 text-teal-300" />
          {jalaliToday()}
        </div>
      </header>

      <section className="mt-7 grid grid-cols-2 gap-3 lg:grid-cols-4" aria-label="آمار">
        {statCards.map((s) => (
          <div
            key={s.label}
            className="flex items-center gap-3.5 rounded-xl border border-line bg-night-850/90 p-4"
          >
            <div className={`grid h-10 w-10 shrink-0 place-items-center rounded-lg border ${s.tone}`}>
              {s.icon}
            </div>
            <div className="min-w-0">
              <p className="text-2xl font-extrabold leading-7 text-fog-50">{faDigits(s.value)}</p>
              <p className="truncate text-xs text-fog-400">{s.label}</p>
            </div>
          </div>
        ))}
      </section>

      <section className="mt-7 flex flex-wrap items-center gap-3">
        <div className="relative min-w-[220px] flex-1">
          <IconSearch className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-fog-500" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="جستجو در عنوان، توضیحات یا برچسب‌ها…"
            aria-label="جستجو"
            className="w-full rounded-xl border border-line bg-night-850 py-2.5 pl-3 pr-9 text-sm text-fog-100 outline-none transition placeholder:text-fog-500 focus:border-teal-400/60 focus:ring-2 focus:ring-teal-400/15"
          />
        </div>
        <div className="relative">
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as SortKey)}
            aria-label="مرتب‌سازی"
            className="appearance-none rounded-xl border border-line bg-night-850 py-2.5 pl-9 pr-3 text-sm text-fog-200 outline-none transition focus:border-teal-400/60"
          >
            <option value="due">مرتب‌سازی: سررسید</option>
            <option value="priority">مرتب‌سازی: اولویت</option>
            <option value="created">مرتب‌سازی: تازه‌ترین</option>
          </select>
          <IconChevronDown className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-fog-400" />
        </div>
        <button
          type="button"
          onClick={openCreate}
          className="flex items-center gap-2 rounded-xl bg-teal-400 px-5 py-2.5 text-sm font-bold text-night-950 shadow-lg shadow-teal-400/10 transition hover:bg-teal-300 active:scale-[0.98]"
        >
          <IconPlus className="h-4 w-4" strokeWidth={2.4} />
          کار تازه
        </button>
      </section>

      <nav className="mt-5 flex flex-wrap gap-2" aria-label="فیلترها">
        {FILTERS.map((f) => {
          const active = filter === f.key;
          return (
            <button
              key={f.key}
              type="button"
              onClick={() => setFilter(f.key)}
              className={`flex items-center gap-2 rounded-full border px-4 py-2 text-sm font-medium transition ${
                active
                  ? "border-teal-400/40 bg-teal-400/15 text-teal-200"
                  : "border-line bg-night-850 text-fog-300 hover:border-line-strong hover:text-fog-100"
              }`}
            >
              {f.label}
              <span
                className={`rounded-full px-1.5 py-0.5 text-[11px] leading-3 ${
                  active ? "bg-teal-400/20 text-teal-100" : "bg-night-750 text-fog-400"
                }`}
              >
                {faDigits(counts[f.key])}
              </span>
            </button>
          );
        })}
      </nav>

      <main className="mt-5">
        {loading ? (
          <ul className="space-y-3" aria-label="در حال بارگذاری">
            {[0, 1, 2].map((i) => (
              <li key={i} className="rounded-xl border border-line bg-night-850/70 p-5">
                <div className="flex items-start gap-3.5">
                  <div className="h-6 w-6 animate-pulse rounded-full bg-night-700" />
                  <div className="flex-1 space-y-2.5">
                    <div className="h-4 w-2/5 animate-pulse rounded bg-night-700" />
                    <div className="h-3 w-3/5 animate-pulse rounded bg-night-750" />
                    <div className="flex gap-2 pt-1">
                      <div className="h-6 w-16 animate-pulse rounded-md bg-night-750" />
                      <div className="h-6 w-20 animate-pulse rounded-md bg-night-750" />
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        ) : error ? (
          <div className="flex flex-col items-center gap-4 rounded-2xl border border-rose-400/25 bg-rose-500/5 px-6 py-14 text-center">
            <div className="grid h-12 w-12 place-items-center rounded-xl border border-rose-400/30 bg-rose-500/10 text-rose-300">
              <IconAlert className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-base font-bold text-fog-50">دریافت داده‌ها ناموفق بود</h2>
              <p className="mt-1 text-sm text-fog-400">{error}</p>
            </div>
            <button
              type="button"
              onClick={() => void load()}
              className="rounded-lg border border-line bg-night-800 px-5 py-2.5 text-sm font-medium text-fog-100 transition hover:bg-night-750"
            >
              تلاش دوباره
            </button>
          </div>
        ) : visible.length === 0 ? (
          <div className="flex flex-col items-center gap-4 rounded-2xl border border-dashed border-line-strong bg-night-900/50 px-6 py-16 text-center">
            <div className="grid h-14 w-14 place-items-center rounded-2xl border border-line bg-night-800 text-fog-400">
              <IconInbox className="h-7 w-7" />
            </div>
            <div>
              <h2 className="text-base font-bold text-fog-100">{emptyMessage.title}</h2>
              <p className="mx-auto mt-1 max-w-sm text-sm leading-6 text-fog-400">
                {emptyMessage.text}
              </p>
            </div>
            {!query.trim() && (filter === "open" || filter === "all" || tasks.length === 0) && (
              <button
                type="button"
                onClick={openCreate}
                className="flex items-center gap-2 rounded-lg bg-teal-400 px-5 py-2.5 text-sm font-bold text-night-950 transition hover:bg-teal-300"
              >
                <IconPlus className="h-4 w-4" strokeWidth={2.4} />
                افزودن کار تازه
              </button>
            )}
          </div>
        ) : (
          <>
            <p className="mb-3 text-xs text-fog-500">
              {faDigits(visible.length)} کار نمایش داده می‌شود
            </p>
            <ul className="space-y-3">
              {visible.map((t, i) => (
                <TaskCard
                  key={t.id}
                  task={t}
                  index={i}
                  onToggle={(task) => void handleToggle(task)}
                  onEdit={openEdit}
                  onDelete={setDeleting}
                />
              ))}
            </ul>
          </>
        )}
      </main>

      <footer className="mt-12 text-center text-xs text-fog-500">
        داده‌ها به‌صورت ماندگار در PostgreSQL ذخیره می‌شوند · تاریخ‌ها به تقویم شمسی
      </footer>

      <TaskFormDrawer
        open={drawerOpen}
        initial={editing}
        onClose={() => {
          setDrawerOpen(false);
          setEditing(null);
        }}
        onSubmit={handleSubmit}
      />

      <ConfirmDialog
        open={deleting !== null}
        title="حذف کار"
        message={deleting ? `«${deleting.title}» برای همیشه حذف می‌شود. ادامه می‌دهید؟` : ""}
        confirmLabel="حذف کن"
        busy={deleteBusy}
        onConfirm={() => void handleDelete()}
        onCancel={() => !deleteBusy && setDeleting(null)}
      />
    </div>
  );
}


