"use client";

import { useEffect, useState } from "react";
import type { Priority, Repeat, Task, TaskPayload } from "@/lib/types";
import { PRIORITY_LABELS, REPEAT_LABELS } from "@/lib/types";
import { toLocalInputParts, todayISO } from "@/lib/format";
import { IconChevronDown, IconSpinner, IconX } from "./icons";

interface Props {
  open: boolean;
  initial: Task | null;
  onClose: () => void;
  onSubmit: (payload: TaskPayload) => Promise<void>;
}

interface FormState {
  title: string;
  description: string;
  dueDate: string;
  dueTime: string;
  priority: Priority;
  repeat: Repeat;
  tags: string;
  reminderEnabled: boolean;
  reminderDate: string;
  reminderTime: string;
}

const EMPTY: FormState = {
  title: "",
  description: "",
  dueDate: "",
  dueTime: "",
  priority: "medium",
  repeat: "none",
  tags: "",
  reminderEnabled: false,
  reminderDate: "",
  reminderTime: "",
};

const fieldCls =
  "w-full rounded-lg border border-line bg-night-800 px-3 py-2.5 text-sm text-fog-100 placeholder:text-fog-500 outline-none transition focus:border-teal-400/60 focus:ring-2 focus:ring-teal-400/15";
const labelCls = "mb-1.5 block text-xs font-medium text-fog-300";

function SelectWrap({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative">
      {children}
      <IconChevronDown className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-fog-400" />
    </div>
  );
}

export default function TaskFormDrawer({ open, initial, onClose, onSubmit }: Props) {
  const [form, setForm] = useState<FormState>(EMPTY);
  const [errors, setErrors] = useState<{ title?: string; reminder?: string }>({});
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) return;
    if (initial) {
      const r = toLocalInputParts(initial.reminderAt);
      setForm({
        title: initial.title,
        description: initial.description ?? "",
        dueDate: initial.dueDate ?? "",
        dueTime: initial.dueTime ?? "",
        priority: initial.priority,
        repeat: initial.repeat,
        tags: initial.tags,
        reminderEnabled: initial.reminderEnabled,
        reminderDate: r.date,
        reminderTime: r.time,
      });
    } else {
      setForm(EMPTY);
    }
    setErrors({});
  }, [open, initial]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !busy) onClose();
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, busy, onClose]);

  if (!open) return null;

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const title = form.title.trim();
    const errs: { title?: string; reminder?: string } = {};
    if (!title) errs.title = "عنوان کار را بنویسید.";
    if (form.reminderEnabled && !form.reminderDate) errs.reminder = "تاریخ یادآوری الزامی است.";
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }
    setBusy(true);
    try {
      await onSubmit({
        title,
        description: form.description.trim() || null,
        dueDate: form.dueDate || null,
        dueTime: form.dueTime || null,
        priority: form.priority,
        repeat: form.repeat,
        tags: form.tags.trim(),
        reminderEnabled: form.reminderEnabled,
        reminderAt:
          form.reminderEnabled && form.reminderDate
            ? `${form.reminderDate}T${form.reminderTime || "09:00"}`
            : null,
      });
    } catch {
      // parent surfaces the error as a toast
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="fixed inset-0 z-[60]">
      <div
        className="animate-overlay-in absolute inset-0 bg-black/65 backdrop-blur-sm"
        onClick={() => !busy && onClose()}
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={initial ? "ویرایش کار" : "کار تازه"}
        className="animate-drawer-in absolute inset-y-0 right-0 flex w-full max-w-md flex-col border-l border-line bg-night-900 shadow-2xl shadow-black/60"
      >
        <header className="flex items-center justify-between border-b border-line px-5 py-4">
          <div>
            <h2 className="text-lg font-bold text-fog-50">{initial ? "ویرایش کار" : "کار تازه"}</h2>
            <p className="mt-0.5 text-xs text-fog-400">
              {initial ? "تغییرها را ذخیره کنید" : "جزئیات کار و یادآوری را وارد کنید"}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            disabled={busy}
            aria-label="بستن"
            className="rounded-lg p-2 text-fog-400 transition hover:bg-night-750 hover:text-fog-100 disabled:opacity-50"
          >
            <IconX className="h-5 w-5" />
          </button>
        </header>

        <form onSubmit={handleSubmit} className="flex min-h-0 flex-1 flex-col">
          <div className="flex-1 space-y-4 overflow-y-auto px-5 py-5">
            <div>
              <label htmlFor="tf-title" className={labelCls}>
                عنوان کار <span className="text-rose-300">*</span>
              </label>
              <input
                id="tf-title"
                autoFocus
                value={form.title}
                onChange={(e) => set("title", e.target.value)}
                placeholder="مثلاً ارسال گزارش هفتگی"
                className={`${fieldCls} ${errors.title ? "border-rose-400/60 focus:border-rose-400/70 focus:ring-rose-400/15" : ""}`}
              />
              {errors.title && <p className="mt-1.5 text-xs text-rose-300">{errors.title}</p>}
            </div>

            <div>
              <label htmlFor="tf-desc" className={labelCls}>
                توضیحات
              </label>
              <textarea
                id="tf-desc"
                rows={3}
                value={form.description}
                onChange={(e) => set("description", e.target.value)}
                placeholder="جزئیات بیشتر (اختیاری)"
                className={`${fieldCls} resize-none`}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="tf-due-date" className={labelCls}>
                  سررسید
                </label>
                <input
                  id="tf-due-date"
                  type="date"
                  value={form.dueDate}
                  onChange={(e) => set("dueDate", e.target.value)}
                  className={fieldCls}
                />
              </div>
              <div>
                <label htmlFor="tf-due-time" className={labelCls}>
                  ساعت
                </label>
                <input
                  id="tf-due-time"
                  type="time"
                  value={form.dueTime}
                  onChange={(e) => set("dueTime", e.target.value)}
                  className={fieldCls}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="tf-priority" className={labelCls}>
                  اولویت
                </label>
                <SelectWrap>
                  <select
                    id="tf-priority"
                    value={form.priority}
                    onChange={(e) => set("priority", e.target.value as Priority)}
                    className={`${fieldCls} appearance-none pl-9`}
                  >
                    {(Object.keys(PRIORITY_LABELS) as Priority[]).map((k) => (
                      <option key={k} value={k}>
                        {PRIORITY_LABELS[k]}
                      </option>
                    ))}
                  </select>
                </SelectWrap>
              </div>
              <div>
                <label htmlFor="tf-repeat" className={labelCls}>
                  تکرار
                </label>
                <SelectWrap>
                  <select
                    id="tf-repeat"
                    value={form.repeat}
                    onChange={(e) => set("repeat", e.target.value as Repeat)}
                    className={`${fieldCls} appearance-none pl-9`}
                  >
                    {(Object.keys(REPEAT_LABELS) as Repeat[]).map((k) => (
                      <option key={k} value={k}>
                        {REPEAT_LABELS[k]}
                      </option>
                    ))}
                  </select>
                </SelectWrap>
              </div>
            </div>

            <div>
              <label htmlFor="tf-tags" className={labelCls}>
                برچسب‌ها <span className="text-fog-500">(با ویرگول جدا کنید)</span>
              </label>
              <input
                id="tf-tags"
                value={form.tags}
                onChange={(e) => set("tags", e.target.value)}
                placeholder="گزارش، فوری"
                className={fieldCls}
              />
            </div>

            <div className="rounded-xl border border-line bg-night-850 p-4">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold text-fog-100">یادآوری</p>
                  <p className="mt-0.5 text-xs text-fog-400">هنگام سررسید، یادآوری ثبت می‌شود</p>
                </div>
                <button
                  type="button"
                  role="switch"
                  aria-checked={form.reminderEnabled}
                  aria-label="فعال‌سازی یادآوری"
                  onClick={() => {
                    const next = !form.reminderEnabled;
                    setForm((prev) => ({
                      ...prev,
                      reminderEnabled: next,
                      reminderDate: next && !prev.reminderDate ? prev.dueDate || todayISO() : prev.reminderDate,
                      reminderTime: next && !prev.reminderTime ? prev.dueTime || "09:00" : prev.reminderTime,
                    }));
                  }}
                  className={`relative h-6 w-11 shrink-0 rounded-full border transition-colors ${
                    form.reminderEnabled
                      ? "border-teal-400/50 bg-teal-400/80"
                      : "border-line-strong bg-night-750"
                  }`}
                >
                  <span
                    className={`absolute top-1/2 h-4 w-4 -translate-y-1/2 rounded-full bg-white shadow transition-all ${
                      form.reminderEnabled ? "right-6" : "right-1"
                    }`}
                  />
                </button>
              </div>

              {form.reminderEnabled && (
                <div className="animate-rise-in mt-4 grid grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="tf-rem-date" className={labelCls}>
                      تاریخ یادآوری <span className="text-rose-300">*</span>
                    </label>
                    <input
                      id="tf-rem-date"
                      type="date"
                      value={form.reminderDate}
                      onChange={(e) => set("reminderDate", e.target.value)}
                      className={`${fieldCls} ${errors.reminder ? "border-rose-400/60" : ""}`}
                    />
                  </div>
                  <div>
                    <label htmlFor="tf-rem-time" className={labelCls}>
                      ساعت یادآوری
                    </label>
                    <input
                      id="tf-rem-time"
                      type="time"
                      value={form.reminderTime}
                      onChange={(e) => set("reminderTime", e.target.value)}
                      className={fieldCls}
                    />
                  </div>
                  {errors.reminder && (
                    <p className="col-span-2 -mt-1 text-xs text-rose-300">{errors.reminder}</p>
                  )}
                </div>
              )}
            </div>
          </div>

          <footer className="flex gap-3 border-t border-line bg-night-850 px-5 py-4">
            <button
              type="submit"
              disabled={busy}
              className="flex flex-1 items-center justify-center gap-2 rounded-lg bg-teal-400 px-4 py-2.5 text-sm font-bold text-night-950 transition hover:bg-teal-300 active:scale-[0.99] disabled:opacity-60"
            >
              {busy && <IconSpinner className="h-4 w-4" />}
              {initial ? "ثبت تغییرات" : "ذخیرهٔ کار"}
            </button>
            <button
              type="button"
              onClick={onClose}
              disabled={busy}
              className="rounded-lg border border-line bg-night-800 px-5 py-2.5 text-sm font-medium text-fog-200 transition hover:bg-night-750 disabled:opacity-50"
            >
              انصراف
            </button>
          </footer>
        </form>
      </div>
    </div>
  );
}
