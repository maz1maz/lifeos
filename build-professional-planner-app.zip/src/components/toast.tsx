"use client";

import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { IconAlert, IconCheckCircle, IconInfo, IconX } from "./icons";

type ToastKind = "success" | "error" | "info";

interface ToastItem {
  id: string;
  kind: ToastKind;
  message: string;
}

interface ToastContextValue {
  push: (kind: ToastKind, message: string) => void;
}

const ToastContext = createContext<ToastContextValue | null>(null);

export function useToast(): ToastContextValue {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error("useToast must be used within ToastProvider");
  return ctx;
}

const KIND_STYLES: Record<ToastKind, string> = {
  success: "border-teal-400/40 text-teal-200 [&_svg]:text-teal-300",
  error: "border-rose-400/40 text-rose-200 [&_svg]:text-rose-300",
  info: "border-sky-400/40 text-sky-200 [&_svg]:text-sky-300",
};

function KindIcon({ kind }: { kind: ToastKind }) {
  const cls = "h-5 w-5 shrink-0";
  if (kind === "success") return <IconCheckCircle className={cls} />;
  if (kind === "error") return <IconAlert className={cls} />;
  return <IconInfo className={cls} />;
}

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const dismiss = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const push = useCallback(
    (kind: ToastKind, message: string) => {
      const id =
        typeof crypto !== "undefined" && "randomUUID" in crypto
          ? crypto.randomUUID()
          : `${Date.now()}-${Math.random()}`;
      setToasts((prev) => [...prev.slice(-3), { id, kind, message }]);
      window.setTimeout(() => dismiss(id), 4200);
    },
    [dismiss],
  );

  const value = useMemo(() => ({ push }), [push]);

  return (
    <ToastContext.Provider value={value}>
      {children}
      <div
        aria-live="polite"
        className="pointer-events-none fixed bottom-5 left-4 z-[80] flex w-[min(92vw,22rem)] flex-col gap-2"
      >
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`animate-toast-in pointer-events-auto flex items-start gap-3 rounded-xl border bg-night-800/95 px-4 py-3 shadow-xl shadow-black/40 backdrop-blur ${KIND_STYLES[t.kind]}`}
          >
            <KindIcon kind={t.kind} />
            <p className="flex-1 text-sm leading-6 text-fog-100">{t.message}</p>
            <button
              type="button"
              onClick={() => dismiss(t.id)}
              className="rounded-md p-1 text-fog-400 transition hover:bg-white/5 hover:text-fog-100"
              aria-label="بستن اعلان"
            >
              <IconX className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}
