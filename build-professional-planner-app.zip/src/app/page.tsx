import PlannerApp from "@/components/PlannerApp";
import { ToastProvider } from "@/components/toast";

export default function Home() {
  return (
    <ToastProvider>
      <PlannerApp />
    </ToastProvider>
  );
}
