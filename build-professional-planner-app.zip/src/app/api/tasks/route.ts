import { desc } from "drizzle-orm";
import { db } from "@/db";
import { tasks } from "@/db/schema";
import { serializeTask } from "@/lib/serialize";
import type { Priority, Repeat } from "@/lib/types";

export const dynamic = "force-dynamic";

const PRIORITIES: Priority[] = ["low", "medium", "high"];
const REPEATS: Repeat[] = ["none", "daily", "weekly", "monthly"];

function strOrNull(v: unknown): string | null {
  const s = String(v ?? "").trim();
  return s ? s : null;
}

export async function GET() {
  try {
    const rows = await db.select().from(tasks).orderBy(desc(tasks.createdAt));
    return Response.json({ tasks: rows.map(serializeTask) });
  } catch {
    return Response.json({ error: "خطا در دریافت کارها" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ error: "بدنهٔ درخواست نامعتبر است" }, { status: 400 });
  }

  const title = String(body.title ?? "").trim();
  if (!title) {
    return Response.json({ error: "عنوان کار الزامی است" }, { status: 422 });
  }

  const priority = PRIORITIES.includes(body.priority as Priority)
    ? (body.priority as Priority)
    : "medium";
  const repeat = REPEATS.includes(body.repeat as Repeat)
    ? (body.repeat as Repeat)
    : "none";

  const reminderAt = body.reminderAt ? new Date(String(body.reminderAt)) : null;

  try {
    const [row] = await db
      .insert(tasks)
      .values({
        title,
        description: strOrNull(body.description),
        dueDate: strOrNull(body.dueDate),
        dueTime: strOrNull(body.dueTime),
        priority,
        repeat,
        tags: String(body.tags ?? "").trim(),
        reminderEnabled: Boolean(body.reminderEnabled),
        reminderAt: reminderAt && !Number.isNaN(reminderAt.getTime()) ? reminderAt : null,
      })
      .returning();
    return Response.json({ task: serializeTask(row) }, { status: 201 });
  } catch {
    return Response.json({ error: "خطا در ذخیرهٔ کار" }, { status: 500 });
  }
}
