import { eq } from "drizzle-orm";
import { db } from "@/db";
import { tasks } from "@/db/schema";
import { serializeTask } from "@/lib/serialize";
import { shiftISOByRepeat } from "@/lib/format";
import type { Priority, Repeat } from "@/lib/types";

export const dynamic = "force-dynamic";

const PRIORITIES: Priority[] = ["low", "medium", "high"];
const REPEATS: Repeat[] = ["none", "daily", "weekly", "monthly"];

type Ctx = { params: Promise<{ id: string }> };

function strOrNull(v: unknown): string | null {
  const s = String(v ?? "").trim();
  return s ? s : null;
}

export async function PATCH(req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  const [existing] = await db.select().from(tasks).where(eq(tasks.id, id));
  if (!existing) {
    return Response.json({ error: "کار پیدا نشد" }, { status: 404 });
  }

  let body: Record<string, unknown> = {};
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    body = {};
  }

  const title = typeof body.title === "string" ? body.title.trim() : "";

  try {
    const [updated] = await db
      .update(tasks)
      .set({
        updatedAt: new Date(),
        ...(title ? { title } : {}),
        ...("description" in body ? { description: strOrNull(body.description) } : {}),
        ...("dueDate" in body ? { dueDate: strOrNull(body.dueDate) } : {}),
        ...("dueTime" in body ? { dueTime: strOrNull(body.dueTime) } : {}),
        ...(PRIORITIES.includes(body.priority as Priority)
          ? { priority: body.priority as Priority }
          : {}),
        ...(REPEATS.includes(body.repeat as Repeat) ? { repeat: body.repeat as Repeat } : {}),
        ...("tags" in body ? { tags: String(body.tags ?? "").trim() } : {}),
        ...(typeof body.reminderEnabled === "boolean"
          ? { reminderEnabled: body.reminderEnabled }
          : {}),
        ...("reminderAt" in body
          ? {
              reminderAt: body.reminderAt
                ? new Date(String(body.reminderAt))
                : null,
            }
          : {}),
        ...(typeof body.completed === "boolean"
          ? { completed: body.completed, completedAt: body.completed ? new Date() : null }
          : {}),
      })
      .where(eq(tasks.id, id))
      .returning();

    let next: ReturnType<typeof serializeTask> | null = null;
    const becameCompleted = body.completed === true && !existing.completed;

    if (becameCompleted && existing.repeat !== "none" && existing.dueDate) {
      const nextDue = shiftISOByRepeat(existing.dueDate, existing.repeat);
      let nextReminder: Date | null = null;
      if (existing.reminderEnabled && existing.reminderAt) {
        const r = new Date(existing.reminderAt);
        if (existing.repeat === "monthly") r.setMonth(r.getMonth() + 1);
        else r.setDate(r.getDate() + (existing.repeat === "weekly" ? 7 : 1));
        nextReminder = r;
      }
      const [created] = await db
        .insert(tasks)
        .values({
          title: existing.title,
          description: existing.description,
          dueDate: nextDue,
          dueTime: existing.dueTime,
          priority: existing.priority,
          repeat: existing.repeat,
          tags: existing.tags,
          reminderEnabled: existing.reminderEnabled,
          reminderAt: nextReminder,
        })
        .returning();
      next = serializeTask(created);
    }

    return Response.json({ task: serializeTask(updated), next });
  } catch {
    return Response.json({ error: "خطا در به‌روزرسانی کار" }, { status: 500 });
  }
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  try {
    const removed = await db.delete(tasks).where(eq(tasks.id, id)).returning();
    if (removed.length === 0) {
      return Response.json({ error: "کار پیدا نشد" }, { status: 404 });
    }
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "خطا در حذف کار" }, { status: 500 });
  }
}
