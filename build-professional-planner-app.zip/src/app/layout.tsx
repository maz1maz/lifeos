import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Vazirmatn } from "next/font/google";
import "./globals.css";

const vazir = Vazirmatn({
  subsets: ["arabic", "latin"],
  display: "swap",
  variable: "--font-vazir",
});

export const metadata: Metadata = {
  title: "پلنر حرفه‌ای | برنامه‌ریز کارها و یادآوری‌ها",
  description: "برنامه‌ریز کارها و یادآوری‌ها با ذخیره‌سازی واقعی در پایگاه داده",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl" className={vazir.variable}>
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}
