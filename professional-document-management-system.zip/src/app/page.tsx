"use client";

import { ChangeEvent, FormEvent, useEffect, useMemo, useRef, useState } from "react";

type DocumentItem = {
  id: string;
  title: string;
  category: string;
  documentDate: string | null;
  notes: string | null;
  tags: string[];
  fileName: string | null;
  fileType: string | null;
  fileSize: number | null;
  hasFile: boolean;
  createdAt: string;
  updatedAt: string;
};

type ViewMode = "grid" | "list";
type FormValues = {
  title: string;
  category: string;
  documentDate: string;
  notes: string;
  tags: string;
};

type IconName =
  | "archive"
  | "plus"
  | "search"
  | "grid"
  | "list"
  | "filter"
  | "upload"
  | "file"
  | "image"
  | "pdf"
  | "sheet"
  | "calendar"
  | "more"
  | "eye"
  | "edit"
  | "download"
  | "trash"
  | "x"
  | "chevron"
  | "tag"
  | "clock"
  | "folder"
  | "check"
  | "arrow"
  | "sparkle"
  | "paperclip";

const categories = ["همه", "هویتی", "مالی", "تحصیلی", "پزشکی", "شغلی", "املاک", "خودرو", "سایر"];
const formCategories = categories.slice(1);

const blankForm: FormValues = {
  title: "",
  category: "هویتی",
  documentDate: "",
  notes: "",
  tags: "",
};

function Icon({ name, size = 20, className = "" }: { name: IconName; size?: number; className?: string }) {
  const paths: Record<IconName, string> = {
    archive: "M3 8.5 5.2 4h13.6L21 8.5M4 9h16v10.5a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 19.5V9Zm5 4h6m-3-3v6",
    plus: "M12 5v14M5 12h14",
    search: "m20 20-4.2-4.2M18 11a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z",
    grid: "M4 4h6v6H4V4Zm10 0h6v6h-6V4ZM4 14h6v6H4v-6Zm10 0h6v6h-6v-6Z",
    list: "M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01",
    filter: "M4 6h16M7 12h10m-6 6h2",
    upload: "M12 16V4m0 0L7.5 8.5M12 4l4.5 4.5M5 19h14",
    file: "M6 3h8l4 4v14H6V3Zm8 0v5h5",
    image: "M4 5.5A1.5 1.5 0 0 1 5.5 4h13A1.5 1.5 0 0 1 20 5.5v13a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 18.5v-13Zm0 11 4.5-4.5 3.5 3.5 2.5-2.5L20 18.5M8 8.5h.01",
    pdf: "M6 3h8l4 4v14H6V3Zm8 0v5h5M8.5 16h7M8.5 12.5h4",
    sheet: "M6 3h8l4 4v14H6V3Zm8 0v5h5M8 12h8M8 16h8M11 9v9",
    calendar: "M7 3v3m10-3v3M4 9h16M5.5 5h13A1.5 1.5 0 0 1 20 6.5v12a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 18.5v-12A1.5 1.5 0 0 1 5.5 5Z",
    more: "M5 12h.01M12 12h.01M19 12h.01",
    eye: "M2.5 12s3.4-6 9.5-6 9.5 6 9.5 6-3.4 6-9.5 6-9.5-6-9.5-6Zm9.5 2.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z",
    edit: "m14.5 5.5 4 4M4 20l3.1-.7L19.5 6.9a1.4 1.4 0 0 0 0-2l-.4-.4a1.4 1.4 0 0 0-2 0L4.7 16.9 4 20Z",
    download: "M12 4v11m0 0 4-4m-4 4-4-4M5 20h14",
    trash: "M4 7h16m-10 4v5m4-5v5M9 7l.7-3h4.6l.7 3m-9 0 .7 13h10.6L18 7",
    x: "M6 6l12 12M18 6 6 18",
    chevron: "m9 18 6-6-6-6",
    tag: "M4 5.5A1.5 1.5 0 0 1 5.5 4H12l8 8-8 8-8-8V5.5ZM8 8h.01",
    clock: "M12 6v6l4 2",
    folder: "M3.5 6.5A1.5 1.5 0 0 1 5 5h5l2 2h7a1.5 1.5 0 0 1 1.5 1.5v9A1.5 1.5 0 0 1 19 19H5a1.5 1.5 0 0 1-1.5-1.5v-11Z",
    check: "m5 12 4.2 4.2L19 6.5",
    arrow: "M5 12h14m-5-5 5 5-5 5",
    sparkle: "m12 3 1.3 5.1L18.5 10l-5.2 1.3L12 16.5l-1.3-5.2L5.5 10l5.2-1.9L12 3Zm6.5 12 .6 2.4 2.4.6-2.4.6-.6 2.4-.6-2.4-2.4-.6 2.4-.6.6-2.4Z",
    paperclip: "m8.5 12.5 5.8-5.8a3 3 0 1 1 4.2 4.2L10 19.4A4.3 4.3 0 1 1 4 13.3l8-8",
  };

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <path d={paths[name]} />
    </svg>
  );
}

function getFileKind(fileType: string | null) {
  const type = (fileType || "").toLowerCase();
  if (type.includes("pdf")) return { label: "PDF", icon: "pdf" as const, tone: "rose" };
  if (type.includes("image")) return { label: "تصویر", icon: "image" as const, tone: "violet" };
  if (type.includes("sheet") || type.includes("excel") || type.includes("csv")) return { label: "جدول", icon: "sheet" as const, tone: "emerald" };
  if (type.includes("word") || type.includes("document") || type.includes("text")) return { label: "سند", icon: "file" as const, tone: "sky" };
  return { label: "فایل", icon: "file" as const, tone: "slate" };
}

function formatBytes(bytes: number | null) {
  if (!bytes) return "بدون پیوست";
  if (bytes < 1024) return `${bytes} بایت`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} کیلوبایت`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} مگابایت`;
}

function formatDate(value: string | null, fallback = "بدون تاریخ") {
  if (!value) return fallback;
  const parsed = new Date(`${value.slice(0, 10)}T12:00:00`);
  if (Number.isNaN(parsed.getTime())) return fallback;
  return new Intl.DateTimeFormat("fa-IR", { day: "numeric", month: "long", year: "numeric" }).format(parsed);
}

function categoryTone(category: string) {
  const tones: Record<string, string> = {
    هویتی: "blue",
    مالی: "amber",
    تحصیلی: "violet",
    پزشکی: "rose",
    شغلی: "cyan",
    املاک: "orange",
    خودرو: "emerald",
    سایر: "slate",
  };
  return tones[category] || "slate";
}

export default function HomePage() {
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("همه");
  const [viewMode, setViewMode] = useState<ViewMode>("grid");
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingDocument, setEditingDocument] = useState<DocumentItem | null>(null);
  const [detailDocument, setDetailDocument] = useState<DocumentItem | null>(null);
  const [formValues, setFormValues] = useState<FormValues>(blankForm);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [removeExistingFile, setRemoveExistingFile] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const loadDocuments = async () => {
    setIsLoading(true);
    try {
      const response = await fetch("/api/documents", { cache: "no-store" });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error);
      setDocuments(payload.documents);
    } catch (error) {
      setToast(error instanceof Error ? error.message : "اتصال به آرشیو برقرار نشد.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    void loadDocuments();
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timeout = window.setTimeout(() => setToast(null), 4200);
    return () => window.clearTimeout(timeout);
  }, [toast]);

  const filteredDocuments = useMemo(() => {
    const normalizedQuery = query.trim().toLocaleLowerCase("fa-IR");
    return documents.filter((document) => {
      const matchesCategory = category === "همه" || document.category === category;
      const haystack = [document.title, document.category, document.notes || "", ...(document.tags || [])]
        .join(" ")
        .toLocaleLowerCase("fa-IR");
      return matchesCategory && (!normalizedQuery || haystack.includes(normalizedQuery));
    });
  }, [category, documents, query]);

  const documentsWithFiles = documents.filter((document) => document.hasFile).length;
  const recentDocuments = documents.filter((document) => {
    const updated = new Date(document.updatedAt).getTime();
    return Date.now() - updated < 7 * 24 * 60 * 60 * 1000;
  }).length;

  const openCreate = () => {
    setEditingDocument(null);
    setFormValues(blankForm);
    setSelectedFile(null);
    setRemoveExistingFile(false);
    setIsFormOpen(true);
  };

  const openEdit = (document: DocumentItem) => {
    setDetailDocument(null);
    setEditingDocument(document);
    setFormValues({
      title: document.title,
      category: document.category,
      documentDate: document.documentDate?.slice(0, 10) || "",
      notes: document.notes || "",
      tags: document.tags.join(", "),
    });
    setSelectedFile(null);
    setRemoveExistingFile(false);
    setIsFormOpen(true);
  };

  const closeForm = () => {
    if (isSaving) return;
    setIsFormOpen(false);
    setEditingDocument(null);
    setSelectedFile(null);
  };

  const changeForm = (field: keyof FormValues, value: string) => {
    setFormValues((current) => ({ ...current, [field]: value }));
  };

  const onFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const nextFile = event.target.files?.[0] || null;
    if (nextFile && nextFile.size > 20 * 1024 * 1024) {
      setToast("حداکثر حجم قابل بارگذاری ۲۰ مگابایت است.");
      event.target.value = "";
      return;
    }
    setSelectedFile(nextFile);
    if (nextFile) setRemoveExistingFile(false);
  };

  const submitForm = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!formValues.title.trim()) {
      setToast("برای مدرک یک عنوان وارد کنید.");
      return;
    }

    setIsSaving(true);
    const body = new FormData();
    body.set("title", formValues.title);
    body.set("category", formValues.category);
    body.set("documentDate", formValues.documentDate);
    body.set("notes", formValues.notes);
    body.set("tags", formValues.tags);
    if (selectedFile) body.set("file", selectedFile);
    if (removeExistingFile) body.set("removeFile", "true");

    try {
      const endpoint = editingDocument ? `/api/documents/${editingDocument.id}` : "/api/documents";
      const response = await fetch(endpoint, { method: editingDocument ? "PATCH" : "POST", body });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error);

      setDocuments((current) => {
        const remaining = current.filter((item) => item.id !== payload.document.id);
        return [payload.document, ...remaining].sort(
          (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime(),
        );
      });
      setToast(editingDocument ? "تغییرات مدرک ذخیره شد." : "مدرک با موفقیت به آرشیو اضافه شد.");
      closeForm();
    } catch (error) {
      setToast(error instanceof Error ? error.message : "ذخیره‌سازی ناموفق بود.");
    } finally {
      setIsSaving(false);
    }
  };

  const deleteDocument = async (document: DocumentItem) => {
    if (!window.confirm(`«${document.title}» از آرشیو حذف شود؟`)) return;
    try {
      const response = await fetch(`/api/documents/${document.id}`, { method: "DELETE" });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error);
      setDocuments((current) => current.filter((item) => item.id !== document.id));
      if (detailDocument?.id === document.id) setDetailDocument(null);
      setToast("مدرک از آرشیو حذف شد.");
    } catch (error) {
      setToast(error instanceof Error ? error.message : "حذف مدرک ناموفق بود.");
    }
  };

  return (
    <main dir="rtl" className="vault-shell min-h-screen text-[#eaf3ff]">
      <div className="vault-backdrop" />
      <div className="relative mx-auto max-w-[1540px] px-4 pb-10 pt-4 sm:px-6 lg:px-8">
        <header className="vault-topbar">
          <div className="flex items-center gap-3">
            <div className="brand-mark"><Icon name="archive" size={24} /></div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-extrabold tracking-tight text-white sm:text-lg">آرشیو شخصی</h1>
                <span className="beta-pill">PRIVATE VAULT</span>
              </div>
              <p className="mt-0.5 text-xs text-[#89a9cb]">مدارک شما، مرتب و همیشه در دسترس</p>
            </div>
          </div>
          <div className="flex items-center gap-2.5">
            <div className="sync-state hidden sm:flex"><span className="sync-dot" />همگام و امن</div>
            <button type="button" onClick={openCreate} className="primary-button">
              <Icon name="plus" size={18} />
              <span className="hidden sm:inline">افزودن مدرک</span>
              <span className="sm:hidden">افزودن</span>
            </button>
          </div>
        </header>

        <section className="hero-panel mt-6 overflow-hidden">
          <div className="hero-glow" />
          <div className="relative flex flex-col justify-between gap-6 p-6 sm:p-8 lg:flex-row lg:items-end">
            <div>
              <div className="eyebrow"><Icon name="sparkle" size={15} />فضای امن اسناد شما</div>
              <h2 className="mt-3 text-2xl font-black tracking-tight text-white sm:text-3xl">همه‌چیز، درست جایی که باید باشد.</h2>
              <p className="mt-2 max-w-xl text-sm leading-7 text-[#9db7d4]">مدارک مهم را با جزئیات و پیوست‌هایشان نگه‌دارید، در چند ثانیه پیدا کنید و هر زمان نیاز داشتید ببینید.</p>
            </div>
            <div className="hero-mini-card">
              <div className="mini-icon"><Icon name="check" size={18} /></div>
              <div><strong>{documentsWithFiles} پیوست امن</strong><span>ذخیره‌شده در آرشیو شما</span></div>
            </div>
          </div>
        </section>

        <section className="stats-grid mt-5" aria-label="آمار آرشیو">
          <div className="stat-card"><div className="stat-icon sky"><Icon name="folder" size={21} /></div><div><span>کل مدارک</span><strong>{documents.length.toLocaleString("fa-IR")}</strong></div><small>آرشیو شخصی شما</small></div>
          <div className="stat-card"><div className="stat-icon violet"><Icon name="paperclip" size={21} /></div><div><span>دارای پیوست</span><strong>{documentsWithFiles.toLocaleString("fa-IR")}</strong></div><small>فایل‌های قابل مشاهده</small></div>
          <div className="stat-card"><div className="stat-icon teal"><Icon name="clock" size={21} /></div><div><span>به‌روزرسانی اخیر</span><strong>{recentDocuments.toLocaleString("fa-IR")}</strong></div><small>در هفت روز گذشته</small></div>
        </section>

        <div className="app-layout mt-6">
          <aside className="side-panel">
            <p className="side-label">دسته‌بندی مدارک</p>
            <nav className="category-nav" aria-label="دسته‌بندی‌ها">
              {categories.map((item) => {
                const count = item === "همه" ? documents.length : documents.filter((document) => document.category === item).length;
                return (
                  <button
                    type="button"
                    key={item}
                    onClick={() => setCategory(item)}
                    className={`category-button ${category === item ? "active" : ""}`}
                  >
                    <span className={`category-dot ${categoryTone(item)}`} />
                    <span>{item}</span>
                    <b>{count.toLocaleString("fa-IR")}</b>
                  </button>
                );
              })}
            </nav>
            <div className="storage-note">
              <div className="storage-note-icon"><Icon name="archive" size={19} /></div>
              <strong>آرشیو منظم‌تر، خیال آسوده‌تر</strong>
              <p>برای هر مدرک برچسب و تاریخ ثبت کنید تا سریع‌تر آن را پیدا کنید.</p>
              <button type="button" onClick={openCreate}>ثبت اولین مدرک <Icon name="arrow" size={15} /></button>
            </div>
          </aside>

          <section className="archive-panel">
            <div className="archive-heading">
              <div>
                <p className="section-kicker">آرشیو شما</p>
                <h2>مدارک و پرونده‌ها</h2>
              </div>
              <button type="button" onClick={openCreate} className="outline-add"><Icon name="plus" size={17} /> مدرک جدید</button>
            </div>

            <div className="toolbar">
              <label className="search-box">
                <Icon name="search" size={19} />
                <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="جست‌وجو در عنوان، برچسب یا توضیحات..." />
              </label>
              <div className="toolbar-actions">
                <div className="filter-label"><Icon name="filter" size={17} /><span className="hidden md:inline">{category}</span></div>
                <div className="view-switch" aria-label="نوع نمایش">
                  <button type="button" aria-label="نمای شبکه" onClick={() => setViewMode("grid")} className={viewMode === "grid" ? "active" : ""}><Icon name="grid" size={17} /></button>
                  <button type="button" aria-label="نمای فهرست" onClick={() => setViewMode("list")} className={viewMode === "list" ? "active" : ""}><Icon name="list" size={18} /></button>
                </div>
              </div>
            </div>

            <div className="result-caption">
              <span>{isLoading ? "در حال دریافت مدارک..." : `${filteredDocuments.length.toLocaleString("fa-IR")} مدرک پیدا شد`}</span>
              {query || category !== "همه" ? <button type="button" onClick={() => { setQuery(""); setCategory("همه"); }}>پاک کردن فیلترها</button> : <span>مرتب‌سازی بر اساس آخرین تغییر</span>}
            </div>

            {isLoading ? (
              <div className={`document-container ${viewMode} loading-grid`}>
                {[1, 2, 3].map((item) => <div key={item} className="skeleton-card"><span /><i /><i /><b /></div>)}
              </div>
            ) : filteredDocuments.length ? (
              <div className={`document-container ${viewMode}`}>
                {filteredDocuments.map((document) => (
                  <DocumentCard
                    key={document.id}
                    document={document}
                    listMode={viewMode === "list"}
                    onOpen={() => setDetailDocument(document)}
                    onEdit={() => openEdit(document)}
                    onDelete={() => void deleteDocument(document)}
                  />
                ))}
              </div>
            ) : (
              <EmptyState hasDocuments={documents.length > 0} onCreate={openCreate} />
            )}
          </section>
        </div>
      </div>

      {isFormOpen && (
        <DocumentForm
          values={formValues}
          editingDocument={editingDocument}
          selectedFile={selectedFile}
          removeExistingFile={removeExistingFile}
          saving={isSaving}
          inputRef={inputRef}
          onChange={changeForm}
          onFileChange={onFileChange}
          onRemoveSelectedFile={() => { setSelectedFile(null); if (inputRef.current) inputRef.current.value = ""; }}
          onToggleRemoveExisting={() => setRemoveExistingFile((current) => !current)}
          onClose={closeForm}
          onSubmit={submitForm}
        />
      )}

      {detailDocument && (
        <DocumentDetails
          document={detailDocument}
          onClose={() => setDetailDocument(null)}
          onEdit={() => openEdit(detailDocument)}
          onDelete={() => void deleteDocument(detailDocument)}
        />
      )}

      {toast && <div className="toast-message"><Icon name="check" size={18} />{toast}<button type="button" onClick={() => setToast(null)}><Icon name="x" size={16} /></button></div>}
    </main>
  );
}

function DocumentCard({ document, listMode, onOpen, onEdit, onDelete }: { document: DocumentItem; listMode: boolean; onOpen: () => void; onEdit: () => void; onDelete: () => void }) {
  const kind = getFileKind(document.fileType);
  return (
    <article className={`document-card ${listMode ? "list-card" : ""}`} onClick={onOpen} tabIndex={0} role="button" onKeyDown={(event) => { if (event.key === "Enter") onOpen(); }}>
      <div className={`file-avatar ${kind.tone}`}><Icon name={document.hasFile ? kind.icon : "file"} size={24} /></div>
      <div className="document-main">
        <div className="document-title-row"><h3>{document.title}</h3><span className={`category-chip ${categoryTone(document.category)}`}>{document.category}</span></div>
        <p className="document-file">{document.fileName || "بدون فایل پیوست"}</p>
        <div className="document-meta"><span><Icon name="calendar" size={14} />{formatDate(document.documentDate)}</span>{document.hasFile && <span>{formatBytes(document.fileSize)}</span>}</div>
        {!listMode && document.tags.length > 0 && <div className="tag-row">{document.tags.slice(0, 3).map((tag) => <span key={tag}>#{tag}</span>)}</div>}
      </div>
      <div className="card-actions" onClick={(event) => event.stopPropagation()}>
        <button type="button" title="مشاهده" onClick={onOpen}><Icon name="eye" size={18} /></button>
        <button type="button" title="ویرایش" onClick={onEdit}><Icon name="edit" size={17} /></button>
        <button type="button" title="حذف" className="danger" onClick={onDelete}><Icon name="trash" size={17} /></button>
      </div>
    </article>
  );
}

function EmptyState({ hasDocuments, onCreate }: { hasDocuments: boolean; onCreate: () => void }) {
  return (
    <div className="empty-state">
      <div className="empty-icon"><Icon name={hasDocuments ? "search" : "archive"} size={30} /></div>
      <h3>{hasDocuments ? "مدرکی با این مشخصات پیدا نشد" : "آرشیو شما آماده‌ی شروع است"}</h3>
      <p>{hasDocuments ? "عبارت جست‌وجو یا دسته‌بندی انتخاب‌شده را تغییر دهید." : "اولین مدرک مهم‌تان را همراه با فایل، تاریخ و برچسب به آرشیو اضافه کنید."}</p>
      {!hasDocuments && <button type="button" className="primary-button" onClick={onCreate}><Icon name="plus" size={18} />افزودن اولین مدرک</button>}
    </div>
  );
}

function DocumentForm({ values, editingDocument, selectedFile, removeExistingFile, saving, inputRef, onChange, onFileChange, onRemoveSelectedFile, onToggleRemoveExisting, onClose, onSubmit }: {
  values: FormValues;
  editingDocument: DocumentItem | null;
  selectedFile: File | null;
  removeExistingFile: boolean;
  saving: boolean;
  inputRef: React.RefObject<HTMLInputElement | null>;
  onChange: (field: keyof FormValues, value: string) => void;
  onFileChange: (event: ChangeEvent<HTMLInputElement>) => void;
  onRemoveSelectedFile: () => void;
  onToggleRemoveExisting: () => void;
  onClose: () => void;
  onSubmit: (event: FormEvent<HTMLFormElement>) => void;
}) {
  return (
    <div className="modal-overlay" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="form-modal" role="dialog" aria-modal="true" aria-labelledby="form-title">
        <div className="modal-header"><div><p className="section-kicker">{editingDocument ? "ویرایش اطلاعات" : "ثبت در آرشیو"}</p><h2 id="form-title">{editingDocument ? "ویرایش مدرک" : "افزودن مدرک جدید"}</h2></div><button type="button" className="icon-close" onClick={onClose}><Icon name="x" size={20} /></button></div>
        <form onSubmit={onSubmit} className="document-form">
          <label className="field-label full"><span>عنوان مدرک <em>*</em></span><input autoFocus value={values.title} onChange={(event) => onChange("title", event.target.value)} placeholder="مثلاً کارت ملی، قرارداد اجاره..." maxLength={160} /></label>
          <label className="field-label"><span>دسته‌بندی</span><select value={values.category} onChange={(event) => onChange("category", event.target.value)}>{formCategories.map((item) => <option key={item} value={item}>{item}</option>)}</select></label>
          <label className="field-label"><span>تاریخ مدرک</span><input type="date" value={values.documentDate} onChange={(event) => onChange("documentDate", event.target.value)} /></label>
          <label className="field-label full"><span>برچسب‌ها <small>با ویرگول جدا کنید</small></span><div className="input-with-icon"><Icon name="tag" size={17} /><input value={values.tags} onChange={(event) => onChange("tags", event.target.value)} placeholder="مهم، تمدید، ۱۴۰۴" /></div></label>
          <label className="field-label full"><span>توضیحات</span><textarea value={values.notes} onChange={(event) => onChange("notes", event.target.value)} placeholder="هر نکته‌ای که لازم است در آینده به یاد بیاورید..." rows={3} maxLength={4000} /></label>
          <div className="field-label full"><span>پیوست فایل <small>حداکثر ۲۰ مگابایت</small></span>
            {selectedFile ? <div className="selected-file"><div><Icon name={getFileKind(selectedFile.type).icon} size={19} /><span><b>{selectedFile.name}</b><small>{formatBytes(selectedFile.size)}</small></span></div><button type="button" onClick={onRemoveSelectedFile}><Icon name="x" size={17} /></button></div> : (
              <label className="drop-zone"><input ref={inputRef} type="file" onChange={onFileChange} /><Icon name="upload" size={22} /><span>فایل را انتخاب کنید یا اینجا رها کنید</span><small>PDF، تصویر، Word، Excel و هر نوع فایل دیگر</small></label>
            )}
            {editingDocument?.hasFile && !selectedFile && <button type="button" className={`remove-file-toggle ${removeExistingFile ? "selected" : ""}`} onClick={onToggleRemoveExisting}><span>{removeExistingFile ? <Icon name="check" size={14} /> : null}</span>{removeExistingFile ? "پیوست فعلی هنگام ذخیره حذف می‌شود" : `حذف پیوست فعلی (${editingDocument.fileName})`}</button>}
          </div>
          <div className="form-footer"><button type="button" className="cancel-button" onClick={onClose}>انصراف</button><button type="submit" disabled={saving} className="primary-button">{saving ? "در حال ذخیره..." : <><Icon name={editingDocument ? "check" : "plus"} size={18} />{editingDocument ? "ذخیره تغییرات" : "ثبت مدرک"}</>}</button></div>
        </form>
      </section>
    </div>
  );
}

function DocumentDetails({ document, onClose, onEdit, onDelete }: { document: DocumentItem; onClose: () => void; onEdit: () => void; onDelete: () => void }) {
  const kind = getFileKind(document.fileType);
  const fileUrl = `/api/documents/${document.id}/file`;
  const canPreview = Boolean(document.fileType?.startsWith("image/") || document.fileType?.includes("pdf"));
  return (
    <div className="modal-overlay detail-overlay" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="detail-modal" role="dialog" aria-modal="true" aria-labelledby="detail-title">
        <div className="modal-header"><button type="button" className="icon-close" onClick={onClose}><Icon name="x" size={20} /></button><div className="detail-header-title"><span className={`file-avatar ${kind.tone}`}><Icon name={document.hasFile ? kind.icon : "file"} size={22} /></span><div><p className="section-kicker">جزئیات مدرک</p><h2 id="detail-title">{document.title}</h2></div></div></div>
        <div className="detail-content">
          <div className="detail-actions"><button type="button" onClick={onEdit}><Icon name="edit" size={17} />ویرایش</button>{document.hasFile && <a href={fileUrl} download={document.fileName || true}><Icon name="download" size={17} />دانلود فایل</a>}<button type="button" className="delete-action" onClick={onDelete}><Icon name="trash" size={17} />حذف</button></div>
          {document.hasFile ? <div className="preview-area">{canPreview ? document.fileType?.startsWith("image/") ? <img src={fileUrl} alt={document.title} /> : <iframe src={fileUrl} title={`پیش‌نمایش ${document.title}`} /> : <div className="generic-preview"><span className={`file-avatar large ${kind.tone}`}><Icon name={kind.icon} size={34} /></span><h3>{document.fileName}</h3><p>پیش‌نمایش این نوع فایل در مرورگر ممکن نیست؛ می‌توانید آن را دانلود کنید.</p><a href={fileUrl} download={document.fileName || true} className="outline-add"><Icon name="download" size={17} />دریافت فایل</a></div>}</div> : <div className="no-file-preview"><Icon name="paperclip" size={25} /><span>فایلی برای این مدرک ثبت نشده است.</span></div>}
          <div className="detail-grid"><div><span>دسته‌بندی</span><b className={`category-chip ${categoryTone(document.category)}`}>{document.category}</b></div><div><span>تاریخ مدرک</span><b>{formatDate(document.documentDate)}</b></div><div><span>نام فایل</span><b>{document.fileName || "—"}</b></div><div><span>حجم فایل</span><b>{formatBytes(document.fileSize)}</b></div></div>
          {document.notes && <div className="detail-note"><span>توضیحات</span><p>{document.notes}</p></div>}
          {document.tags.length > 0 && <div className="detail-tags"><span>برچسب‌ها</span><div>{document.tags.map((tag) => <b key={tag}><Icon name="tag" size={13} />{tag}</b>)}</div></div>}
        </div>
      </section>
    </div>
  );
}
