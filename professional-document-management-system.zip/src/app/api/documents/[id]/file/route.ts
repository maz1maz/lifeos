import { db } from "@/db";
import { documents } from "@/db/schema";
import { eq } from "drizzle-orm";

export const runtime = "nodejs";

type RouteContext = { params: Promise<{ id: string }> };

export async function GET(_: Request, { params }: RouteContext) {
  try {
    const { id } = await params;
    const [document] = await db
      .select({
        fileName: documents.fileName,
        fileType: documents.fileType,
        fileData: documents.fileData,
      })
      .from(documents)
      .where(eq(documents.id, id))
      .limit(1);

    if (!document?.fileData) {
      return Response.json({ error: "پیوستی برای این مدرک وجود ندارد." }, { status: 404 });
    }

    const filename = document.fileName || "document";
    return new Response(new Uint8Array(document.fileData), {
      headers: {
        "Content-Type": document.fileType || "application/octet-stream",
        "Content-Length": String(document.fileData.length),
        "Content-Disposition": `inline; filename*=UTF-8''${encodeURIComponent(filename)}`,
        "Cache-Control": "private, max-age=3600",
      },
    });
  } catch {
    return Response.json({ error: "دریافت فایل ناموفق بود." }, { status: 500 });
  }
}
