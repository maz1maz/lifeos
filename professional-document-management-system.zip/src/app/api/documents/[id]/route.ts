import { db } from "@/db";
import { documents } from "@/db/schema";
import {
  documentSummaryColumns,
  readDocumentFields,
  readUploadedFile,
  toDocumentSummary,
} from "@/lib/documents";
import { eq } from "drizzle-orm";

export const runtime = "nodejs";

type RouteContext = { params: Promise<{ id: string }> };

export async function GET(_: Request, { params }: RouteContext) {
  try {
    const { id } = await params;
    const [document] = await db
      .select(documentSummaryColumns)
      .from(documents)
      .where(eq(documents.id, id))
      .limit(1);

    if (!document) {
      return Response.json({ error: "مدرک پیدا نشد." }, { status: 404 });
    }
    return Response.json({ document: toDocumentSummary(document) });
  } catch {
    return Response.json({ error: "دریافت مدرک ناموفق بود." }, { status: 500 });
  }
}

export async function PATCH(request: Request, { params }: RouteContext) {
  try {
    const { id } = await params;
    const formData = await request.formData();
    const fields = readDocumentFields(formData);
    const uploadedFile = await readUploadedFile(formData);
    const shouldRemoveFile = formData.get("removeFile") === "true";

    const fileChanges = uploadedFile
      ? uploadedFile
      : shouldRemoveFile
        ? { fileName: null, fileType: null, fileSize: null, fileData: null }
        : {};

    const [updated] = await db
      .update(documents)
      .set({ ...fields, ...fileChanges, updatedAt: new Date() })
      .where(eq(documents.id, id))
      .returning();

    if (!updated) {
      return Response.json({ error: "مدرک پیدا نشد." }, { status: 404 });
    }
    return Response.json({ document: toDocumentSummary(updated) });
  } catch (error) {
    const message = error instanceof Error ? error.message : "ویرایش مدرک ناموفق بود.";
    return Response.json({ error: message }, { status: 400 });
  }
}

export async function DELETE(_: Request, { params }: RouteContext) {
  try {
    const { id } = await params;
    const [deleted] = await db.delete(documents).where(eq(documents.id, id)).returning({ id: documents.id });
    if (!deleted) {
      return Response.json({ error: "مدرک پیدا نشد." }, { status: 404 });
    }
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "حذف مدرک ناموفق بود." }, { status: 500 });
  }
}
