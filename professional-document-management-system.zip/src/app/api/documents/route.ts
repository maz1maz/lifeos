import { db } from "@/db";
import { documents } from "@/db/schema";
import {
  documentSummaryColumns,
  readDocumentFields,
  readUploadedFile,
  toDocumentSummary,
} from "@/lib/documents";
import { desc } from "drizzle-orm";

export const runtime = "nodejs";

export async function GET() {
  try {
    const rows = await db
      .select(documentSummaryColumns)
      .from(documents)
      .orderBy(desc(documents.updatedAt));

    return Response.json({ documents: rows.map(toDocumentSummary) });
  } catch {
    return Response.json({ error: "دریافت آرشیو در حال حاضر ممکن نیست." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const formData = await request.formData();
    const fields = readDocumentFields(formData);
    const upload = await readUploadedFile(formData);
    const [created] = await db
      .insert(documents)
      .values({ ...fields, ...(upload ?? {}) })
      .returning();

    return Response.json({ document: toDocumentSummary(created) }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : "ذخیره‌سازی مدرک ناموفق بود.";
    return Response.json({ error: message }, { status: 400 });
  }
}
