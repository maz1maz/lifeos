import { documents } from "@/db/schema";

export const documentSummaryColumns = {
  id: documents.id,
  title: documents.title,
  category: documents.category,
  documentDate: documents.documentDate,
  notes: documents.notes,
  tags: documents.tags,
  fileName: documents.fileName,
  fileType: documents.fileType,
  fileSize: documents.fileSize,
  createdAt: documents.createdAt,
  updatedAt: documents.updatedAt,
};

export const documentCategories = [
  "هویتی",
  "مالی",
  "تحصیلی",
  "پزشکی",
  "شغلی",
  "املاک",
  "خودرو",
  "سایر",
] as const;

export type DocumentRow = typeof documents.$inferSelect;
type DocumentMetadata = Omit<DocumentRow, "fileData"> & { fileData?: Buffer | null };

export function toDocumentSummary(document: DocumentMetadata) {
  return {
    id: document.id,
    title: document.title,
    category: document.category,
    documentDate: document.documentDate,
    notes: document.notes,
    tags: document.tags ?? [],
    fileName: document.fileName,
    fileType: document.fileType,
    fileSize: document.fileSize,
    hasFile: Boolean(document.fileData) || Boolean(document.fileName),
    createdAt: document.createdAt,
    updatedAt: document.updatedAt,
  };
}

export function readDocumentFields(formData: FormData) {
  const title = String(formData.get("title") ?? "").trim();
  const rawCategory = String(formData.get("category") ?? "سایر").trim();
  const category = documentCategories.includes(rawCategory as (typeof documentCategories)[number])
    ? rawCategory
    : "سایر";
  const rawDate = String(formData.get("documentDate") ?? "").trim();
  const documentDate = /^\d{4}-\d{2}-\d{2}$/.test(rawDate) ? rawDate : null;
  const notes = String(formData.get("notes") ?? "").trim();
  const tags = String(formData.get("tags") ?? "")
    .split(",")
    .map((tag) => tag.trim())
    .filter(Boolean)
    .slice(0, 8);

  if (!title) {
    throw new Error("عنوان مدرک را وارد کنید.");
  }
  if (title.length > 160 || notes.length > 4000) {
    throw new Error("اطلاعات واردشده بیش از حد مجاز است.");
  }

  return { title, category, documentDate, notes: notes || null, tags };
}

export async function readUploadedFile(formData: FormData) {
  const candidate = formData.get("file");
  if (!(candidate instanceof File) || candidate.size === 0) {
    return null;
  }
  if (candidate.size > 20 * 1024 * 1024) {
    throw new Error("حداکثر حجم قابل بارگذاری ۲۰ مگابایت است.");
  }

  return {
    fileName: candidate.name.slice(0, 255),
    fileType: candidate.type || "application/octet-stream",
    fileSize: candidate.size,
    fileData: Buffer.from(await candidate.arrayBuffer()),
  };
}
