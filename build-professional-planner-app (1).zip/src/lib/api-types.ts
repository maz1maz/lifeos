export type TaskKind = "task" | "reminder";
export type Priority = "low" | "medium" | "high" | "urgent";
export type Repeat = "none" | "daily" | "weekly" | "monthly";
export type FilterKey = "all" | "today" | "upcoming" | "done";

export interface TaskDto {
  id: string;
  kind: TaskKind;
  title: string;
  notes: string | null;
  dueAt: string | null;
  remindAt: string | null;
  priority: Priority;
  repeat: Repeat;
  tags: string[];
  loose: boolean;
  done: boolean;
  doneAt: string | null;
  createdAt: string;
}

export interface TaskPayload {
  kind: TaskKind;
  title: string;
  notes?: string | null;
  dueAt?: string | null;
  remindAt?: string | null;
  priority?: Priority;
  repeat?: Repeat;
  tags?: string[];
  loose?: boolean;
  done?: boolean;
}

export const PRIORITY_LABEL: Record<Priority, string> = {
  low: "کم",
  medium: "متوسط",
  high: "زیاد",
  urgent: "فوری",
};

export const REPEAT_LABEL: Record<Repeat, string> = {
  none: "بدون تکرار",
  daily: "روزانه",
  weekly: "هفتگی",
  monthly: "ماهانه",
};
