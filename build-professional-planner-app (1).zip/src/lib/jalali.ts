// Jalali (Solar Hijri) calendar conversion — algorithm after Khayyam/Birashk,
// same result set as the well known jalaali-js implementation.

export function toPersianDigits(input: string | number): string {
  const map = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];
  return String(input).replace(/[0-9]/g, (d) => map[Number(d)]);
}

function div(a: number, b: number) {
  return Math.trunc(a / b);
}

export function toJalali(gy: number, gm: number, gd: number) {
  const g_d_m = [
    0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334,
  ];
  let jy = gy <= 1600 ? 0 : 979;
  gy -= gy <= 1600 ? 621 : 1600;
  const gy2 = gm > 2 ? gy + 1 : gy;
  let days =
    365 * gy +
    div(gy2 + 3, 4) -
    div(gy2 + 99, 100) +
    div(gy2 + 399, 400) -
    80 + gd + g_d_m[gm - 1];
  jy += 33 * div(days, 12053);
  days %= 12053;
  jy += 4 * div(days, 1461);
  days %= 1461;
  if (days > 365) {
    jy += div(days - 1, 365);
    days = (days - 1) % 365;
  }
  const jm =
    days < 186 ? 1 + div(days, 31) : 7 + div(days - 186, 30);
  const jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
  return { jy, jm, jd };
}

export const JALALI_MONTHS = [
  "فروردین",
  "اردیبهشت",
  "خرداد",
  "تیر",
  "مرداد",
  "شهریور",
  "مهر",
  "آبان",
  "آذر",
  "دی",
  "بهمن",
  "اسفند",
];

export const JALALI_WEEKDAYS = [
  "یکشنبه",
  "دوشنبه",
  "سه‌شنبه",
  "چهارشنبه",
  "پنجشنبه",
  "جمعه",
  "شنبه",
];

/** "۱۲ آبان ۱۴۰۵" */
export function formatJalali(date: Date): string {
  const { jy, jm, jd } = toJalali(
    date.getFullYear(),
    date.getMonth() + 1,
    date.getDate(),
  );
  return `${toPersianDigits(jd)} ${JALALI_MONTHS[jm - 1]} ${toPersianDigits(jy)}`;
}

/** short: "۱۲/۰۸" */
export function formatJalaliShort(date: Date): string {
  const { jy, jm, jd } = toJalali(
    date.getFullYear(),
    date.getMonth() + 1,
    date.getDate(),
  );
  const p = (n: number) => toPersianDigits(String(n).padStart(2, "0"));
  return `${p(jd)}/${p(jm)}`;
}

export function formatTime(date: Date): string {
  const h = String(date.getHours()).padStart(2, "0");
  const m = String(date.getMinutes()).padStart(2, "0");
  return toPersianDigits(`${h}:${m}`);
}

export function weekdayName(date: Date): string {
  return JALALI_WEEKDAYS[date.getDay()];
}

export function isSameDay(a: Date, b: Date): boolean {
  return (
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  );
}

export function startOfDay(d: Date): Date {
  const c = new Date(d);
  c.setHours(0, 0, 0, 0);
  return c;
}

export function addDays(d: Date, n: number): Date {
  const c = new Date(d);
  c.setDate(c.getDate() + n);
  return c;
}

/** how a due date relates to "today": overdue | today | tomorrow | week | later | none */
export function dueBucket(iso: string | null | undefined): string {
  if (!iso) return "none";
  const d = new Date(iso);
  const today = startOfDay(new Date());
  const day = startOfDay(d);
  const diff = Math.round((day.getTime() - today.getTime()) / 86400000);
  if (diff < 0) return "overdue";
  if (diff === 0) return "today";
  if (diff === 1) return "tomorrow";
  if (diff <= 7) return "week";
  return "later";
}

/** build an ISO string (local time) from yyyy-mm-dd + hh:mm form fields */
export function combineDateTime(date: string, time: string): string | null {
  if (!date) return null;
  const t = time && time !== "--:--" ? time : "09:00";
  const parsed = new Date(`${date}T${t.length === 5 ? `${t}:00` : t}`);
  return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString();
}

export function toDateField(iso?: string | null): string {
  if (!iso) return "";
  const d = new Date(iso);
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

export function toTimeField(iso?: string | null): string {
  if (!iso) return "";
  const d = new Date(iso);
  const p = (n: number) => String(n).padStart(2, "0");
  return `${p(d.getHours())}:${p(d.getMinutes())}`;
}

/** caption shown under the Gregorian date input */
export function dateFieldCaption(date: string): string {
  if (!date) return "تاریخی انتخاب نشده";
  const d = new Date(`${date}T09:00:00`);
  if (Number.isNaN(d.getTime())) return "تاریخ نامعتبر";
  return `${weekdayName(d)}، ${formatJalali(d)}`;
}
