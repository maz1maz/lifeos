import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { tasks } from "@/db/schema";
import type { TaskDto } from "@/lib/api-types";

export const dynamic = "force-dynamic";

function toDto(row: typeof tasks.$inferSelect): TaskDto {
  return {
    id: row.id,
    kind: row.kind,
    title: row.title,
    notes: row.notes,
    dueAt: row.dueAt ? row.dueAt.toISOString() : null,
    remindAt: row.remindAt ? row.remindAt.toISOString() : null,
    priority: row.priority,
    repeat: row.repeat,
    tags: row.tags ?? [],
    loose: row.loose,
    done: row.done,
    doneAt: row.doneAt ? row.doneAt.toISOString() : null,
    createdAt: row.createdAt.toISOString(),
  };
}

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const body = await request.json();
    const patch: Partial<typeof tasks.$inferInsert> = {};
    if ("title" in body) {
      const title = String(body.title ?? "").trim();
      if (!title) {
        return NextResponse.json({ error: "عنوان نمی‌تواند خالی باشد" }, { status: 400 });
      }
      patch.title = title;
    }
    if ("notes" in body) patch.notes = body.notes ? String(body.notes) : null;
    if ("dueAt" in body) patch.dueAt = body.dueAt ? new Date(body.dueAt) : null;
    if ("remindAt" in body) patch.remindAt = body.remindAt ? new Date(body.remindAt) : null;
    if ("kind" in body) patch.kind = body.kind === "reminder" ? "reminder" : "task";
    if ("priority" in body && ["low", "medium", "high", "urgent"].includes(body.priority))
      patch.priority = body.priority;
    if ("repeat" in body && ["none", "daily", "weekly", "monthly"].includes(body.repeat))
      patch.repeat = body.repeat;
    if ("tags" in body && Array.isArray(body.tags))
      patch.tags = body.tags.map((t: unknown) => String(t).trim()).filter(Boolean);
    if ("loose" in body) patch.loose = Boolean(body.loose);
    if ("done" in body) {
      patch.done = Boolean(body.done);
      patch.doneAt = patch.done ? new Date() : null;
    }

    const updated = await db
      .update(tasks)
      .set(patch)
      .where(eq(tasks.id, id))
      .returning();

    if (updated.length === 0) {
      return NextResponse.json({ error: "کار پیدا نشد" }, { status: 404 });
    }
    return NextResponse.json({ task: toDto(updated[0]) });
  } catch (error) {
    console.error("PATCH /api/tasks/[id] failed", error);
    return NextResponse.json({ error: "خطا در به‌روزرسانی" }, { status: 500 });
  }
}

export async function DELETE(_request: Request, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const removed = await db.delete(tasks).where(eq(tasks.id, id)).returning();
    if (removed.length === 0) {
      return NextResponse.json({ error: "کار پیدا نشد" }, { status: 404 });
    }
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("DELETE /api/tasks/[id] failed", error);
    return NextResponse.json({ error: "خطا در حذف" }, { status: 500 });
  }
}
