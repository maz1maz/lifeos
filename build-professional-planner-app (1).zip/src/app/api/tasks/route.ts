import { asc, desc } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { tasks } from "@/db/schema";
import { ensureSeed } from "@/db/seed";
import { dueBucket } from "@/lib/jalali";
import type { FilterKey, TaskDto, TaskKind } from "@/lib/api-types";

export const dynamic = "force-dynamic";

function toDto(row: typeof tasks.$inferSelect): TaskDto {
  return {
    id: row.id,
    kind: row.kind,
    title: row.title,
    notes: row.notes,
    dueAt: row.dueAt ? row.dueAt.toISOString() : null,
    remindAt: row.remindAt ? row.remindAt.toISOString() : null,
    priority: row.priority,
    repeat: row.repeat,
    tags: row.tags ?? [],
    loose: row.loose,
    done: row.done,
    doneAt: row.doneAt ? row.doneAt.toISOString() : null,
    createdAt: row.createdAt.toISOString(),
  };
}

export async function GET(request: Request) {
  try {
    await ensureSeed();
    const url = new URL(request.url);
    const kind = (url.searchParams.get("kind") as TaskKind) || "task";
    const filter = (url.searchParams.get("filter") as FilterKey) || "all";
    const q = (url.searchParams.get("q") || "").trim().toLowerCase();

    const all = await db
      .select()
      .from(tasks)
      .orderBy(desc(tasks.done), asc(tasks.dueAt), desc(tasks.createdAt));

    let rows = all.filter((row) => row.kind === kind);
    if (q) {
      rows = rows.filter((row) =>
        [row.title, row.notes ?? "", (row.tags ?? []).join(" ")]
          .join(" ")
          .toLowerCase()
          .includes(q),
      );
    }

    const filtered = rows.filter((row) => {
      const bucket = dueBucket(row.dueAt?.toISOString());
      if (filter === "done") return row.done;
      if (row.done) return false;
      if (filter === "today") return bucket === "today" || bucket === "overdue";
      if (filter === "upcoming")
        return ["tomorrow", "week", "later"].includes(bucket);
      return true;
    });

    const open = rows.filter((r) => !r.done);
    return NextResponse.json({
      tasks: filtered.map(toDto),
      counts: {
        all: open.length,
        today: open.filter((r) =>
          ["today", "overdue"].includes(dueBucket(r.dueAt?.toISOString())),
        ).length,
        upcoming: open.filter((r) =>
          ["tomorrow", "week", "later"].includes(dueBucket(r.dueAt?.toISOString())),
        ).length,
        done: rows.filter((r) => r.done).length,
        reminders: all.filter((r) => r.kind === "reminder" && !r.done).length,
      },
    });
  } catch (error) {
    console.error("GET /api/tasks failed", error);
    return NextResponse.json(
      { error: "خطا در خواندن فهرست کارها" },
      { status: 500 },
    );
  }
}

export async function POST(request: Request) {
  try {
    await ensureSeed();
    const body = await request.json();
    const title = String(body.title ?? "").trim();
    if (!title) {
      return NextResponse.json(
        { error: "عنوان کار نمی‌تواند خالی باشد" },
        { status: 400 },
      );
    }
    const inserted = await db
      .insert(tasks)
      .values({
        kind: body.kind === "reminder" ? "reminder" : "task",
        title,
        notes: body.notes ? String(body.notes) : null,
        dueAt: body.dueAt ? new Date(body.dueAt) : null,
        remindAt: body.remindAt ? new Date(body.remindAt) : null,
        priority: ["low", "medium", "high", "urgent"].includes(body.priority)
          ? body.priority
          : "medium",
        repeat: ["none", "daily", "weekly", "monthly"].includes(body.repeat)
          ? body.repeat
          : "none",
        tags: Array.isArray(body.tags)
          ? body.tags.map((t: unknown) => String(t).trim()).filter(Boolean)
          : [],
        loose: Boolean(body.loose),
      })
      .returning();
    return NextResponse.json({ task: toDto(inserted[0]) }, { status: 201 });
  } catch (error) {
    console.error("POST /api/tasks failed", error);
    return NextResponse.json(
      { error: "خطا در ذخیرهٔ کار — دوباره تلاش کنید" },
      { status: 500 },
    );
  }
}
