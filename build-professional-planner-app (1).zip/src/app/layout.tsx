import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "کارها و یادآوری‌ها — دفتر برنامهٔ روزانه",
  description:
    "برنامه‌ریزی با دقت و حواسِ دقیق: ثبت کارها، یادآوری‌ها، اولویت‌ها و تکرارها با تاریخ شمسی.",
};

const fontHref =
  "https://fonts.googleapis.com/css2?family=Vazirmatn:wght@100..900&family=Gulzar&display=swap";

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="stylesheet" href={fontHref} />
      </head>
      <body className="min-h-screen">
        <div id="app-shell">{children}</div>
      </body>
    </html>
  );
}
