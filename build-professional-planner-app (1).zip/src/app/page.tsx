import type { Metadata } from "next";
import { Planner } from "@/components/Planner";

export const metadata: Metadata = {
  title: "کارها و یادآوری‌ها — دفتر برنامهٔ روزانه",
  description:
    "برنامه‌ریزی با دقت و حواسِ دقیق: ثبت کارها و یادآوری‌ها با تاریخ شمسی، اولویت و تکرار.",
};

export default function HomePage() {
  return <Planner />;
}
