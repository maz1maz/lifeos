import { eq } from "drizzle-orm";
import { db } from "@/db";
import { tasks } from "@/db/schema";

function at(dayOffset: number, hour: number, minute = 0) {
  const d = new Date();
  d.setDate(d.getDate() + dayOffset);
  d.setHours(hour, minute, 0, 0);
  return d;
}

const SEED: (typeof tasks.$inferInsert)[] = [
  {
    kind: "task",
    title: "پیگیری فاکتور چاپ نگارستان",
    notes: "شمارهٔ فاکتور ۸۴/۲۱۷ — قرارداد سررسید امروز است. زنگ بزن به آقای بهنام.",
    dueAt: at(0, 11, 30),
    remindAt: at(0, 9, 0),
    priority: "high",
    repeat: "none",
    tags: ["مالی", "چاپ"],
  },
  {
    kind: "task",
    title: "جلسهٔ هیئت‌مدیره — سالن زرین",
    notes: "دستور جلسه: بودجهٔ نیم‌سال، ترمیم سقف حیاط، تمدید قرارداد سرایدار.",
    dueAt: at(0, 16, 0),
    remindAt: at(0, 15, 15),
    priority: "medium",
    repeat: "monthly",
    tags: ["جلسه"],
  },
  {
    kind: "task",
    title: "تمدید بیمهٔ شخص ثالث پژو",
    notes: "کارت ماشین و کارت ملی را بردار. بیمهٔ البرز، نمایندگی خیابان چهارباغ.",
    dueAt: at(1, 10, 0),
    priority: "urgent",
    repeat: "none",
    tags: ["کارهای اداری"],
  },
  {
    kind: "task",
    title: "خرید هدیهٔ تولد مادر",
    notes: "شال ابریشم یا کتاب نفیس شاهنامه. سرِ فرصت از بازار هنر بپرس.",
    dueAt: at(4, 18, 0),
    priority: "medium",
    repeat: "none",
    tags: ["خانواده"],
  },
  {
    kind: "task",
    title: "تحویل پیش‌نویس مقاله به دفتر مجله",
    notes: "چکیده و فهرست منابع جداگانه.",
    dueAt: at(-1, 13, 0),
    priority: "high",
    repeat: "none",
    tags: ["نوشتن"],
    done: true,
    doneAt: new Date(),
  },
  {
    kind: "reminder",
    title: "پرداخت قبض آب محله",
    notes: "مهلت پرداخت تا پایان هفته — جریمه دیرکرد می‌خورد.",
    dueAt: at(3, 8, 30),
    remindAt: at(3, 8, 30),
    priority: "low",
    repeat: "monthly",
    tags: ["قبوض"],
  },
  {
    kind: "reminder",
    title: "زنگ بزن به دکتر رضوی برای نوبت کنترل",
    notes: "آزمایش قند ناشتا را هم یادداشت کن.",
    dueAt: at(0, 20, 0),
    remindAt: at(0, 20, 0),
    priority: "medium",
    repeat: "none",
    tags: ["سلامت"],
  },
  {
    kind: "reminder",
    title: "تمدید اشتراک کتابخانهٔ مجلس",
    notes: "کارت عضویت داخل کیف چرمی است.",
    dueAt: at(6, 9, 0),
    remindAt: at(6, 9, 0),
    priority: "low",
    repeat: "monthly",
    tags: ["کتابخانه"],
  },
];

let seeded = false;

export async function ensureSeed() {
  if (seeded) return;
  const existing = await db.select({ id: tasks.id }).from(tasks).limit(1);
  if (existing.length > 0) {
    seeded = true;
    return;
  }
  for (const row of SEED) {
    await db.insert(tasks).values(row);
  }
  seeded = true;
}

export async function taskExists(id: string) {
  const rows = await db.select({ id: tasks.id }).from(tasks).where(eq(tasks.id, id));
  return rows.length > 0;
}
