import {
  boolean,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";

export const taskKindEnum = pgEnum("task_kind", ["task", "reminder"]);

export const priorityEnum = pgEnum("task_priority", [
  "low",
  "medium",
  "high",
  "urgent",
]);

export const repeatEnum = pgEnum("task_repeat", [
  "none",
  "daily",
  "weekly",
  "monthly",
]);

export const tasks = pgTable("tasks", {
  id: uuid("id").defaultRandom().primaryKey(),
  kind: taskKindEnum("kind").default("task").notNull(),
  title: varchar("title", { length: 220 }).notNull(),
  notes: text("notes"),
  dueAt: timestamp("due_at", { withTimezone: true }),
  remindAt: timestamp("remind_at", { withTimezone: true }),
  priority: priorityEnum("priority").default("medium").notNull(),
  repeat: repeatEnum("repeat").default("none").notNull(),
  tags: text("tags").array().default([]).notNull(),
  loose: boolean("loose").default(false).notNull(),
  done: boolean("done").default(false).notNull(),
  doneAt: timestamp("done_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type Task = typeof tasks.$inferSelect;
export type NewTask = typeof tasks.$inferInsert;
