"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Pencil, Repeat2, Tag, Trash2, TriangleAlert } from "lucide-react";
import type { TaskDto } from "@/lib/api-types";
import { PRIORITY_LABEL, REPEAT_LABEL } from "@/lib/api-types";
import { dueBucket, formatJalaliShort, formatTime } from "@/lib/jalali";

const PRIORITY_TONE: Record<TaskDto["priority"], { dot: string; text: string }> = {
  low: { dot: "bg-muted", text: "text-muted" },
  medium: { dot: "bg-firoozeh", text: "text-firoozeh" },
  high: { dot: "bg-rule", text: "text-rule" },
  urgent: { dot: "bg-haematite", text: "text-haematite" },
};

function Check({ done }: { done: boolean }) {
  return (
    <span
      className={[
        "relative flex h-6 w-6 shrink-0 items-center justify-center rounded-full border transition-colors",
        done
          ? "border-firoozeh bg-firoozeh-deep/60"
          : "border-muted/45 hover:border-firoozeh",
      ].join(" ")}
    >
      <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none">
        <motion.path
          d="M5 12.5 L10 17.5 L19 7"
          stroke="#7FE3E8"
          strokeWidth="2.6"
          strokeLinecap="round"
          strokeLinejoin="round"
          initial={false}
          animate={{ pathLength: done ? 1 : 0, opacity: done ? 1 : 0 }}
          transition={{ duration: 0.28, ease: "easeOut" }}
        />
      </svg>
    </span>
  );
}

export function TaskRow({
  task,
  index,
  onToggle,
  onEdit,
  onDelete,
}: {
  task: TaskDto;
  index: number;
  onToggle: (t: TaskDto) => void;
  onEdit: (t: TaskDto) => void;
  onDelete: (t: TaskDto) => void;
}) {
  const [confirming, setConfirming] = useState(false);
  const bucket = dueBucket(task.dueAt);
  const overdue = bucket === "overdue" && !task.done;
  const tone = PRIORITY_TONE[task.priority];
  const due = task.dueAt ? new Date(task.dueAt) : null;
  const remind = task.remindAt ? new Date(task.remindAt) : null;

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -6 }}
      transition={{ duration: 0.22, delay: Math.min(index * 0.035, 0.28) }}
      className="ledger-row group relative grid grid-cols-[auto_1fr_auto] items-start gap-4 py-4"
    >
      <button
        type="button"
        onClick={() => onToggle(task)}
        aria-pressed={task.done}
        aria-label={task.done ? "بازگرداندن کار" : "انجام شد"}
        className="mt-0.5"
      >
        <Check done={task.done} />
      </button>

      <div className="min-w-0">
        <h3
          className={[
            "text-[1.05rem] font-medium leading-7 transition-colors",
            task.done
              ? "text-muted line-through decoration-firoozeh/60"
              : "text-paper",
          ].join(" ")}
        >
          {task.title}
        </h3>

        {task.notes ? (
          <p className="mt-1 line-clamp-2 max-w-[52ch] text-[0.82rem] leading-6 text-muted/85">
            {task.notes}
          </p>
        ) : null}

        <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[0.7rem]">
          <span className={`inline-flex items-center gap-1.5 ${tone.text}`}>
            <span className={`h-2 w-2 rotate-45 ${tone.dot}`} />
            اولویتِ {PRIORITY_LABEL[task.priority]}
          </span>
          {task.repeat !== "none" ? (
            <span className="inline-flex items-center gap-1.5 text-muted">
              <Repeat2 className="h-3.5 w-3.5" strokeWidth={1.5} />
              {REPEAT_LABEL[task.repeat]}
            </span>
          ) : null}
          {task.tags.map((tag) => (
            <span key={tag} className="inline-flex items-center gap-1 text-muted/80">
              <Tag className="h-3 w-3" strokeWidth={1.5} />
              {tag}
            </span>
          ))}
          {overdue ? (
            <span className="inline-flex items-center gap-1 text-haematite">
              <TriangleAlert className="h-3.5 w-3.5" strokeWidth={1.6} />
              از موعد گذشته
            </span>
          ) : null}
          {task.loose ? <span className="text-muted/70">یادداشتِ بی‌تاریخ</span> : null}
        </div>
      </div>

      {/* the margin: the clock hangs outside the text block, against the gold rule */}
      <div className="flex items-start gap-3 border-s border-rule/20 ps-4">
        <div className="w-[4.8rem] text-center">
          <div
            className={[
              "text-[1.15rem] font-light tabular-nums",
              overdue ? "text-haematite" : "text-firoozeh-light",
            ].join(" ")}
          >
            {due ? formatTime(due) : "—"}
          </div>
          <div className="mt-0.5 text-[0.68rem] tabular-nums text-muted/75">
            {due ? formatJalaliShort(due) : "بی‌تاریخ"}
          </div>
          {remind ? (
            <div className="mt-1 text-[0.6rem] tabular-nums text-rule/85">
              یادآوری {formatTime(remind)}
            </div>
          ) : null}
        </div>

        <div className="flex items-center gap-1 opacity-0 transition-opacity focus-within:opacity-100 group-hover:opacity-100">
          <button
            type="button"
            onClick={() => onEdit(task)}
            aria-label="ویرایش کار"
            className="rounded-sm p-1.5 text-muted transition-colors hover:bg-raised hover:text-firoozeh-light"
          >
            <Pencil className="h-4 w-4" strokeWidth={1.5} />
          </button>
          {confirming ? (
            <span className="flex items-center gap-1.5 whitespace-nowrap text-[0.68rem]">
              <button
                type="button"
                onClick={() => onDelete(task)}
                className="text-haematite underline underline-offset-4"
              >
                حذف شود
              </button>
              <button
                type="button"
                onClick={() => setConfirming(false)}
                className="text-muted underline underline-offset-4"
              >
                نه
              </button>
            </span>
          ) : (
            <button
              type="button"
              onClick={() => setConfirming(true)}
              aria-label="حذف کار"
              className="rounded-sm p-1.5 text-muted transition-colors hover:bg-raised hover:text-haematite"
            >
              <Trash2 className="h-4 w-4" strokeWidth={1.5} />
            </button>
          )}
        </div>
      </div>
    </motion.article>
  );
}
