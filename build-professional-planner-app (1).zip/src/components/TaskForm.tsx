"use client";

import { useEffect, useState, type FormEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { CalendarClock, X } from "lucide-react";
import type { Priority, Repeat, TaskDto, TaskKind, TaskPayload } from "@/lib/api-types";
import { PRIORITY_LABEL, REPEAT_LABEL } from "@/lib/api-types";
import {
  combineDateTime,
  dateFieldCaption,
  toDateField,
  toPersianDigits,
  toTimeField,
} from "@/lib/jalali";

interface FormState {
  title: string;
  notes: string;
  dueDate: string;
  dueTime: string;
  remindDate: string;
  remindTime: string;
  priority: Priority;
  repeat: Repeat;
  tags: string;
  loose: boolean;
}

function emptyState(kind: TaskKind): FormState {
  const today = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  const dateField = `${today.getFullYear()}-${p(today.getMonth() + 1)}-${p(today.getDate())}`;
  return {
    title: "",
    notes: "",
    dueDate: kind === "reminder" ? dateField : dateField,
    dueTime: kind === "reminder" ? "08:30" : "09:00",
    remindDate: "",
    remindTime: "",
    priority: "medium",
    repeat: "none",
    tags: "",
    loose: false,
  };
}

function fromTask(task: TaskDto): FormState {
  return {
    title: task.title,
    notes: task.notes ?? "",
    dueDate: toDateField(task.dueAt),
    dueTime: toTimeField(task.dueAt) || "09:00",
    remindDate: toDateField(task.remindAt),
    remindTime: toTimeField(task.remindAt),
    priority: task.priority,
    repeat: task.repeat,
    tags: task.tags.join("، "),
    loose: task.loose,
  };
}

export function TaskForm({
  kind,
  editing,
  onSaved,
  onCancelEdit,
}: {
  kind: TaskKind;
  editing: TaskDto | null;
  onSaved: (task: TaskDto) => void;
  onCancelEdit: () => void;
}) {
  const [form, setForm] = useState<FormState>(() => emptyState(kind));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [flash, setFlash] = useState<string | null>(null);

  useEffect(() => {
    if (editing) setForm(fromTask(editing));
  }, [editing]);

  useEffect(() => {
    if (!editing) setForm(emptyState(kind));
  }, [kind, editing]);

  useEffect(() => {
    if (!flash) return;
    const t = window.setTimeout(() => setFlash(null), 2600);
    return () => window.clearTimeout(t);
  }, [flash]);

  function set<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (saving) return;
    const title = form.title.trim();
    if (!title) {
      setError("عنوان کار را بنویسید؛ دفترِ بی‌عنوان بسته نمی‌شود.");
      return;
    }
    setError(null);
    setSaving(true);

    const payload: TaskPayload = {
      kind,
      title,
      notes: form.notes.trim() || null,
      dueAt: form.loose ? null : combineDateTime(form.dueDate, form.dueTime),
      remindAt: combineDateTime(form.remindDate, form.remindTime),
      priority: form.priority,
      repeat: form.repeat,
      tags: form.tags
        .split(/[،,]/)
        .map((t) => t.trim())
        .filter(Boolean),
      loose: form.loose,
    };

    try {
      const res = await fetch(editing ? `/api/tasks/${editing.id}` : "/api/tasks", {
        method: editing ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error ?? "ذخیره انجام نشد");
      onSaved(data.task);
      // state reset — never `form.reset()` on a ref that can be null
      setForm(emptyState(kind));
      setFlash(editing ? "کار به‌روزرسانی شد" : kind === "reminder" ? "یادآوری ثبت شد" : "کار ذخیره شد");
    } catch (err) {
      setError(err instanceof Error ? err.message : "خطای ناشناخته رخ داد");
    } finally {
      setSaving(false);
    }
  }

  const caption = form.loose ? "این یادداشت تاریخ نمی‌گیرد" : dateFieldCaption(form.dueDate);

  return (
    <form
      onSubmit={handleSubmit}
      className="gold-frame relative bg-panel/85 p-6 backdrop-blur-sm"
      noValidate
    >
      <div className="mb-5 flex items-baseline justify-between border-b border-rule/25 pb-3">
        <h2 className="text-2xl font-extrabold tracking-tight text-paper">
          {editing ? "ویرایشِ کار" : kind === "reminder" ? "یادآوریِ تازه" : "کارِ تازه"}
        </h2>
        {editing ? (
          <button
            type="button"
            onClick={onCancelEdit}
            className="label-track inline-flex items-center gap-1 text-muted transition-colors hover:text-haematite"
          >
            <X className="h-3.5 w-3.5" />
            انصراف
          </button>
        ) : (
          <span className="label-track">حاشیه</span>
        )}
      </div>

      <div className="space-y-4">
        <label className="block">
          <span className="label-track">عنوان</span>
          <input
            className="field mt-1.5"
            value={form.title}
            onChange={(e) => set("title", e.target.value)}
            placeholder="مثلاً: زنگ بزن به چاپخانهٔ نگارستان"
            maxLength={220}
          />
        </label>

        <label className="block">
          <span className="label-track">یادداشت</span>
          <textarea
            className="field mt-1.5 min-h-[5.5rem] resize-y leading-6"
            value={form.notes}
            onChange={(e) => set("notes", e.target.value)}
            placeholder="جزئیات، شمارهٔ فاکتور، آدرس…"
          />
        </label>

        <fieldset disabled={form.loose} className="disabled:opacity-40">
          <div className="grid grid-cols-2 gap-3">
            <label className="block">
              <span className="label-track">تاریخ</span>
              <input
                type="date"
                className="field mt-1.5"
                value={form.dueDate}
                onChange={(e) => set("dueDate", e.target.value)}
              />
            </label>
            <label className="block">
              <span className="label-track">ساعت</span>
              <input
                type="time"
                className="field mt-1.5"
                value={form.dueTime}
                onChange={(e) => set("dueTime", e.target.value)}
              />
            </label>
          </div>
          <p className="mt-2 flex items-center gap-1.5 text-[0.7rem] text-rule/90">
            <CalendarClock className="h-3.5 w-3.5" strokeWidth={1.5} />
            <AnimatePresence mode="wait" initial={false}>
              <motion.span
                key={caption}
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                transition={{ duration: 0.18 }}
              >
                {toPersianDigits(caption)}
              </motion.span>
            </AnimatePresence>
          </p>
        </fieldset>

        <div className="grid grid-cols-2 gap-3">
          <label className="block">
            <span className="label-track">اولویت</span>
            <select
              className="field mt-1.5"
              value={form.priority}
              onChange={(e) => set("priority", e.target.value as Priority)}
            >
              {(Object.keys(PRIORITY_LABEL) as Priority[]).map((p) => (
                <option key={p} value={p}>
                  {PRIORITY_LABEL[p]}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label-track">تکرار</span>
            <select
              className="field mt-1.5"
              value={form.repeat}
              onChange={(e) => set("repeat", e.target.value as Repeat)}
            >
              {(Object.keys(REPEAT_LABEL) as Repeat[]).map((r) => (
                <option key={r} value={r}>
                  {REPEAT_LABEL[r]}
                </option>
              ))}
            </select>
          </label>
        </div>

        <label className="block">
          <span className="label-track">تگ‌ها</span>
          <input
            className="field mt-1.5"
            value={form.tags}
            onChange={(e) => set("tags", e.target.value)}
            placeholder="مالی، چاپ، خانواده"
          />
        </label>

        <div className="rounded-sm border border-rule/15 bg-ink/40 p-3">
          <span className="label-track">یادآوری</span>
          <div className="mt-2 grid grid-cols-2 gap-3">
            <input
              type="date"
              aria-label="تاریخ یادآوری"
              className="field"
              value={form.remindDate}
              onChange={(e) => set("remindDate", e.target.value)}
            />
            <input
              type="time"
              aria-label="ساعت یادآوری"
              className="field"
              value={form.remindTime}
              onChange={(e) => set("remindTime", e.target.value)}
            />
          </div>
          <p className="mt-2 text-[0.68rem] leading-5 text-muted/80">
            {form.remindDate
              ? `یادآوری: ${toPersianDigits(dateFieldCaption(form.remindDate))}`
              : "یادآوری ثبت نشده است."}
          </p>
        </div>

        <label className="flex cursor-pointer items-center gap-2.5 text-[0.8rem] text-muted">
          <input
            type="checkbox"
            checked={form.loose}
            onChange={(e) => set("loose", e.target.checked)}
            className="h-4 w-4 accent-[#2FB8C4]"
          />
          یادداشتِ بی‌تاریخ — بدون موعد و ساعت
        </label>
      </div>

      <AnimatePresence>
        {error ? (
          <motion.p
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            role="alert"
            className="mt-4 overflow-hidden border-s-2 border-haematite bg-haematite/10 px-3 py-2 text-[0.78rem] text-haematite"
          >
            {error}
          </motion.p>
        ) : null}
        {flash ? (
          <motion.p
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            role="status"
            className="mt-4 overflow-hidden border-s-2 border-firoozeh bg-firoozeh/10 px-3 py-2 text-[0.78rem] text-firoozeh-light"
          >
            {flash}
          </motion.p>
        ) : null}
      </AnimatePresence>

      <button
        type="submit"
        disabled={saving}
        className="mt-5 w-full bg-firoozeh-deep py-3 text-sm font-bold tracking-wide text-paper transition-colors hover:bg-firoozeh disabled:cursor-not-allowed disabled:opacity-60"
      >
        {saving
          ? "در حال ذخیره…"
          : editing
            ? "به‌روزرسانیِ کار"
            : kind === "reminder"
              ? "ذخیرهٔ یادآوری"
              : "ذخیرهٔ کار"}
      </button>
    </form>
  );
}
