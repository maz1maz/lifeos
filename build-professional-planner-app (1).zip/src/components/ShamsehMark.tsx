export function ShamsehMark({
  className = "",
  size = 44,
}: {
  className?: string;
  size?: number;
}) {
  return (
    <svg
      viewBox="0 0 100 100"
      width={size}
      height={size}
      className={className}
      role="img"
      aria-label="نشانِ شمسه"
    >
      <defs>
        <path
          id="shamseh-petal"
          d="M50 6 C55.5 20, 62 27.5, 74 33 C62 38.5, 55.5 46, 50 60 C44.5 46, 38 38.5, 26 33 C38 27.5, 44.5 20, 50 6 Z"
        />
        <path
          id="shamseh-ray"
          d="M50 2 C51.6 12, 53 18, 54.4 25 C52.2 26, 51.1 26.4, 50 26.4 C48.9 26.4, 47.8 26, 45.6 25 C47 18, 48.4 12, 50 2 Z"
        />
        <radialGradient id="shamseh-gold" cx="50%" cy="42%" r="60%">
          <stop offset="0%" stopColor="#F0DCA0" />
          <stop offset="55%" stopColor="#C9A24A" />
          <stop offset="100%" stopColor="#7A5F22" />
        </radialGradient>
      </defs>
      <g fill="url(#shamseh-gold)" stroke="rgba(201,162,74,0.55)" strokeWidth="0.6">
        <g>
          <use href="#shamseh-ray" transform="rotate(45 50 50)" />
          <use href="#shamseh-ray" transform="rotate(90 50 50)" />
          <use href="#shamseh-ray" transform="rotate(135 50 50)" />
          <use href="#shamseh-ray" transform="rotate(180 50 50)" />
          <use href="#shamseh-ray" transform="rotate(225 50 50)" />
          <use href="#shamseh-ray" transform="rotate(270 50 50)" />
          <use href="#shamseh-ray" transform="rotate(315 50 50)" />
          <use href="#shamseh-ray" />
        </g>
        <g opacity="0.92">
          <use href="#shamseh-petal" transform="rotate(45 50 50)" />
          <use href="#shamseh-petal" transform="rotate(90 50 50)" />
          <use href="#shamseh-petal" transform="rotate(135 50 50)" />
          <use href="#shamseh-petal" transform="rotate(180 50 50)" />
          <use href="#shamseh-petal" transform="rotate(225 50 50)" />
          <use href="#shamseh-petal" transform="rotate(270 50 50)" />
          <use href="#shamseh-petal" transform="rotate(315 50 50)" />
        </g>
      </g>
      <circle cx="50" cy="50" r="9.5" fill="#071722" stroke="#C9A24A" strokeWidth="1.2" />
      <circle cx="50" cy="50" r="4.2" fill="#2FB8C4" />
    </svg>
  );
}
