"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { BookOpenCheck, Search } from "lucide-react";
import { ShamsehMark } from "@/components/ShamsehMark";
import { TaskForm } from "@/components/TaskForm";
import { TaskRow } from "@/components/TaskRow";
import type { FilterKey, TaskDto, TaskKind } from "@/lib/api-types";
import {
  addDays,
  formatJalali,
  formatJalaliShort,
  formatTime,
  toPersianDigits,
  weekdayName,
} from "@/lib/jalali";

interface Counts {
  all: number;
  today: number;
  upcoming: number;
  done: number;
  reminders: number;
}

const FILTERS: { key: FilterKey; label: string }[] = [
  { key: "all", label: "همه" },
  { key: "today", label: "امروز" },
  { key: "upcoming", label: "پیشِ رو" },
  { key: "done", label: "انجام‌شده" },
];

const KINDS: { key: TaskKind; label: string }[] = [
  { key: "task", label: "کارها" },
  { key: "reminder", label: "یادآوری‌ها" },
];

export function Planner() {
  const [kind, setKind] = useState<TaskKind>("task");
  const [filter, setFilter] = useState<FilterKey>("all");
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  const [tasks, setTasks] = useState<TaskDto[]>([]);
  const [counts, setCounts] = useState<Counts>({
    all: 0,
    today: 0,
    upcoming: 0,
    done: 0,
    reminders: 0,
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [editing, setEditing] = useState<TaskDto | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    const t = window.setTimeout(() => setDebounced(query.trim()), 220);
    return () => window.clearTimeout(t);
  }, [query]);

  const load = useCallback(async () => {
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;
    setLoading(true);
    try {
      const params = new URLSearchParams({ kind, filter });
      if (debounced) params.set("q", debounced);
      const res = await fetch(`/api/tasks?${params.toString()}`, {
        signal: controller.signal,
        cache: "no-store",
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error ?? "خواندن دفتر ممکن نشد");
      setTasks(data.tasks as TaskDto[]);
      setCounts(data.counts as Counts);
      setError(null);
    } catch (err) {
      if (err instanceof DOMException && err.name === "AbortError") return;
      setError(err instanceof Error ? err.message : "خطای ناشناخته رخ داد");
    } finally {
      if (abortRef.current === controller) setLoading(false);
    }
  }, [kind, filter, debounced]);

  useEffect(() => {
    void load();
  }, [load]);

  async function patch(task: TaskDto, body: Record<string, unknown>) {
    const res = await fetch(`/api/tasks/${task.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data?.error ?? "به‌روزرسانی انجام نشد");
    return data.task as TaskDto;
  }

  async function handleToggle(task: TaskDto) {
    try {
      const updated = await patch(task, { done: !task.done });
      setTasks((prev) =>
        filter === "done" && !updated.done
          ? prev.filter((t) => t.id !== updated.id)
          : prev.map((t) => (t.id === updated.id ? updated : t)),
      );
      void load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "تغییر وضعیت انجام نشد");
    }
  }

  async function handleDelete(task: TaskDto) {
    try {
      const res = await fetch(`/api/tasks/${task.id}`, { method: "DELETE" });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data?.error ?? "حذف انجام نشد");
      }
      setTasks((prev) => prev.filter((t) => t.id !== task.id));
      if (editing?.id === task.id) setEditing(null);
      void load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "حذف انجام نشد");
    }
  }

  function handleSaved(task: TaskDto) {
    setTasks((prev) => {
      const exists = prev.some((t) => t.id === task.id);
      return exists ? prev.map((t) => (t.id === task.id ? task : t)) : [task, ...prev];
    });
    setEditing(null);
    void load();
  }

  const today = new Date();
  const tomorrow = addDays(today, 1);

  const emptyMessage = useMemo(() => {
    if (debounced) return `چیزی برای «${debounced}» در دفتر پیدا نشد.`;
    if (filter === "done") return "هنوز کاری را تمام نکرده‌اید.";
    if (filter === "today") return "برای امروز کاری ثبت نشده — روزِ سبکی است.";
    if (filter === "upcoming") return "پیشِ رو چیزی نیست؛ دفتر تا هفتهٔ آینده خالی است.";
    return kind === "reminder"
      ? "یادآوری‌ای ثبت نشده است."
      : "دفترِ امروز خالی است. اولین کار را در حاشیه بنویسید.";
  }, [debounced, filter, kind]);

  return (
    <div className="mx-auto max-w-[1180px] px-5 pb-24 pt-6 sm:px-8">
      {/* ─── سرلوح ─── */}
      <header className="gold-frame relative overflow-hidden bg-panel/70">
        <img
          src="images/tazhib.jpg"
          alt=""
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 h-full w-full scale-x-[-1] object-cover opacity-45 mix-blend-luminosity"
          onError={(e) => {
            e.currentTarget.style.display = "none";
          }}
        />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-l from-ink/30 via-ink/75 to-ink/95" />
        <div className="relative flex flex-col gap-6 p-7 sm:p-9 lg:flex-row lg:items-end lg:justify-between">
          <div className="flex items-start gap-4">
            <ShamsehMark size={52} className="mt-1 shrink-0" />
            <div>
              <p className="label-track">دفترِ برنامهٔ روزانه</p>
              <h1 className="mt-1 text-[2.4rem] font-black leading-[1.15] tracking-tight text-paper sm:text-[3rem]">
                کارها و یادآوری‌ها
              </h1>
              <p className="nastaliq mt-1 text-[1.35rem] text-rule">
                برنامه‌ریزی با دقت و حواسِّ دقیق
              </p>
            </div>
          </div>

          <div className="flex flex-col items-start gap-4 lg:items-end">
            <nav className="flex gap-2">
              {KINDS.map((k) => (
                <button
                  key={k.key}
                  type="button"
                  onClick={() => {
                    setKind(k.key);
                    setFilter("all");
                    setEditing(null);
                  }}
                  data-active={kind === k.key}
                  className="chip"
                >
                  {k.label}
                </button>
              ))}
            </nav>
            <div className="text-[0.8rem] text-muted">
              <span className="nastaliq text-[1.5rem] text-firoozeh-light">امروز</span>{" "}
              {weekdayName(today)}، {formatJalali(today)} —{" "}
              <span className="text-muted/70">فردا {formatJalaliShort(tomorrow)}</span>
            </div>
            <dl className="flex gap-5 text-[0.72rem]">
              {[
                { label: "باز", value: counts.all },
                { label: "امروز", value: counts.today },
                { label: "پیشِ رو", value: counts.upcoming },
                { label: "انجام‌شده", value: counts.done },
              ].map((s) => (
                <div key={s.label} className="text-center">
                  <dt className="label-track">{s.label}</dt>
                  <dd className="mt-0.5 text-lg font-light tabular-nums text-paper">
                    {toPersianDigits(s.value)}
                  </dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </header>

      {/* ─── نوار فیلتر ─── */}
      <div className="mt-5 flex flex-col gap-3 rounded-sm border border-rule/15 bg-panel/55 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap gap-2">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              type="button"
              onClick={() => setFilter(f.key)}
              data-active={filter === f.key}
              className="chip"
            >
              {f.label}
              <span className="ms-1.5 tabular-nums opacity-70">
                {toPersianDigits(
                  f.key === "all"
                    ? counts.all
                    : f.key === "today"
                      ? counts.today
                      : f.key === "upcoming"
                        ? counts.upcoming
                        : counts.done,
                )}
              </span>
            </button>
          ))}
        </div>
        <label className="relative block sm:w-64">
          <Search
            className="pointer-events-none absolute end-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted/70"
            strokeWidth={1.5}
          />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="جست‌وجو در دفتر…"
            className="field pe-9"
            aria-label="جست‌وجو در دفتر"
          />
        </label>
      </div>

      <AnimatePresence>
        {error ? (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            role="alert"
            className="mt-4 flex items-center justify-between gap-4 overflow-hidden border-s-2 border-haematite bg-haematite/10 px-4 py-2.5 text-[0.8rem] text-haematite"
          >
            <span>{error}</span>
            <button
              type="button"
              onClick={() => setError(null)}
              className="label-track shrink-0"
            >
              بستن
            </button>
          </motion.div>
        ) : null}
      </AnimatePresence>

      {/* ─── صفحه: حاشیه + دفتر ─── */}
      <div className="mt-6 grid grid-cols-1 gap-7 lg:grid-cols-12">
        <aside className="lg:col-span-4 lg:col-start-9">
          <div className="lg:sticky lg:top-6">
            <TaskForm
              kind={kind}
              editing={editing}
              onSaved={handleSaved}
              onCancelEdit={() => setEditing(null)}
            />
            <p className="mt-4 border-s border-rule/25 ps-3 text-[0.7rem] leading-6 text-muted/75">
              همه چیز همان‌جا که نوشته‌اید می‌نشیند: ساعت و تاریخِ شمسی در حاشیهٔ دفتر
              ثبت می‌شود و کارِ انجام‌شده با یک خطِّ فیروزه‌ای از دفتر کنار می‌رود.
            </p>
          </div>
        </aside>

        <section className="lg:col-span-8 lg:col-start-1">
          <div className="flex items-baseline justify-between border-b-2 border-rule/35 pb-2">
            <h2 className="flex items-center gap-2 text-xl font-extrabold text-paper">
              <BookOpenCheck className="h-5 w-5 text-rule" strokeWidth={1.5} />
              {kind === "reminder" ? "فهرستِ یادآوری‌ها" : "دفترِ کارها"}
            </h2>
            <span className="label-track">
              {FILTERS.find((f) => f.key === filter)?.label} ·{" "}
              {toPersianDigits(tasks.length)} سطر
            </span>
          </div>

          <div className="relative mt-2">
            {/* continuous margin rule of the ledger */}
            <div className="pointer-events-none absolute inset-y-0 start-0 hidden w-px bg-rule/20 lg:block" />
            {loading && tasks.length === 0 ? (
              <div className="space-y-3 py-8">
                {[0, 1, 2].map((i) => (
                  <div
                    key={i}
                    className="h-16 animate-pulse rounded-sm bg-raised/50"
                    style={{ animationDelay: `${i * 120}ms` }}
                  />
                ))}
              </div>
            ) : null}

            <AnimatePresence mode="popLayout" initial={false}>
              {tasks.map((task, index) => (
                <TaskRow
                  key={task.id}
                  task={task}
                  index={index}
                  onToggle={handleToggle}
                  onEdit={setEditing}
                  onDelete={handleDelete}
                />
              ))}
            </AnimatePresence>

            {!loading && tasks.length === 0 ? (
              <div className="flex flex-col items-center gap-3 border border-dashed border-rule/20 px-6 py-16 text-center">
                <ShamsehMark size={40} className="opacity-60" />
                <p className="max-w-[36ch] text-sm leading-7 text-muted">{emptyMessage}</p>
              </div>
            ) : null}
          </div>
        </section>
      </div>

      <footer className="mt-16 flex items-center justify-between border-t border-rule/20 pt-4 text-[0.68rem] text-muted/70">
        <span>دفترِ کارها و یادآوری‌ها — ثبت به تاریخِ هجریِ شمسی</span>
        <span className="tabular-nums">
          آخرین به‌روزرسانی: {formatTime(new Date())}
        </span>
      </footer>
    </div>
  );
}


