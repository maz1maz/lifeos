"use client";

import { motion } from "framer-motion";
import { Plus, Repeat } from "lucide-react";
import { GirihMark } from "@/components/Ornament";
import {
  faNum,
  gregorianShort,
  isoToJalali,
  isoWeekNumber,
  jalaliToIso,
  monthLength,
  weekdayIndex,
} from "@/lib/dates";
import { occasionsFor } from "@/lib/occasions";
import { occurrencesOn } from "@/lib/occurrence";
import { CATEGORY_META, type EventRow, type TaskRow } from "@/lib/types";

export default function MonthSheet({
  days,
  monthAnchor,
  events,
  tasks,
  selected,
  today,
  onSelect,
  onCreate,
  onOpenEvent,
  onOpenTask,
}: {
  days: string[];
  monthAnchor: string;
  events: EventRow[];
  tasks: TaskRow[];
  selected: string;
  today: string;
  onSelect: (day: string) => void;
  onCreate: (day: string) => void;
  onOpenEvent: (event: EventRow) => void;
  onOpenTask: (task: TaskRow) => void;
}) {
  const anchorJ = isoToJalali(monthAnchor);
  const rows = [0, 1, 2, 3, 4, 5];

  return (
    <div className="border-t border-r border-rule bg-[rgba(9,16,31,0.55)]">
      <div className="grid grid-cols-7 border-b border-rule">
        {["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"].map((w, i) => (
          <div
            key={w}
            className={`border-l border-rule px-3 py-2.5 text-center ${
              i === 6 ? "text-crimson/80" : "text-muted"
            }`}
          >
            <span className="micro">{w}</span>
          </div>
        ))}
      </div>

      {rows.map((rowIndex) => (
        <motion.div
          key={`${monthAnchor}-${rowIndex}`}
          className="grid grid-cols-7"
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.22, delay: rowIndex * 0.018, ease: [0.2, 0.7, 0.3, 1] }}
        >
          {days.slice(rowIndex * 7, rowIndex * 7 + 7).map((day) => {
            const j = isoToJalali(day);
            const inMonth = j.jy === anchorJ.jy && j.jm === anchorJ.jm;
            const isToday = day === today;
            const isSelected = day === selected;
            const isFriday = weekdayIndex(day) === 6;
            const occs = occurrencesOn(events, day);
            const dayTasks = tasks.filter((t) => t.due === day);
            const occ = occasionsFor(j.jm, j.jd);
            const holiday = occ.some((o) => o.holiday);
            const isSaturday = weekdayIndex(day) === 0;

            return (
              <div
                key={day}
                onClick={() => onSelect(day)}
                onDoubleClick={() => onCreate(day)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === "Enter") onSelect(day);
                }}
                className={`group relative min-h-[104px] cursor-pointer border-b border-l border-rule px-2 py-1.5 transition-colors md:min-h-[132px] ${
                  inMonth ? "" : "bg-[rgba(4,9,18,0.55)] opacity-45"
                } ${isSelected ? "bg-[rgba(216,166,87,0.08)]" : "hover:bg-[rgba(55,201,192,0.05)]"}`}
              >
                {isToday ? (
                  <span className="pointer-events-none absolute inset-0 border border-gold/70" />
                ) : null}

                <div className="flex items-start justify-between">
                  <span
                    className={`tnum text-[1.35rem] font-bold leading-none ${
                      holiday || isFriday
                        ? "text-crimson"
                        : isToday
                          ? "text-goldsoft"
                          : inMonth
                            ? "text-fg"
                            : "text-dim"
                    }`}
                  >
                    {faNum(j.jd)}
                  </span>
                  <span className="tnum text-[0.68rem] leading-none text-dim">
                    {gregorianShort(day)}
                  </span>
                </div>

                {isToday ? (
                  <span className="absolute left-1.5 top-8 flex items-center gap-1 text-[0.6rem] font-bold text-gold">
                    <GirihMark className="h-2.5 w-2.5" fill="#d8a657" /> امروز
                  </span>
                ) : null}

                {isSaturday ? (
                  <span className="tnum mt-1 block text-[0.6rem] text-dim/80">
                    هفتهٔ {faNum(isoWeekNumber(day))}
                  </span>
                ) : null}

                {occ.length > 0 ? (
                  <p className="serif-voice mt-1 truncate text-[0.72rem] text-crimson">
                    {occ[0].title}
                  </p>
                ) : null}

                <div className="mt-1 space-y-[3px]">
                  {occs.slice(0, 3).map(({ event, day: occDay }) => {
                    const meta = CATEGORY_META[event.category] ?? CATEGORY_META.personal;
                    return (
                      <button
                        key={`${event.id}-${occDay}`}
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenEvent(event);
                        }}
                        title={event.title}
                        className="flex w-full items-center gap-1 truncate px-1.5 py-[3px] text-right text-[0.7rem] transition-transform hover:translate-x-[-2px]"
                        style={{
                          background: meta.soft,
                          borderInlineStart: `2px solid ${meta.color}`,
                          color: "#dbe5f5",
                        }}
                      >
                        {!event.allDay && event.startTime ? (
                          <span className="tnum shrink-0 text-[0.62rem] text-muted">
                            {faNum(event.startTime)}
                          </span>
                        ) : null}
                        {event.repeatRule !== "none" ? (
                          <Repeat size={9} className="shrink-0 text-muted" />
                        ) : null}
                        <span className={`truncate ${event.done ? "line-through opacity-50" : ""}`}>
                          {event.title}
                        </span>
                      </button>
                    );
                  })}
                  {dayTasks.slice(0, 2).map((task) => (
                    <button
                      key={`t-${task.id}`}
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenTask(task);
                      }}
                      title={task.title}
                      className="flex w-full items-center gap-1 truncate px-1.5 py-[3px] text-right text-[0.7rem]"
                      style={{
                        background: "rgba(55,201,192,0.08)",
                        borderInlineStart: "2px dotted #37c9c0",
                        color: "#a9e7e2",
                      }}
                    >
                      <span className={`truncate ${task.done ? "line-through opacity-50" : ""}`}>
                        □ {task.title}
                      </span>
                    </button>
                  ))}
                  {occs.length + dayTasks.length > 5 ? (
                    <span className="tnum block px-1 text-[0.62rem] text-dim">
                      +{faNum(occs.length + dayTasks.length - 5)} مورد دیگر
                    </span>
                  ) : null}
                </div>

                <button
                  type="button"
                  aria-label="افزودن رویداد"
                  onClick={(e) => {
                    e.stopPropagation();
                    onCreate(day);
                  }}
                  className="absolute bottom-1.5 left-1.5 border border-rule bg-lapis p-1 text-dim opacity-0 transition-all hover:border-gold hover:text-gold focus-visible:opacity-100 group-hover:opacity-100"
                >
                  <Plus size={12} />
                </button>
              </div>
            );
          })}
        </motion.div>
      ))}
    </div>
  );
}

export function monthHasData(anchor: string, events: EventRow[], tasks: TaskRow[]) {
  const j = isoToJalali(anchor);
  const first = jalaliToIso(j.jy, j.jm, 1);
  const len = monthLength(j.jy, j.jm);
  let eventCount = 0;
  let taskCount = 0;
  for (let d = 0; d < len; d += 1) {
    const day = new Date(new Date(`${first}T00:00:00Z`).getTime() + d * 86400000)
      .toISOString()
      .slice(0, 10);
    eventCount += occurrencesOn(events, day).length;
    taskCount += tasks.filter((t) => t.due === day).length;
  }
  return { eventCount, taskCount };
}
