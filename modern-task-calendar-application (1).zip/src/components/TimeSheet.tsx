"use client";

import { motion } from "framer-motion";
import {
  faNum,
  isoToJalali,
  jalaliDateLine,
  weekdayFull,
} from "@/lib/dates";
import { occasionsFor } from "@/lib/occasions";
import { occurrencesOn } from "@/lib/occurrence";
import { CATEGORY_META, type EventRow, type Occurrence } from "@/lib/types";

const START_HOUR = 5;
const END_HOUR = 24;
const HOUR_PX = 52;

function minutesOf(time: string | null): number {
  if (!time) return START_HOUR * 60;
  const [h, m] = time.split(":").map(Number);
  return h * 60 + m;
}

function layout(dayOccs: Occurrence[]) {
  const timed = dayOccs.filter((o) => !o.event.allDay);
  const sorted = [...timed].sort(
    (a, b) => minutesOf(a.event.startTime) - minutesOf(b.event.startTime),
  );
  const result: { occ: Occurrence; lane: number; lanes: number }[] = [];
  let cluster: typeof result = [];
  let clusterEnd = -1;

  const flush = () => {
    const lanes = Math.max(1, cluster.length);
    cluster.forEach((item, i) => result.push({ ...item, lane: i, lanes }));
    cluster = [];
    clusterEnd = -1;
  };

  for (const occ of sorted) {
    const start = minutesOf(occ.event.startTime);
    const end = Math.max(start + 30, minutesOf(occ.event.endTime));
    if (start >= clusterEnd && cluster.length > 0) flush();
    cluster.push({ occ, lane: 0, lanes: 1 });
    clusterEnd = Math.max(clusterEnd, end);
  }
  if (cluster.length > 0) flush();
  return result;
}

export default function TimeSheet({
  days,
  events,
  today,
  onOpenEvent,
  onCreate,
}: {
  days: string[];
  events: EventRow[];
  today: string;
  onOpenEvent: (event: EventRow) => void;
  onCreate: (day: string, time: string) => void;
}) {
  const hours = Array.from({ length: END_HOUR - START_HOUR }, (_, i) => START_HOUR + i);
  const cols = `52px repeat(${days.length}, minmax(0, 1fr))`;

  return (
    <div className="overflow-x-auto border border-rule bg-[rgba(9,16,31,0.55)]">
      <div className="min-w-[680px]">
      <div
        className="grid border-b border-rule"
        style={{ gridTemplateColumns: cols }}
      >
        <div className="border-l border-rule" />
        {days.map((day) => {
          const j = isoToJalali(day);
          const occ = occasionsFor(j.jm, j.jd);
          return (
            <div
              key={day}
              className={`border-l border-rule px-2 py-2 text-center ${
                day === today ? "bg-[rgba(216,166,87,0.08)]" : ""
              }`}
            >
              <p className="micro text-muted">{weekdayFull(day)}</p>
              <p
                className={`tnum mt-1 text-xl font-bold ${
                  occ.some((o) => o.holiday) ? "text-crimson" : day === today ? "text-goldsoft" : ""
                }`}
              >
                {faNum(j.jd)}
              </p>
              {occ.length > 0 ? (
                <p className="serif-voice truncate text-[0.65rem] text-crimson">{occ[0].title}</p>
              ) : null}
            </div>
          );
        })}
      </div>

      <div className="grid border-b border-rule" style={{ gridTemplateColumns: cols }}>
        <div className="border-l border-rule px-1 py-2 text-center">
          <span className="micro text-dim">تمام‌روز</span>
        </div>
        {days.map((day) => {
          const allDay = occurrencesOn(events, day).filter((o) => o.event.allDay);
          return (
            <div key={day} className="min-h-[38px] space-y-1 border-l border-rule p-1">
              {allDay.map(({ event }) => {
                const meta = CATEGORY_META[event.category] ?? CATEGORY_META.personal;
                return (
                  <button
                    key={`${event.id}-${day}`}
                    type="button"
                    onClick={() => onOpenEvent(event)}
                    className="block w-full truncate px-1.5 py-[3px] text-right text-[0.7rem]"
                    style={{
                      background: meta.soft,
                      borderInlineStart: `2px solid ${meta.color}`,
                      color: "#dbe5f5",
                    }}
                  >
                    {event.title}
                  </button>
                );
              })}
            </div>
          );
        })}
      </div>

      <div className="max-h-[560px] overflow-y-auto">
        <div
          className="relative grid"
          style={{
            height: (END_HOUR - START_HOUR) * HOUR_PX,
            gridTemplateColumns: cols,
          }}
        >
          <div className="border-l border-rule">
            {hours.map((h) => (
              <div
                key={h}
                className="tnum border-b border-rule/60 pr-2 pt-1 text-[0.68rem] text-dim"
                style={{ height: HOUR_PX }}
              >
                {faNum(String(h).padStart(2, "0"))}:۰۰
              </div>
            ))}
          </div>

          {days.map((day) => (
            <div key={day} className="relative border-l border-rule">
              {hours.map((h) => (
                <button
                  key={h}
                  type="button"
                  aria-label={`افزودن رویداد ساعت ${h}`}
                  onClick={() => onCreate(day, `${String(h).padStart(2, "0")}:00`)}
                  className="block w-full border-b border-rule/60 transition-colors hover:bg-[rgba(55,201,192,0.06)]"
                  style={{ height: HOUR_PX }}
                />
              ))}

              {layout(occurrencesOn(events, day)).map(({ occ, lane, lanes }) => {
                const meta = CATEGORY_META[occ.event.category] ?? CATEGORY_META.personal;
                const start = minutesOf(occ.event.startTime);
                const end = Math.max(start + 30, minutesOf(occ.event.endTime));
                const top = ((start - START_HOUR * 60) / 60) * HOUR_PX;
                const height = Math.max(22, ((end - start) / 60) * HOUR_PX - 2);
                return (
                  <motion.button
                    key={occ.key}
                    type="button"
                    initial={{ opacity: 0, scale: 0.96 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.2 }}
                    onClick={() => onOpenEvent(occ.event)}
                    className="absolute overflow-hidden px-2 py-1 text-right text-[0.72rem] leading-5"
                    style={{
                      top,
                      height,
                      insetInlineStart: `${(lane / lanes) * 100}%`,
                      width: `${100 / lanes}%`,
                      background: meta.soft,
                      borderInlineStart: `2px solid ${meta.color}`,
                      color: "#dbe5f5",
                    }}
                  >
                    <span className="tnum text-[0.65rem] text-muted">{faNum(occ.event.startTime ?? "")}</span>{" "}
                    <span className={occ.event.done ? "line-through opacity-60" : ""}>
                      {occ.event.title}
                    </span>
                  </motion.button>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      <p className="serif-voice border-t border-rule px-4 py-2 text-xs text-dim">
        {jalaliDateLine(days[0])} — {jalaliDateLine(days[days.length - 1])}
      </p>
      </div>
    </div>
  );
}
