"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Bell, Check, ListTodo, Pencil, Plus, Repeat, Save, Square } from "lucide-react";
import { GirihRosette } from "@/components/Ornament";
import { faNum, gregorianDateLine, isoToJalali, jalaliDateLine } from "@/lib/dates";
import { occasionsFor } from "@/lib/occasions";
import type { EventRow, Occurrence, TaskRow } from "@/lib/types";
import { CATEGORY_META, PRIORITY_META } from "@/lib/types";

function relTime(ms: number): string {
  const mins = Math.round(ms / 60000);
  if (mins < 1) return "همین حالا";
  if (mins < 60) return `${faNum(mins)} دقیقهٔ دیگر`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${faNum(hours)} ساعت دیگر`;
  return `${faNum(Math.round(hours / 24))} روز دیگر`;
}

export default function DayRail({
  day,
  occurrences,
  dayTasks,
  openTasks,
  note,
  today,
  upcoming,
  onSaveNote,
  onToggleTask,
  onOpenEvent,
  onOpenTask,
  onNewEvent,
  onNewTask,
}: {
  day: string;
  occurrences: Occurrence[];
  dayTasks: TaskRow[];
  openTasks: TaskRow[];
  note: string;
  today: string;
  upcoming: { key: string; title: string; at: number; meta: string }[];
  onSaveNote: (text: string) => void;
  onToggleTask: (task: TaskRow) => void;
  onOpenEvent: (event: EventRow) => void;
  onOpenTask: (task: TaskRow) => void;
  onNewEvent: () => void;
  onNewTask: () => void;
}) {
  const [text, setText] = useState(note);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setText(note);
    setSaved(false);
  }, [day, note]);

  const j = isoToJalali(day);
  const occ = occasionsFor(j.jm, j.jd);
  const isToday = day === today;

  return (
    <motion.aside
      key={day}
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.24, ease: [0.2, 0.7, 0.3, 1] }}
      className="border border-rule bg-[rgba(9,16,31,0.62)] lg:sticky lg:top-4 lg:self-start"
    >
      {/* لوح روز — تذهیب گره */}
      <div className="relative overflow-hidden border-b border-rule">
        <img
          src="images/gilt-leather.jpg"
          alt=""
          aria-hidden="true"
          className="absolute inset-0 h-full w-full object-cover opacity-30"
          onError={(e) => {
            e.currentTarget.style.display = "none";
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[rgba(7,12,24,0.94)] via-[rgba(7,12,24,0.72)] to-[rgba(7,12,24,0.55)]" />
        <div className="relative px-5 py-6 text-center">
          <GirihRosette className="absolute inset-0 mx-auto h-full w-auto opacity-45" />
          <p className="micro relative text-gold">{isToday ? "امروز" : "روز برگزیده"}</p>
          <p className="relative mt-2 text-[1.55rem] font-black leading-tight text-fg">
            {jalaliDateLine(day)}
          </p>
          <p className="serif-voice relative mt-1 text-sm text-muted">{gregorianDateLine(day)}</p>
          <div className="relative mt-3 flex justify-center gap-2">
            <button
              type="button"
              onClick={onNewEvent}
              className="flex items-center gap-1.5 bg-gold px-3 py-1.5 text-[0.75rem] font-bold text-ink transition-colors hover:bg-goldsoft"
            >
              <Plus size={13} /> رویداد
            </button>
            <button
              type="button"
              onClick={onNewTask}
              className="flex items-center gap-1.5 border border-firoozeh/60 px-3 py-1.5 text-[0.75rem] font-bold text-firoozeh transition-colors hover:bg-[rgba(55,201,192,0.12)]"
            >
              <ListTodo size={13} /> کار
            </button>
          </div>
        </div>
      </div>

      {occ.length > 0 ? (
        <div className="border-b border-rule px-4 py-3">
          {occ.map((o) => (
            <p key={o.title} className="serif-voice text-sm text-crimson">
              {o.title}
            </p>
          ))}
        </div>
      ) : null}

      {/* برنامهٔ روز */}
      <section className="border-b border-rule px-4 py-4">
        <h3 className="micro mb-3 text-dim">برنامهٔ این روز</h3>
        {occurrences.length === 0 ? (
          <p className="serif-voice text-sm leading-7 text-muted">
            این روز خالی است. دوبار روی روز در برگهٔ ماه بزنید یا دکمهٔ «رویداد» را بگیرید.
          </p>
        ) : (
          <ul className="space-y-2">
            {occurrences.map(({ event, key }) => {
              const meta = CATEGORY_META[event.category] ?? CATEGORY_META.personal;
              return (
                <li key={key}>
                  <button
                    type="button"
                    onClick={() => onOpenEvent(event)}
                    className="group flex w-full items-start gap-2.5 border border-rule/70 px-2.5 py-2 text-right transition-colors hover:border-gold/60"
                  >
                    <span
                      className="mt-1 h-2.5 w-2.5 shrink-0 rounded-full"
                      style={{ background: meta.color }}
                    />
                    <span className="flex-1">
                      <span
                        className={`block text-sm leading-6 ${
                          event.done ? "text-dim line-through" : "text-fg"
                        }`}
                      >
                        {event.title}
                      </span>
                      <span className="tnum mt-0.5 flex items-center gap-2 text-[0.68rem] text-dim">
                        {event.allDay ? "تمام‌روز" : `${faNum(event.startTime ?? "")} تا ${faNum(event.endTime ?? "")}`}
                        {event.repeatRule !== "none" ? (
                          <span className="flex items-center gap-1">
                            <Repeat size={10} />
                            {event.repeatRule === "weekly"
                              ? "هفتگی"
                              : event.repeatRule === "daily"
                                ? "روزانه"
                                : event.repeatRule === "monthly"
                                  ? "ماهانه"
                                  : "سالانه"}
                          </span>
                        ) : null}
                        {event.remindBefore != null ? (
                          <span className="flex items-center gap-1 text-gold">
                            <Bell size={10} />
                            {faNum(event.remindBefore)} دقیقه پیش
                          </span>
                        ) : null}
                      </span>
                      {event.notes ? (
                        <span className="serif-voice mt-1 block text-xs text-muted">{event.notes}</span>
                      ) : null}
                    </span>
                    <Pencil size={13} className="mt-1 shrink-0 text-dim group-hover:text-gold" />
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </section>

      {/* کارهای این روز */}
      <section className="border-b border-rule px-4 py-4">
        <h3 className="micro mb-3 text-dim">کارهای این روز</h3>
        {dayTasks.length === 0 ? (
          <p className="text-sm text-muted">کاری برای این روز ثبت نشده است.</p>
        ) : (
          <ul className="space-y-1.5">
            {dayTasks.map((task) => (
              <li key={task.id} className="flex items-center gap-2">
                <button
                  type="button"
                  aria-label={task.done ? "برگرداندن کار" : "انجام شد"}
                  onClick={() => onToggleTask(task)}
                  className="shrink-0 text-firoozeh transition-transform hover:scale-110"
                >
                  {task.done ? <Check size={16} /> : <Square size={15} />}
                </button>
                <button
                  type="button"
                  onClick={() => onOpenTask(task)}
                  className={`flex-1 truncate text-right text-sm transition-colors hover:text-gold ${
                    task.done ? "text-dim line-through" : "text-fg"
                  }`}
                >
                  {task.title}
                </button>
                <span className="micro shrink-0 text-dim">{PRIORITY_META[task.priority].mark}</span>
              </li>
            ))}
          </ul>
        )}
        <button
          type="button"
          onClick={onNewTask}
          className="mt-3 flex items-center gap-1.5 text-[0.75rem] text-firoozeh transition-colors hover:text-gold"
        >
          <Plus size={13} /> کار تازه
        </button>
      </section>

      {/* یادداشت روز */}
      <section className="border-b border-rule px-4 py-4">
        <h3 className="micro mb-3 text-dim">یادداشت این روز</h3>
        <textarea
          className="field min-h-[96px] resize-y font-serif text-[0.95rem] leading-8"
          value={text}
          placeholder="قرار، حس و حال یا نکته‌ای از این روز…"
          onChange={(e) => {
            setText(e.target.value);
            setSaved(false);
          }}
        />
        <div className="mt-2 flex items-center justify-between">
          <span className="serif-voice text-[0.7rem] text-dim">با حساب کاربری شما همگام می‌شود</span>
          <button
            type="button"
            onClick={() => {
              onSaveNote(text);
              setSaved(true);
            }}
            className="flex items-center gap-1.5 bg-firoozeh px-3 py-1.5 text-[0.75rem] font-bold text-ink transition-colors hover:bg-[#5fe0d8]"
          >
            <Save size={13} /> {saved ? "ذخیره شد" : "ذخیرهٔ یادداشت"}
          </button>
        </div>
      </section>

      {/* کارهای باز */}
      <section className="border-b border-rule px-4 py-4">
        <h3 className="micro mb-3 text-dim">کارهای باز ({faNum(openTasks.length)})</h3>
        {openTasks.length === 0 ? (
          <p className="text-sm text-muted">همه‌چیز انجام شده است.</p>
        ) : (
          <ul className="space-y-1.5">
            {openTasks.slice(0, 5).map((task) => (
              <li key={task.id} className="flex items-center gap-2">
                <button
                  type="button"
                  aria-label="انجام شد"
                  onClick={() => onToggleTask(task)}
                  className="shrink-0 text-firoozeh transition-transform hover:scale-110"
                >
                  <Square size={15} />
                </button>
                <button
                  type="button"
                  onClick={() => onOpenTask(task)}
                  className="flex-1 truncate text-right text-sm text-fg transition-colors hover:text-gold"
                >
                  {task.title}
                </button>
                <span className="tnum shrink-0 text-[0.65rem] text-dim">
                  {task.due ? `${faNum(isoToJalali(task.due).jd)}/${faNum(isoToJalali(task.due).jm)}` : ""}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* یادآوری‌های پیش رو */}
      <section className="px-4 py-4">
        <h3 className="micro mb-3 text-dim">یادآوری‌های پیش رو</h3>
        {upcoming.length === 0 ? (
          <p className="text-sm text-muted">یادآوری فعالی ندارید.</p>
        ) : (
          <ul className="space-y-2">
            {upcoming.map((u) => (
              <li key={u.key} className="flex items-start gap-2">
                <Bell size={13} className="mt-1 shrink-0 text-gold" />
                <span className="flex-1">
                  <span className="block text-sm leading-6 text-fg">{u.title}</span>
                  <span className="tnum text-[0.68rem] text-dim">
                    {u.meta} · {relTime(u.at - Date.now())}
                  </span>
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </motion.aside>
  );
}
