"use client";

import { J_MONTHS, faNum, jalaliToIso, isoToJalali, monthLength } from "@/lib/dates";

export default function JalaliDateField({
  value,
  onChange,
  label = "تاریخ شمسی",
}: {
  value: string;
  onChange: (iso: string) => void;
  label?: string;
}) {
  const j = isoToJalali(value);
  const days = monthLength(j.jy, j.jm);
  const jd = Math.min(j.jd, days);
  const years = Array.from({ length: 46 }, (_, i) => 1395 + i);

  return (
    <div>
      <span className="micro mb-1.5 block text-dim">{label}</span>
      <div className="grid grid-cols-[1.1fr_1.6fr_1fr] gap-1.5">
        <select
          className="field tnum text-center"
          value={jd}
          aria-label="روز"
          onChange={(e) => onChange(jalaliToIso(j.jy, j.jm, Number(e.target.value)))}
        >
          {Array.from({ length: days }, (_, i) => i + 1).map((d) => (
            <option key={d} value={d}>
              {faNum(d)}
            </option>
          ))}
        </select>
        <select
          className="field text-center"
          value={j.jm}
          aria-label="ماه"
          onChange={(e) =>
            onChange(jalaliToIso(j.jy, Number(e.target.value), Math.min(j.jd, monthLength(j.jy, Number(e.target.value)))))
          }
        >
          {J_MONTHS.map((m, i) => (
            <option key={m} value={i + 1}>
              {m}
            </option>
          ))}
        </select>
        <select
          className="field tnum text-center"
          value={j.jy}
          aria-label="سال"
          onChange={(e) =>
            onChange(jalaliToIso(Number(e.target.value), j.jm, Math.min(j.jd, monthLength(Number(e.target.value), j.jm))))
          }
        >
          {years.map((y) => (
            <option key={y} value={y}>
              {faNum(y)}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
}
