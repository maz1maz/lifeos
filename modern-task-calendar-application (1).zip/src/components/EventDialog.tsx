"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Repeat, Trash2, X } from "lucide-react";
import JalaliDateField from "@/components/JalaliDateField";
import { gregorianDateLine, jalaliDateLine } from "@/lib/dates";
import {
  CATEGORY_META,
  PRIORITY_META,
  REPEAT_META,
  type Category,
  type EventRow,
  type Priority,
  type RepeatRule,
} from "@/lib/types";

export type EventValues = Omit<EventRow, "id">;

export const REMINDER_OPTIONS: { value: number | null; label: string }[] = [
  { value: null, label: "بدون یادآوری" },
  { value: 5, label: "۵ دقیقه پیش" },
  { value: 10, label: "۱۰ دقیقه پیش" },
  { value: 30, label: "نیم‌ساعت پیش" },
  { value: 60, label: "یک ساعت پیش" },
  { value: 1440, label: "یک روز پیش" },
];

export function emptyEvent(day: string): EventValues {
  return {
    title: "",
    day,
    allDay: false,
    startTime: "09:00",
    endTime: "10:00",
    category: "personal",
    priority: "medium",
    repeatRule: "none",
    remindBefore: 30,
    notes: null,
    done: false,
  };
}

export default function EventDialog({
  open,
  initial,
  editingId,
  onClose,
  onSave,
  onDelete,
}: {
  open: boolean;
  initial: EventValues | null;
  editingId: number | null;
  onClose: () => void;
  onSave: (values: EventValues, id: number | null) => void;
  onDelete: () => void;
}) {
  const [draft, setDraft] = useState<EventValues>(emptyEvent(""));

  useEffect(() => {
    if (open && initial) setDraft(initial);
  }, [open, initial]);

  const set = <K extends keyof EventValues>(key: K, value: EventValues[K]) =>
    setDraft((d) => ({ ...d, [key]: value }));

  return (
    <AnimatePresence>
      {open ? (
        <motion.div
          className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-[rgba(3,7,15,0.82)] px-4 py-8 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) onClose();
          }}
        >
          <motion.div
            initial={{ y: 12, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 8, opacity: 0 }}
            transition={{ duration: 0.22, ease: [0.2, 0.7, 0.3, 1] }}
            className="w-full max-w-2xl border border-rule bg-lapis shadow-[0_30px_80px_rgba(0,0,0,0.6)]"
          >
            <header className="flex items-center justify-between border-b border-rule px-6 py-4">
              <div>
                <p className="micro text-gold">{editingId ? "ویرایش رویداد" : "رویداد تازه"}</p>
                <h2 className="mt-1 text-xl font-bold">{draft.title.trim() || "بی‌عنوان"}</h2>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="بستن"
                className="border border-rule p-2 text-muted transition-colors hover:border-gold hover:text-gold"
              >
                <X size={16} />
              </button>
            </header>

            <div className="grid gap-5 px-6 py-5 md:grid-cols-[1.4fr_1fr]">
              <div className="space-y-4">
                <div>
                  <span className="micro mb-1.5 block text-dim">عنوان</span>
                  <input
                    className="field text-lg"
                    value={draft.title}
                    placeholder="مثلاً: جلسهٔ هفتگی تیم محصول"
                    onChange={(e) => set("title", e.target.value)}
                  />
                </div>

                <JalaliDateField value={draft.day} onChange={(iso) => set("day", iso)} />

                <div>
                  <label className="micro mb-2 flex cursor-pointer items-center gap-2 text-dim">
                    <input
                      type="checkbox"
                      checked={draft.allDay}
                      onChange={(e) => set("allDay", e.target.checked)}
                      className="accent-[#d8a657]"
                    />
                    تمام‌روز
                  </label>
                  {!draft.allDay ? (
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <span className="micro mb-1.5 block text-dim">ساعت شروع</span>
                        <input
                          type="time"
                          className="field tnum"
                          value={draft.startTime ?? "09:00"}
                          onChange={(e) => set("startTime", e.target.value)}
                        />
                      </div>
                      <div>
                        <span className="micro mb-1.5 block text-dim">ساعت پایان</span>
                        <input
                          type="time"
                          className="field tnum"
                          value={draft.endTime ?? "10:00"}
                          onChange={(e) => set("endTime", e.target.value)}
                        />
                      </div>
                    </div>
                  ) : null}
                </div>

                <div>
                  <span className="micro mb-1.5 block text-dim">یادداشت</span>
                  <textarea
                    className="field min-h-[92px] resize-y leading-7"
                    value={draft.notes ?? ""}
                    placeholder="جزئیات، آدرس، نکته‌ها…"
                    onChange={(e) => set("notes", e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-4 border-r border-rule pr-5">
                <div>
                  <span className="micro mb-1.5 block text-dim">دسته</span>
                  <div className="grid grid-cols-2 gap-1.5">
                    {(Object.keys(CATEGORY_META) as Category[]).map((c) => {
                      const active = draft.category === c;
                      return (
                        <button
                          key={c}
                          type="button"
                          onClick={() => set("category", c)}
                          className="flex items-center gap-2 border px-2.5 py-2 text-sm transition-colors"
                          style={{
                            borderColor: active ? CATEGORY_META[c].color : "#21355c",
                            background: active ? CATEGORY_META[c].soft : "transparent",
                            color: active ? "#e8eef9" : "#8ca0c4",
                          }}
                        >
                          <span
                            className="inline-block h-2 w-2 rounded-full"
                            style={{ background: CATEGORY_META[c].color }}
                          />
                          {CATEGORY_META[c].label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <span className="micro mb-1.5 block text-dim">اولویت</span>
                  <div className="flex gap-1.5">
                    {(Object.keys(PRIORITY_META) as Priority[]).map((p) => {
                      const active = draft.priority === p;
                      return (
                        <button
                          key={p}
                          type="button"
                          onClick={() => set("priority", p)}
                          className={`flex-1 border px-2 py-2 text-sm transition-colors ${
                            active
                              ? "border-gold bg-[rgba(216,166,87,0.12)] text-goldsoft"
                              : "border-rule text-muted hover:border-gold"
                          }`}
                        >
                          {PRIORITY_META[p].label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <span className="micro mb-1.5 flex items-center gap-1.5 text-dim">
                    <Repeat size={12} /> تکرار
                  </span>
                  <select
                    className="field"
                    value={draft.repeatRule}
                    onChange={(e) => set("repeatRule", e.target.value as RepeatRule)}
                  >
                    {(Object.keys(REPEAT_META) as RepeatRule[]).map((r) => (
                      <option key={r} value={r}>
                        {REPEAT_META[r]}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <span className="micro mb-1.5 block text-dim">یادآوری</span>
                  <select
                    className="field"
                    value={draft.remindBefore ?? ""}
                    onChange={(e) =>
                      set("remindBefore", e.target.value === "" ? null : Number(e.target.value))
                    }
                  >
                    {REMINDER_OPTIONS.map((o) => (
                      <option key={String(o.value)} value={o.value ?? ""}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="border-t border-rule pt-3">
                  <p className="serif-voice text-sm text-muted">{jalaliDateLine(draft.day)}</p>
                  <p className="serif-voice mt-1 text-xs text-dim">{gregorianDateLine(draft.day)}</p>
                </div>
              </div>
            </div>

            <footer className="flex items-center justify-between gap-3 border-t border-rule px-6 py-4">
              <button
                type="button"
                onClick={onDelete}
                className={`flex items-center gap-2 px-3 py-2 text-sm transition-colors ${
                  editingId ? "text-crimson hover:text-[#ff7a6e]" : "pointer-events-none opacity-0"
                }`}
              >
                <Trash2 size={15} /> حذف
              </button>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="border border-rule px-4 py-2 text-sm text-muted transition-colors hover:border-gold hover:text-gold"
                >
                  انصراف
                </button>
                <button
                  type="button"
                  onClick={() => onSave(draft, editingId)}
                  className="flex items-center gap-2 bg-gold px-5 py-2 text-sm font-bold text-ink transition-colors hover:bg-goldsoft"
                >
                  <Check size={15} /> ذخیرهٔ رویداد
                </button>
              </div>
            </footer>
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}
