"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, ListTodo, X } from "lucide-react";
import JalaliDateField from "@/components/JalaliDateField";
import { REMINDER_OPTIONS } from "@/components/EventDialog";
import { jalaliDateLine, todayIso } from "@/lib/dates";
import {
  CATEGORY_META,
  PRIORITY_META,
  type Category,
  type Priority,
  type TaskRow,
} from "@/lib/types";

export type TaskValues = Omit<TaskRow, "id">;

export function emptyTask(day: string): TaskValues {
  return {
    title: "",
    due: day || todayIso(),
    allDay: true,
    startTime: null,
    category: "personal",
    priority: "medium",
    remindBefore: 30,
    notes: null,
    done: false,
  };
}

export default function TaskDialog({
  open,
  initial,
  editingId,
  onClose,
  onSave,
  onDelete,
}: {
  open: boolean;
  initial: TaskValues | null;
  editingId: number | null;
  onClose: () => void;
  onSave: (values: TaskValues, id: number | null) => void;
  onDelete: () => void;
}) {
  const [draft, setDraft] = useState<TaskValues>(emptyTask(todayIso()));

  useEffect(() => {
    if (open && initial) setDraft(initial);
  }, [open, initial]);

  const set = <K extends keyof TaskValues>(key: K, value: TaskValues[K]) =>
    setDraft((d) => ({ ...d, [key]: value }));

  return (
    <AnimatePresence>
      {open ? (
        <motion.div
          className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-[rgba(3,7,15,0.82)] px-4 py-10 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) onClose();
          }}
        >
          <motion.div
            initial={{ y: 12, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 8, opacity: 0 }}
            transition={{ duration: 0.22, ease: [0.2, 0.7, 0.3, 1] }}
            className="w-full max-w-lg border border-rule bg-lapis shadow-[0_30px_80px_rgba(0,0,0,0.6)]"
          >
            <header className="flex items-center justify-between border-b border-rule px-6 py-4">
              <div className="flex items-center gap-2">
                <ListTodo size={16} className="text-firoozeh" />
                <h2 className="text-lg font-bold">{editingId ? "ویرایش کار" : "کار تازه"}</h2>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="بستن"
                className="border border-rule p-2 text-muted transition-colors hover:border-gold hover:text-gold"
              >
                <X size={16} />
              </button>
            </header>

            <div className="space-y-4 px-6 py-5">
              <div>
                <span className="micro mb-1.5 block text-dim">عنوان کار</span>
                <input
                  className="field text-lg"
                  value={draft.title}
                  placeholder="مثلاً: ارسال فاکتور مشتری"
                  onChange={(e) => set("title", e.target.value)}
                />
              </div>

              <JalaliDateField
                value={draft.due ?? todayIso()}
                label="سررسید"
                onChange={(iso) => set("due", iso)}
              />

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="micro mb-1.5 block text-dim">دسته</span>
                  <select
                    className="field"
                    value={draft.category}
                    onChange={(e) => set("category", e.target.value as Category)}
                  >
                    {(Object.keys(CATEGORY_META) as Category[]).map((c) => (
                      <option key={c} value={c}>
                        {CATEGORY_META[c].label}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <span className="micro mb-1.5 block text-dim">اولویت</span>
                  <select
                    className="field"
                    value={draft.priority}
                    onChange={(e) => set("priority", e.target.value as Priority)}
                  >
                    {(Object.keys(PRIORITY_META) as Priority[]).map((p) => (
                      <option key={p} value={p}>
                        {PRIORITY_META[p].label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <span className="micro mb-1.5 block text-dim">یادآوری</span>
                <select
                  className="field"
                  value={draft.remindBefore ?? ""}
                  onChange={(e) =>
                    set("remindBefore", e.target.value === "" ? null : Number(e.target.value))
                  }
                >
                  {REMINDER_OPTIONS.map((o) => (
                    <option key={String(o.value)} value={o.value ?? ""}>
                      {o.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <span className="micro mb-1.5 block text-dim">یادداشت</span>
                <textarea
                  className="field min-h-[72px] resize-y leading-7"
                  value={draft.notes ?? ""}
                  placeholder="جزئیات کار…"
                  onChange={(e) => set("notes", e.target.value)}
                />
              </div>

              {draft.due ? (
                <p className="serif-voice text-sm text-muted">{jalaliDateLine(draft.due)}</p>
              ) : null}
            </div>

            <footer className="flex items-center justify-between gap-3 border-t border-rule px-6 py-4">
              <button
                type="button"
                onClick={onDelete}
                className={`text-sm text-crimson transition-colors hover:text-[#ff7a6e] ${
                  editingId ? "" : "pointer-events-none opacity-0"
                }`}
              >
                حذف
              </button>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="border border-rule px-4 py-2 text-sm text-muted transition-colors hover:border-gold hover:text-gold"
                >
                  انصراف
                </button>
                <button
                  type="button"
                  onClick={() => onSave(draft, editingId)}
                  className="flex items-center gap-2 bg-firoozeh px-5 py-2 text-sm font-bold text-ink transition-colors hover:bg-[#5fe0d8]"
                >
                  <Check size={15} /> ذخیرهٔ کار
                </button>
              </div>
            </footer>
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}
