/**
 * زینت‌های دست‌ساز گره (girih) — همه با مسیرهای SVG کشیده شده‌اند
 * تا در ۱۶ پیکسل و تک‌رنگ هم خوانا بمانند.
 */

export function GirihRosette({
  className = "",
  stroke = "#d8a657",
  width = 1,
}: {
  className?: string;
  stroke?: string;
  width?: number;
}) {
  return (
    <svg viewBox="0 0 120 120" className={className} aria-hidden="true">
      <g
        fill="none"
        stroke={stroke}
        strokeWidth={width}
        strokeLinejoin="round"
        strokeLinecap="round"
      >
        {/* ستارهٔ ده‌پر */}
        <path d="M60 12 L68.3 34.3 L88.2 21.2 L81.8 44.1 L105.7 45.2 L87 60 L105.7 74.8 L81.8 75.9 L88.2 98.8 L68.3 85.7 L60 108 L51.7 85.7 L31.8 98.8 L38.2 75.9 L14.3 74.8 L33 60 L14.3 45.2 L38.2 44.1 L31.8 21.2 L51.7 34.3 Z" />
        {/* ده‌ضلعی درونی */}
        <path d="M68.3 34.3 L81.8 44.1 L87 60 L81.8 75.9 L68.3 85.7 L51.7 85.7 L38.2 75.9 L33 60 L38.2 44.1 L51.7 34.3 Z" />
        {/* بندهای گره */}
        <path d="M60 12 L60 2 L68.3 34.3 M88.2 21.2 L95.5 12.6 L81.8 44.1 M105.7 45.2 L116 43.5 L87 60 M105.7 74.8 L116 76.5 L81.8 75.9 M88.2 98.8 L95.5 107.4 L68.3 85.7 M60 108 L60 118 L51.7 85.7 M31.8 98.8 L24.5 107.4 L38.2 75.9 M14.3 74.8 L4 76.5 L33 60 M14.3 45.2 L4 43.5 L38.2 44.1 M31.8 21.2 L24.5 12.6 L51.7 34.3" />
        <circle cx="60" cy="60" r="11" />
        <circle cx="60" cy="60" r="3.2" fill={stroke} stroke="none" />
      </g>
    </svg>
  );
}

/** نشان کوچک گره برای کنار عنوان‌ها و نشانگر انتخاب */
export function GirihMark({
  className = "",
  fill = "#d8a657",
}: {
  className?: string;
  fill?: string;
}) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
      <path
        d="M12 1 L14.1 7.2 L20 4.2 L17.4 10 L23 12 L17.4 14 L20 19.8 L14.1 16.8 L12 23 L9.9 16.8 L4 19.8 L6.6 14 L1 12 L6.6 10 L4 4.2 L9.9 7.2 Z"
        fill={fill}
      />
    </svg>
  );
}

/** قاب گوشهٔ ورق تقویم */
export function CornerRule({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
      <g fill="none" stroke="#d8a657" strokeWidth="1">
        <path d="M0 22 L22 22 L22 0" opacity="0.6" />
        <path d="M0 12 L12 12 L12 0" opacity="0.35" />
        <path d="M6 30 L30 30 L30 6" opacity="0.2" />
      </g>
    </svg>
  );
}
