"use client";

import { motion } from "framer-motion";
import { Bell, ListTodo, Repeat } from "lucide-react";
import {
  faNum,
  gregorianDateLine,
  isoToJalali,
  jalaliDateLine,
  monthLength,
} from "@/lib/dates";
import { occasionsFor } from "@/lib/occasions";
import { occurrencesInRange } from "@/lib/occurrence";
import {
  CATEGORY_META,
  PRIORITY_META,
  type EventRow,
  type TaskRow,
} from "@/lib/types";

export default function AgendaSheet({
  from,
  to,
  events,
  tasks,
  onSelect,
  onOpenEvent,
  onOpenTask,
}: {
  from: string;
  to: string;
  events: EventRow[];
  tasks: TaskRow[];
  onSelect: (day: string) => void;
  onOpenEvent: (event: EventRow) => void;
  onOpenTask: (task: TaskRow) => void;
}) {
  const occs = occurrencesInRange(events, from, to);
  const byDay = new Map<string, typeof occs>();
  for (const occ of occs) {
    const list = byDay.get(occ.day) ?? [];
    list.push(occ);
    byDay.set(occ.day, list);
  }
  for (const task of tasks) {
    if (task.due && task.due >= from && task.due <= to) {
      const list = byDay.get(task.due) ?? [];
      byDay.set(task.due, list);
    }
  }

  const days = [...byDay.keys()].sort();

  return (
    <div className="border border-rule bg-[rgba(9,16,31,0.55)]">
      {days.length === 0 ? (
        <div className="px-6 py-16 text-center">
          <p className="serif-voice text-lg text-muted">در این بازه چیزی ثبت نشده است.</p>
          <p className="mt-2 text-sm text-dim">
            با دکمهٔ «رویداد تازه» یا کلید میان‌بر N نخستین قرار این روزها را بگذارید.
          </p>
        </div>
      ) : null}

      {days.map((day, index) => {
        const occList = byDay.get(day) ?? [];
        const dayTasks = tasks.filter((t) => t.due === day);
        const j = isoToJalali(day);
        const occ = occasionsFor(j.jm, j.jd);
        return (
          <motion.section
            key={day}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2, delay: Math.min(index * 0.015, 0.3) }}
            className="grid grid-cols-[190px_1fr] border-b border-rule last:border-b-0"
          >
            <button
              type="button"
              onClick={() => onSelect(day)}
              className="border-l border-rule px-4 py-5 text-right transition-colors hover:bg-[rgba(216,166,87,0.06)]"
            >
              <p className="text-base font-bold text-fg">{jalaliDateLine(day)}</p>
              <p className="serif-voice mt-1 text-xs text-dim">{gregorianDateLine(day)}</p>
              {occ.map((o) => (
                <p key={o.title} className="serif-voice mt-1 text-[0.75rem] text-crimson">
                  {o.title}
                </p>
              ))}
            </button>

            <div className="divide-y divide-rule/60">
              {occList.map(({ event, key }) => {
                const meta = CATEGORY_META[event.category] ?? CATEGORY_META.personal;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => onOpenEvent(event)}
                    className="flex w-full items-center gap-3 px-4 py-3 text-right transition-colors hover:bg-[rgba(55,201,192,0.05)]"
                  >
                    <span
                      className="h-8 w-[3px] shrink-0"
                      style={{ background: meta.color }}
                    />
                    <span className="tnum w-16 shrink-0 text-sm text-muted">
                      {event.allDay ? "تمام‌روز" : faNum(event.startTime ?? "")}
                    </span>
                    <span className="flex-1 truncate text-sm">
                      <span className={event.done ? "line-through opacity-60" : ""}>
                        {event.title}
                      </span>
                      {event.notes ? (
                        <span className="serif-voice mr-2 text-xs text-dim">{event.notes}</span>
                      ) : null}
                    </span>
                    {event.repeatRule !== "none" ? (
                      <Repeat size={13} className="shrink-0 text-dim" />
                    ) : null}
                    {event.remindBefore != null ? (
                      <Bell size={13} className="shrink-0 text-gold" />
                    ) : null}
                    <span
                      className="micro shrink-0"
                      style={{ color: meta.color }}
                    >
                      {meta.label}
                    </span>
                  </button>
                );
              })}

              {dayTasks.map((task) => {
                const meta = CATEGORY_META[task.category] ?? CATEGORY_META.personal;
                return (
                  <button
                    key={`t-${task.id}`}
                    type="button"
                    onClick={() => onOpenTask(task)}
                    className="flex w-full items-center gap-3 px-4 py-3 text-right transition-colors hover:bg-[rgba(55,201,192,0.05)]"
                  >
                    <ListTodo size={15} className="shrink-0 text-firoozeh" />
                    <span className="flex-1 truncate text-sm">
                      <span className={task.done ? "line-through opacity-60" : ""}>
                        {task.title}
                      </span>
                    </span>
                    <span className="micro shrink-0 text-muted">
                      کار · {PRIORITY_META[task.priority].label}
                    </span>
                    <span className="micro shrink-0" style={{ color: meta.color }}>
                      {meta.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </motion.section>
        );
      })}

      <p className="serif-voice border-t border-rule px-4 py-3 text-xs text-dim">
        {faNum(monthLength(jiso(from).jy, jiso(from).jm))} روز در این ماه · نمای برنامه تا ۴۵ روز
        آینده را نشان می‌دهد
      </p>
    </div>
  );
}

function jiso(iso: string) {
  return isoToJalali(iso);
}
