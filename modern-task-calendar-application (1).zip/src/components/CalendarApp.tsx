"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion, MotionConfig } from "framer-motion";
import {
  Bell,
  CalendarDays,
  Check,
  ChevronLeft,
  ChevronRight,
  Clock,
  LayoutGrid,
  List,
  Plus,
  Search,
} from "lucide-react";
import DayRail from "@/components/DayRail";
import EventDialog, { emptyEvent, type EventValues } from "@/components/EventDialog";
import MonthSheet from "@/components/MonthSheet";
import TaskDialog, { emptyTask, type TaskValues } from "@/components/TaskDialog";
import TimeSheet from "@/components/TimeSheet";
import AgendaSheet from "@/components/AgendaSheet";
import { GirihMark, GirihRosette } from "@/components/Ornament";
import {
  faNum,
  gregorianShort,
  isoAddDays,
  isoToJalali,
  jalaliDateLine,
  jalaliToIso,
  J_MONTHS,
  monthBounds,
  monthGridDays,
  monthLength,
  todayIso,
  weekDays,
} from "@/lib/dates";
import { occasionsFor } from "@/lib/occasions";
import { occursOn, occurrencesInRange, occurrencesOn as dayOccurrences } from "@/lib/occurrence";
import {
  CATEGORY_META,
  type Category,
  type EventRow,
  type NoteRow,
  type TaskRow,
} from "@/lib/types";

type View = "month" | "week" | "day" | "agenda";

const VIEWS: { id: View; label: string; icon: typeof LayoutGrid }[] = [
  { id: "month", label: "ماه", icon: LayoutGrid },
  { id: "week", label: "هفته", icon: CalendarDays },
  { id: "day", label: "روز", icon: Clock },
  { id: "agenda", label: "برنامه", icon: List },
];

async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
  });
  if (!res.ok) throw new Error(`request failed: ${res.status}`);
  return (await res.json()) as T;
}

export default function CalendarApp({
  initialEvents,
  initialTasks,
  initialNotes,
  serverToday,
}: {
  initialEvents: EventRow[];
  initialTasks: TaskRow[];
  initialNotes: NoteRow[];
  serverToday: string;
}) {
  // تاریخ امروز از سرور می‌آید تا سمت کلاینت و سرور یکی باشد؛
  // بعد از نشستن صفحه، به وقت محلی مرورگر تازه می‌شود.
  const [today, setToday] = useState<string>(serverToday);
  useEffect(() => {
    setToday(todayIso());
  }, []);
  const [events, setEvents] = useState<EventRow[]>(initialEvents);
  const [tasks, setTasks] = useState<TaskRow[]>(initialTasks);
  const [notes, setNotes] = useState<NoteRow[]>(initialNotes);

  const [view, setView] = useState<View>("month");
  const [cursor, setCursor] = useState<string>(today);
  const [selected, setSelected] = useState<string>(today);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<Category | "all">("all");

  const [eventDialog, setEventDialog] = useState<{
    open: boolean;
    initial: EventValues | null;
    editingId: number | null;
  }>({ open: false, initial: null, editingId: null });
  const [taskDialog, setTaskDialog] = useState<{
    open: boolean;
    initial: TaskValues | null;
    editingId: number | null;
  }>({ open: false, initial: null, editingId: null });
  const [toast, setToast] = useState<{ title: string; body: string } | null>(null);
  const [notifOn, setNotifOn] = useState(false);
  const firedRef = useRef<Set<string>>(new Set());

  const jcur = isoToJalali(cursor);

  /* ---------------- filtering ---------------- */
  const q = query.trim();
  const matches = (text: string) => (q ? text.includes(q) : true);
  const visibleEvents = useMemo(
    () =>
      events.filter(
        (e) =>
          (filter === "all" || e.category === filter) &&
          (matches(e.title) || matches(e.notes ?? "")),
      ),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [events, filter, q],
  );
  const visibleTasks = useMemo(
    () =>
      tasks.filter(
        (t) => (filter === "all" || t.category === filter) && (matches(t.title) || matches(t.notes ?? "")),
      ),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [tasks, filter, q],
  );

  /* ---------------- navigation ---------------- */
  function shift(step: number) {
    if (view === "month") {
      let jm = jcur.jm + step;
      let jy = jcur.jy;
      while (jm > 12) {
        jm -= 12;
        jy += 1;
      }
      while (jm < 1) {
        jm += 12;
        jy -= 1;
      }
      setCursor(jalaliToIso(jy, jm, Math.min(jcur.jd, monthLength(jy, jm))));
    } else if (view === "week") {
      setCursor(isoAddDays(cursor, 7 * step));
    } else if (view === "day") {
      setCursor(isoAddDays(cursor, step));
    } else {
      setCursor(isoAddDays(cursor, 45 * step));
    }
  }

  function gotoToday() {
    setCursor(today);
    setSelected(today);
  }

  /* ---------------- mutations ---------------- */
  async function saveEvent(values: EventValues, id: number | null) {
    if (id) {
      const row = await api<EventRow>(`/api/events/${id}`, {
        method: "PATCH",
        body: JSON.stringify(values),
      });
      setEvents((list) => list.map((e) => (e.id === id ? { ...e, ...row } : e)));
    } else {
      const row = await api<EventRow>("/api/events", {
        method: "POST",
        body: JSON.stringify(values),
      });
      setEvents((list) => [...list, row]);
    }
    setSelected(values.day);
    setCursor(values.day);
    setEventDialog({ open: false, initial: null, editingId: null });
  }

  async function removeEvent(id: number) {
    await api(`/api/events/${id}`, { method: "DELETE" });
    setEvents((list) => list.filter((e) => e.id !== id));
    setEventDialog({ open: false, initial: null, editingId: null });
  }

  async function saveTask(values: TaskValues, id: number | null) {
    if (id) {
      const row = await api<TaskRow>(`/api/tasks/${id}`, {
        method: "PATCH",
        body: JSON.stringify(values),
      });
      setTasks((list) => list.map((t) => (t.id === id ? { ...t, ...row } : t)));
    } else {
      const row = await api<TaskRow>("/api/tasks", {
        method: "POST",
        body: JSON.stringify(values),
      });
      setTasks((list) => [...list, row]);
    }
    setTaskDialog({ open: false, initial: null, editingId: null });
  }

  async function removeTask(id: number) {
    await api(`/api/tasks/${id}`, { method: "DELETE" });
    setTasks((list) => list.filter((t) => t.id !== id));
    setTaskDialog({ open: false, initial: null, editingId: null });
  }

  async function toggleTask(task: TaskRow) {
    const row = await api<TaskRow>(`/api/tasks/${task.id}`, {
      method: "PATCH",
      body: JSON.stringify({ done: !task.done }),
    });
    setTasks((list) => list.map((t) => (t.id === task.id ? { ...t, ...row } : t)));
  }

  async function saveNote(text: string) {
    const trimmed = text.trim();
    await api("/api/notes", {
      method: "POST",
      body: JSON.stringify({ day: selected, text: trimmed }),
    });
    setNotes((list) => {
      const others = list.filter((n) => n.day !== selected);
      return trimmed ? [...others, { id: Date.now(), day: selected, text: trimmed }] : others;
    });
  }

  /* ---------------- dialogs ---------------- */
  const openNewEvent = (day = selected, time?: string) =>
    setEventDialog({
      open: true,
      editingId: null,
      initial: { ...emptyEvent(day), startTime: time ?? "09:00", endTime: time ? bump(time, 1) : "10:00" },
    });

  const openEvent = (event: EventRow) => {
    const { id, ...values } = event;
    setEventDialog({ open: true, editingId: id, initial: values });
  };

  const openNewTask = () =>
    setTaskDialog({ open: true, editingId: null, initial: emptyTask(selected) });

  const openTask = (task: TaskRow) => {
    const { id, ...values } = task;
    setTaskDialog({ open: true, editingId: id, initial: values });
  };

  /* ---------------- reminders ---------------- */
  useEffect(() => {
    if (typeof Notification !== "undefined" && Notification.permission === "granted") {
      setNotifOn(true);
    }
  }, []);

  useEffect(() => {
    const tick = () => {
      const now = Date.now();
      const fire = (key: string, title: string, body: string) => {
        if (firedRef.current.has(key)) return;
        firedRef.current.add(key);
        setToast({ title, body });
        if (typeof Notification !== "undefined" && Notification.permission === "granted") {
          try {
            new Notification(title, { body });
          } catch {
            /* ignore */
          }
        }
      };

      for (const event of events) {
        if (event.remindBefore == null || event.done) continue;
        for (let i = 0; i < 2; i += 1) {
          const day = isoAddDays(todayIso(), i);
          if (!occursOn(event, day)) continue;
          const key = `e-${event.id}-${day}`;
          if (firedRef.current.has(key)) continue;
          const at =
            new Date(`${day}T${event.allDay ? "09:00" : event.startTime ?? "09:00"}:00`).getTime() -
            event.remindBefore * 60000;
          if (at <= now && now - at < 120000) {
            fire(key, `یادآوری: ${event.title}`, `${jalaliDateLine(day)} · ${faNum(event.startTime ?? "تمام‌روز")}`);
          }
        }
      }

      for (const task of tasks) {
        if (task.remindBefore == null || task.done || !task.due) continue;
        const key = `t-${task.id}-${task.due}`;
        if (firedRef.current.has(key)) continue;
        const at =
          new Date(`${task.due}T${task.startTime ?? "09:00"}:00`).getTime() -
          task.remindBefore * 60000;
        if (at <= now && now - at < 120000) {
          fire(key, `کار سررسیددار: ${task.title}`, jalaliDateLine(task.due));
        }
      }
    };

    tick();
    const id = window.setInterval(tick, 20000);
    return () => window.clearInterval(id);
  }, [events, tasks]);

  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => setToast(null), 9000);
    return () => window.clearTimeout(id);
  }, [toast]);

  /* ---------------- keyboard ---------------- */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const typing =
        target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT");
      if (e.key === "Escape") {
        setEventDialog({ open: false, initial: null, editingId: null });
        setTaskDialog({ open: false, initial: null, editingId: null });
        return;
      }
      if (typing) return;
      if (e.key === "n" || e.key === "ن") {
        e.preventDefault();
        openNewEvent();
      } else if (e.key === "t" || e.key === "ف") {
        e.preventDefault();
        gotoToday();
      } else if (e.key === "ArrowLeft") {
        shift(1);
      } else if (e.key === "ArrowRight") {
        shift(-1);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cursor, selected, view]);

  /* ---------------- derived ---------------- */
  const selectedOccurrences = useMemo(
    () => dayOccurrences(visibleEvents, selected),
    [visibleEvents, selected],
  );
  const selectedTasks = useMemo(
    () => visibleTasks.filter((t) => t.due === selected),
    [visibleTasks, selected],
  );
  const openTasks = useMemo(() => tasks.filter((t) => !t.done), [tasks]);

  const upcoming = useMemo(() => {
    const out: { key: string; title: string; at: number; meta: string }[] = [];
    const now = Date.now();
    for (let i = 0; i < 21; i += 1) {
      const day = isoAddDays(today, i);
      for (const event of visibleEvents) {
        if (event.remindBefore == null || event.done || !occursOn(event, day)) continue;
        const at =
          new Date(`${day}T${event.allDay ? "09:00" : event.startTime ?? "09:00"}:00`).getTime() -
          event.remindBefore * 60000;
        if (at > now) {
          out.push({
            key: `u-${event.id}-${day}`,
            title: event.title,
            at,
            meta: `${jalaliDateLine(day)} · ${faNum(event.startTime ?? "تمام‌روز")}`,
          });
        }
      }
    }
    return out.sort((a, b) => a.at - b.at).slice(0, 5);
  }, [visibleEvents, today]);

  const monthStats = useMemo(() => {
    const [first, last] = monthBounds(jcur.jy, jcur.jm);
    const occs = occurrencesInRange(visibleEvents, first, last);
    let holidays = 0;
    const len = monthLength(jcur.jy, jcur.jm);
    for (let d = 1; d <= len; d += 1) {
      const list = occasionsFor(jcur.jm, d);
      if (list.some((o) => o.holiday)) holidays += 1;
    }
    const monthTasks = visibleTasks.filter((t) => t.due && t.due >= first && t.due <= last).length;
    return { events: occs.length, holidays, tasks: monthTasks };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visibleEvents, visibleTasks, jcur.jy, jcur.jm]);

  const noteText = notes.find((n) => n.day === selected)?.text ?? "";
  const titleLine =
    view === "month"
      ? `${J_MONTHS[jcur.jm - 1]} ${faNum(jcur.jy)}`
      : view === "agenda"
        ? "برنامهٔ پیش رو"
        : jalaliDateLine(cursor);
  const subLine =
    view === "month"
      ? gregorianMonthLine(jcur.jy, jcur.jm)
      : view === "agenda"
        ? `${faNum(45)} روز آینده · رویدادها، کارها و یادآوری‌ها`
        : `${faNum(isoToJalali(cursor).jd)} ${J_MONTHS[isoToJalali(cursor).jm - 1]} · نمای ${view === "week" ? "هفته" : "روز"}`;

  return (
    <MotionConfig reducedMotion="user">
    <div className="min-h-screen">
      {/* ============ سرلوحه ============ */}
      <header className="relative overflow-hidden border-b border-rule">
        <img
          src="images/lapis-girih.jpg"
          alt=""
          aria-hidden="true"
          className="absolute inset-0 h-full w-full object-cover opacity-40"
          onError={(e) => {
            e.currentTarget.style.display = "none";
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-l from-[rgba(7,12,24,0.35)] via-[rgba(7,12,24,0.86)] to-[rgba(7,12,24,0.97)]" />
        <GirihRosette className="pointer-events-none absolute -left-16 -top-24 h-[320px] w-[320px] opacity-20" />

        <div className="relative mx-auto max-w-[1560px] px-5 py-7 md:px-8">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <GirihMark className="h-4 w-4" />
              <p className="micro text-gold">تقویم شمسی و میلادی با یادداشت و یادآوری</p>
            </div>
            <p className="tnum micro text-dim">
              N رویداد تازه · T امروز · ← → جابه‌جایی میان بازه‌ها
            </p>
          </div>

          <div className="mt-5 flex flex-wrap items-end justify-between gap-6">
            <div>
              <h1 className="text-[clamp(2.6rem,7vw,5rem)] font-black leading-[0.95] tracking-tight text-fg">
                {titleLine}
              </h1>
              <p className="serif-voice mt-2 text-lg text-muted">{subLine}</p>
            </div>

            <dl className="flex flex-wrap items-end gap-6 text-right">
              <div>
                <dt className="micro text-dim">رویداد این بازه</dt>
                <dd className="tnum text-3xl font-black text-firoozeh">{faNum(monthStats.events)}</dd>
              </div>
              <div>
                <dt className="micro text-dim">کار ثبت‌شده</dt>
                <dd className="tnum text-3xl font-black text-peri">{faNum(monthStats.tasks)}</dd>
              </div>
              <div>
                <dt className="micro text-dim">تعطیلات رسمی</dt>
                <dd className="tnum text-3xl font-black text-crimson">{faNum(monthStats.holidays)}</dd>
              </div>
            </dl>
          </div>
        </div>
      </header>

      {/* ============ نوار ابزار ============ */}
      <div className="border-b border-rule bg-[rgba(9,16,31,0.75)] backdrop-blur">
        <div className="mx-auto flex max-w-[1560px] flex-wrap items-center gap-3 px-5 py-3 md:px-8">
          <div className="flex items-center gap-1">
            <button
              type="button"
              aria-label="بازهٔ بعدی"
              onClick={() => shift(1)}
              className="border border-rule p-2 text-muted transition-colors hover:border-gold hover:text-gold"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              type="button"
              aria-label="بازهٔ پیشین"
              onClick={() => shift(-1)}
              className="border border-rule p-2 text-muted transition-colors hover:border-gold hover:text-gold"
            >
              <ChevronRight size={16} />
            </button>
            <button
              type="button"
              onClick={gotoToday}
              className="mr-1 border border-gold/70 bg-[rgba(216,166,87,0.1)] px-3 py-2 text-sm font-bold text-goldsoft transition-colors hover:bg-[rgba(216,166,87,0.2)]"
            >
              امروز
            </button>
          </div>

          <div className="flex items-center gap-1">
            <select
              className="field w-auto py-2"
              value={jcur.jm}
              aria-label="ماه"
              onChange={(e) =>
                setCursor(jalaliToIso(jcur.jy, Number(e.target.value), Math.min(jcur.jd, monthLength(jcur.jy, Number(e.target.value)))))
              }
            >
              {J_MONTHS.map((m, i) => (
                <option key={m} value={i + 1}>
                  {m}
                </option>
              ))}
            </select>
            <select
              className="field tnum w-auto py-2"
              value={jcur.jy}
              aria-label="سال"
              onChange={(e) => setCursor(jalaliToIso(Number(e.target.value), jcur.jm, Math.min(jcur.jd, monthLength(Number(e.target.value), jcur.jm))))}
            >
              {Array.from({ length: 16 }, (_, i) => 1395 + i).map((y) => (
                <option key={y} value={y}>
                  {faNum(y)}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center border border-rule">
            {VIEWS.map((v) => {
              const Icon = v.icon;
              const active = view === v.id;
              return (
                <button
                  key={v.id}
                  type="button"
                  onClick={() => setView(v.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 text-sm transition-colors ${
                    active
                      ? "bg-[rgba(216,166,87,0.14)] text-goldsoft"
                      : "text-muted hover:text-fg"
                  }`}
                >
                  <Icon size={14} /> {v.label}
                </button>
              );
            })}
          </div>

          <div className="relative min-w-[180px] flex-1">
            <Search size={14} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-dim" />
            <input
              className="field pr-9"
              placeholder="جست‌وجوی رویداد، کار یا یادداشت…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => setFilter("all")}
              className={`micro border px-2.5 py-2 transition-colors ${
                filter === "all" ? "border-gold text-goldsoft" : "border-rule text-dim hover:text-fg"
              }`}
            >
              همه
            </button>
            {(Object.keys(CATEGORY_META) as Category[]).map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setFilter(filter === c ? "all" : c)}
                className="micro flex items-center gap-1.5 border px-2.5 py-2 transition-colors"
                style={{
                  borderColor: filter === c ? CATEGORY_META[c].color : "#21355c",
                  color: filter === c ? CATEGORY_META[c].color : "#5c7098",
                }}
              >
                <span
                  className="inline-block h-2 w-2 rounded-full"
                  style={{ background: CATEGORY_META[c].color }}
                />
                {CATEGORY_META[c].label}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => {
              if (typeof Notification !== "undefined" && Notification.permission !== "granted") {
                Notification.requestPermission().then((p) => setNotifOn(p === "granted"));
              }
            }}
            title="روشن کردن یادآوری مرورگر"
            className={`border p-2 transition-colors ${
              notifOn ? "border-gold text-gold" : "border-rule text-dim hover:text-fg"
            }`}
          >
            <Bell size={16} />
          </button>

          <button
            type="button"
            onClick={() => openNewEvent()}
            className="flex items-center gap-2 bg-gold px-4 py-2 text-sm font-black text-ink transition-colors hover:bg-goldsoft"
          >
            <Plus size={15} /> رویداد تازه
          </button>
        </div>
      </div>

      {/* ============ تنه ============ */}
      <main className="mx-auto grid max-w-[1560px] items-start gap-0 px-0 py-0 lg:grid-cols-[352px_1fr] lg:px-8 lg:py-6">
        <DayRail
          day={selected}
          occurrences={selectedOccurrences}
          dayTasks={selectedTasks}
          openTasks={openTasks}
          note={noteText}
          today={today}
          upcoming={upcoming}
          onSaveNote={saveNote}
          onToggleTask={toggleTask}
          onOpenEvent={openEvent}
          onOpenTask={openTask}
          onNewEvent={() => openNewEvent(selected)}
          onNewTask={openNewTask}
        />

        <section className="min-w-0 border-r border-rule/60 lg:pr-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={`${view}-${cursor}`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.18 }}
            >
              {view === "month" ? (
                <MonthSheet
                  days={monthGridDays(jcur.jy, jcur.jm)}
                  monthAnchor={cursor}
                  events={visibleEvents}
                  tasks={visibleTasks}
                  selected={selected}
                  today={today}
                  onSelect={setSelected}
                  onCreate={(day) => openNewEvent(day)}
                  onOpenEvent={openEvent}
                  onOpenTask={openTask}
                />
              ) : null}

              {view === "week" ? (
                <TimeSheet
                  days={weekDays(cursor)}
                  events={visibleEvents}
                  today={today}
                  onOpenEvent={openEvent}
                  onCreate={(day, time) => openNewEvent(day, time)}
                />
              ) : null}

              {view === "day" ? (
                <TimeSheet
                  days={[cursor]}
                  events={visibleEvents}
                  today={today}
                  onOpenEvent={openEvent}
                  onCreate={(day, time) => openNewEvent(day, time)}
                />
              ) : null}

              {view === "agenda" ? (
                <AgendaSheet
                  from={cursor}
                  to={isoAddDays(cursor, 45)}
                  events={visibleEvents}
                  tasks={visibleTasks}
                  onSelect={setSelected}
                  onOpenEvent={openEvent}
                  onOpenTask={openTask}
                />
              ) : null}
            </motion.div>
          </AnimatePresence>

          {/* راهنمای رنگ‌ها */}
          <div className="mt-4 flex flex-wrap items-center gap-4 px-1">
            {(Object.keys(CATEGORY_META) as Category[]).map((c) => (
              <span key={c} className="micro flex items-center gap-1.5 text-dim">
                <span
                  className="inline-block h-2 w-2 rounded-full"
                  style={{ background: CATEGORY_META[c].color }}
                />
                {CATEGORY_META[c].label}
              </span>
            ))}
            <span className="micro flex items-center gap-1.5 text-crimson">
              <span className="inline-block h-2 w-2 rounded-full bg-crimson" /> تعطیل رسمی
            </span>
            <span className="serif-voice mr-auto text-xs text-dim">
              دوبار روی هر روز بزنید تا رویداد تازه‌ای برایش ساخته شود
            </span>
          </div>
        </section>
      </main>

      <footer className="mt-10 border-t border-rule px-5 py-6 md:px-8">
        <div className="mx-auto flex max-w-[1560px] flex-wrap items-center justify-between gap-3">
          <p className="micro text-dim">
            تقویم — هجری شمسی و میلادی · ذخیرهٔ رویدادها، کارها و یادداشت‌ها در پایگاه داده
          </p>
          <p className="tnum micro text-dim">
            امروز {jalaliDateLine(today)} · {gregorianShort(today)}
          </p>
        </div>
      </footer>

      <EventDialog
        open={eventDialog.open}
        initial={eventDialog.initial}
        editingId={eventDialog.editingId}
        onClose={() => setEventDialog({ open: false, initial: null, editingId: null })}
        onSave={saveEvent}
        onDelete={() => {
          if (eventDialog.editingId != null) void removeEvent(eventDialog.editingId);
        }}
      />
      <TaskDialog
        open={taskDialog.open}
        initial={taskDialog.initial}
        editingId={taskDialog.editingId}
        onClose={() => setTaskDialog({ open: false, initial: null, editingId: null })}
        onSave={saveTask}
        onDelete={() => {
          if (taskDialog.editingId != null) void removeTask(taskDialog.editingId);
        }}
      />

      <AnimatePresence>
        {toast ? (
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="fixed bottom-5 right-5 z-40 w-[320px] border border-gold/60 bg-lapis2 p-4 shadow-[0_20px_50px_rgba(0,0,0,0.55)]"
          >
            <p className="micro flex items-center gap-1.5 text-gold">
              <Check size={12} /> یادآوری
            </p>
            <p className="mt-2 text-sm font-bold text-fg">{toast.title}</p>
            <p className="serif-voice mt-1 text-xs text-muted">{toast.body}</p>
            <button
              type="button"
              onClick={() => setToast(null)}
              className="micro mt-3 text-dim transition-colors hover:text-gold"
            >
              بستن
            </button>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </div>
    </MotionConfig>
  );
}

function bump(time: string, hours: number): string {
  const [h, m] = time.split(":").map(Number);
  return `${String(Math.min(23, h + hours)).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

function gregorianMonthLine(jy: number, jm: number): string {
  const first = jalaliToIso(jy, jm, 1);
  const g = new Date(`${first}T00:00:00Z`);
  const names = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];
  const span = `${names[g.getUTCMonth()]} ${g.getUTCFullYear()}`;
  return span;
}
