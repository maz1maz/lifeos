import { db } from "@/db";
import { dayNotes } from "@/db/schema";
import { asc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(dayNotes).orderBy(asc(dayNotes.day));
  return Response.json(rows);
}

export async function POST(req: Request) {
  const body = (await req.json()) as { day?: string; text?: string };
  const day = body.day ?? "";
  const text = (body.text ?? "").trim();
  if (!day) return Response.json({ error: "day required" }, { status: 400 });
  if (!text) {
    await db.delete(dayNotes).where(eq(dayNotes.day, day));
    return Response.json({ ok: true });
  }
  const existing = await db.select().from(dayNotes).where(eq(dayNotes.day, day));
  if (existing.length > 0) {
    const [row] = await db
      .update(dayNotes)
      .set({ text, updatedAt: new Date() })
      .where(eq(dayNotes.day, day))
      .returning();
    return Response.json(row);
  }
  const [row] = await db.insert(dayNotes).values({ day, text }).returning();
  return Response.json(row, { status: 201 });
}
