import { db } from "@/db";
import { tasks } from "@/db/schema";
import type { Category, Priority, TaskRow } from "@/lib/types";
import { asc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(tasks).orderBy(asc(tasks.due), asc(tasks.startTime));
  return Response.json(rows);
}

type Payload = {
  title?: string;
  due?: string | null;
  allDay?: boolean;
  startTime?: string | null;
  category?: Category;
  priority?: Priority;
  remindBefore?: number | null;
  notes?: string | null;
  done?: boolean;
};

export async function POST(req: Request) {
  const body = (await req.json()) as Payload;
  const [row] = await db
    .insert(tasks)
    .values({
      title: (body.title ?? "").trim() || "کار بی‌عنوان",
      due: body.due ?? null,
      allDay: body.allDay ?? true,
      startTime: body.allDay === false ? body.startTime ?? null : null,
      category: body.category ?? "personal",
      priority: body.priority ?? "medium",
      remindBefore: body.remindBefore ?? null,
      notes: body.notes?.trim() ? body.notes.trim() : null,
    })
    .returning();
  return Response.json(row satisfies TaskRow, { status: 201 });
}
