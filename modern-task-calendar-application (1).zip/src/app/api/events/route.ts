import { db } from "@/db";
import { events } from "@/db/schema";
import type { Category, EventRow, Priority, RepeatRule } from "@/lib/types";
import { asc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(events).orderBy(asc(events.day), asc(events.startTime));
  return Response.json(rows);
}

type Payload = {
  title?: string;
  day?: string;
  allDay?: boolean;
  startTime?: string | null;
  endTime?: string | null;
  category?: Category;
  priority?: Priority;
  repeatRule?: RepeatRule;
  remindBefore?: number | null;
  notes?: string | null;
  done?: boolean;
};

function clean(body: Payload, fallbackDay: string) {
  const title = (body.title ?? "").trim();
  return {
    title: title || "رویداد بی‌عنوان",
    day: body.day ?? fallbackDay,
    allDay: Boolean(body.allDay),
    startTime: body.allDay ? null : body.startTime ?? null,
    endTime: body.allDay ? null : body.endTime ?? null,
    category: body.category ?? "personal",
    priority: body.priority ?? "medium",
    repeatRule: body.repeatRule ?? "none",
    remindBefore: body.remindBefore ?? null,
    notes: body.notes?.trim() ? body.notes.trim() : null,
  };
}

export async function POST(req: Request) {
  const body = (await req.json()) as Payload;
  const values = clean(body, body.day ?? "");
  const [row] = await db.insert(events).values(values).returning();
  return Response.json(row satisfies EventRow, { status: 201 });
}
