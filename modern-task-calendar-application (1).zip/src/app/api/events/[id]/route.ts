import { db } from "@/db";
import { events } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, { params }: Params) {
  const { id } = await params;
  const body = await req.json();
  const values: Record<string, unknown> = {};
  const allowed = [
    "title",
    "day",
    "allDay",
    "startTime",
    "endTime",
    "category",
    "priority",
    "repeatRule",
    "remindBefore",
    "notes",
    "done",
  ];
  for (const key of allowed) {
    if (key in body) values[key] = body[key];
  }
  if (values.allDay === true) {
    values.startTime = null;
    values.endTime = null;
  }
  const [row] = await db
    .update(events)
    .set(values)
    .where(eq(events.id, Number(id)))
    .returning();
  if (!row) return Response.json({ error: "not found" }, { status: 404 });
  return Response.json(row);
}

export async function DELETE(_req: Request, { params }: Params) {
  const { id } = await params;
  await db.delete(events).where(eq(events.id, Number(id)));
  return Response.json({ ok: true });
}
