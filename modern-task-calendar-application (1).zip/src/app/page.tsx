import { db } from "@/db";
import { dayNotes, events, tasks } from "@/db/schema";
import { seedIfNeeded } from "@/db/seed";
import CalendarApp from "@/components/CalendarApp";
import { todayIso } from "@/lib/dates";
import type { EventRow, NoteRow, TaskRow } from "@/lib/types";
import { asc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  await seedIfNeeded();

  const [eventRows, taskRows, noteRows] = await Promise.all([
    db.select().from(events).orderBy(asc(events.day), asc(events.startTime)),
    db.select().from(tasks).orderBy(asc(tasks.due), asc(tasks.startTime)),
    db.select().from(dayNotes).orderBy(asc(dayNotes.day)),
  ]);

  return (
    <CalendarApp
      initialEvents={eventRows as EventRow[]}
      initialTasks={taskRows as TaskRow[]}
      initialNotes={noteRows as NoteRow[]}
      serverToday={todayIso()}
    />
  );
}
