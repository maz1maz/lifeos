import { db } from "@/db";
import { dayNotes, events, tasks } from "@/db/schema";
import { count } from "drizzle-orm";
import { isoAddDays, jalaliToIso, todayIso } from "@/lib/dates";

/**
 * داده‌های نمونهٔ فارسی — هر بار که جدول رویدادها خالی باشد ساخته می‌شود؛
 * پس از نخستین ثبتِ کاربر، هرگز چیزی اضافه نمی‌شود.
 */
export async function seedIfNeeded(): Promise<void> {
  try {
    const [row] = await db.select({ n: count() }).from(events);
    if ((row?.n ?? 0) > 0) return;

    const today = todayIso();
    const inDays = (n: number) => isoAddDays(today, n);
    const nextJalaliYear = jalaliToIso(1405, 1, 1);

    await db.insert(events).values([
      {
        title: "شروع رسمی سال نو — نوروز",
        day: nextJalaliYear,
        allDay: true,
        category: "occasion",
        priority: "high",
        repeatRule: "yearly",
        notes: "دید و بازدید خانوادگی",
      },
      {
        title: "جلسهٔ هفتگی تیم محصول",
        day: inDays(0),
        startTime: "10:00",
        endTime: "11:30",
        category: "work",
        priority: "medium",
        repeatRule: "weekly",
        remindBefore: 15,
        notes: "مرور رونمایی نسخهٔ ۲٫۰ — اتاق جلسات زنگوله",
      },
      {
        title: "تحویل گزارش فصلی به معاونت",
        day: inDays(2),
        startTime: "14:00",
        endTime: "15:00",
        category: "work",
        priority: "high",
        remindBefore: 60,
        notes: "پیوست نمودار فروش یادت نرود",
      },
      {
        title: "دندان‌پزشکی — دکتر کریمی",
        day: inDays(4),
        startTime: "17:30",
        endTime: "18:30",
        category: "personal",
        priority: "medium",
        remindBefore: 30,
        notes: "خیابان ونک، ساختمان پزشکان آفتاب، طبقهٔ ۳",
      },
      {
        title: "پرداخت اجارهٔ خانه",
        day: inDays(5),
        allDay: true,
        category: "reminder",
        priority: "high",
        remindBefore: 60,
        repeatRule: "monthly",
      },
      {
        title: "تمرین یوگا",
        day: inDays(1),
        startTime: "07:00",
        endTime: "08:00",
        category: "personal",
        priority: "low",
        repeatRule: "weekly",
      },
      {
        title: "تولد سارا",
        day: inDays(9),
        allDay: true,
        category: "occasion",
        priority: "medium",
        repeatRule: "yearly",
        notes: "کیک از قنادی لادن + هدیه",
      },
      {
        title: "یادآوری قبض برق و گاز",
        day: inDays(7),
        allDay: true,
        category: "reminder",
        priority: "medium",
        remindBefore: 30,
        repeatRule: "monthly",
      },
      {
        title: "کارگاه «طراحی تقویم» در خانهٔ هنرمندان",
        day: inDays(-2),
        startTime: "16:00",
        endTime: "18:00",
        category: "personal",
        priority: "low",
      },
      {
        title: "بازبینی قرارداد با شرکت نقش‌جهان",
        day: inDays(12),
        startTime: "09:00",
        endTime: "10:00",
        category: "work",
        priority: "high",
        remindBefore: 30,
        repeatRule: "none",
      },
    ]);

    await db.insert(tasks).values([
      {
        title: "ارسال فاکتور مشتری نقش‌جهان",
        due: inDays(1),
        priority: "high",
        category: "work",
        remindBefore: 30,
      },
      {
        title: "تمدید بیمهٔ ماشین",
        due: inDays(6),
        priority: "medium",
        category: "personal",
      },
      {
        title: "خرید هدیهٔ تولد سارا",
        due: inDays(8),
        priority: "medium",
        category: "personal",
      },
      {
        title: "خواندن فصل سوم کتاب «تقویم و فرهنگ»",
        due: inDays(3),
        priority: "low",
        category: "personal",
      },
    ]);

    await db.insert(dayNotes).values([
      {
        day: today,
        text: "قرار و حس و حالیا نکته‌ای از این روز…",
      },
    ]);
  } catch (error) {
    console.error("seed failed", error);
  }
}
