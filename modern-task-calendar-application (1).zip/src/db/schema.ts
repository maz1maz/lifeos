import {
  boolean,
  date,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import type { Category, Priority, RepeatRule } from "@/lib/types";

/** رویدادها و یادآوری‌های تقویم */
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  day: date("day").notNull(), // تاریخ میلادی: 2026-09-23
  allDay: boolean("all_day").notNull().default(false),
  startTime: text("start_time"),
  endTime: text("end_time"),
  category: text("category").$type<Category>().notNull().default("personal"),
  priority: text("priority").$type<Priority>().notNull().default("medium"),
  repeatRule: text("repeat_rule").$type<RepeatRule>().notNull().default("none"),
  remindBefore: integer("remind_before"), // دقیقه پیش از شروع
  notes: text("notes"),
  done: boolean("done").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

/** کارها با سررسید */
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  due: date("due"),
  allDay: boolean("all_day").notNull().default(true),
  startTime: text("start_time"),
  category: text("category").$type<Category>().notNull().default("personal"),
  priority: text("priority").$type<Priority>().notNull().default("medium"),
  remindBefore: integer("remind_before"),
  notes: text("notes"),
  done: boolean("done").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

/** یادداشت روزانه */
export const dayNotes = pgTable("day_notes", {
  id: serial("id").primaryKey(),
  day: date("day").notNull().unique(),
  text: text("text").notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});
