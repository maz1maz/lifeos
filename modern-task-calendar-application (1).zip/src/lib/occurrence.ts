import { isoAddDays, isoToJalali, weekdayIndex } from "@/lib/dates";
import type { EventRow, Occurrence, TaskRow } from "@/lib/types";

/** آیا رویدادِ تکرارشونده در این روز رخ می‌دهد؟ */
export function occursOn(event: EventRow, day: string): boolean {
  if (event.repeatRule === "none") return event.day === day;
  if (day < event.day) return false;
  switch (event.repeatRule) {
    case "daily":
      return true;
    case "weekly":
      return weekdayIndex(day) === weekdayIndex(event.day);
    case "monthly":
      return isoToJalali(day).jd === isoToJalali(event.day).jd;
    case "yearly": {
      const a = isoToJalali(day);
      const b = isoToJalali(event.day);
      return a.jm === b.jm && a.jd === b.jd;
    }
    default:
      return false;
  }
}

export function occurrencesOn(events: EventRow[], day: string): Occurrence[] {
  return events
    .filter((event) => occursOn(event, day))
    .sort((a, b) => {
      if (a.allDay !== b.allDay) return a.allDay ? -1 : 1;
      return (a.startTime ?? "99:99").localeCompare(b.startTime ?? "99:99");
    })
    .map((event) => ({ key: `${event.id}-${day}`, event, day }));
}

export function occurrencesInRange(
  events: EventRow[],
  from: string,
  to: string,
): Occurrence[] {
  const out: Occurrence[] = [];
  let cursor = from;
  let guard = 0;
  while (cursor <= to && guard < 400) {
    out.push(...occurrencesOn(events, cursor));
    cursor = isoAddDays(cursor, 1);
    guard += 1;
  }
  return out;
}

export function tasksOn(tasks: TaskRow[], day: string): TaskRow[] {
  return tasks.filter((t) => t.due === day);
}

export function nextOccurrences(
  events: EventRow[],
  from: string,
  count: number,
): Occurrence[] {
  const out: Occurrence[] = [];
  let cursor = from;
  for (let i = 0; i < 60 && out.length < count; i += 1) {
    out.push(...occurrencesOn(events, cursor));
    cursor = isoAddDays(cursor, 1);
  }
  return out.slice(0, count);
}
