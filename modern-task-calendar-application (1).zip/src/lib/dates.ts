import {
  isLeapJalaaliYear,
  jalaaliMonthLength,
  toGregorian,
  toJalaali,
} from "jalaali-js";

export const WEEKDAY_SHORT = ["ش", "ی", "د", "س", "چ", "پ", "ج"];
export const WEEKDAY_FULL = [
  "شنبه",
  "یکشنبه",
  "دوشنبه",
  "سه‌شنبه",
  "چهارشنبه",
  "پنجشنبه",
  "جمعه",
];
export const J_MONTHS = [
  "فروردین",
  "اردیبهشت",
  "خرداد",
  "تیر",
  "مرداد",
  "شهریور",
  "مهر",
  "آبان",
  "آذر",
  "دی",
  "بهمن",
  "اسفند",
];
export const G_MONTHS_EN = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];
export const WEEKDAY_EN = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];

export type JDate = { jy: number; jm: number; jd: number };

/** تبدیل ارقام لاتین به فارسی */
export function faNum(value: number | string): string {
  const digits = "۰۱۲۳۴۵۶۷۸۹";
  return String(value).replace(/\d/g, (d) => digits[Number(d)]);
}

/** تاریخ امروز به شکل ISO میلادی (به وقت محلی) */
export function todayIso(): string {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function pad(n: number): string {
  return n < 10 ? `0${n}` : String(n);
}

export function isoToJalali(iso: string): JDate {
  const [gy, gm, gd] = iso.split("-").map(Number);
  return toJalaali(gy, gm, gd);
}

export function jalaliToIso(jy: number, jm: number, jd: number): string {
  const g = toGregorian(jy, jm, jd);
  return `${g.gy}-${pad(g.gm)}-${pad(g.gd)}`;
}

export function isoAddDays(iso: string, n: number): string {
  const [y, m, d] = iso.split("-").map(Number);
  const date = new Date(Date.UTC(y, m - 1, d));
  date.setUTCDate(date.getUTCDate() + n);
  return `${date.getUTCFullYear()}-${pad(date.getUTCMonth() + 1)}-${pad(
    date.getUTCDate(),
  )}`;
}

/** شاخص روز هفتهٔ شمسی: شنبه = ۰ … جمعه = ۶ */
export function weekdayIndex(iso: string): number {
  const [y, m, d] = iso.split("-").map(Number);
  const jsDay = new Date(Date.UTC(y, m - 1, d)).getUTCDay();
  return (jsDay + 1) % 7;
}

export function weekdayFull(iso: string): string {
  return WEEKDAY_FULL[weekdayIndex(iso)];
}

export function weekdayEn(iso: string): string {
  const [y, m, d] = iso.split("-").map(Number);
  return WEEKDAY_EN[new Date(Date.UTC(y, m - 1, d)).getUTCDay()];
}

export function monthLength(jy: number, jm: number): number {
  return jalaaliMonthLength(jy, jm);
}

export function isLeap(jy: number): boolean {
  return isLeapJalaaliYear(jy);
}

export function jalaliTitle(jy: number, jm: number): string {
  return `${J_MONTHS[jm - 1]} ${faNum(jy)}`;
}

export function jalaliDateLine(iso: string): string {
  const { jy, jm, jd } = isoToJalali(iso);
  return `${WEEKDAY_FULL[weekdayIndex(iso)]} ${faNum(jd)} ${J_MONTHS[jm - 1]} ${faNum(jy)}`;
}

export function gregorianDateLine(iso: string): string {
  const [y, m, d] = iso.split("-").map(Number);
  return `${weekdayEn(iso)}, ${d} ${G_MONTHS_EN[m - 1]} ${y}`;
}

export function gregorianShort(iso: string): string {
  const [y, m, d] = iso.split("-").map(Number);
  return `${m}/${d}`;
}

export function faTime(time: string | null): string {
  if (!time) return "";
  return faNum(time);
}

/** نخستین و آخرین روز ماه شمسی به شکل ISO */
export function monthBounds(jy: number, jm: number): [string, string] {
  const first = jalaliToIso(jy, jm, 1);
  const last = isoAddDays(first, monthLength(jy, jm) - 1);
  return [first, last];
}

/** ۴۲ روز جدول ماه (۶ هفته کامل از شنبه) */
export function monthGridDays(jy: number, jm: number): string[] {
  const first = jalaliToIso(jy, jm, 1);
  const start = isoAddDays(first, -weekdayIndex(first));
  return Array.from({ length: 42 }, (_, i) => isoAddDays(start, i));
}

/** هفت روزِ هفتهٔ شامل این تاریخ (شروع از شنبه) */
export function weekDays(iso: string): string[] {
  const start = isoAddDays(iso, -weekdayIndex(iso));
  return Array.from({ length: 7 }, (_, i) => isoAddDays(start, i));
}

/** شمارهٔ هفتهٔ ISO برای نمایش روی برگهٔ ماه */
export function isoWeekNumber(iso: string): number {
  const [y, m, d] = iso.split("-").map(Number);
  const date = new Date(Date.UTC(y, m - 1, d));
  const dayNum = (date.getUTCDay() + 6) % 7;
  date.setUTCDate(date.getUTCDate() - dayNum + 3);
  const firstThursday = new Date(Date.UTC(date.getUTCFullYear(), 0, 4));
  const diff = date.getTime() - firstThursday.getTime();
  return 1 + Math.round(diff / (7 * 24 * 3600 * 1000));
}

export function compareIso(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}

/** زمان اجرای رویداد به میلی‌ثانیه (برای محاسبهٔ یادآوری) */
export function occurrenceMs(day: string, time: string | null): number {
  const [y, m, d] = day.split("-").map(Number);
  const [hh, mm] = (time ?? "09:00").split(":").map(Number);
  return new Date(y, m - 1, d, hh, mm, 0, 0).getTime();
}
