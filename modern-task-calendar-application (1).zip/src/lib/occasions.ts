import type { Occasion } from "@/lib/types";

/** مناسبت‌های هجری شمسی (بر پایهٔ تقویم رسمی ایران) */
export const OCCASIONS: Occasion[] = [
  { jm: 1, jd: 1, title: "جشن نوروز", holiday: true },
  { jm: 1, jd: 2, title: "عیدنوروز", holiday: true },
  { jm: 1, jd: 3, title: "عیدنوروز", holiday: true },
  { jm: 1, jd: 4, title: "عیدنوروز", holiday: true },
  { jm: 1, jd: 12, title: "روز جمهوری اسلامی", holiday: true },
  { jm: 1, jd: 13, title: "روز طبیعت — سیزده‌به‌در", holiday: true },
  { jm: 2, jd: 10, title: "روز ملی خلیج فارس", holiday: false },
  { jm: 3, jd: 14, title: "رحلت امام خمینی", holiday: true },
  { jm: 3, jd: 15, title: "قیام ۱۵ خرداد", holiday: true },
  { jm: 4, jd: 25, title: "روز بهزیستی و تأمین اجتماعی", holiday: false },
  { jm: 5, jd: 17, title: "شهادت آیت‌الله بهشتی — روز قوهٔ قضائیه", holiday: false },
  { jm: 6, jd: 30, title: "روز گفت‌وگوی تمدن‌ها", holiday: false },
  { jm: 7, jd: 1, title: "آغاز سال تحصیلی", holiday: false },
  { jm: 7, jd: 7, title: "روز بزرگداشت شعر و ادب — روز مولانا", holiday: false },
  { jm: 7, jd: 13, title: "روز نیروی انتظامی", holiday: false },
  { jm: 7, jd: 14, title: "روز دامپزشکی", holiday: false },
  { jm: 7, jd: 20, title: "روز بزرگداشت حافظ", holiday: false },
  { jm: 8, jd: 13, title: "روز دانش‌آموز", holiday: false },
  { jm: 8, jd: 24, title: "روز کتاب و کتاب‌خوانی", holiday: false },
  { jm: 9, jd: 7, title: "روز نیروی دریایی", holiday: false },
  { jm: 9, jd: 16, title: "روز دانشجو", holiday: false },
  { jm: 9, jd: 25, title: "روز پژوهش", holiday: false },
  { jm: 10, jd: 13, title: "روز جهانی مقاومت", holiday: false },
  { jm: 11, jd: 12, title: "بازگشت امام خمینی به ایران", holiday: false },
  { jm: 11, jd: 22, title: "پیروزی انقلاب اسلامی", holiday: true },
  { jm: 12, jd: 29, title: "ملی شدن صنعت نفت", holiday: true },
  { jm: 12, jd: 25, title: "روز درختکاری", holiday: false },
];

export function occasionsFor(jm: number, jd: number): Occasion[] {
  return OCCASIONS.filter((o) => o.jm === jm && o.jd === jd);
}
