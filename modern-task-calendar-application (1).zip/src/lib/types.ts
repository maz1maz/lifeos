export type Category = "work" | "reminder" | "personal" | "occasion";
export type Priority = "low" | "medium" | "high";
export type RepeatRule = "none" | "daily" | "weekly" | "monthly" | "yearly";

export type EventRow = {
  id: number;
  title: string;
  day: string;
  allDay: boolean;
  startTime: string | null;
  endTime: string | null;
  category: Category;
  priority: Priority;
  repeatRule: RepeatRule;
  remindBefore: number | null;
  notes: string | null;
  done: boolean;
};

export type TaskRow = {
  id: number;
  title: string;
  due: string | null;
  allDay: boolean;
  startTime: string | null;
  category: Category;
  priority: Priority;
  remindBefore: number | null;
  notes: string | null;
  done: boolean;
};

export type NoteRow = {
  id: number;
  day: string;
  text: string;
};

export type Occasion = {
  jm: number;
  jd: number;
  title: string;
  holiday: boolean;
};

export type Occurrence = {
  key: string;
  event: EventRow;
  day: string;
};

export const CATEGORY_META: Record<
  Category,
  { label: string; color: string; soft: string }
> = {
  work: { label: "کار", color: "#37C9C0", soft: "rgba(55,201,192,0.14)" },
  reminder: { label: "یادآوری", color: "#D8A657", soft: "rgba(216,166,87,0.14)" },
  personal: { label: "شخصی", color: "#7C8FD6", soft: "rgba(124,143,214,0.14)" },
  occasion: { label: "مناسبت", color: "#E2574C", soft: "rgba(226,87,76,0.14)" },
};

export const PRIORITY_META: Record<Priority, { label: string; mark: string }> = {
  low: { label: "کم", mark: "•" },
  medium: { label: "میانه", mark: "••" },
  high: { label: "زیاد", mark: "•••" },
};

export const REPEAT_META: Record<RepeatRule, string> = {
  none: "بدون تکرار",
  daily: "هر روز",
  weekly: "هفتگی",
  monthly: "ماهانه",
  yearly: "سالانه",
};
