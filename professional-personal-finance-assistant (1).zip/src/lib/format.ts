export function faNum(n: number | string): string {
  const num = typeof n === "string" ? Number(n) : n;
  if (Number.isNaN(num)) return "۰";
  return new Intl.NumberFormat("fa-IR").format(num);
}

export function faMoney(n: number | string): string {
  return `${faNum(n)} ریال`;
}

export function faMoneyCompact(n: number): string {
  if (Math.abs(n) >= 1_000_000_000) {
    const v = n / 1_000_000_000;
    return `${new Intl.NumberFormat("fa-IR", { maximumFractionDigits: 2 }).format(v)} میلیارد ریال`;
  }
  if (Math.abs(n) >= 1_000_000) {
    const v = n / 1_000_000;
    return `${new Intl.NumberFormat("fa-IR", { maximumFractionDigits: 1 }).format(v)} میلیون ریال`;
  }
  if (Math.abs(n) >= 1_000) {
    const v = n / 1_000;
    return `${new Intl.NumberFormat("fa-IR", { maximumFractionDigits: 0 }).format(v)} هزار ریال`;
  }
  return faMoney(n);
}

export function toFaDate(iso: string): string {
  try {
    const d = new Date(iso);
    return new Intl.DateTimeFormat("fa-IR", { year: "numeric", month: "long", day: "numeric" }).format(d);
  } catch {
    return iso;
  }
}

export function currentMonthKey(d = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  return `${y}-${m}`;
}

export function monthKeyToFa(monthKey: string): string {
  try {
    const [y, m] = monthKey.split("-").map(Number);
    const d = new Date(y, m - 1, 1);
    return new Intl.DateTimeFormat("fa-IR", { year: "numeric", month: "long" }).format(d);
  } catch {
    return monthKey;
  }
}

export const CATEGORIES = [
  "خوراک",
  "حمل‌ونقل",
  "قبض",
  "انتقال",
  "متفرقه",
  "مسکن",
  "سلامت",
  "تفریح",
  "آموزش",
  "پوشاک",
  "حقوق",
  "سرمایه‌گذاری",
  "هدیه",
  "سفر",
];

export const CATEGORY_COLORS: Record<string, string> = {
  "خوراک": "#22d3ee",
  "حمل‌ونقل": "#a78bfa",
  "قبض": "#fbbf24",
  "انتقال": "#34d399",
  "متفرقه": "#64748b",
  "مسکن": "#f472b6",
  "سلامت": "#fb7185",
  "تفریح": "#60a5fa",
  "آموزش": "#4ade80",
  "پوشاک": "#f97316",
  "حقوق": "#2dd4bf",
  "سرمایه‌گذاری": "#e879f9",
  "هدیه": "#facc15",
  "سفر": "#38bdf8",
};

export const CATEGORY_ICONS: Record<string, string> = {
  "خوراک": "🍔",
  "حمل‌ونقل": "🚕",
  "قبض": "🧾",
  "انتقال": "🔄",
  "متفرقه": "📦",
  "مسکن": "🏠",
  "سلامت": "💊",
  "تفریح": "🎮",
  "آموزش": "📚",
  "پوشاک": "👕",
  "حقوق": "💼",
  "سرمایه‌گذاری": "📈",
  "هدیه": "🎁",
  "سفر": "✈️",
};
