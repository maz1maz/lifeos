import { NextResponse } from "next/server";
import { db } from "@/db";
import { transfers } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  const rows = await db.select().from(transfers).orderBy(desc(transfers.date), desc(transfers.id)).limit(100);
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const body = await req.json();
  const fromAccountId = body.fromAccountId ? Number(body.fromAccountId) : null;
  const toAccountId = body.toAccountId ? Number(body.toAccountId) : null;
  const amount = Number(body.amount ?? 0);
  const date = String(body.date ?? new Date().toISOString().slice(0, 10));
  const description = String(body.description ?? "");
  if (!fromAccountId || !toAccountId)
    return NextResponse.json({ error: "حساب مبدأ و مقصد لازم است" }, { status: 400 });
  if (fromAccountId === toAccountId)
    return NextResponse.json({ error: "مبدأ و مقصد یکسان است" }, { status: 400 });
  if (!amount || amount <= 0) return NextResponse.json({ error: "مبلغ معتبر نیست" }, { status: 400 });
  const [row] = await db
    .insert(transfers)
    .values({ fromAccountId, toAccountId, amount, date, description })
    .returning();
  return NextResponse.json(row);
}

export async function DELETE(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = Number(searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "id لازم است" }, { status: 400 });
  await db.delete(transfers).where(eq(transfers.id, id));
  return NextResponse.json({ ok: true });
}
