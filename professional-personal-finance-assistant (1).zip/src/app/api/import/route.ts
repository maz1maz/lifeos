import { NextResponse } from "next/server";
import { db } from "@/db";
import { transactions, accounts } from "@/db/schema";

function parseAmount(v: string): number {
  const cleaned = String(v ?? "").replace(/[,،٬\sریال]/g, "").replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)));
  const n = Number(cleaned);
  return Number.isFinite(n) ? Math.abs(Math.round(n)) : 0;
}

export async function POST(req: Request) {
  const body = await req.json();
  const rows = body.rows as Array<Record<string, string>> | undefined;
  const accountId = body.accountId ? Number(body.accountId) : null;
  if (!rows || !Array.isArray(rows) || !rows.length)
    return NextResponse.json({ error: "ردیفی برای ورود نیست" }, { status: 400 });

  const accs = await db.select().from(accounts);
  const defaultAcc = accs[0]?.id ?? null;
  const acc = accountId ?? defaultAcc;

  let inserted = 0;
  const preview: { title: string; amount: number; date: string }[] = [];

  for (const r of rows.slice(0, 500)) {
    const keys = Object.keys(r);
    const low: Record<string, string> = {};
    for (const k of keys) low[k.trim().toLowerCase()] = String(r[k] ?? "");

    const title =
      r["شرح"] ?? r["title"] ?? r["description"] ?? r["Description"] ?? r["شرح تراکنش"] ?? low["title"] ?? low["description"] ?? Object.values(r)[0] ?? "تراکنش بانکی";
    const amountRaw = r["مبلغ"] ?? r["amount"] ?? r["Amount"] ?? low["amount"] ?? low["مبلغ"] ?? Object.values(r)[1] ?? "0";
    const dateRaw = r["تاریخ"] ?? r["date"] ?? r["Date"] ?? low["date"] ?? new Date().toISOString().slice(0, 10);
    const amount = parseAmount(String(amountRaw));
    if (!amount) continue;

    let date = new Date().toISOString().slice(0, 10);
    const dm = String(dateRaw).match(/(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
    if (dm) date = `${dm[1]}-${dm[2].padStart(2, "0")}-${dm[3].padStart(2, "0")}`;

    const isIncome = /واریز|دریافت|حقوق|income|deposit/i.test(String(title) + String(amountRaw)) || Number(String(amountRaw).replace(/[,٬]/g, "")) > 0 && /\+/.test(String(amountRaw));
    // heuristic: if raw contains '-' it's expense
    const kind = String(amountRaw).includes("-") ? "expense" : isIncome ? "income" : "expense";

    preview.push({ title: String(title).slice(0, 80), amount, date });

    if (body.previewOnly) continue;

    await db.insert(transactions).values({
      title: String(title).slice(0, 200),
      amount,
      kind,
      category: kind === "income" ? "حقوق" : "متفرقه",
      accountId: acc,
      date,
      tags: "بانکی,درون‌ریزی",
      note: "درون‌ریزی صورت‌حساب",
    });
    inserted++;
  }

  if (body.previewOnly) return NextResponse.json({ preview: preview.slice(0, 20), count: preview.length });
  return NextResponse.json({ ok: true, inserted });
}
