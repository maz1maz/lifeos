import { NextResponse } from "next/server";
import { db } from "@/db";
import { debts } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  const rows = await db.select().from(debts).orderBy(desc(debts.id)).limit(200);
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const body = await req.json();
  const person = String(body.person ?? "").trim();
  const title = String(body.title ?? "").trim() || `طلب از ${person}`;
  const amount = Number(body.amount ?? 0);
  if (!person) return NextResponse.json({ error: "نام طرف حساب لازم است" }, { status: 400 });
  if (!amount || amount <= 0) return NextResponse.json({ error: "مبلغ معتبر نیست" }, { status: 400 });
  const kind = body.kind === "payable" ? "payable" : "receivable";
  const description = String(body.description ?? "");
  const [row] = await db.insert(debts).values({ person, title, amount, kind, description }).returning();
  return NextResponse.json(row);
}

export async function PATCH(req: Request) {
  const body = await req.json();
  const id = Number(body.id);
  if (!id) return NextResponse.json({ error: "id لازم است" }, { status: 400 });
  if (body.action === "settle") {
    const [row] = await db
      .update(debts)
      .set({ isSettled: true, settledAt: new Date() })
      .where(eq(debts.id, id))
      .returning();
    return NextResponse.json(row);
  }
  if (body.action === "unsettled") {
    const [row] = await db
      .update(debts)
      .set({ isSettled: false, settledAt: null })
      .where(eq(debts.id, id))
      .returning();
    return NextResponse.json(row);
  }
  return NextResponse.json({ error: "action نامعتبر" }, { status: 400 });
}

export async function DELETE(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = Number(searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "id لازم است" }, { status: 400 });
  await db.delete(debts).where(eq(debts.id, id));
  return NextResponse.json({ ok: true });
}
