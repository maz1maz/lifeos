import { NextResponse } from "next/server";
import { db } from "@/db";
import { transactions } from "@/db/schema";
import { and, desc, eq, gte, lte, sql } from "drizzle-orm";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const month = searchParams.get("month"); // YYYY-MM
  const kind = searchParams.get("kind");
  const q = searchParams.get("q") ?? "";
  const limit = Math.min(Number(searchParams.get("limit") ?? 300), 1000);

  const conds = [];
  if (month) {
    conds.push(gte(transactions.date, `${month}-01`));
    // last day
    const [y, m] = month.split("-").map(Number);
    const last = new Date(y, m, 0).getDate();
    conds.push(lte(transactions.date, `${month}-${String(last).padStart(2, "0")}`));
  }
  if (kind && kind !== "all") conds.push(eq(transactions.kind, kind));

  let rows;
  if (conds.length) {
    rows = await db
      .select()
      .from(transactions)
      .where(and(...conds))
      .orderBy(desc(transactions.date), desc(transactions.id))
      .limit(limit);
  } else {
    rows = await db
      .select()
      .from(transactions)
      .orderBy(desc(transactions.date), desc(transactions.id))
      .limit(limit);
  }

  let filtered = rows;
  if (q) {
    filtered = rows.filter(
      (r) =>
        r.title.includes(q) ||
        (r.category ?? "").includes(q) ||
        (r.note ?? "").includes(q) ||
        (r.tags ?? "").includes(q)
    );
  }

  // totals for month (or all)
  const totals = await db
    .select({
      kind: transactions.kind,
      total: sql<number>`sum(${transactions.amount})`.as("total"),
      count: sql<number>`count(*)`.as("count"),
    })
    .from(transactions)
    .where(conds.length ? and(...conds) : undefined)
    .groupBy(transactions.kind);

  return NextResponse.json({ items: filtered, totals });
}

export async function POST(req: Request) {
  const body = await req.json();
  const title = String(body.title ?? "").trim();
  const amount = Number(body.amount ?? 0);
  if (!title) return NextResponse.json({ error: "شرح الزامی است" }, { status: 400 });
  if (!amount || amount <= 0) return NextResponse.json({ error: "مبلغ معتبر نیست" }, { status: 400 });
  const kind = ["expense", "income", "transfer"].includes(body.kind) ? body.kind : "expense";
  const category = String(body.category ?? "متفرقه");
  const accountId = body.accountId ? Number(body.accountId) : null;
  const tags = String(body.tags ?? "");
  const date = String(body.date ?? new Date().toISOString().slice(0, 10));
  const note = String(body.note ?? "");
  const [row] = await db
    .insert(transactions)
    .values({ title, amount, kind, category, accountId, tags, date, note })
    .returning();
  return NextResponse.json(row);
}

export async function DELETE(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = Number(searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "id لازم است" }, { status: 400 });
  await db.delete(transactions).where(eq(transactions.id, id));
  return NextResponse.json({ ok: true });
}
