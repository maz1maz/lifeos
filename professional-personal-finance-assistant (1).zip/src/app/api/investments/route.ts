import { NextResponse } from "next/server";
import { db } from "@/db";
import { investments } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  const rows = await db.select().from(investments).orderBy(desc(investments.date), desc(investments.id)).limit(200);
  // aggregate holdings by symbol
  const holdings: Record<string, { symbol: string; name: string; kind: string; qty: number; cost: number; buys: number; sells: number }> = {};
  for (const r of rows) {
    const q = Number(r.quantity ?? 0);
    const cost = q * Number(r.unitPrice ?? 0);
    if (!holdings[r.symbol]) holdings[r.symbol] = { symbol: r.symbol, name: r.name, kind: r.kind, qty: 0, cost: 0, buys: 0, sells: 0 };
    if (r.side === "buy") {
      holdings[r.symbol].qty += q;
      holdings[r.symbol].cost += cost + Number(r.fee ?? 0);
      holdings[r.symbol].buys += cost;
    } else {
      holdings[r.symbol].qty -= q;
      holdings[r.symbol].cost -= cost;
      holdings[r.symbol].sells += cost;
    }
  }
  const list = Object.values(holdings).filter((h) => Math.abs(h.qty) > 1e-9);
  return NextResponse.json({ items: rows, holdings: list });
}

export async function POST(req: Request) {
  const body = await req.json();
  const symbol = String(body.symbol ?? "").trim().toUpperCase();
  if (!symbol) return NextResponse.json({ error: "نماد لازم است" }, { status: 400 });
  const quantity = Number(body.quantity ?? 0);
  const unitPrice = Number(body.unitPrice ?? 0);
  if (!quantity || quantity <= 0) return NextResponse.json({ error: "تعداد معتبر نیست" }, { status: 400 });
  const name = String(body.name ?? symbol);
  const kind = String(body.kind ?? "crypto");
  const side = body.side === "sell" ? "sell" : "buy";
  const fee = Number(body.fee ?? 0) || 0;
  const date = String(body.date ?? new Date().toISOString().slice(0, 10));
  const note = String(body.note ?? "");
  const [row] = await db
    .insert(investments)
    .values({ symbol, name, kind, side, quantity: String(quantity), unitPrice, fee, date, note })
    .returning();
  return NextResponse.json(row);
}

export async function DELETE(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = Number(searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "id لازم است" }, { status: 400 });
  await db.delete(investments).where(eq(investments.id, id));
  return NextResponse.json({ ok: true });
}
