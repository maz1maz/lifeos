import { NextResponse } from "next/server";
import { db } from "@/db";
import { accounts, transactions, budgets, debts, investments, transfers } from "@/db/schema";
import { sql } from "drizzle-orm";

export async function POST() {
  // clear
  await db.delete(transfers);
  await db.delete(transactions);
  await db.delete(budgets);
  await db.delete(debts);
  await db.delete(investments);
  await db.delete(accounts);

  const [acc1] = await db
    .insert(accounts)
    .values({ name: "کارت اصلی", bank: "ملی", type: "بانک", initialBalance: 120000000 })
    .returning();
  const [acc2] = await db
    .insert(accounts)
    .values({ name: "بلو بانک", bank: "بلو", type: "نئوبانک", initialBalance: 38079726 })
    .returning();
  const [acc3] = await db
    .insert(accounts)
    .values({ name: "نقدی", bank: "نقدی", type: "نقدی", initialBalance: 5000000 })
    .returning();

  const M = "2026-09";
  const txData = [
    { title: "حقوق شهریور", amount: 857773740, kind: "income", category: "حقوق", accountId: acc1.id, date: `${M}-01`, tags: "حقوق,ماهانه", note: "واریز حقوق" },
    { title: "انتقال بانکی به حساب مقصد", amount: 10000000, kind: "transfer", category: "انتقال", accountId: null, date: `${M}-21`, tags: "", note: "" },
    { title: "زیبو", amount: 5000000, kind: "expense", category: "متفرقه", accountId: null, date: `${M}-20`, tags: "", note: "" },
    { title: "شارژ اسنپ", amount: 46179550, kind: "expense", category: "حمل‌ونقل", accountId: null, date: `${M}-19`, tags: "اسنپ", note: "" },
    { title: "خرید از فروشگاه", amount: 14221000, kind: "expense", category: "خوراک", accountId: acc1.id, date: `${M}-18`, tags: "سوپرمارکت", note: "#سوپرمارکت" },
    { title: "خرید فیلترنتی", amount: 7630000, kind: "expense", category: "قبض", accountId: acc1.id, date: `${M}-18`, tags: "اشتراک", note: "تمدید" },
    { title: "کارمزد", amount: 148000, kind: "expense", category: "متفرقه", accountId: acc1.id, date: `${M}-18`, tags: "", note: "" },
    { title: "قهوه کافه", amount: 890000, kind: "expense", category: "تفریح", accountId: acc2.id, date: `${M}-17`, tags: "کافه", note: "" },
    { title: "اجاره خانه", amount: 45000000, kind: "expense", category: "مسکن", accountId: acc1.id, date: `${M}-15`, tags: "اجاره", note: "" },
    { title: "باشگاه", amount: 3200000, kind: "expense", category: "سلامت", accountId: acc2.id, date: `${M}-12`, tags: "", note: "" },
    { title: "قبض برق", amount: 14807220, kind: "expense", category: "قبض", accountId: acc1.id, date: `${M}-10`, tags: "برق", note: "" },
    { title: "اسنپ‌فود", amount: 232203000 - 200000000, kind: "expense", category: "خوراک", accountId: acc2.id, date: `${M}-08`, tags: "", note: "" },
    { title: "بنزین", amount: 4676950, kind: "expense", category: "حمل‌ونقل", accountId: acc3.id, date: `${M}-05`, tags: "", note: "" },
    { title: "فروش لaptop", amount: 25000000, kind: "income", category: "متفرقه", accountId: acc2.id, date: `${M}-06`, tags: "", note: "" },
  ] as const;

  for (const t of txData) {
    await db.insert(transactions).values({
      title: t.title,
      amount: t.amount,
      kind: t.kind as string,
      category: t.category,
      accountId: t.accountId as number | null,
      date: t.date,
      tags: t.tags ?? "",
      note: t.note ?? "",
    });
  }

  await db.insert(budgets).values([
    { month: M, category: "__total__", limitAmount: 500000000 },
    { month: M, category: "خوراک", limitAmount: 60000000 },
    { month: M, category: "حمل‌ونقل", limitAmount: 20000000 },
    { month: M, category: "قبض", limitAmount: 30000000 },
    { month: M, category: "متفرقه", limitAmount: 25000000 },
    { month: M, category: "مسکن", limitAmount: 50000000 },
  ]);

  const debtData = [
    { person: "علیرضا", title: "طلب از علیرضا", amount: 12000000, kind: "receivable", description: "قرض خرداد - پول قبلی" },
    { person: "علیرضا", title: "طلب از علیرضا", amount: 8000000, kind: "receivable", description: "هاست سایت" },
    { person: "علیرضا", title: "طلب از علیرضا", amount: 10000000, kind: "receivable", description: "قبا - قبضا سعید - از USD" },
    { person: "علیرضا", title: "طلب از علیرضا", amount: 5000000, kind: "receivable", description: "دلمین سایت" },
    { person: "علیرضا", title: "طلب از علیرضا", amount: 11000000, kind: "receivable", description: "کلاه دو ماه" },
    { person: "مامان", title: "طلب از مامان", amount: 15000000, kind: "receivable", description: "کارگر" },
    { person: "علیرضا", title: "طلب از علیرضا", amount: 7000000, kind: "receivable", description: "کلاه فالر سایت" },
    { person: "پیمان", title: "طلب از پیمان", amount: 8000000, kind: "receivable", description: "" },
    { person: "فرشید", title: "طلب از فرشید", amount: 8000000, kind: "receivable", description: "" },
    { person: "خودم", title: "بدهی قسط وام", amount: 22000000, kind: "payable", description: "قسط بانک" },
  ];
  for (const d of debtData) {
    await db.insert(debts).values({ person: d.person, title: d.title, amount: d.amount, kind: d.kind, description: d.description });
  }

  await db.insert(investments).values([
    { symbol: "USD", name: "dollar", kind: "fiat", side: "buy", quantity: "500", unitPrice: 102000, fee: 0, date: `${M}-10`, note: "اسکناس" },
    { symbol: "EUR", name: "euro", kind: "fiat", side: "buy", quantity: "100", unitPrice: 110000, fee: 0, date: `${M}-10`, note: "" },
    { symbol: "BTC", name: "Bitcoin", kind: "crypto", side: "buy", quantity: "0.015", unitPrice: 4200000000, fee: 500000, date: `${M}-05`, note: "هولد" },
  ]);

  await db.insert(transfers).values({
    fromAccountId: acc1.id,
    toAccountId: acc2.id,
    amount: 10000000,
    date: `${M}-21`,
    description: "انتقال بانکی به حساب مقصد",
  });

  const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(transactions);
  return NextResponse.json({ ok: true, count });
}
