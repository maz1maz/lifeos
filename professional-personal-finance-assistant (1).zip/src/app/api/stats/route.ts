import { NextResponse } from "next/server";
import { db } from "@/db";
import { transactions } from "@/db/schema";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const month = searchParams.get("month") ?? new Date().toISOString().slice(0, 7);
  const [y, m] = month.split("-").map(Number);

  const all = await db.select().from(transactions);

  const inMonthKey = (d: string) => d.slice(0, 7);

  const monthRows = all.filter((t) => inMonthKey(t.date) === month);
  let income = 0,
    expense = 0;
  const byCat: Record<string, number> = {};
  for (const t of monthRows) {
    const a = Number(t.amount);
    if (t.kind === "income") income += a;
    else if (t.kind === "expense") {
      expense += a;
      byCat[t.category] = (byCat[t.category] ?? 0) + a;
    }
  }

  // last 6 months trend
  const trend: { month: string; income: number; expense: number; balance: number }[] = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(y, m - 1 - i, 1);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    let inc = 0,
      exp = 0;
    for (const t of all) {
      if (inMonthKey(t.date) === key) {
        if (t.kind === "income") inc += Number(t.amount);
        if (t.kind === "expense") exp += Number(t.amount);
      }
    }
    trend.push({ month: key, income: inc, expense: exp, balance: inc - exp });
  }

  // daily in month
  const lastDay = new Date(y, m, 0).getDate();
  const daily: { day: string; expense: number; income: number }[] = [];
  for (let d = 1; d <= lastDay; d++) {
    const ds = `${month}-${String(d).padStart(2, "0")}`;
    let inc = 0,
      exp = 0;
    for (const t of monthRows) {
      if (t.date === ds) {
        if (t.kind === "income") inc += Number(t.amount);
        if (t.kind === "expense") exp += Number(t.amount);
      }
    }
    daily.push({ day: String(d), expense: exp, income: inc });
  }

  const topCats = Object.entries(byCat)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 8);

  const balance = income - expense;
  const savingsRate = income > 0 ? Math.round(((income - expense) / income) * 100) : 0;

  // insights
  const insights: string[] = [];
  if (expense > income && income > 0) insights.push(`هشدار: هزینه‌های این ماه ${Math.round((expense / income) * 100 - 100)}٪ بیشتر از درآمد است.`);
  if (savingsRate >= 20) insights.push(`آفرین! نرخ پس‌انداز شما ${savingsRate}٪ است؛ بالاتر از استاندارد ۲۰٪.`);
  if (savingsRate < 0) insights.push(`تراز ماه منفی است؛ پیشنهاد می‌شود هزینه‌های «متفرقه» و «تفریح» را ۱۵٪ کاهش دهید.`);
  if (topCats[0]) insights.push(`بیشترین هزینه در «${topCats[0].name}» ثبت شده (${Math.round((topCats[0].value / (expense || 1)) * 100)}٪ از کل هزینه).`);
  if (trend.length >= 2) {
    const prev = trend[trend.length - 2].expense || 1;
    const cur = trend[trend.length - 1].expense;
    const diff = Math.round(((cur - prev) / prev) * 100);
    if (diff > 5) insights.push(`هزینه نسبت به ماه قبل ${diff}٪ رشد کرده است.`);
    else if (diff < -5) insights.push(`هزینه نسبت به ماه قبل ${Math.abs(diff)}٪ کمتر شده؛ روند عالی است.`);
  }
  if (!insights.length) insights.push("داده کافی برای تحلیل هوشمند وجود ندارد؛ چند تراکنش تازه ثبت کنید.");

  return NextResponse.json({
    month,
    income,
    expense,
    balance,
    savingsRate,
    byCat,
    topCats,
    trend,
    daily,
    count: monthRows.length,
    insights,
  });
}
