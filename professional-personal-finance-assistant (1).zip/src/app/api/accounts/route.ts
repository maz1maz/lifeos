import { NextResponse } from "next/server";
import { db } from "@/db";
import { accounts, transactions, transfers } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function GET() {
  const list = await db.select().from(accounts).orderBy(accounts.id);
  // compute balances
  const txSums = await db
    .select({
      accountId: transactions.accountId,
      kind: transactions.kind,
      total: sql<number>`sum(${transactions.amount})`.as("total"),
    })
    .from(transactions)
    .groupBy(transactions.accountId, transactions.kind);

  const trOut = await db
    .select({
      accountId: transfers.fromAccountId,
      total: sql<number>`sum(${transfers.amount})`.as("total"),
    })
    .from(transfers)
    .groupBy(transfers.fromAccountId);

  const trIn = await db
    .select({
      accountId: transfers.toAccountId,
      total: sql<number>`sum(${transfers.amount})`.as("total"),
    })
    .from(transfers)
    .groupBy(transfers.toAccountId);

  const enriched = list.map((a) => {
    let bal = Number(a.initialBalance ?? 0);
    for (const t of txSums) {
      if (t.accountId === a.id) {
        const v = Number(t.total ?? 0);
        if (t.kind === "income") bal += v;
        else if (t.kind === "expense") bal -= v;
      }
    }
    for (const t of trOut) if (t.accountId === a.id) bal -= Number(t.total ?? 0);
    for (const t of trIn) if (t.accountId === a.id) bal += Number(t.total ?? 0);
    return { ...a, balance: bal };
  });

  return NextResponse.json(enriched);
}

export async function POST(req: Request) {
  const body = await req.json();
  const name = String(body.name ?? "").trim();
  if (!name) return NextResponse.json({ error: "نام حساب الزامی است" }, { status: 400 });
  const bank = String(body.bank ?? "بانک");
  const type = String(body.type ?? "بانک");
  const initialBalance = Number(body.initialBalance ?? 0) || 0;
  const [row] = await db
    .insert(accounts)
    .values({ name, bank, type, initialBalance })
    .returning();
  return NextResponse.json(row);
}

export async function DELETE(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = Number(searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "id لازم است" }, { status: 400 });
  await db.delete(accounts).where(eq(accounts.id, id));
  return NextResponse.json({ ok: true });
}
