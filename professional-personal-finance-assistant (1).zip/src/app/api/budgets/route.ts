import { NextResponse } from "next/server";
import { db } from "@/db";
import { budgets, transactions } from "@/db/schema";
import { and, eq } from "drizzle-orm";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const month = searchParams.get("month") ?? new Date().toISOString().slice(0, 7);
  const rows = await db.select().from(budgets).where(eq(budgets.month, month));

  // spent per category for month
  const [y, m] = month.split("-").map(Number);
  const last = new Date(y || 2026, m || 9, 0).getDate();
  const start = `${month}-01`;
  const end = `${month}-${String(last).padStart(2, "0")}`;

  const txs = await db.select().from(transactions);
  const inMonth = txs.filter((t) => t.date >= start && t.date <= end && t.kind === "expense");
  const spentByCat: Record<string, number> = {};
  let totalSpent = 0;
  for (const t of inMonth) {
    spentByCat[t.category] = (spentByCat[t.category] ?? 0) + Number(t.amount);
    totalSpent += Number(t.amount);
  }

  const enriched = rows.map((b) => ({
    ...b,
    spent: spentByCat[b.category] ?? (b.category === "__total__" ? totalSpent : 0),
  }));

  // ensure total row
  const totalBudget = rows.find((r) => r.category === "__total__");
  return NextResponse.json({ items: enriched, spentByCat, totalSpent, totalBudget: totalBudget ?? null });
}

export async function POST(req: Request) {
  const body = await req.json();
  const month = String(body.month ?? new Date().toISOString().slice(0, 7));
  const category = String(body.category ?? "__total__");
  const limitAmount = Number(body.limitAmount ?? 0);
  if (!limitAmount || limitAmount <= 0)
    return NextResponse.json({ error: "سقف بودجه معتبر نیست" }, { status: 400 });

  const existing = await db
    .select()
    .from(budgets)
    .where(and(eq(budgets.month, month), eq(budgets.category, category)));
  if (existing.length) {
    const [updated] = await db
      .update(budgets)
      .set({ limitAmount })
      .where(and(eq(budgets.month, month), eq(budgets.category, category)))
      .returning();
    return NextResponse.json(updated);
  }
  const [row] = await db.insert(budgets).values({ month, category, limitAmount }).returning();
  return NextResponse.json(row);
}

export async function DELETE(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = Number(searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "id لازم است" }, { status: 400 });
  await db.delete(budgets).where(eq(budgets.id, id));
  return NextResponse.json({ ok: true });
}
