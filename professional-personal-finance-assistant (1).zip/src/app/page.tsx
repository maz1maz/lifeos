"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  Legend,
} from "recharts";
import {
  faNum,
  faMoney,
  faMoneyCompact,
  monthKeyToFa,
  CATEGORIES,
  CATEGORY_COLORS,
  CATEGORY_ICONS,
} from "@/lib/format";

type Account = { id: number; name: string; bank: string; type: string; initialBalance: number; balance: number };
type Tx = { id: number; title: string; amount: number; kind: string; category: string; accountId: number | null; tags: string; date: string; note: string };
type Budget = { id: number; month: string; category: string; limitAmount: number; spent?: number };
type Transfer = { id: number; fromAccountId: number; toAccountId: number; amount: number; date: string; description: string };
type Debt = { id: number; person: string; title: string; amount: number; kind: string; description: string; isSettled: boolean };
type Holding = { symbol: string; name: string; kind: string; qty: number; cost: number; buys: number; sells: number };
type Investment = { id: number; symbol: string; name: string; kind: string; side: string; quantity: string; unitPrice: number; fee: number; date: string; note: string };
type Stats = {
  income: number; expense: number; balance: number; savingsRate: number;
  topCats: { name: string; value: number }[];
  trend: { month: string; income: number; expense: number; balance: number }[];
  daily: { day: string; expense: number; income: number }[];
  count: number; insights: string[];
};

const PIE_COLORS = ["#22d3ee", "#a78bfa", "#fbbf24", "#34d399", "#f472b6", "#60a5fa", "#fb7185", "#4ade80"];

function shiftMonth(key: string, delta: number) {
  const [y, m] = key.split("-").map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

/* ---------- small UI atoms ---------- */
function Card({ title, sub, children, className = "" }: { title: string; sub?: string; children: React.ReactNode; className?: string }) {
  return (
    <section className={`glass rounded-2xl p-5 ${className}`}>
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <h2 className="text-lg font-extrabold text-white">{title}</h2>
          {sub && <p className="mt-1 text-[11px] leading-5 text-cyan-200/70">{sub}</p>}
        </div>
        <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-cyan-400 shadow-[0_0_12px_2px_rgba(34,211,238,.8)]" />
      </div>
      {children}
    </section>
  );
}

function Kpi({ label, value, sub, tone = "cyan", icon }: { label: string; value: string; sub?: string; tone?: "cyan" | "green" | "rose" | "amber"; icon: string }) {
  const tones: Record<string, string> = {
    cyan: "from-cyan-400/20 to-cyan-400/5 text-cyan-200 border-cyan-300/30",
    green: "from-emerald-400/20 to-emerald-400/5 text-emerald-200 border-emerald-300/30",
    rose: "from-rose-400/20 to-rose-400/5 text-rose-200 border-rose-300/30",
    amber: "from-amber-400/20 to-amber-400/5 text-amber-200 border-amber-300/30",
  };
  return (
    <div className={`glass rounded-2xl border p-4 bg-gradient-to-b ${tones[tone]}`}>
      <div className="flex items-center justify-between">
        <span className="text-2xl">{icon}</span>
        <span className="text-[11px] font-bold opacity-80">{label}</span>
      </div>
      <div className="mt-2 text-left text-lg font-black tracking-tight text-white" dir="ltr">{value}</div>
      {sub && <div className="mt-1 text-left text-[11px] opacity-70" dir="ltr">{sub}</div>}
    </div>
  );
}

function ChartTip({ active, payload, label, money = true }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-xl border border-cyan-300/30 bg-[#071022]/95 px-3 py-2 text-xs shadow-xl" dir="rtl">
      <div className="mb-1 font-bold text-white">{label}</div>
      {payload.map((p: any, i: number) => (
        <div key={i} className="flex items-center justify-between gap-4 py-0.5">
          <span style={{ color: p.color || p.payload?.fill }}>{p.name}</span>
          <span className="font-bold text-white" dir="ltr">{money ? faNum(p.value) : faNum(p.value)}</span>
        </div>
      ))}
    </div>
  );
}

/* ================= MAIN ================= */
export default function FinancePage() {
  const [month, setMonth] = useState("2026-09");
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [txs, setTxs] = useState<Tx[]>([]);
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [spentByCat, setSpentByCat] = useState<Record<string, number>>({});
  const [totalSpent, setTotalSpent] = useState(0);
  const [transfers, setTransfers] = useState<Transfer[]>([]);
  const [debts, setDebts] = useState<Debt[]>([]);
  const [investments, setInvestments] = useState<Investment[]>([]);
  const [holdings, setHoldings] = useState<Holding[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [seeding, setSeeding] = useState(false);
  const [activeTab, setActiveTab] = useState("داشبورد");

  // forms
  const [txForm, setTxForm] = useState({ title: "", amount: "", kind: "expense", category: "خوراک", accountId: "", tags: "", date: "2026-09-24", note: "" });
  const [accForm, setAccForm] = useState({ name: "", bank: "بلو", type: "بانک", initialBalance: "" });
  const [trForm, setTrForm] = useState({ from: "", to: "", amount: "", date: "2026-09-24", description: "" });
  const [budgetForm, setBudgetForm] = useState({ category: "__total__", limitAmount: "" });
  const [debtForm, setDebtForm] = useState({ person: "", amount: "", kind: "receivable", description: "" });
  const [invForm, setInvForm] = useState({ symbol: "", name: "", kind: "crypto", side: "buy", quantity: "", unitPrice: "", fee: "", date: "2026-09-24", note: "" });
  const [importPreview, setImportPreview] = useState<{ title: string; amount: number; date: string }[]>([]);
  const [importing, setImporting] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [a, t, b, tr, d, iv, s] = await Promise.all([
        fetch("/api/accounts").then((r) => r.json()),
        fetch(`/api/transactions?month=${month}&limit=400`).then((r) => r.json()),
        fetch(`/api/budgets?month=${month}`).then((r) => r.json()),
        fetch("/api/transfers").then((r) => r.json()),
        fetch("/api/debts").then((r) => r.json()),
        fetch("/api/investments").then((r) => r.json()),
        fetch(`/api/stats?month=${month}`).then((r) => r.json()),
      ]);
      setAccounts(Array.isArray(a) ? a : []);
      setTxs(t.items ?? []);
      setBudgets(b.items ?? []);
      setSpentByCat(b.spentByCat ?? {});
      setTotalSpent(b.totalSpent ?? 0);
      setTransfers(Array.isArray(tr) ? tr : []);
      setDebts(Array.isArray(d) ? d : []);
      setInvestments(iv.items ?? []);
      setHoldings(iv.holdings ?? []);
      setStats(s);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [month]);

  useEffect(() => {
    load();
  }, [load]);

  const accMap = useMemo(() => Object.fromEntries(accounts.map((a) => [a.id, a])), [accounts]);
  const netWorth = useMemo(() => accounts.reduce((s, a) => s + (a.balance ?? 0), 0), [accounts]);
  const receivable = useMemo(() => debts.filter((d) => d.kind !== "payable" && !d.isSettled).reduce((s, d) => s + d.amount, 0), [debts]);
  const payable = useMemo(() => debts.filter((d) => d.kind === "payable" && !d.isSettled).reduce((s, d) => s + d.amount, 0), [debts]);

  const filteredTxs = useMemo(() => {
    let list = txs;
    if (filter !== "all") list = list.filter((t) => t.kind === filter);
    if (search.trim()) {
      const q = search.trim();
      list = list.filter((t) => t.title.includes(q) || t.category.includes(q) || (t.note ?? "").includes(q));
    }
    return list;
  }, [txs, filter, search]);

  const budgetRows = useMemo(() => {
    const cats = budgets.filter((b) => b.category !== "__total__");
    const total = budgets.find((b) => b.category === "__total__");
    return { cats, total };
  }, [budgets]);

  const budgetChart = useMemo(() => {
    return budgetRows.cats.slice(0, 6).map((b) => ({
      name: b.category,
      بودجه: b.limitAmount,
      هزینه: b.spent ?? spentByCat[b.category] ?? 0,
    }));
  }, [budgetRows, spentByCat]);

  const pieData = useMemo(() => (stats?.topCats ?? []).map((c) => ({ ...c })), [stats]);

  async function seed() {
    setSeeding(true);
    await fetch("/api/seed", { method: "POST" });
    await load();
    setSeeding(false);
  }

  async function submitTx(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch("/api/transactions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: txForm.title,
        amount: Number(txForm.amount),
        kind: txForm.kind,
        category: txForm.kind === "transfer" ? "انتقال" : txForm.category,
        accountId: txForm.accountId ? Number(txForm.accountId) : null,
        tags: txForm.tags,
        date: txForm.date,
        note: txForm.note,
      }),
    });
    if (res.ok) {
      setTxForm({ title: "", amount: "", kind: "expense", category: "خوراک", accountId: "", tags: "", date: txForm.date, note: "" });
      load();
    } else {
      const j = await res.json();
      alert(j.error ?? "خطا");
    }
  }

  async function submitAccount(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch("/api/accounts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: accForm.name, bank: accForm.bank, type: accForm.type, initialBalance: Number(accForm.initialBalance || 0) }),
    });
    if (res.ok) {
      setAccForm({ name: "", bank: "بلو", type: "بانک", initialBalance: "" });
      load();
    } else alert("خطا در ثبت حساب");
  }

  async function submitTransfer(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch("/api/transfers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fromAccountId: Number(trForm.from), toAccountId: Number(trForm.to), amount: Number(trForm.amount), date: trForm.date, description: trForm.description }),
    });
    if (res.ok) {
      setTrForm({ from: "", to: "", amount: "", date: trForm.date, description: "" });
      load();
    } else {
      const j = await res.json();
      alert(j.error ?? "خطا");
    }
  }

  async function submitBudget(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch("/api/budgets", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ month, category: budgetForm.category, limitAmount: Number(budgetForm.limitAmount) }),
    });
    if (res.ok) {
      setBudgetForm({ category: "__total__", limitAmount: "" });
      load();
    } else alert("خطا");
  }

  async function submitDebt(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch("/api/debts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ person: debtForm.person, title: debtForm.kind === "payable" ? `بدهی به ${debtForm.person}` : `طلب از ${debtForm.person}`, amount: Number(debtForm.amount), kind: debtForm.kind, description: debtForm.description }),
    });
    if (res.ok) {
      setDebtForm({ person: "", amount: "", kind: "receivable", description: "" });
      load();
    } else alert("خطا");
  }

  async function submitInv(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch("/api/investments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        symbol: invForm.symbol,
        name: invForm.name || invForm.symbol,
        kind: invForm.kind,
        side: invForm.side,
        quantity: Number(invForm.quantity),
        unitPrice: Number(invForm.unitPrice),
        fee: Number(invForm.fee || 0),
        date: invForm.date,
        note: invForm.note,
      }),
    });
    if (res.ok) {
      setInvForm({ symbol: "", name: "", kind: "crypto", side: "buy", quantity: "", unitPrice: "", fee: "", date: invForm.date, note: "" });
      load();
    } else {
      const j = await res.json();
      alert(j.error ?? "خطا");
    }
  }

  async function handleFile(file: File) {
    setImporting(true);
    const text = await file.text();
    // simple CSV parse (support , ; and header fa/en)
    const lines = text.split(/\r?\n/).filter((l) => l.trim());
    if (!lines.length) { setImporting(false); return; }
    const delim = lines[0].includes(";") ? ";" : ",";
    const headers = lines[0].split(delim).map((h) => h.trim().replace(/^"|"$/g, ""));
    const rows = lines.slice(1).map((ln) => {
      const cells = ln.split(delim).map((c) => c.trim().replace(/^"|"$/g, ""));
      const o: Record<string, string> = {};
      headers.forEach((h, i) => (o[h] = cells[i] ?? ""));
      // fallback positional
      if (!o["شرح"] && !o["title"]) { o["شرح"] = cells[0] ?? ""; o["مبلغ"] = cells[1] ?? ""; o["تاریخ"] = cells[2] ?? ""; }
      return o;
    });
    const res = await fetch("/api/import", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ rows, previewOnly: true }),
    });
    const j = await res.json();
    setImportPreview(j.preview ?? []);
    // store raw for confirm
    (window as any).__importRows = rows;
    setImporting(false);
  }

  async function confirmImport() {
    const rows = (window as any).__importRows ?? [];
    if (!rows.length) return;
    setImporting(true);
    await fetch("/api/import", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ rows, accountId: accounts[0]?.id ?? null }),
    });
    setImportPreview([]);
    (window as any).__importRows = [];
    setImporting(false);
    load();
  }

  const income = stats?.income ?? 0;
  const expense = stats?.expense ?? 0;
  const balance = stats?.balance ?? 0;

  return (
    <div className="mx-auto max-w-[1400px] px-3 pb-16 pt-5 sm:px-6">
      {/* top nav */}
      <div className="glass mb-4 flex flex-wrap items-center justify-between gap-3 rounded-2xl px-5 py-3">
        <div className="flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-b from-cyan-300 to-cyan-600 text-2xl shadow-lg">💠</div>
          <div>
            <div className="text-[10px] font-bold tracking-widest text-cyan-300">نمای ماهانه • داده واقعی</div>
            <h1 className="text-2xl font-black text-white">دستیار مالی شخصی</h1>
            <p className="text-[11px] text-slate-400">حسابداری حرفه‌ای • بودجه • سبد سرمایه • بدهی و طلب</p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {["داشبورد", "تراکنش‌ها", "بودجه و حساب‌ها", "بدهی و سرمایه"].map((t) => (
            <button key={t} onClick={() => setActiveTab(t)} className={`btn-ghost ${activeTab === t ? "active" : ""}`}>{t}</button>
          ))}
          <button onClick={seed} disabled={seeding} className="btn-ghost">✨ {seeding ? "در حال ساخت..." : "ساخت داده نمونه"}</button>
        </div>
      </div>

      {/* month + kpi header */}
      <div className="glass rounded-2xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <button onClick={() => setMonth(shiftMonth(month, -1))} className="btn-ghost">ماه قبل ◀</button>
            <input type="month" value={month} onChange={(e) => e.target.value && setMonth(e.target.value)} className="input-dark !w-auto text-center font-bold" />
            <button onClick={() => setMonth(shiftMonth(month, 1))} className="btn-ghost">▶ ماه بعد</button>
            <span className="mr-2 hidden text-sm font-bold text-cyan-200 sm:inline">{monthKeyToFa(month)} • بودجه {budgetRows.total ? faMoney(budgetRows.total.limitAmount) : "—"}</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-300">
            <span className="chip border-cyan-300/30 bg-cyan-400/10 text-cyan-200">دارایی کل: {faMoneyCompact(netWorth)}</span>
            <span className="chip border-emerald-300/30 bg-emerald-400/10 text-emerald-200">طلب: {faMoneyCompact(receivable)}</span>
            <span className="chip border-rose-300/30 bg-rose-400/10 text-rose-200">بدهی: {faMoneyCompact(payable)}</span>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
          <Kpi label="درآمد ماه" value={faNum(income)} sub="ریال • IRR" tone="green" icon="💰" />
          <Kpi label="هزینه ماه" value={faNum(expense)} sub="ریال • IRR" tone="rose" icon="💸" />
          <Kpi label="مانده ماه" value={faNum(balance)} sub={balance >= 0 ? "مثبت • پس‌انداز" : "منفی • کسری"} tone={balance >= 0 ? "cyan" : "amber"} icon="⚖️" />
          <div className="glass-soft rounded-2xl border border-cyan-200/20 p-4">
            <div className="flex items-center justify-between text-[11px] font-bold text-cyan-200"><span>📊 نرخ پس‌انداز</span><span dir="ltr">{faNum(stats?.savingsRate ?? 0)}٪</span></div>
            <div className="mt-3 h-3 overflow-hidden rounded-full bg-slate-800">
              <div className="h-full rounded-full bg-gradient-to-l from-cyan-300 via-emerald-300 to-cyan-500 transition-all" style={{ width: `${Math.max(0, Math.min(100, stats?.savingsRate ?? 0))}%` }} />
            </div>
            <div className="mt-2 text-[11px] text-slate-400">{faNum(stats?.count ?? 0)} تراکنش در {monthKeyToFa(month)}</div>
          </div>
        </div>

        {/* top cats */}
        <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
          {(stats?.topCats ?? []).slice(0, 5).map((c) => (
            <div key={c.name} className="glass-soft rounded-xl border border-white/10 p-3 text-center">
              <div className="text-sm font-extrabold text-white">{CATEGORY_ICONS[c.name] ?? "•"} {c.name}</div>
              <div className="mt-1 text-[11px] text-cyan-200">{faMoney(c.value)}</div>
              <div className="mx-auto mt-2 h-1.5 w-3/4 overflow-hidden rounded-full bg-slate-800">
                <div className="h-full rounded-full" style={{ width: `${Math.min(100, Math.round((c.value / (expense || 1)) * 100))}%`, background: CATEGORY_COLORS[c.name] ?? "#22d3ee" }} />
              </div>
            </div>
          ))}
          {(!stats?.topCats?.length) && <div className="col-span-full py-2 text-center text-xs text-slate-400">هنوز هزینه‌ای برای این ماه ثبت نشده — از فرم «تراکنش تازه» شروع کنید.</div>}
        </div>
      </div>

      {/* charts */}
      {(activeTab === "داشبورد" || activeTab === "تراکنش‌ها") && (
        <div className="mt-4 grid grid-cols-1 gap-4 xl:grid-cols-3">
          <Card title="روند ۶ ماهه درآمد و هزینه" sub="مقایسه ورود و خروج پول • اعداد به ریال" className="xl:col-span-2">
            <div className="h-[280px]" dir="ltr">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={(stats?.trend ?? []).map((t) => ({ ...t, ماه: t.month.slice(5) }))}>
                  <defs>
                    <linearGradient id="gInc" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#34d399" stopOpacity={0.5} /><stop offset="100%" stopColor="#34d399" stopOpacity={0} /></linearGradient>
                    <linearGradient id="gExp" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#fb7185" stopOpacity={0.5} /><stop offset="100%" stopColor="#fb7185" stopOpacity={0} /></linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,.15)" />
                  <XAxis dataKey="ماه" tick={{ fill: "#94a3b8", fontSize: 11 }} />
                  <YAxis tickFormatter={(v: number) => v >= 1e9 ? `${(v / 1e9).toFixed(0)}B` : v >= 1e6 ? `${(v / 1e6).toFixed(0)}M` : `${v / 1e3}K`} tick={{ fill: "#94a3b8", fontSize: 10 }} width={48} />
                  <Tooltip content={<ChartTip />} />
                  <Legend wrapperStyle={{ color: "#cbd5e1", fontSize: 12 }} />
                  <Area type="monotone" dataKey="income" name="درآمد" stroke="#34d399" fill="url(#gInc)" strokeWidth={2.5} />
                  <Area type="monotone" dataKey="expense" name="هزینه" stroke="#fb7185" fill="url(#gExp)" strokeWidth={2.5} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card title="ترکیب هزینه‌ها" sub="سهم هر دسته از کل هزینه ماه">
            <div className="h-[280px]" dir="ltr">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={pieData as any[]} dataKey="value" nameKey="name" innerRadius={58} outerRadius={95} paddingAngle={3} strokeWidth={0}>
                    {(pieData as any[]).map((_, i) => (
                      <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip content={<ChartTip />} />
                  <Legend layout="vertical" align="right" verticalAlign="middle" wrapperStyle={{ color: "#e2e8f0", fontSize: 11 }} formatter={(v: string) => v} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-2 space-y-1.5">
              {pieData.slice(0, 4).map((c, i) => (
                <div key={c.name} className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-2 text-slate-200"><span className="h-2.5 w-2.5 rounded-full" style={{ background: PIE_COLORS[i % PIE_COLORS.length] }} />{c.name}</span>
                  <span className="font-bold text-white">{faNum(Math.round((c.value / (expense || 1)) * 100))}٪</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}

      {(activeTab === "داشبورد") && (
        <div className="mt-4 grid grid-cols-1 gap-4 xl:grid-cols-3">
          <Card title="هزینه روزانه ماه" sub="الگوی خرج روزانه — روزهای اوج را پیدا کنید" className="xl:col-span-2">
            <div className="h-[220px]" dir="ltr">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats?.daily ?? []}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,.12)" />
                  <XAxis dataKey="day" tick={{ fill: "#94a3b8", fontSize: 9 }} interval={2} />
                  <YAxis tick={{ fill: "#94a3b8", fontSize: 10 }} width={44} tickFormatter={(v: number) => v >= 1e6 ? `${Math.round(v / 1e6)}M` : `${Math.round(v / 1e3)}K`} />
                  <Tooltip content={<ChartTip />} cursor={{ fill: "rgba(34,211,238,.08)" }} />
                  <Bar dataKey="expense" name="هزینه" fill="#22d3ee" radius={[6, 6, 0, 0]} />
                  <Bar dataKey="income" name="درآمد" fill="#34d399" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
          <Card title="تحلیل هوشمند مالی" sub="پیشنهادهای خودکار بر اساس رفتار خرج شما">
            <ul className="space-y-2.5">
              {(stats?.insights ?? []).map((ins, i) => (
                <li key={i} className="anim-in flex gap-2 rounded-xl border border-cyan-200/15 bg-cyan-400/5 p-3 text-[12px] leading-6 text-cyan-50" style={{ animationDelay: `${i * 80}ms` }}>
                  <span className="mt-0.5 text-base">{["💡", "🎯", "⚠️", "📈", "✨"][i % 5]}</span>
                  <span>{ins}</span>
                </li>
              ))}
            </ul>
            <div className="mt-3 rounded-xl border border-amber-200/20 bg-amber-400/10 p-3 text-[11px] leading-5 text-amber-100">
              💎 دارایی خالص شما (موجودی حساب‌ها + طلب − بدهی): <b dir="ltr">{faNum(netWorth + receivable - payable)}</b> ریال
            </div>
          </Card>
        </div>
      )}

      {/* main grid */}
      <div className="mt-4 grid grid-cols-1 gap-4 xl:grid-cols-3">
        {/* tx form + list */}
        <div className="space-y-4 xl:col-span-2">
          <Card title="تراکنش‌های ماه" sub={`${faNum(filteredTxs.length)} ردیف • ${monthKeyToFa(month)} — برای حذف روی ✕ بزنید`}>
            <form onSubmit={submitTx} className="glass-soft mb-4 rounded-xl border border-cyan-200/15 p-4">
              <div className="mb-3 flex items-center justify-between">
                <h3 className="font-extrabold text-white">➕ تراکنش تازه</h3>
                <div className="flex gap-1.5">
                  {[["expense", "هزینه"], ["income", "درآمد"], ["transfer", "انتقال"]].map(([v, l]) => (
                    <button type="button" key={v} onClick={() => setTxForm({ ...txForm, kind: v })} className={`btn-ghost ${txForm.kind === v ? "active" : ""}`}>{l}</button>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                <input className="input-dark" placeholder="شرح — مثل خرید از فروشگاه" value={txForm.title} onChange={(e) => setTxForm({ ...txForm, title: e.target.value })} required />
                <input className="input-dark" placeholder="مبلغ (ریال)" type="number" min={1} value={txForm.amount} onChange={(e) => setTxForm({ ...txForm, amount: e.target.value })} required />
                <div className="flex gap-2">
                  <select className="input-dark" value={txForm.category} onChange={(e) => setTxForm({ ...txForm, category: e.target.value })}>
                    {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <select className="input-dark" value={txForm.accountId} onChange={(e) => setTxForm({ ...txForm, accountId: e.target.value })}>
                  <option value="">بدون حساب</option>
                  {accounts.map((a) => <option key={a.id} value={a.id}>{a.name} — {a.bank}</option>)}
                </select>
                <input className="input-dark" placeholder="تگ‌ها، با ویرگول جدا" value={txForm.tags} onChange={(e) => setTxForm({ ...txForm, tags: e.target.value })} />
                <input className="input-dark" type="date" value={txForm.date} onChange={(e) => setTxForm({ ...txForm, date: e.target.value })} />
              </div>
              <input className="input-dark mt-2" placeholder="یادداشت (اختیاری)" value={txForm.note} onChange={(e) => setTxForm({ ...txForm, note: e.target.value })} />
              <button className="btn-cyan mt-3">ثبت تراکنش ✅</button>
            </form>

            <div className="mb-3 flex flex-wrap items-center gap-2">
              {[["all", "همه"], ["expense", "هزینه"], ["income", "درآمد"], ["transfer", "انتقال"]].map(([v, l]) => (
                <button key={v} onClick={() => setFilter(v)} className={`btn-ghost ${filter === v ? "active" : ""}`}>{l}</button>
              ))}
              <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="🔍 جستجو در شرح و دسته..." className="input-dark !w-auto flex-1" />
            </div>

            <div className="overflow-hidden rounded-xl border border-white/10">
              <div className="table-head grid grid-cols-[1fr_90px_70px_36px] gap-2 px-3 py-2 text-[11px] font-bold text-cyan-100 sm:grid-cols-[1fr_110px_90px_90px_60px]">
                <span>شرح</span><span className="hidden sm:inline">دسته</span><span className="hidden sm:inline">حساب</span><span>مبلغ</span><span>عملیات</span>
              </div>
              <div className="max-h-[480px] divide-y divide-white/5 overflow-y-auto bg-black/20">
                {filteredTxs.map((t) => (
                  <div key={t.id} className="grid grid-cols-[1fr_90px_70px_36px] items-center gap-2 px-3 py-2.5 text-xs hover:bg-cyan-400/5 sm:grid-cols-[1fr_110px_90px_90px_60px]">
                    <div>
                      <div className="font-bold text-white">{t.title}</div>
                      <div className="mt-0.5 text-[10px] text-slate-400">{t.date} {t.note ? `• ${t.note}` : ""} {t.tags ? `• #${t.tags}` : ""}</div>
                      <div className="mt-1 sm:hidden"><span className="chip bg-white/5 text-slate-300">{t.category}</span> <span className="text-[10px] text-slate-400">{t.accountId ? accMap[t.accountId]?.name ?? "" : "بدون حساب"}</span></div>
                    </div>
                    <span className="hidden sm:inline"><span className="chip bg-white/5 text-slate-200">{CATEGORY_ICONS[t.category] ?? ""} {t.category}</span></span>
                    <span className="hidden text-[11px] text-slate-300 sm:inline">{t.accountId ? accMap[t.accountId]?.name ?? "—" : "بدون حساب"}</span>
                    <span dir="ltr" className={`font-black ${t.kind === "income" ? "text-emerald-300" : t.kind === "expense" ? "text-rose-300" : "text-cyan-300"}`}>{t.kind === "income" ? "+" : "−"}{faNum(t.amount)}</span>
                    <span className="flex items-center gap-1">
                      <span className={`chip ${t.kind === "income" ? "bg-emerald-400/15 text-emerald-200" : "bg-cyan-400/15 text-cyan-200"}`}>{t.kind === "income" ? "دریافت" : t.kind === "expense" ? "پرداخت" : "انتقال"}</span>
                      <button onClick={async () => { if (confirm("حذف شود؟")) { await fetch(`/api/transactions?id=${t.id}`, { method: "DELETE" }); load(); } }} className="text-rose-400 hover:text-rose-200">✕</button>
                    </span>
                  </div>
                ))}
                {!filteredTxs.length && <div className="p-8 text-center text-xs text-slate-400">تراکنشی نیست. {loading ? "در حال بارگذاری..." : "ثبت کنید یا داده نمونه بسازید."}</div>}
              </div>
            </div>
          </Card>

          {(activeTab === "داشبورد" || activeTab === "بودجه و حساب‌ها") && (
            <Card title={`بودجه ${month}`} sub={budgetRows.total ? `${faNum(totalSpent)} از ${faNum(budgetRows.total.limitAmount)} ریال مصرف شده` : "سقف کلی و سقف هر دسته را تعیین کنید"}>
              {budgetRows.total && (
                <div className="mb-3">
                  <div className="flex justify-between text-xs font-bold text-white"><span>پیشرفت بودجه کل</span><span dir="ltr">{faNum(Math.round((totalSpent / (budgetRows.total.limitAmount || 1)) * 100))}٪</span></div>
                  <div className="mt-2 h-3 overflow-hidden rounded-full bg-slate-800">
                    <div className={`h-full rounded-full transition-all ${totalSpent > budgetRows.total.limitAmount ? "bg-gradient-to-l from-rose-400 to-red-500" : "bg-gradient-to-l from-cyan-300 to-emerald-400"}`} style={{ width: `${Math.min(100, (totalSpent / (budgetRows.total.limitAmount || 1)) * 100)}%` }} />
                  </div>
                </div>
              )}
              <div className="h-[210px]" dir="ltr">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={budgetChart} layout="vertical" margin={{ left: 10, right: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,.12)" horizontal={false} />
                    <XAxis type="number" hide />
                    <YAxis type="category" dataKey="name" tick={{ fill: "#e2e8f0", fontSize: 11 }} width={70} />
                    <Tooltip content={<ChartTip />} cursor={{ fill: "rgba(34,211,238,.08)" }} />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                    <Bar dataKey="بودجه" fill="#1e3a5f" radius={[0, 8, 8, 0]} />
                    <Bar dataKey="هزینه" fill="#22d3ee" radius={[0, 8, 8, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <form onSubmit={submitBudget} className="glass-soft mt-3 grid grid-cols-1 gap-2 rounded-xl border border-cyan-200/15 p-3 sm:grid-cols-[1fr_1fr_auto]">
                <select className="input-dark" value={budgetForm.category} onChange={(e) => setBudgetForm({ ...budgetForm, category: e.target.value })}>
                  <option value="__total__">کل ماه (total)</option>
                  {CATEGORIES.map((c) => <option key={c} value={c}>دسته {c}</option>)}
                </select>
                <input className="input-dark" placeholder="سقف بودجه، ریال" type="number" value={budgetForm.limitAmount} onChange={(e) => setBudgetForm({ ...budgetForm, limitAmount: e.target.value })} required />
                <button className="btn-cyan !w-auto px-6">ذخیره بودجه</button>
              </form>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {budgets.map((b) => (
                  <span key={b.id} className="chip border-white/10 bg-white/5 text-slate-200">{b.category === "__total__" ? "کل" : b.category}: {faMoneyCompact(b.limitAmount)} • مصرف {faMoneyCompact(b.spent ?? 0)}
                    <button onClick={async () => { await fetch(`/api/budgets?id=${b.id}`, { method: "DELETE" }); load(); }} className="text-rose-300"> ✕</button>
                  </span>
                ))}
              </div>
            </Card>
          )}
        </div>

        {/* side */}
        <div className="space-y-4">
          <Card title="حساب‌ها" sub={`موجودی کل ${faMoney(netWorth)}`}>
            <div className="space-y-2">
              {accounts.map((a) => (
                <div key={a.id} className="glass-soft rounded-xl border border-cyan-200/15 p-3">
                  <div className="flex items-center justify-between">
                    <b className="text-sm text-white">🏦 {a.name}</b>
                    <button onClick={async () => { if (confirm("حساب حذف شود؟")) { await fetch(`/api/accounts?id=${a.id}`, { method: "DELETE" }); load(); } }} className="text-[11px] text-rose-300 hover:text-rose-100">حذف</button>
                  </div>
                  <div className="mt-1 text-[11px] text-slate-400">{a.bank} • {a.type} • bank {faNum(a.balance)} ریال</div>
                  <div className="mt-1 text-left text-sm font-black text-cyan-200" dir="ltr">{faNum(a.balance)}</div>
                </div>
              ))}
              {!accounts.length && <div className="text-center text-xs text-slate-400">حسابی نیست — پایین بسازید.</div>}
            </div>
            <form onSubmit={submitAccount} className="glass-soft mt-3 space-y-2 rounded-xl border border-cyan-200/15 p-3">
              <input className="input-dark" placeholder="نام حساب" value={accForm.name} onChange={(e) => setAccForm({ ...accForm, name: e.target.value })} required />
              <div className="grid grid-cols-2 gap-2">
                <select className="input-dark" value={accForm.bank} onChange={(e) => setAccForm({ ...accForm, bank: e.target.value })}>
                  {["بلو", "ملی", "ملت", "صادرات", "سامان", "نقدی", "ارز دیجیتال", "سایر"].map((b) => <option key={b}>{b}</option>)}
                </select>
                <input className="input-dark" placeholder="مانده اولیه" type="number" value={accForm.initialBalance} onChange={(e) => setAccForm({ ...accForm, initialBalance: e.target.value })} />
              </div>
              <button className="btn-cyan">افزودن حساب ➕</button>
            </form>

            <form onSubmit={submitTransfer} className="glass-soft mt-3 space-y-2 rounded-xl border border-cyan-200/15 p-3">
              <h3 className="text-sm font-extrabold text-white">🔄 انتقال بین حساب‌ها</h3>
              <input className="input-dark" placeholder="شرح انتقال" value={trForm.description} onChange={(e) => setTrForm({ ...trForm, description: e.target.value })} />
              <div className="grid grid-cols-2 gap-2">
                <select className="input-dark" value={trForm.from} onChange={(e) => setTrForm({ ...trForm, from: e.target.value })} required>
                  <option value="">از حساب</option>
                  {accounts.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
                </select>
                <select className="input-dark" value={trForm.to} onChange={(e) => setTrForm({ ...trForm, to: e.target.value })} required>
                  <option value="">به حساب</option>
                  {accounts.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <input className="input-dark" placeholder="مبلغ" type="number" value={trForm.amount} onChange={(e) => setTrForm({ ...trForm, amount: e.target.value })} required />
                <input className="input-dark" type="date" value={trForm.date} onChange={(e) => setTrForm({ ...trForm, date: e.target.value })} />
              </div>
              <button className="btn-cyan">ثبت انتقال</button>
              {transfers.slice(0, 3).map((t) => (
                <div key={t.id} className="flex items-center justify-between text-[11px] text-slate-300">
                  <span>{t.date} • {accMap[t.fromAccountId]?.name} ← {accMap[t.toAccountId]?.name}</span>
                  <span className="flex items-center gap-2"><b dir="ltr">{faNum(t.amount)}</b>
                    <button type="button" onClick={async () => { await fetch(`/api/transfers?id=${t.id}`, { method: "DELETE" }); load(); }} className="text-rose-300">✕</button>
                  </span>
                </div>
              ))}
            </form>
          </Card>

          <Card title="بدهی و طلب" sub={`${faNum(debts.filter((d) => !d.isSettled).length)} پرونده باز • طلب ${faMoneyCompact(receivable)} • بدهی ${faMoneyCompact(payable)}`}>
            <form onSubmit={submitDebt} className="glass-soft mb-3 grid grid-cols-2 gap-2 rounded-xl border border-cyan-200/15 p-3">
              <input className="input-dark col-span-1" placeholder="نام طرف — علیرضا" value={debtForm.person} onChange={(e) => setDebtForm({ ...debtForm, person: e.target.value })} required />
              <input className="input-dark" placeholder="مبلغ (ریال)" type="number" value={debtForm.amount} onChange={(e) => setDebtForm({ ...debtForm, amount: e.target.value })} required />
              <select className="input-dark" value={debtForm.kind} onChange={(e) => setDebtForm({ ...debtForm, kind: e.target.value })}>
                <option value="receivable">طلب (من طلبکارم)</option>
                <option value="payable">بدهی (من بدهکارم)</option>
              </select>
              <input className="input-dark" placeholder="بابت — هاست سایت" value={debtForm.description} onChange={(e) => setDebtForm({ ...debtForm, description: e.target.value })} />
              <button className="btn-cyan col-span-2">ثبت بدهی / طلب</button>
            </form>
            <div className="max-h-[380px] space-y-2 overflow-y-auto">
              {debts.map((d) => (
                <div key={d.id} className={`rounded-xl border p-3 ${d.isSettled ? "border-emerald-300/20 bg-emerald-400/5 opacity-70" : "glass-soft border-white/10"}`}>
                  <div className="flex items-center justify-between gap-2">
                    <b className="text-[13px] text-white">{d.kind === "payable" ? `بدهی به ${d.person}` : d.title}</b>
                    <span className="text-[11px] font-bold text-cyan-200" dir="ltr">{faNum(d.amount)} ریال</span>
                  </div>
                  {d.description && <div className="mt-1 text-[11px] text-slate-400">{d.description}</div>}
                  <div className="mt-2 flex gap-2">
                    {!d.isSettled ? (
                      <button onClick={async () => { await fetch("/api/debts", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: d.id, action: "settle" }) }); load(); }} className="btn-ghost flex-1">✅ تسویه</button>
                    ) : (
                      <button onClick={async () => { await fetch("/api/debts", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: d.id, action: "unsettled" }) }); load(); }} className="btn-ghost flex-1">↩ برگشت</button>
                    )}
                    <button onClick={async () => { if (confirm("حذف شود؟")) { await fetch(`/api/debts?id=${d.id}`, { method: "DELETE" }); load(); } }} className="btn-ghost">✕</button>
                  </div>
                </div>
              ))}
              {!debts.length && <div className="text-center text-xs text-slate-400">موردی نیست.</div>}
            </div>
          </Card>

          <Card title="سبد سرمایه" sub="ارزش گزارش‌شده بر اساس آخرین خرید">
            {holdings.length > 0 ? (
              <div className="overflow-hidden rounded-xl border border-white/10">
                <div className="table-head grid grid-cols-3 px-3 py-2 text-[11px] font-bold text-cyan-100"><span>دارایی</span><span>تعداد</span><span>ارزش</span></div>
                {holdings.map((h) => (
                  <div key={h.symbol} className="grid grid-cols-3 items-center border-t border-white/5 bg-black/20 px-3 py-2 text-xs">
                    <div><b className="text-white">{h.symbol}</b><div className="text-[10px] text-slate-400">{h.name}</div></div>
                    <div dir="ltr" className="font-bold">{faNum(h.qty)}</div>
                    <div dir="ltr" className="text-cyan-200">{h.kind === "fiat" ? `${h.symbol} • ` : ""}{faNum(Math.round(h.qty * (h.qty ? h.cost / h.qty : 0)))}</div>
                  </div>
                ))}
              </div>
            ) : <div className="text-xs text-slate-400">دارایی ندارید — فرم زیر را پر کنید.</div>}
            <form onSubmit={submitInv} className="glass-soft mt-3 space-y-2 rounded-xl border border-cyan-200/15 p-3">
              <div className="grid grid-cols-2 gap-2">
                <select className="input-dark" value={invForm.kind} onChange={(e) => setInvForm({ ...invForm, kind: e.target.value })}>
                  <option value="crypto">رمز ارز</option>
                  <option value="fiat">ارز فیات</option>
                  <option value="stock">سهام</option>
                  <option value="gold">طلا</option>
                  <option value="fund">صندوق</option>
                </select>
                <select className="input-dark" value={invForm.side} onChange={(e) => setInvForm({ ...invForm, side: e.target.value })}>
                  <option value="buy">خرید</option>
                  <option value="sell">فروش</option>
                </select>
              </div>
              <input className="input-dark" placeholder="نماد / نام دارایی — BTC" value={invForm.symbol} onChange={(e) => setInvForm({ ...invForm, symbol: e.target.value })} required />
              <div className="grid grid-cols-2 gap-2">
                <input className="input-dark" placeholder="تعداد" type="number" step="any" value={invForm.quantity} onChange={(e) => setInvForm({ ...invForm, quantity: e.target.value })} required />
                <input className="input-dark" placeholder="قیمت واحد" type="number" value={invForm.unitPrice} onChange={(e) => setInvForm({ ...invForm, unitPrice: e.target.value })} required />
              </div>
              <input className="input-dark" placeholder="کارمزد" type="number" value={invForm.fee} onChange={(e) => setInvForm({ ...invForm, fee: e.target.value })} />
              <input className="input-dark" type="date" value={invForm.date} onChange={(e) => setInvForm({ ...invForm, date: e.target.value })} />
              <input className="input-dark" placeholder="یادداشت" value={invForm.note} onChange={(e) => setInvForm({ ...invForm, note: e.target.value })} />
              <button className="btn-cyan">ثبت سرمایه‌گذاری 📈</button>
            </form>
            <div className="mt-2 space-y-1">
              {investments.slice(0, 5).map((iv) => (
                <div key={iv.id} className="flex items-center justify-between text-[11px] text-slate-300">
                  <span>{iv.side === "buy" ? "🟢 خرید" : "🔴 فروش"} {iv.symbol} • {faNum(Number(iv.quantity))} • {iv.date}</span>
                  <button onClick={async () => { await fetch(`/api/investments?id=${iv.id}`, { method: "DELETE" }); load(); }} className="text-rose-300">✕</button>
                </div>
              ))}
            </div>
          </Card>

          <Card title="درون‌ریزی صورت‌حساب بانکی" sub="فایل CSV ،XLS ،XLSX را انتخاب کنید؛ ابتدا فقط پیش‌نمایش تراکنش‌های تازه دریافت می‌شود.">
            <label className="block cursor-pointer rounded-xl border border-dashed border-cyan-300/40 bg-cyan-400/5 p-4 text-center text-sm text-cyan-100 hover:bg-cyan-400/10">
              📂 انتخاب فایل صورت‌حساب
              <input type="file" accept=".csv,.txt" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }} />
              <div className="mt-1 text-[11px] text-slate-400">ستون‌ها: شرح، مبلغ، تاریخ — با کاما یا سمی‌کالن</div>
            </label>
            {importing && <div className="mt-2 text-center text-xs text-cyan-200">در حال پردازش...</div>}
            {!!importPreview.length && (
              <div className="mt-3 rounded-xl border border-white/10 bg-black/30 p-3">
                <div className="mb-2 text-xs font-bold text-white">پیش‌نمایش {faNum(importPreview.length)} تراکنش تازه:</div>
                {importPreview.slice(0, 8).map((r, i) => (
                  <div key={i} className="flex justify-between py-1 text-[11px] text-slate-300"><span>{r.title}</span><span dir="ltr">{faNum(r.amount)} • {r.date}</span></div>
                ))}
                <button onClick={confirmImport} className="btn-cyan mt-2">تأیید و ورود {faNum(importPreview.length)} تراکنش ✅</button>
                <button onClick={() => setImportPreview([])} className="btn-ghost mt-2 w-full">انصراف</button>
              </div>
            )}
            <div className="mt-3 grid grid-cols-3 gap-2 text-center">
              <div className="glass-soft rounded-xl p-2"><div className="text-[10px] text-slate-400">تراکنش ماه</div><div className="font-black text-white">{faNum(txs.length)}</div></div>
              <div className="glass-soft rounded-xl p-2"><div className="text-[10px] text-slate-400">حساب</div><div className="font-black text-white">{faNum(accounts.length)}</div></div>
              <div className="glass-soft rounded-xl p-2"><div className="text-[10px] text-slate-400">دارایی</div><div className="font-black text-white">{faNum(holdings.length)}</div></div>
            </div>
          </Card>
        </div>
      </div>

      <footer className="mt-8 text-center text-[11px] leading-5 text-slate-500">
        ساخته‌شده با ❤️ برای مدیریت حرفه‌ای پول • {monthKeyToFa(month)} • نرخ پس‌انداز {faNum(stats?.savingsRate ?? 0)}٪ • خالص {faMoneyCompact(netWorth + receivable - payable)}
      </footer>
    </div>
  );
}


