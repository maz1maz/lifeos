import {
  pgTable,
  serial,
  text,
  bigint,
  boolean,
  timestamp,
  date,
  numeric,
  integer,
} from "drizzle-orm/pg-core";

export const accounts = pgTable("accounts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  bank: text("bank").notNull().default("بانک"),
  type: text("type").notNull().default("بانک"),
  initialBalance: bigint("initial_balance", { mode: "number" }).notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  amount: bigint("amount", { mode: "number" }).notNull(),
  kind: text("kind").notNull().default("expense"), // expense | income | transfer
  category: text("category").notNull().default("متفرقه"),
  accountId: integer("account_id").references(() => accounts.id, { onDelete: "set null" }),
  tags: text("tags").default(""),
  date: date("date").notNull(),
  note: text("note").default(""),
  createdAt: timestamp("created_at").defaultNow(),
});

export const budgets = pgTable("budgets", {
  id: serial("id").primaryKey(),
  month: text("month").notNull(), // YYYY-MM
  category: text("category").notNull(),
  limitAmount: bigint("limit_amount", { mode: "number" }).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const transfers = pgTable("transfers", {
  id: serial("id").primaryKey(),
  fromAccountId: integer("from_account_id").references(() => accounts.id, { onDelete: "set null" }),
  toAccountId: integer("to_account_id").references(() => accounts.id, { onDelete: "set null" }),
  amount: bigint("amount", { mode: "number" }).notNull(),
  date: date("date").notNull(),
  description: text("description").default(""),
  createdAt: timestamp("created_at").defaultNow(),
});

export const debts = pgTable("debts", {
  id: serial("id").primaryKey(),
  person: text("person").notNull(),
  title: text("title").notNull(),
  amount: bigint("amount", { mode: "number" }).notNull(),
  kind: text("kind").notNull().default("receivable"), // receivable طلب | payable بدهی
  description: text("description").default(""),
  isSettled: boolean("is_settled").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
  settledAt: timestamp("settled_at"),
});

export const investments = pgTable("investments", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  name: text("name").notNull().default(""),
  kind: text("kind").notNull().default("crypto"), // crypto | stock | fiat | gold | fund
  side: text("side").notNull().default("buy"), // buy | sell
  quantity: numeric("quantity").notNull().default("0"),
  unitPrice: bigint("unit_price", { mode: "number" }).notNull().default(0),
  fee: bigint("fee", { mode: "number" }).notNull().default(0),
  date: date("date").notNull(),
  note: text("note").default(""),
  createdAt: timestamp("created_at").defaultNow(),
});
